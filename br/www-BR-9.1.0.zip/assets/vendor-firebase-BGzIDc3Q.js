var g_=Object.defineProperty;var m_=(s,e,t)=>e in s?g_(s,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):s[e]=t;var H=(s,e,t)=>m_(s,typeof e!="symbol"?e+"":e,t);/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const __=()=>{};var ah={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const FC={NODE_ADMIN:!1,SDK_VERSION:"${JSCORE_VERSION}"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const K=function(s,e){if(!s)throw dr(e)},dr=function(s){return new Error("Firebase Database ("+FC.SDK_VERSION+") INTERNAL ASSERT FAILED: "+s)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const OC=function(s){const e=[];let t=0;for(let n=0;n<s.length;n++){let r=s.charCodeAt(n);r<128?e[t++]=r:r<2048?(e[t++]=r>>6|192,e[t++]=r&63|128):(r&64512)===55296&&n+1<s.length&&(s.charCodeAt(n+1)&64512)===56320?(r=65536+((r&1023)<<10)+(s.charCodeAt(++n)&1023),e[t++]=r>>18|240,e[t++]=r>>12&63|128,e[t++]=r>>6&63|128,e[t++]=r&63|128):(e[t++]=r>>12|224,e[t++]=r>>6&63|128,e[t++]=r&63|128)}return e},E_=function(s){const e=[];let t=0,n=0;for(;t<s.length;){const r=s[t++];if(r<128)e[n++]=String.fromCharCode(r);else if(r>191&&r<224){const i=s[t++];e[n++]=String.fromCharCode((r&31)<<6|i&63)}else if(r>239&&r<365){const i=s[t++],o=s[t++],a=s[t++],l=((r&7)<<18|(i&63)<<12|(o&63)<<6|a&63)-65536;e[n++]=String.fromCharCode(55296+(l>>10)),e[n++]=String.fromCharCode(56320+(l&1023))}else{const i=s[t++],o=s[t++];e[n++]=String.fromCharCode((r&15)<<12|(i&63)<<6|o&63)}}return e.join("")},Nl={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(s,e){if(!Array.isArray(s))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,n=[];for(let r=0;r<s.length;r+=3){const i=s[r],o=r+1<s.length,a=o?s[r+1]:0,l=r+2<s.length,c=l?s[r+2]:0,h=i>>2,f=(i&3)<<4|a>>4;let d=(a&15)<<2|c>>6,_=c&63;l||(_=64,o||(d=64)),n.push(t[h],t[f],t[d],t[_])}return n.join("")},encodeString(s,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(s):this.encodeByteArray(OC(s),e)},decodeString(s,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(s):E_(this.decodeStringToByteArray(s,e))},decodeStringToByteArray(s,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,n=[];for(let r=0;r<s.length;){const i=t[s.charAt(r++)],a=r<s.length?t[s.charAt(r)]:0;++r;const c=r<s.length?t[s.charAt(r)]:64;++r;const f=r<s.length?t[s.charAt(r)]:64;if(++r,i==null||a==null||c==null||f==null)throw new D_;const d=i<<2|a>>4;if(n.push(d),c!==64){const _=a<<4&240|c>>2;if(n.push(_),f!==64){const y=c<<6&192|f;n.push(y)}}}return n},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let s=0;s<this.ENCODED_VALS.length;s++)this.byteToCharMap_[s]=this.ENCODED_VALS.charAt(s),this.charToByteMap_[this.byteToCharMap_[s]]=s,this.byteToCharMapWebSafe_[s]=this.ENCODED_VALS_WEBSAFE.charAt(s),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[s]]=s,s>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(s)]=s,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(s)]=s)}}};class D_ extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const LC=function(s){const e=OC(s);return Nl.encodeByteArray(e,!0)},Ho=function(s){return LC(s).replace(/\./g,"")},jB=function(s){try{return Nl.decodeString(s,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function y_(s){return xC(void 0,s)}function xC(s,e){if(!(e instanceof Object))return e;switch(e.constructor){case Date:const t=e;return new Date(t.getTime());case Object:s===void 0&&(s={});break;case Array:s=[];break;default:return e}for(const t in e)!e.hasOwnProperty(t)||!w_(t)||(s[t]=xC(s[t],e[t]));return s}function w_(s){return s!=="__proto__"}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function T_(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const I_=()=>T_().__FIREBASE_DEFAULTS__,A_=()=>{if(typeof process>"u"||typeof ah>"u")return;const s=ah.__FIREBASE_DEFAULTS__;if(s)return JSON.parse(s)},v_=()=>{if(typeof document>"u")return;let s;try{s=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=s&&jB(s[1]);return e&&JSON.parse(e)},Pl=()=>{try{return __()||I_()||A_()||v_()}catch(s){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${s}`);return}},R_=s=>{var e,t;return(t=(e=Pl())==null?void 0:e.emulatorHosts)==null?void 0:t[s]},S_=s=>{const e=R_(s);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const n=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),n]:[e.substring(0,t),n]},kC=()=>{var s;return(s=Pl())==null?void 0:s.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fl{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,n)=>{t?this.reject(t):this.resolve(n),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,n))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function b_(s,e){if(s.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},n=e||"demo-project",r=s.iat||0,i=s.sub||s.user_id;if(!i)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const o={iss:`https://securetoken.google.com/${n}`,aud:n,iat:r,exp:r+3600,auth_time:r,sub:i,user_id:i,firebase:{sign_in_provider:"custom",identities:{}},...s};return[Ho(JSON.stringify(t)),Ho(JSON.stringify(o)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function VC(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function MC(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(VC())}function N_(){var e;const s=(e=Pl())==null?void 0:e.forceEnvironment;if(s==="node")return!0;if(s==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function P_(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function F_(){return FC.NODE_ADMIN===!0}function O_(){return!N_()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function GC(){try{return typeof indexedDB=="object"}catch{return!1}}function L_(){return new Promise((s,e)=>{try{let t=!0;const n="validate-browser-context-for-indexeddb-analytics-module",r=self.indexedDB.open(n);r.onsuccess=()=>{r.result.close(),t||self.indexedDB.deleteDatabase(n),s(!0)},r.onupgradeneeded=()=>{t=!1},r.onerror=()=>{var i;e(((i=r.error)==null?void 0:i.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const x_="FirebaseError";class yn extends Error{constructor(e,t,n){super(t),this.code=e,this.customData=n,this.name=x_,Object.setPrototypeOf(this,yn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,fa.prototype.create)}}class fa{constructor(e,t,n){this.service=e,this.serviceName=t,this.errors=n}create(e,...t){const n=t[0]||{},r=`${this.service}/${e}`,i=this.errors[e],o=i?k_(i,n):"Error",a=`${this.serviceName}: ${o} (${r}).`;return new yn(r,a,n)}}function k_(s,e){try{let t=0,n="";for(;t<s.length;){const r=s.indexOf("{$",t);if(r===-1){n+=s.substring(t);break}const i=s.indexOf("}",r+2);if(i===-1){n+=s.substring(t);break}const o=s.substring(r+2,i),a=e[o];n+=s.substring(t,r)+(a!=null?String(a):`<${o}?>`),t=i+1}return n}catch{return s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function di(s){return JSON.parse(s)}function tt(s){return JSON.stringify(s)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const HC=function(s){let e={},t={},n={},r="";try{const i=s.split(".");e=di(jB(i[0])||""),t=di(jB(i[1])||""),r=i[2],n=t.d||{},delete t.d}catch{}return{header:e,claims:t,data:n,signature:r}},V_=function(s){const e=HC(s),t=e.claims;return!!t&&typeof t=="object"&&t.hasOwnProperty("iat")},M_=function(s){const e=HC(s).claims;return typeof e=="object"&&e.admin===!0};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wn(s,e){return Object.prototype.hasOwnProperty.call(s,e)}function nr(s,e){if(Object.prototype.hasOwnProperty.call(s,e))return s[e]}function Bh(s){for(const e in s)if(Object.prototype.hasOwnProperty.call(s,e))return!1;return!0}function Uo(s,e,t){const n={};for(const r in s)Object.prototype.hasOwnProperty.call(s,r)&&(n[r]=e.call(t,s[r],r,s));return n}function sr(s,e){if(s===e)return!0;const t=Object.keys(s),n=Object.keys(e);for(const r of t){if(!n.includes(r))return!1;const i=s[r],o=e[r];if(lh(i)&&lh(o)){if(!sr(i,o))return!1}else if(i!==o)return!1}for(const r of n)if(!t.includes(r))return!1;return!0}function lh(s){return s!==null&&typeof s=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function G_(s){const e=[];for(const[t,n]of Object.entries(s))Array.isArray(n)?n.forEach(r=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(r))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(n));return e.length?"&"+e.join("&"):""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class H_{constructor(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=512/8,this.pad_[0]=128;for(let e=1;e<this.blockSize;++e)this.pad_[e]=0;this.reset()}reset(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0}compress_(e,t){t||(t=0);const n=this.W_;if(typeof e=="string")for(let f=0;f<16;f++)n[f]=e.charCodeAt(t)<<24|e.charCodeAt(t+1)<<16|e.charCodeAt(t+2)<<8|e.charCodeAt(t+3),t+=4;else for(let f=0;f<16;f++)n[f]=e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3],t+=4;for(let f=16;f<80;f++){const d=n[f-3]^n[f-8]^n[f-14]^n[f-16];n[f]=(d<<1|d>>>31)&4294967295}let r=this.chain_[0],i=this.chain_[1],o=this.chain_[2],a=this.chain_[3],l=this.chain_[4],c,h;for(let f=0;f<80;f++){f<40?f<20?(c=a^i&(o^a),h=1518500249):(c=i^o^a,h=1859775393):f<60?(c=i&o|a&(i|o),h=2400959708):(c=i^o^a,h=3395469782);const d=(r<<5|r>>>27)+c+l+h+n[f]&4294967295;l=a,a=o,o=(i<<30|i>>>2)&4294967295,i=r,r=d}this.chain_[0]=this.chain_[0]+r&4294967295,this.chain_[1]=this.chain_[1]+i&4294967295,this.chain_[2]=this.chain_[2]+o&4294967295,this.chain_[3]=this.chain_[3]+a&4294967295,this.chain_[4]=this.chain_[4]+l&4294967295}update(e,t){if(e==null)return;t===void 0&&(t=e.length);const n=t-this.blockSize;let r=0;const i=this.buf_;let o=this.inbuf_;for(;r<t;){if(o===0)for(;r<=n;)this.compress_(e,r),r+=this.blockSize;if(typeof e=="string"){for(;r<t;)if(i[o]=e.charCodeAt(r),++o,++r,o===this.blockSize){this.compress_(i),o=0;break}}else for(;r<t;)if(i[o]=e[r],++o,++r,o===this.blockSize){this.compress_(i),o=0;break}}this.inbuf_=o,this.total_+=t}digest(){const e=[];let t=this.total_*8;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(let r=this.blockSize-1;r>=56;r--)this.buf_[r]=t&255,t/=256;this.compress_(this.buf_);let n=0;for(let r=0;r<5;r++)for(let i=24;i>=0;i-=8)e[n]=this.chain_[r]>>i&255,++n;return e}}function U_(s,e){return`${s} failed: ${e} argument `}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const q_=function(s){const e=[];let t=0;for(let n=0;n<s.length;n++){let r=s.charCodeAt(n);if(r>=55296&&r<=56319){const i=r-55296;n++,K(n<s.length,"Surrogate pair missing trail surrogate.");const o=s.charCodeAt(n)-56320;r=65536+(i<<10)+o}r<128?e[t++]=r:r<2048?(e[t++]=r>>6|192,e[t++]=r&63|128):r<65536?(e[t++]=r>>12|224,e[t++]=r>>6&63|128,e[t++]=r&63|128):(e[t++]=r>>18|240,e[t++]=r>>12&63|128,e[t++]=r>>6&63|128,e[t++]=r&63|128)}return e},Ca=function(s){let e=0;for(let t=0;t<s.length;t++){const n=s.charCodeAt(t);n<128?e++:n<2048?e+=2:n>=55296&&n<=56319?(e+=4,t++):e+=3}return e};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const J_=1e3,j_=2,K_=4*60*60*1e3,z_=.5;function UC(s,e=J_,t=j_){const n=e*Math.pow(t,s),r=Math.round(z_*n*(Math.random()-.5)*2);return Math.min(K_,n+r)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qe(s){return s&&s._delegate?s._delegate:s}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qC(s){try{return(s.startsWith("http://")||s.startsWith("https://")?new URL(s).hostname:s).endsWith(".cloudworkstations.dev")}catch{return!1}}async function Q_(s){return(await fetch(s,{credentials:"include"})).ok}class gn{constructor(e,t,n){this.name=e,this.instanceFactory=t,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hs="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W_{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const n=new Fl;if(this.instancesDeferred.set(t,n),this.isInitialized(t)||this.shouldAutoInitialize())try{const r=this.getOrInitializeService({instanceIdentifier:t});r&&n.resolve(r)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),n=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(r){if(n)return null;throw r}else{if(n)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if($_(e))try{this.getOrInitializeService({instanceIdentifier:hs})}catch{}for(const[t,n]of this.instancesDeferred.entries()){const r=this.normalizeInstanceIdentifier(t);try{const i=this.getOrInitializeService({instanceIdentifier:r});n.resolve(i)}catch{}}}}clearInstance(e=hs){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=hs){return this.instances.has(e)}getOptions(e=hs){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,n=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(n))throw Error(`${this.name}(${n}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const r=this.getOrInitializeService({instanceIdentifier:n,options:t});for(const[i,o]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(i);n===a&&o.resolve(r)}return r}onInit(e,t){const n=this.normalizeInstanceIdentifier(t),r=this.onInitCallbacks.get(n)??new Set;r.add(e),this.onInitCallbacks.set(n,r);const i=this.instances.get(n);return i&&e(i,n),()=>{r.delete(e)}}invokeOnInitCallbacks(e,t){const n=this.onInitCallbacks.get(t);if(n)for(const r of n)try{r(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let n=this.instances.get(e);if(!n&&this.component&&(n=this.component.instanceFactory(this.container,{instanceIdentifier:Y_(e),options:t}),this.instances.set(e,n),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(n,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,n)}catch{}return n||null}normalizeInstanceIdentifier(e=hs){return this.component?this.component.multipleInstances?e:hs:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Y_(s){return s===hs?void 0:s}function $_(s){return s.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class X_{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new W_(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Be;(function(s){s[s.DEBUG=0]="DEBUG",s[s.VERBOSE=1]="VERBOSE",s[s.INFO=2]="INFO",s[s.WARN=3]="WARN",s[s.ERROR=4]="ERROR",s[s.SILENT=5]="SILENT"})(Be||(Be={}));const Z_={debug:Be.DEBUG,verbose:Be.VERBOSE,info:Be.INFO,warn:Be.WARN,error:Be.ERROR,silent:Be.SILENT},eE=Be.INFO,tE={[Be.DEBUG]:"log",[Be.VERBOSE]:"log",[Be.INFO]:"info",[Be.WARN]:"warn",[Be.ERROR]:"error"},nE=(s,e,...t)=>{if(e<s.logLevel)return;const n=new Date().toISOString(),r=tE[e];if(r)console[r](`[${n}]  ${s.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class da{constructor(e){this.name=e,this._logLevel=eE,this._logHandler=nE,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in Be))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Z_[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,Be.DEBUG,...e),this._logHandler(this,Be.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,Be.VERBOSE,...e),this._logHandler(this,Be.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,Be.INFO,...e),this._logHandler(this,Be.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,Be.WARN,...e),this._logHandler(this,Be.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,Be.ERROR,...e),this._logHandler(this,Be.ERROR,...e)}}const sE=(s,e)=>e.some(t=>s instanceof t);let ch,uh;function rE(){return ch||(ch=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function iE(){return uh||(uh=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const JC=new WeakMap,KB=new WeakMap,jC=new WeakMap,_B=new WeakMap,Ol=new WeakMap;function oE(s){const e=new Promise((t,n)=>{const r=()=>{s.removeEventListener("success",i),s.removeEventListener("error",o)},i=()=>{t(kn(s.result)),r()},o=()=>{n(s.error),r()};s.addEventListener("success",i),s.addEventListener("error",o)});return e.then(t=>{t instanceof IDBCursor&&JC.set(t,s)}).catch(()=>{}),Ol.set(e,s),e}function aE(s){if(KB.has(s))return;const e=new Promise((t,n)=>{const r=()=>{s.removeEventListener("complete",i),s.removeEventListener("error",o),s.removeEventListener("abort",o)},i=()=>{t(),r()},o=()=>{n(s.error||new DOMException("AbortError","AbortError")),r()};s.addEventListener("complete",i),s.addEventListener("error",o),s.addEventListener("abort",o)});KB.set(s,e)}let zB={get(s,e,t){if(s instanceof IDBTransaction){if(e==="done")return KB.get(s);if(e==="objectStoreNames")return s.objectStoreNames||jC.get(s);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return kn(s[e])},set(s,e,t){return s[e]=t,!0},has(s,e){return s instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in s}};function BE(s){zB=s(zB)}function lE(s){return s===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const n=s.call(EB(this),e,...t);return jC.set(n,e.sort?e.sort():[e]),kn(n)}:iE().includes(s)?function(...e){return s.apply(EB(this),e),kn(JC.get(this))}:function(...e){return kn(s.apply(EB(this),e))}}function cE(s){return typeof s=="function"?lE(s):(s instanceof IDBTransaction&&aE(s),sE(s,rE())?new Proxy(s,zB):s)}function kn(s){if(s instanceof IDBRequest)return oE(s);if(_B.has(s))return _B.get(s);const e=cE(s);return e!==s&&(_B.set(s,e),Ol.set(e,s)),e}const EB=s=>Ol.get(s);function KC(s,e,{blocked:t,upgrade:n,blocking:r,terminated:i}={}){const o=indexedDB.open(s,e),a=kn(o);return n&&o.addEventListener("upgradeneeded",l=>{n(kn(o.result),l.oldVersion,l.newVersion,kn(o.transaction),l)}),t&&o.addEventListener("blocked",l=>t(l.oldVersion,l.newVersion,l)),a.then(l=>{i&&l.addEventListener("close",()=>i()),r&&l.addEventListener("versionchange",c=>r(c.oldVersion,c.newVersion,c))}).catch(()=>{}),a}const uE=["get","getKey","getAll","getAllKeys","count"],hE=["put","add","delete","clear"],DB=new Map;function hh(s,e){if(!(s instanceof IDBDatabase&&!(e in s)&&typeof e=="string"))return;if(DB.get(e))return DB.get(e);const t=e.replace(/FromIndex$/,""),n=e!==t,r=hE.includes(t);if(!(t in(n?IDBIndex:IDBObjectStore).prototype)||!(r||uE.includes(t)))return;const i=async function(o,...a){const l=this.transaction(o,r?"readwrite":"readonly");let c=l.store;return n&&(c=c.index(a.shift())),(await Promise.all([c[t](...a),r&&l.done]))[0]};return DB.set(e,i),i}BE(s=>({...s,get:(e,t,n)=>hh(e,t)||s.get(e,t,n),has:(e,t)=>!!hh(e,t)||s.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fE{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(CE(t)){const n=t.getImmediate();return`${n.library}/${n.version}`}else return null}).filter(t=>t).join(" ")}}function CE(s){const e=s.getComponent();return(e==null?void 0:e.type)==="VERSION"}const QB="@firebase/app",fh="0.16.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mn=new da("@firebase/app"),dE="@firebase/app-compat",pE="@firebase/analytics-compat",gE="@firebase/analytics",mE="@firebase/app-check-compat",_E="@firebase/app-check",EE="@firebase/auth",DE="@firebase/auth-compat",yE="@firebase/database",wE="@firebase/data-connect",TE="@firebase/database-compat",IE="@firebase/functions",AE="@firebase/functions-compat",vE="@firebase/installations",RE="@firebase/installations-compat",SE="@firebase/messaging",bE="@firebase/messaging-compat",NE="@firebase/performance",PE="@firebase/performance-compat",FE="@firebase/remote-config",OE="@firebase/remote-config-compat",LE="@firebase/storage",xE="@firebase/storage-compat",kE="@firebase/firestore",VE="@firebase/ai",ME="@firebase/firestore-compat",GE="firebase",HE="12.19.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const WB="[DEFAULT]",UE={[QB]:"fire-core",[dE]:"fire-core-compat",[gE]:"fire-analytics",[pE]:"fire-analytics-compat",[_E]:"fire-app-check",[mE]:"fire-app-check-compat",[EE]:"fire-auth",[DE]:"fire-auth-compat",[yE]:"fire-rtdb",[wE]:"fire-data-connect",[TE]:"fire-rtdb-compat",[IE]:"fire-fn",[AE]:"fire-fn-compat",[vE]:"fire-iid",[RE]:"fire-iid-compat",[SE]:"fire-fcm",[bE]:"fire-fcm-compat",[NE]:"fire-perf",[PE]:"fire-perf-compat",[FE]:"fire-rc",[OE]:"fire-rc-compat",[LE]:"fire-gcs",[xE]:"fire-gcs-compat",[kE]:"fire-fst",[ME]:"fire-fst-compat",[VE]:"fire-vertex","fire-js":"fire-js",[GE]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pi=new Map,qE=new Map,YB=new Map;function Ch(s,e){try{s.container.addComponent(e)}catch(t){mn.debug(`Component ${e.name} failed to register with FirebaseApp ${s.name}`,t)}}function jn(s){const e=s.name;if(YB.has(e))return mn.debug(`There were multiple attempts to register component ${e}.`),!1;YB.set(e,s);for(const t of pi.values())Ch(t,s);for(const t of qE.values())Ch(t,s);return!0}function pa(s,e){const t=s.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),s.container.getProvider(e)}function zC(s){return s==null?!1:s.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const JE={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},un=new fa("app","Firebase",JE);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jE{constructor(e,t,n){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=n,this.container.addComponent(new gn("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw un.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qo=HE;function KE(s,e={}){let t=s;typeof e!="object"&&(e={name:e});const n={name:WB,automaticDataCollectionEnabled:!0,...e},r=n.name;if(typeof r!="string"||!r)throw un.create("bad-app-name",{appName:String(r)});if(t||(t=kC()),!t)throw un.create("no-options");const i=pi.get(r);if(i)if(sr(t,i.options)){if(sr(n,i.config))return i;throw un.create("duplicate-app",{appName:r,mismatchedParam:"config",oldValue:JSON.stringify(i.config),newValue:JSON.stringify(n)})}else throw un.create("duplicate-app",{appName:r,mismatchedParam:"options",oldValue:JSON.stringify(i.options),newValue:JSON.stringify(t)});const o=new X_(r);for(const l of YB.values())o.addComponent(l);const a=new jE(t,n,o);return pi.set(r,a),a}function QC(s=WB){const e=pi.get(s);if(!e&&s===WB&&kC())return KE();if(!e)throw un.create("no-app",{appName:s});return e}function V0(){return Array.from(pi.values())}function Mt(s,e,t){let n=UE[s]??s;t&&(n+=`-${t}`);const r=n.match(/\s|\//),i=e.match(/\s|\//);if(r||i){const o=[`Unable to register library "${n}" with version "${e}":`];r&&o.push(`library name "${n}" contains illegal characters (whitespace or "/")`),r&&i&&o.push("and"),i&&o.push(`version name "${e}" contains illegal characters (whitespace or "/")`),mn.warn(o.join(" "));return}jn(new gn(`${n}-version`,()=>({library:n,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zE="firebase-heartbeat-database",QE=1,gi="firebase-heartbeat-store";let yB=null;function WC(){return yB||(yB=KC(zE,QE,{upgrade:(s,e)=>{switch(e){case 0:try{s.createObjectStore(gi)}catch(t){console.warn(t)}}}}).catch(s=>{throw un.create("idb-open",{originalErrorMessage:s.message})})),yB}async function WE(s){try{const t=(await WC()).transaction(gi),n=await t.objectStore(gi).get(YC(s));return await t.done,n}catch(e){if(e instanceof yn)mn.warn(e.message);else{const t=un.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});mn.warn(t.message)}}}async function dh(s,e){try{const n=(await WC()).transaction(gi,"readwrite");await n.objectStore(gi).put(e,YC(s)),await n.done}catch(t){if(t instanceof yn)mn.warn(t.message);else{const n=un.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});mn.warn(n.message)}}}function YC(s){return`${s.name}!${s.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const YE=1024,$E=30;class XE{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new eD(t),this._heartbeatsCachePromise=this._storage.read().then(n=>(this._heartbeatsCache=n,n))}async triggerHeartbeat(){var e,t;try{const r=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=ph();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(o=>o.date===i))return;if(this._heartbeatsCache.heartbeats.push({date:i,agent:r}),this._heartbeatsCache.heartbeats.length>$E){const o=tD(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(o,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(n){mn.warn(n)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=ph(),{heartbeatsToSend:n,unsentEntries:r}=ZE(this._heartbeatsCache.heartbeats),i=Ho(JSON.stringify({version:2,heartbeats:n}));return this._heartbeatsCache.lastSentHeartbeatDate=t,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}catch(t){return mn.warn(t),""}}}function ph(){return new Date().toISOString().substring(0,10)}function ZE(s,e=YE){const t=[];let n=s.slice();for(const r of s){const i=t.find(o=>o.agent===r.agent);if(i){if(i.dates.push(r.date),gh(t)>e){i.dates.pop();break}}else if(t.push({agent:r.agent,dates:[r.date]}),gh(t)>e){t.pop();break}n=n.slice(1)}return{heartbeatsToSend:t,unsentEntries:n}}class eD{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return GC()?L_().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await WE(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const n=await this.read();return dh(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??n.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const n=await this.read();return dh(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??n.lastSentHeartbeatDate,heartbeats:[...n.heartbeats,...e.heartbeats]})}else return}}function gh(s){return Ho(JSON.stringify({version:2,heartbeats:s})).length}function tD(s){if(s.length===0)return-1;let e=0,t=s[0].date;for(let n=1;n<s.length;n++)s[n].date<t&&(t=s[n].date,e=n);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nD(s){jn(new gn("platform-logger",e=>new fE(e),"PRIVATE")),jn(new gn("heartbeat",e=>new XE(e),"PRIVATE")),Mt(QB,fh,s),Mt(QB,fh,"esm2020"),Mt("fire-js","")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */nD("");var sD="firebase",rD="12.19.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Mt(sD,rD,"app");const $C="@firebase/installations",Ll="0.6.24";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const XC=1e4,ZC=`w:${Ll}`,ed="FIS_v2",iD="https://firebaseinstallations.googleapis.com/v1",oD=60*60*1e3,aD="installations",BD="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lD={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},Ts=new fa(aD,BD,lD);function td(s){return s instanceof yn&&s.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nd({projectId:s}){return`${iD}/projects/${s}/installations`}function sd(s){return{token:s.token,requestStatus:2,expiresIn:uD(s.expiresIn),creationTime:Date.now()}}async function rd(s,e){const n=(await e.json()).error;return Ts.create("request-failed",{requestName:s,serverCode:n.code,serverMessage:n.message,serverStatus:n.status})}function id({apiKey:s}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":s})}function cD(s,{refreshToken:e}){const t=id(s);return t.append("Authorization",hD(e)),t}async function od(s){const e=await s();return e.status>=500&&e.status<600?s():e}function uD(s){return Number(s.replace("s","000"))}function hD(s){return`${ed} ${s}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function fD({appConfig:s,heartbeatServiceProvider:e},{fid:t}){const n=nd(s),r=id(s),i=e.getImmediate({optional:!0});if(i){const c=await i.getHeartbeatsHeader();c&&r.append("x-firebase-client",c)}const o={fid:t,authVersion:ed,appId:s.appId,sdkVersion:ZC},a={method:"POST",headers:r,body:JSON.stringify(o)},l=await od(()=>fetch(n,a));if(l.ok){const c=await l.json();return{fid:c.fid||t,registrationStatus:2,refreshToken:c.refreshToken,authToken:sd(c.authToken)}}else throw await rd("Create Installation",l)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ad(s){return new Promise(e=>{setTimeout(e,s)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function CD(s){return btoa(String.fromCharCode(...s)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dD=/^[cdef][\w-]{21}$/,$B="";function pD(){try{const s=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(s),s[0]=112+s[0]%16;const t=gD(s);return dD.test(t)?t:$B}catch{return $B}}function gD(s){return CD(s).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ga(s){return`${s.appName}!${s.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bd=new Map;function ld(s,e){const t=ga(s);cd(t,e),mD(t,e)}function cd(s,e){const t=Bd.get(s);if(t)for(const n of t)n(e)}function mD(s,e){const t=_D();t&&t.postMessage({key:s,fid:e}),ED()}let ps=null;function _D(){return!ps&&"BroadcastChannel"in self&&(ps=new BroadcastChannel("[Firebase] FID Change"),ps.onmessage=s=>{cd(s.data.key,s.data.fid)}),ps}function ED(){Bd.size===0&&ps&&(ps.close(),ps=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const DD="firebase-installations-database",yD=1,Is="firebase-installations-store";let wB=null;function xl(){return wB||(wB=KC(DD,yD,{upgrade:(s,e)=>{switch(e){case 0:s.createObjectStore(Is)}}})),wB}async function Jo(s,e){const t=ga(s),r=(await xl()).transaction(Is,"readwrite"),i=r.objectStore(Is),o=await i.get(t);return await i.put(e,t),await r.done,(!o||o.fid!==e.fid)&&ld(s,e.fid),e}async function ud(s){const e=ga(s),n=(await xl()).transaction(Is,"readwrite");await n.objectStore(Is).delete(e),await n.done}async function ma(s,e){const t=ga(s),r=(await xl()).transaction(Is,"readwrite"),i=r.objectStore(Is),o=await i.get(t),a=e(o);return a===void 0?await i.delete(t):await i.put(a,t),await r.done,a&&(!o||o.fid!==a.fid)&&ld(s,a.fid),a}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function kl(s){let e;const t=await ma(s.appConfig,n=>{const r=wD(n),i=TD(s,r);return e=i.registrationPromise,i.installationEntry});return t.fid===$B?{installationEntry:await e}:{installationEntry:t,registrationPromise:e}}function wD(s){const e=s||{fid:pD(),registrationStatus:0};return hd(e)}function TD(s,e){if(e.registrationStatus===0){if(!navigator.onLine){const r=Promise.reject(Ts.create("app-offline"));return{installationEntry:e,registrationPromise:r}}const t={fid:e.fid,registrationStatus:1,registrationTime:Date.now()},n=ID(s,t);return{installationEntry:t,registrationPromise:n}}else return e.registrationStatus===1?{installationEntry:e,registrationPromise:AD(s)}:{installationEntry:e}}async function ID(s,e){try{const t=await fD(s,e);return Jo(s.appConfig,t)}catch(t){throw td(t)&&t.customData.serverCode===409?await ud(s.appConfig):await Jo(s.appConfig,{fid:e.fid,registrationStatus:0}),t}}async function AD(s){let e=await mh(s.appConfig);for(;e.registrationStatus===1;)await ad(100),e=await mh(s.appConfig);if(e.registrationStatus===0){const{installationEntry:t,registrationPromise:n}=await kl(s);return n||t}return e}function mh(s){return ma(s,e=>{if(!e)throw Ts.create("installation-not-found");return hd(e)})}function hd(s){return vD(s)?{fid:s.fid,registrationStatus:0}:s}function vD(s){return s.registrationStatus===1&&s.registrationTime+XC<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function RD({appConfig:s,heartbeatServiceProvider:e},t){const n=SD(s,t),r=cD(s,t),i=e.getImmediate({optional:!0});if(i){const c=await i.getHeartbeatsHeader();c&&r.append("x-firebase-client",c)}const o={installation:{sdkVersion:ZC,appId:s.appId}},a={method:"POST",headers:r,body:JSON.stringify(o)},l=await od(()=>fetch(n,a));if(l.ok){const c=await l.json();return sd(c)}else throw await rd("Generate Auth Token",l)}function SD(s,{fid:e}){return`${nd(s)}/${e}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Vl(s,e=!1){let t;const n=await ma(s.appConfig,i=>{if(!fd(i))throw Ts.create("not-registered");const o=i.authToken;if(!e&&PD(o))return i;if(o.requestStatus===1)return t=bD(s,e),i;{if(!navigator.onLine)throw Ts.create("app-offline");const a=OD(i);return t=ND(s,a),a}});return t?await t:n.authToken}async function bD(s,e){let t=await _h(s.appConfig);for(;t.authToken.requestStatus===1;)await ad(100),t=await _h(s.appConfig);const n=t.authToken;return n.requestStatus===0?Vl(s,e):n}function _h(s){return ma(s,e=>{if(!fd(e))throw Ts.create("not-registered");const t=e.authToken;return LD(t)?{...e,authToken:{requestStatus:0}}:e})}async function ND(s,e){try{const t=await RD(s,e),n={...e,authToken:t};return await Jo(s.appConfig,n),t}catch(t){if(td(t)&&(t.customData.serverCode===401||t.customData.serverCode===404))await ud(s.appConfig);else{const n={...e,authToken:{requestStatus:0}};await Jo(s.appConfig,n)}throw t}}function fd(s){return s!==void 0&&s.registrationStatus===2}function PD(s){return s.requestStatus===2&&!FD(s)}function FD(s){const e=Date.now();return e<s.creationTime||s.creationTime+s.expiresIn<e+oD}function OD(s){const e={requestStatus:1,requestTime:Date.now()};return{...s,authToken:e}}function LD(s){return s.requestStatus===1&&s.requestTime+XC<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function xD(s){const e=s,{installationEntry:t,registrationPromise:n}=await kl(e);return n?n.catch(console.error):Vl(e).catch(console.error),t.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function kD(s,e=!1){const t=s;return await VD(t),(await Vl(t,e)).token}async function VD(s){const{registrationPromise:e}=await kl(s);e&&await e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function MD(s){if(!s||!s.options)throw TB("App Configuration");if(!s.name)throw TB("App Name");const e=["projectId","apiKey","appId"];for(const t of e)if(!s.options[t])throw TB(t);return{appName:s.name,projectId:s.options.projectId,apiKey:s.options.apiKey,appId:s.options.appId}}function TB(s){return Ts.create("missing-app-config-values",{valueName:s})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cd="installations",GD="installations-internal",HD=s=>{const e=s.getProvider("app").getImmediate(),t=MD(e),n=pa(e,"heartbeat");return{app:e,appConfig:t,heartbeatServiceProvider:n,_delete:()=>Promise.resolve()}},UD=s=>{const e=s.getProvider("app").getImmediate(),t=pa(e,Cd).getImmediate();return{getId:()=>xD(t),getToken:r=>kD(t,r)}};function qD(){jn(new gn(Cd,HD,"PUBLIC")),jn(new gn(GD,UD,"PRIVATE"))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */qD();Mt($C,Ll);Mt($C,Ll,"esm2020");const IB="@firebase/remote-config",Eh="0.9.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dd{constructor(){this.listeners=[]}addEventListener(e){this.listeners.push(e)}abort(){this.listeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pd="remote-config",Dh=100;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const JD={"already-initialized":"Remote Config already initialized","registration-window":"Undefined window object. This SDK only supports usage in a browser environment.","registration-project-id":"Undefined project identifier. Check Firebase app initialization.","registration-api-key":"Undefined API key. Check Firebase app initialization.","registration-app-id":"Undefined app identifier. Check Firebase app initialization.","storage-open":"Error thrown when opening storage. Original error: {$originalErrorMessage}.","storage-get":"Error thrown when reading from storage. Original error: {$originalErrorMessage}.","storage-set":"Error thrown when writing to storage. Original error: {$originalErrorMessage}.","storage-delete":"Error thrown when deleting from storage. Original error: {$originalErrorMessage}.","fetch-client-network":"Fetch client failed to connect to a network. Check Internet connection. Original error: {$originalErrorMessage}.","fetch-timeout":'The config fetch request timed out.  Configure timeout using "fetchTimeoutMillis" SDK setting.',"fetch-throttle":'The config fetch request timed out while in an exponential backoff state. Configure timeout using "fetchTimeoutMillis" SDK setting. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.',"fetch-client-parse":"Fetch client could not parse response. Original error: {$originalErrorMessage}.","fetch-status":"Fetch server returned an HTTP error status. HTTP status: {$httpStatus}.","indexed-db-unavailable":"Indexed DB is not supported by current browser","custom-signal-max-allowed-signals":"Setting more than {$maxSignals} custom signals is not supported.","stream-error":"The stream was not able to connect to the backend: {$originalErrorMessage}.","realtime-unavailable":"The Realtime service is unavailable: {$originalErrorMessage}","update-message-invalid":"The stream invalidation message was unparsable: {$originalErrorMessage}","update-not-fetched":"Unable to fetch the latest config: {$originalErrorMessage}","analytics-unavailable":"Connection to Firebase Analytics failed: {$originalErrorMessage}"},xe=new fa("remoteconfig","Remote Config",JD);function jD(s,e){return s instanceof yn&&s.code.indexOf(e)!==-1}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const KD=!1,zD="",yh=0,QD=["1","true","t","yes","y","on"];class AB{constructor(e,t=zD){this._source=e,this._value=t}asString(){return this._value}asBoolean(){return this._source==="static"?KD:QD.indexOf(this._value.toLowerCase())>=0}asNumber(){if(this._source==="static")return yh;let e=Number(this._value);return isNaN(e)&&(e=yh),e}getSource(){return this._source}}class WD{constructor(e){this.storage=e._storage,this.logger=e._logger,this.analyticsProvider=e._analyticsProvider}async updateActiveExperiments(e){const t=await this.storage.getActiveExperiments()||new Set,n=this.createExperimentInfoMap(e);return this.addActiveExperiments(n),this.removeInactiveExperiments(t,n),this.storage.setActiveExperiments(new Set(n.keys()))}createExperimentInfoMap(e){const t=new Map;for(const n of e)t.set(n.experimentId,n);return t}addActiveExperiments(e){const t={};for(const[n,r]of e.entries())t[`firebase${n}`]=r.variantId;this.addExperimentToAnalytics(t)}removeInactiveExperiments(e,t){const n={};for(const r of e)t.has(r)||(n[`firebase${r}`]=null);this.addExperimentToAnalytics(n)}addExperimentToAnalytics(e){if(Object.keys(e).length!==0)try{const t=this.analyticsProvider.getImmediate({optional:!0});t?(t.setUserProperties(e),t.logEvent("set_firebase_experiment_state")):this.logger.warn("Analytics import failed. Verify if you have imported Firebase Analytics in your app code.")}catch(t){throw xe.create("analytics-unavailable",{originalErrorMessage:t==null?void 0:t.message})}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function M0(s=QC(),e={}){var r,i;s=qe(s);const t=pa(s,pd);if(t.isInitialized()){const o=t.getOptions();if(sr(o,e))return t.getImmediate();throw xe.create("already-initialized")}t.initialize({options:e});const n=t.getImmediate();return e.initialFetchResponse&&(n._initializePromise=Promise.all([n._storage.setLastSuccessfulFetchResponse(e.initialFetchResponse),n._storage.setActiveConfigEtag(((r=e.initialFetchResponse)==null?void 0:r.eTag)||""),n._storage.setActiveConfigTemplateVersion(e.initialFetchResponse.templateVersion||0),n._storageCache.setLastSuccessfulFetchTimestampMillis(Date.now()),n._storageCache.setLastFetchStatus("success"),n._storageCache.setActiveConfig(((i=e.initialFetchResponse)==null?void 0:i.config)||{})]).then(),n._isInitializationComplete=!0),n}async function YD(s){const e=qe(s),[t,n]=await Promise.all([e._storage.getLastSuccessfulFetchResponse(),e._storage.getActiveConfigEtag()]);if(!t||!t.config||!t.eTag||!t.templateVersion||t.eTag===n)return!1;const i=new WD(e).updateActiveExperiments(t.experiments||[]);return await Promise.all([e._storageCache.setActiveConfig(t.config),e._storage.setActiveConfigEtag(t.eTag),e._storage.setActiveConfigTemplateVersion(t.templateVersion),i]),!0}function $D(s){const e=qe(s);return e._initializePromise||(e._initializePromise=e._storageCache.loadFromStorage().then(()=>{e._isInitializationComplete=!0})),e._initializePromise}async function XD(s){const e=qe(s),t=new dd;setTimeout(async()=>{t.abort()},e.settings.fetchTimeoutMillis);const n=e._storageCache.getCustomSignals();n&&e._logger.debug(`Fetching config with custom signals: ${JSON.stringify(n)}`);try{await e._client.fetch({cacheMaxAgeMillis:e.settings.minimumFetchIntervalMillis,signal:t,customSignals:n}),await e._storageCache.setLastFetchStatus("success")}catch(r){const i=jD(r,"fetch-throttle")?"throttle":"failure";throw await e._storageCache.setLastFetchStatus(i),r}}function G0(s,e){const t=qe(s);t._isInitializationComplete||t._logger.debug(`A value was requested for key "${e}" before SDK initialization completed. Await on ensureInitialized if the intent was to get a previously activated value.`);const n=t._storageCache.getActiveConfig();return n&&n[e]!==void 0?new AB("remote",n[e]):t.defaultConfig&&t.defaultConfig[e]!==void 0?new AB("default",String(t.defaultConfig[e])):(t._logger.debug(`Returning static value for key "${e}". Define a default or remote value if this is unintentional.`),new AB("static"))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ZD{constructor(e,t,n,r){this.client=e,this.storage=t,this.storageCache=n,this.logger=r}isCachedDataFresh(e,t){if(!t)return this.logger.debug("Config fetch cache check. Cache unpopulated."),!1;const n=Date.now()-t,r=n<=e;return this.logger.debug(`Config fetch cache check. Cache age millis: ${n}. Cache max age millis (minimumFetchIntervalMillis setting): ${e}. Is cache hit: ${r}.`),r}async fetch(e){const[t,n]=await Promise.all([this.storage.getLastSuccessfulFetchTimestampMillis(),this.storage.getLastSuccessfulFetchResponse()]);if(n&&this.isCachedDataFresh(e.cacheMaxAgeMillis,t))return n;e.eTag=n&&n.eTag;const r=await this.client.fetch(e),i=[this.storageCache.setLastSuccessfulFetchTimestampMillis(Date.now())];return r.status===200&&i.push(this.storage.setLastSuccessfulFetchResponse(r)),await Promise.all(i),r}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ey(s=navigator){return s.languages&&s.languages[0]||s.language}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ty{constructor(e,t,n,r,i,o){this.firebaseInstallations=e,this.sdkVersion=t,this.namespace=n,this.projectId=r,this.apiKey=i,this.appId=o}async fetch(e){const[t,n]=await Promise.all([this.firebaseInstallations.getId(),this.firebaseInstallations.getToken()]),i=`${window.FIREBASE_REMOTE_CONFIG_URL_BASE||"https://firebaseremoteconfig.googleapis.com"}/v1/projects/${this.projectId}/namespaces/${this.namespace}:fetch?key=${this.apiKey}`,o={"Content-Type":"application/json","Content-Encoding":"gzip","If-None-Match":e.eTag||"*"},a={sdk_version:this.sdkVersion,app_instance_id:t,app_instance_id_token:n,app_id:this.appId,language_code:ey(),custom_signals:e.customSignals},l={method:"POST",headers:o,body:JSON.stringify(a)},c=fetch(i,l),h=new Promise((re,ge)=>{e.signal.addEventListener(()=>{const Le=new Error("The operation was aborted.");Le.name="AbortError",ge(Le)})});let f;try{await Promise.race([c,h]),f=await c}catch(re){let ge="fetch-client-network";throw(re==null?void 0:re.name)==="AbortError"&&(ge="fetch-timeout"),xe.create(ge,{originalErrorMessage:re==null?void 0:re.message})}let d=f.status;const _=f.headers.get("ETag")||void 0;let y,N,F,J,te;if(f.status===200){let re;try{re=await f.json()}catch(ge){throw xe.create("fetch-client-parse",{originalErrorMessage:ge==null?void 0:ge.message})}y=re.entries,N=re.state,F=re.templateVersion,J=re.experimentDescriptions,te=re.rolloutMetadata}if(N==="INSTANCE_STATE_UNSPECIFIED"?d=500:N==="NO_CHANGE"?d=304:(N==="NO_TEMPLATE"||N==="EMPTY_CONFIG")&&(y={},J=[],te=[]),d!==304&&d!==200)throw xe.create("fetch-status",{httpStatus:d});return{status:d,eTag:_,config:y,templateVersion:F,experiments:J,rollouts:te}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ny(s,e){return new Promise((t,n)=>{const r=Math.max(e-Date.now(),0),i=setTimeout(t,r);s.addEventListener(()=>{clearTimeout(i),n(xe.create("fetch-throttle",{throttleEndTimeMillis:e}))})})}function sy(s){if(!(s instanceof yn)||!s.customData)return!1;const e=Number(s.customData.httpStatus);return e===429||e===500||e===503||e===504}class ry{constructor(e,t){this.client=e,this.storage=t}async fetch(e){const t=await this.storage.getThrottleMetadata()||{backoffCount:0,throttleEndTimeMillis:Date.now()};return this.attemptFetch(e,t)}async attemptFetch(e,{throttleEndTimeMillis:t,backoffCount:n}){await ny(e.signal,t);try{const r=await this.client.fetch(e);return await this.storage.deleteThrottleMetadata(),r}catch(r){if(!sy(r))throw r;const i={throttleEndTimeMillis:Date.now()+UC(n),backoffCount:n+1};return await this.storage.setThrottleMetadata(i),this.attemptFetch(e,i)}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iy=60*1e3,oy=12*60*60*1e3;class ay{get fetchTimeMillis(){return this._storageCache.getLastSuccessfulFetchTimestampMillis()||-1}get lastFetchStatus(){return this._storageCache.getLastFetchStatus()||"no-fetch-yet"}constructor(e,t,n,r,i,o,a){this.app=e,this._client=t,this._storageCache=n,this._storage=r,this._logger=i,this._realtimeHandler=o,this._analyticsProvider=a,this._isInitializationComplete=!1,this.settings={fetchTimeoutMillis:iy,minimumFetchIntervalMillis:oy},this.defaultConfig={}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fo(s,e){const t=s.target.error||void 0;return xe.create(e,{originalErrorMessage:t&&(t==null?void 0:t.message)})}const Pn="app_namespace_store",By="firebase_remote_config",ly=1;function cy(){return new Promise((s,e)=>{try{const t=indexedDB.open(By,ly);t.onerror=n=>{e(Fo(n,"storage-open"))},t.onsuccess=n=>{s(n.target.result)},t.onupgradeneeded=n=>{const r=n.target.result;switch(n.oldVersion){case 0:r.createObjectStore(Pn,{keyPath:"compositeKey"})}}}catch(t){e(xe.create("storage-open",{originalErrorMessage:t==null?void 0:t.message}))}})}class gd{getLastFetchStatus(){return this.get("last_fetch_status")}setLastFetchStatus(e){return this.set("last_fetch_status",e)}getLastSuccessfulFetchTimestampMillis(){return this.get("last_successful_fetch_timestamp_millis")}setLastSuccessfulFetchTimestampMillis(e){return this.set("last_successful_fetch_timestamp_millis",e)}getLastSuccessfulFetchResponse(){return this.get("last_successful_fetch_response")}setLastSuccessfulFetchResponse(e){return this.set("last_successful_fetch_response",e)}getActiveConfig(){return this.get("active_config")}setActiveConfig(e){return this.set("active_config",e)}getActiveConfigEtag(){return this.get("active_config_etag")}setActiveConfigEtag(e){return this.set("active_config_etag",e)}getActiveExperiments(){return this.get("active_experiments")}setActiveExperiments(e){return this.set("active_experiments",e)}getThrottleMetadata(){return this.get("throttle_metadata")}setThrottleMetadata(e){return this.set("throttle_metadata",e)}deleteThrottleMetadata(){return this.delete("throttle_metadata")}getCustomSignals(){return this.get("custom_signals")}getRealtimeBackoffMetadata(){return this.get("realtime_backoff_metadata")}setRealtimeBackoffMetadata(e){return this.set("realtime_backoff_metadata",e)}getActiveConfigTemplateVersion(){return this.get("last_known_template_version")}setActiveConfigTemplateVersion(e){return this.set("last_known_template_version",e)}}class uy extends gd{constructor(e,t,n,r=cy()){super(),this.appId=e,this.appName=t,this.namespace=n,this.openDbPromise=r}async setCustomSignals(e){const n=(await this.openDbPromise).transaction([Pn],"readwrite"),r=await this.getWithTransaction("custom_signals",n),i=md(e,r||{});return await this.setWithTransaction("custom_signals",i,n),i}async getWithTransaction(e,t){return new Promise((n,r)=>{const i=t.objectStore(Pn),o=this.createCompositeKey(e);try{const a=i.get(o);a.onerror=l=>{r(Fo(l,"storage-get"))},a.onsuccess=l=>{const c=l.target.result;n(c?c.value:void 0)}}catch(a){r(xe.create("storage-get",{originalErrorMessage:a==null?void 0:a.message}))}})}async setWithTransaction(e,t,n){return new Promise((r,i)=>{const o=n.objectStore(Pn),a=this.createCompositeKey(e);try{const l=o.put({compositeKey:a,value:t});l.onerror=c=>{i(Fo(c,"storage-set"))},l.onsuccess=()=>{r()}}catch(l){i(xe.create("storage-set",{originalErrorMessage:l==null?void 0:l.message}))}})}async get(e){const n=(await this.openDbPromise).transaction([Pn],"readonly");return this.getWithTransaction(e,n)}async set(e,t){const r=(await this.openDbPromise).transaction([Pn],"readwrite");return this.setWithTransaction(e,t,r)}async delete(e){const t=await this.openDbPromise;return new Promise((n,r)=>{const o=t.transaction([Pn],"readwrite").objectStore(Pn),a=this.createCompositeKey(e);try{const l=o.delete(a);l.onerror=c=>{r(Fo(c,"storage-delete"))},l.onsuccess=()=>{n()}}catch(l){r(xe.create("storage-delete",{originalErrorMessage:l==null?void 0:l.message}))}})}createCompositeKey(e){return[this.appId,this.appName,this.namespace,e].join()}}class hy extends gd{constructor(){super(...arguments),this.storage={}}async get(e){return Promise.resolve(this.storage[e])}async set(e,t){return this.storage[e]=t,Promise.resolve(void 0)}async delete(e){return this.storage[e]=void 0,Promise.resolve()}async setCustomSignals(e){const t=this.storage.custom_signals||{};return this.storage.custom_signals=md(e,t),Promise.resolve(this.storage.custom_signals)}}function md(s,e){const t={...e,...s},n=Object.fromEntries(Object.entries(t).filter(([r,i])=>i!==null).map(([r,i])=>typeof i=="number"?[r,i.toString()]:[r,i]));if(Object.keys(n).length>Dh)throw xe.create("custom-signal-max-allowed-signals",{maxSignals:Dh});return n}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fy{constructor(e){this.storage=e}getLastFetchStatus(){return this.lastFetchStatus}getLastSuccessfulFetchTimestampMillis(){return this.lastSuccessfulFetchTimestampMillis}getActiveConfig(){return this.activeConfig}getCustomSignals(){return this.customSignals}async loadFromStorage(){const e=this.storage.getLastFetchStatus(),t=this.storage.getLastSuccessfulFetchTimestampMillis(),n=this.storage.getActiveConfig(),r=this.storage.getCustomSignals(),i=await e;i&&(this.lastFetchStatus=i);const o=await t;o&&(this.lastSuccessfulFetchTimestampMillis=o);const a=await n;a&&(this.activeConfig=a);const l=await r;l&&(this.customSignals=l)}setLastFetchStatus(e){return this.lastFetchStatus=e,this.storage.setLastFetchStatus(e)}setLastSuccessfulFetchTimestampMillis(e){return this.lastSuccessfulFetchTimestampMillis=e,this.storage.setLastSuccessfulFetchTimestampMillis(e)}setActiveConfig(e){return this.activeConfig=e,this.storage.setActiveConfig(e)}async setCustomSignals(e){this.customSignals=await this.storage.setCustomSignals(e)}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Cy=class{constructor(e){this.allowedEvents_=e,this.listeners_={},K(Array.isArray(e)&&e.length>0,"Requires a non-empty array")}trigger(e,...t){if(Array.isArray(this.listeners_[e])){const n=[...this.listeners_[e]];for(let r=0;r<n.length;r++)n[r].callback.apply(n[r].context,t)}}on(e,t,n){this.validateEventType_(e),this.listeners_[e]=this.listeners_[e]||[],this.listeners_[e].push({callback:t,context:n});const r=this.getInitialEvent(e);r&&t.apply(n,r)}off(e,t,n){this.validateEventType_(e);const r=this.listeners_[e]||[];for(let i=0;i<r.length;i++)if(r[i].callback===t&&(!n||n===r[i].context)){r.splice(i,1);return}}validateEventType_(e){K(this.allowedEvents_.find(t=>t===e),"Unknown event: "+e)}};/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let dy=class _d extends Cy{static getInstance(){return new _d}constructor(){super(["visible"]);let e,t;typeof document<"u"&&typeof document.addEventListener<"u"&&(typeof document.hidden<"u"?(t="visibilitychange",e="hidden"):typeof document.mozHidden<"u"?(t="mozvisibilitychange",e="mozHidden"):typeof document.msHidden<"u"?(t="msvisibilitychange",e="msHidden"):typeof document.webkitHidden<"u"&&(t="webkitvisibilitychange",e="webkitHidden")),this.visible_=!0,t&&document.addEventListener(t,()=>{const n=!document[e];n!==this.visible_&&(this.visible_=n,this.trigger("visible",n))},!1)}getInitialEvent(e){return K(e==="visible","Unknown event type: "+e),[this.visible_]}};/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const py="X-Goog-Api-Key",gy="X-Goog-Firebase-Installations-Auth",vB=8,wh=3,Th=-1,Ih=0,Ah="featureDisabled",vh="retryIntervalSeconds",Rh="latestTemplateVersionNumber",my="_exp_rollout";class _y{constructor(e,t,n,r,i,o,a,l,c,h){this.firebaseInstallations=e,this.storage=t,this.sdkVersion=n,this.namespace=r,this.projectId=i,this.apiKey=o,this.appId=a,this.logger=l,this.storageCache=c,this.cachingClient=h,this.observers=new Set,this.isConnectionActive=!1,this.isRealtimeDisabled=!1,this.httpRetriesRemaining=vB,this.isInBackground=!1,this.decoder=new TextDecoder("utf-8"),this.isClosingConnection=!1,this.propagateError=f=>this.observers.forEach(d=>{var _;return(_=d.error)==null?void 0:_.call(d,f)}),this.isStatusCodeRetryable=f=>!f||[408,429,502,503,504].includes(f),this.setRetriesRemaining(),dy.getInstance().on("visible",this.onVisibilityChange,this)}async setRetriesRemaining(){const e=await this.storage.getRealtimeBackoffMetadata(),t=(e==null?void 0:e.numFailedStreams)||0;this.httpRetriesRemaining=Math.max(vB-t,1)}async updateBackoffMetadataWithLastFailedStreamConnectionTime(e){var r;const t=(((r=await this.storage.getRealtimeBackoffMetadata())==null?void 0:r.numFailedStreams)||0)+1,n=UC(t,6e4,2);await this.storage.setRealtimeBackoffMetadata({backoffEndTimeMillis:new Date(e.getTime()+n),numFailedStreams:t})}async updateBackoffMetadataWithRetryInterval(e){const t=Date.now(),n=e*1e3,r=new Date(t+n);await this.storage.setRealtimeBackoffMetadata({backoffEndTimeMillis:r,numFailedStreams:0}),await this.retryHttpConnectionWhenBackoffEnds()}async closeRealtimeHttpConnection(){if(!this.isClosingConnection){this.isClosingConnection=!0;try{this.reader&&await this.reader.cancel()}catch{this.logger.debug("Failed to cancel the reader, connection was lost.")}finally{this.reader=void 0}this.controller&&(await this.controller.abort(),this.controller=void 0),this.isClosingConnection=!1}}async resetRealtimeBackoff(){await this.storage.setRealtimeBackoffMetadata({backoffEndTimeMillis:new Date(-1),numFailedStreams:0})}resetRetryCount(){this.httpRetriesRemaining=vB}async establishRealtimeConnection(e,t,n,r){const i=await this.storage.getActiveConfigEtag(),o=await this.storage.getActiveConfigTemplateVersion(),a={[py]:this.apiKey,[gy]:n,"Content-Type":"application/json",Accept:"application/json","If-None-Match":i||"*","Content-Encoding":"gzip"},l={project:this.projectId,namespace:this.namespace,lastKnownVersionNumber:o,appId:this.appId,sdkVersion:this.sdkVersion,appInstanceId:t};return await fetch(e,{method:"POST",headers:a,body:JSON.stringify(l),signal:r})}getRealtimeUrl(){const t=`${window.FIREBASE_REMOTE_CONFIG_URL_BASE||"https://firebaseremoteconfigrealtime.googleapis.com"}/v1/projects/${this.projectId}/namespaces/${this.namespace}:streamFetchInvalidations?key=${this.apiKey}`;return new URL(t)}async createRealtimeConnection(){const[e,t]=await Promise.all([this.firebaseInstallations.getId(),this.firebaseInstallations.getToken(!1)]);this.controller=new AbortController;const n=this.getRealtimeUrl();return await this.establishRealtimeConnection(n,e,t,this.controller.signal)}async retryHttpConnectionWhenBackoffEnds(){let e=await this.storage.getRealtimeBackoffMetadata();e||(e={backoffEndTimeMillis:new Date(Th),numFailedStreams:Ih});const t=new Date(e.backoffEndTimeMillis).getTime(),n=Date.now(),r=Math.max(0,t-n);await this.makeRealtimeHttpConnection(r)}setIsHttpConnectionRunning(e){this.isConnectionActive=e}checkAndSetHttpConnectionFlagIfNotRunning(){const e=this.canEstablishStreamConnection();return e&&this.setIsHttpConnectionRunning(!0),e}fetchResponseIsUpToDate(e,t){return e.config!=null&&e.templateVersion?e.templateVersion>=t:this.storageCache.getLastFetchStatus()==="success"}parseAndValidateConfigUpdateMessage(e){const t=e.indexOf("{"),n=e.indexOf("}",t);return t<0||n<0||t>=n?"":e.substring(t,n+1)}isEventListenersEmpty(){return this.observers.size===0}getRandomInt(e){return Math.floor(Math.random()*e)}executeAllListenerCallbacks(e){this.observers.forEach(t=>t.next(e))}getChangedParams(e,t,n,r){const i=new Set,o=new Set(Object.keys(e||{})),a=new Set(Object.keys(t||{})),l=n.experiments||[],c=(r==null?void 0:r.experiments)||[],h=this.createExperimentsMap(l),f=this.createExperimentsMap(c),d=n.rollouts||[],_=(r==null?void 0:r.rollouts)||[],y=this.createRolloutsMap(d),N=this.createRolloutsMap(_);for(const F of o){if(!a.has(F)||e[F]!==t[F]){i.add(F);continue}if(h.has(F)!==f.has(F)){i.add(F);continue}const J=h.get(F),te=f.get(F);if(J&&te&&!this.areExperimentsEqual(J,te)){i.add(F);continue}if(y.has(F)!==N.has(F)){i.add(F);continue}const re=y.get(F),ge=N.get(F);re&&ge&&!this.areRolloutsEqual(re,ge)&&i.add(F)}for(const F of a)o.has(F)||i.add(F);return i}areExperimentsEqual(e,t){return e.experimentId===t.experimentId&&e.variantId===t.variantId&&e.timeToLiveMillis===t.timeToLiveMillis&&e.triggerTimeoutMillis===t.triggerTimeoutMillis}areRolloutsEqual(e,t){if(e.size!==t.size)return!1;for(const[n,r]of e)if(t.get(n)!==r)return!1;return!0}createExperimentsMap(e){const t=new Map;for(const n of e)if(!(!n.affectedParameterKeys||n.experimentId.startsWith(my)))for(const r of n.affectedParameterKeys)t.set(r,n);return t}createRolloutsMap(e){const t=new Map;for(const n of e){const r=n.rolloutId,i=n.variantId,o=n.affectedParameterKeys||[];for(const a of o){let l=t.get(a);l||(l=new Map,t.set(a,l)),l.set(r,i)}}return t}async fetchLatestConfig(e,t){const n=e-1,r=wh-n,i=this.storageCache.getCustomSignals();i&&this.logger.debug(`Fetching config with custom signals: ${JSON.stringify(i)}`);const o=new dd;try{const a={cacheMaxAgeMillis:0,signal:o,customSignals:i,fetchType:"REALTIME",fetchAttempt:r},l=await this.storage.getLastSuccessfulFetchResponse(),c=await this.cachingClient.fetch(a);let h=await this.storage.getActiveConfig();if(!this.fetchResponseIsUpToDate(c,t)){this.logger.debug("Fetched template version is the same as SDK's current version. Retrying fetch."),await this.autoFetch(n,t);return}if(c.config==null){this.logger.debug("The fetch succeeded, but the backend had no updates.");return}h==null&&(h={});const f=this.getChangedParams(c.config,h,c,l);if(f.size===0){this.logger.debug("Config was fetched, but no params changed.");return}const d={getUpdatedKeys(){return new Set(f)}};this.executeAllListenerCallbacks(d)}catch(a){const l=a instanceof Error?a.message:String(a),c=xe.create("update-not-fetched",{originalErrorMessage:`Failed to auto-fetch config update: ${l}`});this.propagateError(c)}}async autoFetch(e,t){if(e===0){const i=xe.create("update-not-fetched",{originalErrorMessage:"Unable to fetch the latest version of the template."});this.propagateError(i);return}const r=this.getRandomInt(4)*1e3;await new Promise(i=>setTimeout(i,r)),await this.fetchLatestConfig(e,t)}async handleNotifications(e){let t,n="";for(;;){const{done:r,value:i}=await e.read();if(r)break;if(t=this.decoder.decode(i,{stream:!0}),n+=t,t.includes("}")){if(n=this.parseAndValidateConfigUpdateMessage(n),n.length===0)continue;try{const o=JSON.parse(n);if(this.isEventListenersEmpty())break;if(Ah in o&&o[Ah]===!0){const a=xe.create("realtime-unavailable",{originalErrorMessage:"The server is temporarily unavailable. Try again in a few minutes."});this.propagateError(a);break}if(Rh in o){const a=await this.storage.getActiveConfigTemplateVersion(),l=Number(o[Rh]);a&&l>a&&await this.autoFetch(wh,l)}if(vh in o){const a=Number(o[vh]);await this.updateBackoffMetadataWithRetryInterval(a)}}catch(o){this.logger.debug("Unable to parse latest config update message.",o);const a=o instanceof Error?o.message:String(o);this.propagateError(xe.create("update-message-invalid",{originalErrorMessage:a}))}n=""}}}async listenForNotifications(e){try{await this.handleNotifications(e)}catch{this.isInBackground||this.logger.debug("Real-time connection was closed due to an exception.")}}async prepareAndBeginRealtimeHttpStream(){if(!this.checkAndSetHttpConnectionFlagIfNotRunning())return;let e=await this.storage.getRealtimeBackoffMetadata();e||(e={backoffEndTimeMillis:new Date(Th),numFailedStreams:Ih});const t=e.backoffEndTimeMillis.getTime();if(Date.now()<t){await this.retryHttpConnectionWhenBackoffEnds();return}let n,r;try{if(n=await this.createRealtimeConnection(),r=n.status,n.ok&&n.body){this.resetRetryCount(),await this.resetRealtimeBackoff();const i=n.body.getReader();this.reader=i,await this.listenForNotifications(i)}}catch(i){this.isInBackground?this.resetRetryCount():this.logger.debug("Exception connecting to real-time RC backend. Retrying the connection...:",i)}finally{await this.closeRealtimeHttpConnection(),this.setIsHttpConnectionRunning(!1);const i=!this.isInBackground&&(r===void 0||this.isStatusCodeRetryable(r));if(i&&await this.updateBackoffMetadataWithLastFailedStreamConnectionTime(new Date),i||n!=null&&n.ok)await this.retryHttpConnectionWhenBackoffEnds();else{const o=`Unable to connect to the server. HTTP status code: ${r}`,a=xe.create("stream-error",{originalErrorMessage:o});this.propagateError(a)}}}canEstablishStreamConnection(){const e=this.observers.size>0,t=!this.isRealtimeDisabled,n=!this.isConnectionActive,r=!this.isInBackground;return e&&t&&n&&r}async makeRealtimeHttpConnection(e){if(this.canEstablishStreamConnection()){if(this.httpRetriesRemaining>0)this.httpRetriesRemaining--,await new Promise(t=>setTimeout(t,e)),this.prepareAndBeginRealtimeHttpStream();else if(!this.isInBackground){const t=xe.create("stream-error",{originalErrorMessage:"Unable to connect to the server. Check your connection and try again."});this.propagateError(t)}}}async beginRealtime(){this.observers.size>0&&await this.makeRealtimeHttpConnection(0)}addObserver(e){this.observers.add(e),this.beginRealtime()}removeObserver(e){this.observers.has(e)&&this.observers.delete(e)}async onVisibilityChange(e){this.isInBackground=!e,e?e&&await this.beginRealtime():await this.closeRealtimeHttpConnection()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ey(){jn(new gn(pd,s,"PUBLIC").setMultipleInstances(!0)),Mt(IB,Eh),Mt(IB,Eh,"esm2020");function s(e,{options:t}){const n=e.getProvider("app").getImmediate(),r=e.getProvider("installations-internal").getImmediate(),i=e.getProvider("analytics-internal"),{projectId:o,apiKey:a,appId:l}=n.options;if(!o)throw xe.create("registration-project-id");if(!a)throw xe.create("registration-api-key");if(!l)throw xe.create("registration-app-id");const c=(t==null?void 0:t.templateId)||"firebase",h=GC()?new uy(l,n.name,c):new hy,f=new fy(h),d=new da(IB);d.logLevel=Be.ERROR;const _=new ty(r,qo,c,o,a,l),y=new ry(_,h),N=new ZD(y,h,f,d),F=new _y(r,h,qo,c,o,a,l,d,f,N),J=new ay(n,N,f,h,d,F,i);return $D(J),J}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function U0(s){return s=qe(s),await XD(s),YD(s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ey();var Sh=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Vn,Ed;(function(){var s;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(v,E){function w(){}w.prototype=E.prototype,v.F=E.prototype,v.prototype=new w,v.prototype.constructor=v,v.D=function(R,A,b){for(var D=Array(arguments.length-2),gt=2;gt<arguments.length;gt++)D[gt-2]=arguments[gt];return E.prototype[A].apply(R,D)}}function t(){this.blockSize=-1}function n(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(n,t),n.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function r(v,E,w){w||(w=0);const R=Array(16);if(typeof E=="string")for(var A=0;A<16;++A)R[A]=E.charCodeAt(w++)|E.charCodeAt(w++)<<8|E.charCodeAt(w++)<<16|E.charCodeAt(w++)<<24;else for(A=0;A<16;++A)R[A]=E[w++]|E[w++]<<8|E[w++]<<16|E[w++]<<24;E=v.g[0],w=v.g[1],A=v.g[2];let b=v.g[3],D;D=E+(b^w&(A^b))+R[0]+3614090360&4294967295,E=w+(D<<7&4294967295|D>>>25),D=b+(A^E&(w^A))+R[1]+3905402710&4294967295,b=E+(D<<12&4294967295|D>>>20),D=A+(w^b&(E^w))+R[2]+606105819&4294967295,A=b+(D<<17&4294967295|D>>>15),D=w+(E^A&(b^E))+R[3]+3250441966&4294967295,w=A+(D<<22&4294967295|D>>>10),D=E+(b^w&(A^b))+R[4]+4118548399&4294967295,E=w+(D<<7&4294967295|D>>>25),D=b+(A^E&(w^A))+R[5]+1200080426&4294967295,b=E+(D<<12&4294967295|D>>>20),D=A+(w^b&(E^w))+R[6]+2821735955&4294967295,A=b+(D<<17&4294967295|D>>>15),D=w+(E^A&(b^E))+R[7]+4249261313&4294967295,w=A+(D<<22&4294967295|D>>>10),D=E+(b^w&(A^b))+R[8]+1770035416&4294967295,E=w+(D<<7&4294967295|D>>>25),D=b+(A^E&(w^A))+R[9]+2336552879&4294967295,b=E+(D<<12&4294967295|D>>>20),D=A+(w^b&(E^w))+R[10]+4294925233&4294967295,A=b+(D<<17&4294967295|D>>>15),D=w+(E^A&(b^E))+R[11]+2304563134&4294967295,w=A+(D<<22&4294967295|D>>>10),D=E+(b^w&(A^b))+R[12]+1804603682&4294967295,E=w+(D<<7&4294967295|D>>>25),D=b+(A^E&(w^A))+R[13]+4254626195&4294967295,b=E+(D<<12&4294967295|D>>>20),D=A+(w^b&(E^w))+R[14]+2792965006&4294967295,A=b+(D<<17&4294967295|D>>>15),D=w+(E^A&(b^E))+R[15]+1236535329&4294967295,w=A+(D<<22&4294967295|D>>>10),D=E+(A^b&(w^A))+R[1]+4129170786&4294967295,E=w+(D<<5&4294967295|D>>>27),D=b+(w^A&(E^w))+R[6]+3225465664&4294967295,b=E+(D<<9&4294967295|D>>>23),D=A+(E^w&(b^E))+R[11]+643717713&4294967295,A=b+(D<<14&4294967295|D>>>18),D=w+(b^E&(A^b))+R[0]+3921069994&4294967295,w=A+(D<<20&4294967295|D>>>12),D=E+(A^b&(w^A))+R[5]+3593408605&4294967295,E=w+(D<<5&4294967295|D>>>27),D=b+(w^A&(E^w))+R[10]+38016083&4294967295,b=E+(D<<9&4294967295|D>>>23),D=A+(E^w&(b^E))+R[15]+3634488961&4294967295,A=b+(D<<14&4294967295|D>>>18),D=w+(b^E&(A^b))+R[4]+3889429448&4294967295,w=A+(D<<20&4294967295|D>>>12),D=E+(A^b&(w^A))+R[9]+568446438&4294967295,E=w+(D<<5&4294967295|D>>>27),D=b+(w^A&(E^w))+R[14]+3275163606&4294967295,b=E+(D<<9&4294967295|D>>>23),D=A+(E^w&(b^E))+R[3]+4107603335&4294967295,A=b+(D<<14&4294967295|D>>>18),D=w+(b^E&(A^b))+R[8]+1163531501&4294967295,w=A+(D<<20&4294967295|D>>>12),D=E+(A^b&(w^A))+R[13]+2850285829&4294967295,E=w+(D<<5&4294967295|D>>>27),D=b+(w^A&(E^w))+R[2]+4243563512&4294967295,b=E+(D<<9&4294967295|D>>>23),D=A+(E^w&(b^E))+R[7]+1735328473&4294967295,A=b+(D<<14&4294967295|D>>>18),D=w+(b^E&(A^b))+R[12]+2368359562&4294967295,w=A+(D<<20&4294967295|D>>>12),D=E+(w^A^b)+R[5]+4294588738&4294967295,E=w+(D<<4&4294967295|D>>>28),D=b+(E^w^A)+R[8]+2272392833&4294967295,b=E+(D<<11&4294967295|D>>>21),D=A+(b^E^w)+R[11]+1839030562&4294967295,A=b+(D<<16&4294967295|D>>>16),D=w+(A^b^E)+R[14]+4259657740&4294967295,w=A+(D<<23&4294967295|D>>>9),D=E+(w^A^b)+R[1]+2763975236&4294967295,E=w+(D<<4&4294967295|D>>>28),D=b+(E^w^A)+R[4]+1272893353&4294967295,b=E+(D<<11&4294967295|D>>>21),D=A+(b^E^w)+R[7]+4139469664&4294967295,A=b+(D<<16&4294967295|D>>>16),D=w+(A^b^E)+R[10]+3200236656&4294967295,w=A+(D<<23&4294967295|D>>>9),D=E+(w^A^b)+R[13]+681279174&4294967295,E=w+(D<<4&4294967295|D>>>28),D=b+(E^w^A)+R[0]+3936430074&4294967295,b=E+(D<<11&4294967295|D>>>21),D=A+(b^E^w)+R[3]+3572445317&4294967295,A=b+(D<<16&4294967295|D>>>16),D=w+(A^b^E)+R[6]+76029189&4294967295,w=A+(D<<23&4294967295|D>>>9),D=E+(w^A^b)+R[9]+3654602809&4294967295,E=w+(D<<4&4294967295|D>>>28),D=b+(E^w^A)+R[12]+3873151461&4294967295,b=E+(D<<11&4294967295|D>>>21),D=A+(b^E^w)+R[15]+530742520&4294967295,A=b+(D<<16&4294967295|D>>>16),D=w+(A^b^E)+R[2]+3299628645&4294967295,w=A+(D<<23&4294967295|D>>>9),D=E+(A^(w|~b))+R[0]+4096336452&4294967295,E=w+(D<<6&4294967295|D>>>26),D=b+(w^(E|~A))+R[7]+1126891415&4294967295,b=E+(D<<10&4294967295|D>>>22),D=A+(E^(b|~w))+R[14]+2878612391&4294967295,A=b+(D<<15&4294967295|D>>>17),D=w+(b^(A|~E))+R[5]+4237533241&4294967295,w=A+(D<<21&4294967295|D>>>11),D=E+(A^(w|~b))+R[12]+1700485571&4294967295,E=w+(D<<6&4294967295|D>>>26),D=b+(w^(E|~A))+R[3]+2399980690&4294967295,b=E+(D<<10&4294967295|D>>>22),D=A+(E^(b|~w))+R[10]+4293915773&4294967295,A=b+(D<<15&4294967295|D>>>17),D=w+(b^(A|~E))+R[1]+2240044497&4294967295,w=A+(D<<21&4294967295|D>>>11),D=E+(A^(w|~b))+R[8]+1873313359&4294967295,E=w+(D<<6&4294967295|D>>>26),D=b+(w^(E|~A))+R[15]+4264355552&4294967295,b=E+(D<<10&4294967295|D>>>22),D=A+(E^(b|~w))+R[6]+2734768916&4294967295,A=b+(D<<15&4294967295|D>>>17),D=w+(b^(A|~E))+R[13]+1309151649&4294967295,w=A+(D<<21&4294967295|D>>>11),D=E+(A^(w|~b))+R[4]+4149444226&4294967295,E=w+(D<<6&4294967295|D>>>26),D=b+(w^(E|~A))+R[11]+3174756917&4294967295,b=E+(D<<10&4294967295|D>>>22),D=A+(E^(b|~w))+R[2]+718787259&4294967295,A=b+(D<<15&4294967295|D>>>17),D=w+(b^(A|~E))+R[9]+3951481745&4294967295,v.g[0]=v.g[0]+E&4294967295,v.g[1]=v.g[1]+(A+(D<<21&4294967295|D>>>11))&4294967295,v.g[2]=v.g[2]+A&4294967295,v.g[3]=v.g[3]+b&4294967295}n.prototype.v=function(v,E){E===void 0&&(E=v.length);const w=E-this.blockSize,R=this.C;let A=this.h,b=0;for(;b<E;){if(A==0)for(;b<=w;)r(this,v,b),b+=this.blockSize;if(typeof v=="string"){for(;b<E;)if(R[A++]=v.charCodeAt(b++),A==this.blockSize){r(this,R),A=0;break}}else for(;b<E;)if(R[A++]=v[b++],A==this.blockSize){r(this,R),A=0;break}}this.h=A,this.o+=E},n.prototype.A=function(){var v=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);v[0]=128;for(var E=1;E<v.length-8;++E)v[E]=0;E=this.o*8;for(var w=v.length-8;w<v.length;++w)v[w]=E&255,E/=256;for(this.v(v),v=Array(16),E=0,w=0;w<4;++w)for(let R=0;R<32;R+=8)v[E++]=this.g[w]>>>R&255;return v};function i(v,E){var w=a;return Object.prototype.hasOwnProperty.call(w,v)?w[v]:w[v]=E(v)}function o(v,E){this.h=E;const w=[];let R=!0;for(let A=v.length-1;A>=0;A--){const b=v[A]|0;R&&b==E||(w[A]=b,R=!1)}this.g=w}var a={};function l(v){return-128<=v&&v<128?i(v,function(E){return new o([E|0],E<0?-1:0)}):new o([v|0],v<0?-1:0)}function c(v){if(isNaN(v)||!isFinite(v))return f;if(v<0)return F(c(-v));const E=[];let w=1;for(let R=0;v>=w;R++)E[R]=v/w|0,w*=4294967296;return new o(E,0)}function h(v,E){if(v.length==0)throw Error("number format error: empty string");if(E=E||10,E<2||36<E)throw Error("radix out of range: "+E);if(v.charAt(0)=="-")return F(h(v.substring(1),E));if(v.indexOf("-")>=0)throw Error('number format error: interior "-" character');const w=c(Math.pow(E,8));let R=f;for(let b=0;b<v.length;b+=8){var A=Math.min(8,v.length-b);const D=parseInt(v.substring(b,b+A),E);A<8?(A=c(Math.pow(E,A)),R=R.j(A).add(c(D))):(R=R.j(w),R=R.add(c(D)))}return R}var f=l(0),d=l(1),_=l(16777216);s=o.prototype,s.m=function(){if(N(this))return-F(this).m();let v=0,E=1;for(let w=0;w<this.g.length;w++){const R=this.i(w);v+=(R>=0?R:4294967296+R)*E,E*=4294967296}return v},s.toString=function(v){if(v=v||10,v<2||36<v)throw Error("radix out of range: "+v);if(y(this))return"0";if(N(this))return"-"+F(this).toString(v);const E=c(Math.pow(v,6));var w=this;let R="";for(;;){const A=ge(w,E).g;w=J(w,A.j(E));let b=((w.g.length>0?w.g[0]:w.h)>>>0).toString(v);if(w=A,y(w))return b+R;for(;b.length<6;)b="0"+b;R=b+R}},s.i=function(v){return v<0?0:v<this.g.length?this.g[v]:this.h};function y(v){if(v.h!=0)return!1;for(let E=0;E<v.g.length;E++)if(v.g[E]!=0)return!1;return!0}function N(v){return v.h==-1}s.l=function(v){return v=J(this,v),N(v)?-1:y(v)?0:1};function F(v){const E=v.g.length,w=[];for(let R=0;R<E;R++)w[R]=~v.g[R];return new o(w,~v.h).add(d)}s.abs=function(){return N(this)?F(this):this},s.add=function(v){const E=Math.max(this.g.length,v.g.length),w=[];let R=0;for(let A=0;A<=E;A++){let b=R+(this.i(A)&65535)+(v.i(A)&65535),D=(b>>>16)+(this.i(A)>>>16)+(v.i(A)>>>16);R=D>>>16,b&=65535,D&=65535,w[A]=D<<16|b}return new o(w,w[w.length-1]&-2147483648?-1:0)};function J(v,E){return v.add(F(E))}s.j=function(v){if(y(this)||y(v))return f;if(N(this))return N(v)?F(this).j(F(v)):F(F(this).j(v));if(N(v))return F(this.j(F(v)));if(this.l(_)<0&&v.l(_)<0)return c(this.m()*v.m());const E=this.g.length+v.g.length,w=[];for(var R=0;R<2*E;R++)w[R]=0;for(R=0;R<this.g.length;R++)for(let A=0;A<v.g.length;A++){const b=this.i(R)>>>16,D=this.i(R)&65535,gt=v.i(A)>>>16,os=v.i(A)&65535;w[2*R+2*A]+=D*os,te(w,2*R+2*A),w[2*R+2*A+1]+=b*os,te(w,2*R+2*A+1),w[2*R+2*A+1]+=D*gt,te(w,2*R+2*A+1),w[2*R+2*A+2]+=b*gt,te(w,2*R+2*A+2)}for(v=0;v<E;v++)w[v]=w[2*v+1]<<16|w[2*v];for(v=E;v<2*E;v++)w[v]=0;return new o(w,0)};function te(v,E){for(;(v[E]&65535)!=v[E];)v[E+1]+=v[E]>>>16,v[E]&=65535,E++}function re(v,E){this.g=v,this.h=E}function ge(v,E){if(y(E))throw Error("division by zero");if(y(v))return new re(f,f);if(N(v))return E=ge(F(v),E),new re(F(E.g),F(E.h));if(N(E))return E=ge(v,F(E)),new re(F(E.g),E.h);if(v.g.length>30){if(N(v)||N(E))throw Error("slowDivide_ only works with positive integers.");for(var w=d,R=E;R.l(v)<=0;)w=Le(w),R=Le(R);var A=Fe(w,1),b=Fe(R,1);for(R=Fe(R,2),w=Fe(w,2);!y(R);){var D=b.add(R);D.l(v)<=0&&(A=A.add(w),b=D),R=Fe(R,1),w=Fe(w,1)}return E=J(v,A.j(E)),new re(A,E)}for(A=f;v.l(E)>=0;){for(w=Math.max(1,Math.floor(v.m()/E.m())),R=Math.ceil(Math.log(w)/Math.LN2),R=R<=48?1:Math.pow(2,R-48),b=c(w),D=b.j(E);N(D)||D.l(v)>0;)w-=R,b=c(w),D=b.j(E);y(b)&&(b=d),A=A.add(b),v=J(v,D)}return new re(A,v)}s.B=function(v){return ge(this,v).h},s.and=function(v){const E=Math.max(this.g.length,v.g.length),w=[];for(let R=0;R<E;R++)w[R]=this.i(R)&v.i(R);return new o(w,this.h&v.h)},s.or=function(v){const E=Math.max(this.g.length,v.g.length),w=[];for(let R=0;R<E;R++)w[R]=this.i(R)|v.i(R);return new o(w,this.h|v.h)},s.xor=function(v){const E=Math.max(this.g.length,v.g.length),w=[];for(let R=0;R<E;R++)w[R]=this.i(R)^v.i(R);return new o(w,this.h^v.h)};function Le(v){const E=v.g.length+1,w=[];for(let R=0;R<E;R++)w[R]=v.i(R)<<1|v.i(R-1)>>>31;return new o(w,v.h)}function Fe(v,E){const w=E>>5;E%=32;const R=v.g.length-w,A=[];for(let b=0;b<R;b++)A[b]=E>0?v.i(b+w)>>>E|v.i(b+w+1)<<32-E:v.i(b+w);return new o(A,v.h)}n.prototype.digest=n.prototype.A,n.prototype.reset=n.prototype.u,n.prototype.update=n.prototype.v,Ed=n,o.prototype.add=o.prototype.add,o.prototype.multiply=o.prototype.j,o.prototype.modulo=o.prototype.B,o.prototype.compare=o.prototype.l,o.prototype.toNumber=o.prototype.m,o.prototype.toString=o.prototype.toString,o.prototype.getBits=o.prototype.i,o.fromNumber=c,o.fromString=h,Vn=o}).apply(typeof Sh<"u"?Sh:typeof self<"u"?self:typeof window<"u"?window:{});var Eo=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Dd,Xr,yd,Oo,XB,wd,Td,Id;(function(){var s,e=Object.defineProperty;function t(B){B=[typeof globalThis=="object"&&globalThis,B,typeof window=="object"&&window,typeof self=="object"&&self,typeof Eo=="object"&&Eo];for(var u=0;u<B.length;++u){var C=B[u];if(C&&C.Math==Math)return C}throw Error("Cannot find global object")}var n=t(this);function r(B,u){if(u)e:{var C=n;B=B.split(".");for(var p=0;p<B.length-1;p++){var S=B[p];if(!(S in C))break e;C=C[S]}B=B[B.length-1],p=C[B],u=u(p),u!=p&&u!=null&&e(C,B,{configurable:!0,writable:!0,value:u})}}r("Symbol.dispose",function(B){return B||Symbol("Symbol.dispose")}),r("Array.prototype.values",function(B){return B||function(){return this[Symbol.iterator]()}}),r("Object.entries",function(B){return B||function(u){var C=[],p;for(p in u)Object.prototype.hasOwnProperty.call(u,p)&&C.push([p,u[p]]);return C}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var i=i||{},o=this||self;function a(B){var u=typeof B;return u=="object"&&B!=null||u=="function"}function l(B,u,C){return B.call.apply(B.bind,arguments)}function c(B,u,C){return c=l,c.apply(null,arguments)}function h(B,u){var C=Array.prototype.slice.call(arguments,1);return function(){var p=C.slice();return p.push.apply(p,arguments),B.apply(this,p)}}function f(B,u){function C(){}C.prototype=u.prototype,B.Z=u.prototype,B.prototype=new C,B.prototype.constructor=B,B.Ob=function(p,S,P){for(var j=Array(arguments.length-2),ie=2;ie<arguments.length;ie++)j[ie-2]=arguments[ie];return u.prototype[S].apply(p,j)}}var d=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?B=>B&&AsyncContext.Snapshot.wrap(B):B=>B;function _(B){const u=B.length;if(u>0){const C=Array(u);for(let p=0;p<u;p++)C[p]=B[p];return C}return[]}function y(B,u){for(let p=1;p<arguments.length;p++){const S=arguments[p];var C=typeof S;if(C=C!="object"?C:S?Array.isArray(S)?"array":C:"null",C=="array"||C=="object"&&typeof S.length=="number"){C=B.length||0;const P=S.length||0;B.length=C+P;for(let j=0;j<P;j++)B[C+j]=S[j]}else B.push(S)}}class N{constructor(u,C){this.i=u,this.j=C,this.h=0,this.g=null}get(){let u;return this.h>0?(this.h--,u=this.g,this.g=u.next,u.next=null):u=this.i(),u}}function F(B){o.setTimeout(()=>{throw B},0)}function J(){var B=v;let u=null;return B.g&&(u=B.g,B.g=B.g.next,B.g||(B.h=null),u.next=null),u}class te{constructor(){this.h=this.g=null}add(u,C){const p=re.get();p.set(u,C),this.h?this.h.next=p:this.g=p,this.h=p}}var re=new N(()=>new ge,B=>B.reset());class ge{constructor(){this.next=this.g=this.h=null}set(u,C){this.h=u,this.g=C,this.next=null}reset(){this.next=this.g=this.h=null}}let Le,Fe=!1,v=new te,E=()=>{const B=Promise.resolve(void 0);Le=()=>{B.then(w)}};function w(){for(var B;B=J();){try{B.h.call(B.g)}catch(C){F(C)}var u=re;u.j(B),u.h<100&&(u.h++,B.next=u.g,u.g=B)}Fe=!1}function R(){this.u=this.u,this.C=this.C}R.prototype.u=!1,R.prototype.dispose=function(){this.u||(this.u=!0,this.N())},R.prototype[Symbol.dispose]=function(){this.dispose()},R.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function A(B,u){this.type=B,this.g=this.target=u,this.defaultPrevented=!1}A.prototype.h=function(){this.defaultPrevented=!0};var b=function(){if(!o.addEventListener||!Object.defineProperty)return!1;var B=!1,u=Object.defineProperty({},"passive",{get:function(){B=!0}});try{const C=()=>{};o.addEventListener("test",C,u),o.removeEventListener("test",C,u)}catch{}return B}();function D(B){return/^[\s\xa0]*$/.test(B)}function gt(B,u){A.call(this,B?B.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,B&&this.init(B,u)}f(gt,A),gt.prototype.init=function(B,u){const C=this.type=B.type,p=B.changedTouches&&B.changedTouches.length?B.changedTouches[0]:null;this.target=B.target||B.srcElement,this.g=u,u=B.relatedTarget,u||(C=="mouseover"?u=B.fromElement:C=="mouseout"&&(u=B.toElement)),this.relatedTarget=u,p?(this.clientX=p.clientX!==void 0?p.clientX:p.pageX,this.clientY=p.clientY!==void 0?p.clientY:p.pageY,this.screenX=p.screenX||0,this.screenY=p.screenY||0):(this.clientX=B.clientX!==void 0?B.clientX:B.pageX,this.clientY=B.clientY!==void 0?B.clientY:B.pageY,this.screenX=B.screenX||0,this.screenY=B.screenY||0),this.button=B.button,this.key=B.key||"",this.ctrlKey=B.ctrlKey,this.altKey=B.altKey,this.shiftKey=B.shiftKey,this.metaKey=B.metaKey,this.pointerId=B.pointerId||0,this.pointerType=B.pointerType,this.state=B.state,this.i=B,B.defaultPrevented&&gt.Z.h.call(this)},gt.prototype.h=function(){gt.Z.h.call(this);const B=this.i;B.preventDefault?B.preventDefault():B.returnValue=!1};var os="closure_listenable_"+(Math.random()*1e6|0),Mm=0;function Gm(B,u,C,p,S){this.listener=B,this.proxy=null,this.src=u,this.type=C,this.capture=!!p,this.ha=S,this.key=++Mm,this.da=this.fa=!1}function ro(B){B.da=!0,B.listener=null,B.proxy=null,B.src=null,B.ha=null}function io(B,u,C){for(const p in B)u.call(C,B[p],p,B)}function Hm(B,u){for(const C in B)u.call(void 0,B[C],C,B)}function ou(B){const u={};for(const C in B)u[C]=B[C];return u}const au="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function Bu(B,u){let C,p;for(let S=1;S<arguments.length;S++){p=arguments[S];for(C in p)B[C]=p[C];for(let P=0;P<au.length;P++)C=au[P],Object.prototype.hasOwnProperty.call(p,C)&&(B[C]=p[C])}}function oo(B){this.src=B,this.g={},this.h=0}oo.prototype.add=function(B,u,C,p,S){const P=B.toString();B=this.g[P],B||(B=this.g[P]=[],this.h++);const j=Ya(B,u,p,S);return j>-1?(u=B[j],C||(u.fa=!1)):(u=new Gm(u,this.src,P,!!p,S),u.fa=C,B.push(u)),u};function Wa(B,u){const C=u.type;if(C in B.g){var p=B.g[C],S=Array.prototype.indexOf.call(p,u,void 0),P;(P=S>=0)&&Array.prototype.splice.call(p,S,1),P&&(ro(u),B.g[C].length==0&&(delete B.g[C],B.h--))}}function Ya(B,u,C,p){for(let S=0;S<B.length;++S){const P=B[S];if(!P.da&&P.listener==u&&P.capture==!!C&&P.ha==p)return S}return-1}var $a="closure_lm_"+(Math.random()*1e6|0),Xa={};function lu(B,u,C,p,S){if(Array.isArray(u)){for(let P=0;P<u.length;P++)lu(B,u[P],C,p,S);return null}return C=hu(C),B&&B[os]?B.J(u,C,a(p)?!!p.capture:!1,S):Um(B,u,C,!1,p,S)}function Um(B,u,C,p,S,P){if(!u)throw Error("Invalid event type");const j=a(S)?!!S.capture:!!S;let ie=eB(B);if(ie||(B[$a]=ie=new oo(B)),C=ie.add(u,C,p,j,P),C.proxy)return C;if(p=qm(),C.proxy=p,p.src=B,p.listener=C,B.addEventListener)b||(S=j),S===void 0&&(S=!1),B.addEventListener(u.toString(),p,S);else if(B.attachEvent)B.attachEvent(uu(u.toString()),p);else if(B.addListener&&B.removeListener)B.addListener(p);else throw Error("addEventListener and attachEvent are unavailable.");return C}function qm(){function B(C){return u.call(B.src,B.listener,C)}const u=Jm;return B}function cu(B,u,C,p,S){if(Array.isArray(u))for(var P=0;P<u.length;P++)cu(B,u[P],C,p,S);else p=a(p)?!!p.capture:!!p,C=hu(C),B&&B[os]?(B=B.i,P=String(u).toString(),P in B.g&&(u=B.g[P],C=Ya(u,C,p,S),C>-1&&(ro(u[C]),Array.prototype.splice.call(u,C,1),u.length==0&&(delete B.g[P],B.h--)))):B&&(B=eB(B))&&(u=B.g[u.toString()],B=-1,u&&(B=Ya(u,C,p,S)),(C=B>-1?u[B]:null)&&Za(C))}function Za(B){if(typeof B!="number"&&B&&!B.da){var u=B.src;if(u&&u[os])Wa(u.i,B);else{var C=B.type,p=B.proxy;u.removeEventListener?u.removeEventListener(C,p,B.capture):u.detachEvent?u.detachEvent(uu(C),p):u.addListener&&u.removeListener&&u.removeListener(p),(C=eB(u))?(Wa(C,B),C.h==0&&(C.src=null,u[$a]=null)):ro(B)}}}function uu(B){return B in Xa?Xa[B]:Xa[B]="on"+B}function Jm(B,u){if(B.da)B=!0;else{u=new gt(u,this);const C=B.listener,p=B.ha||B.src;B.fa&&Za(B),B=C.call(p,u)}return B}function eB(B){return B=B[$a],B instanceof oo?B:null}var tB="__closure_events_fn_"+(Math.random()*1e9>>>0);function hu(B){return typeof B=="function"?B:(B[tB]||(B[tB]=function(u){return B.handleEvent(u)}),B[tB])}function it(){R.call(this),this.i=new oo(this),this.M=this,this.G=null}f(it,R),it.prototype[os]=!0,it.prototype.removeEventListener=function(B,u,C,p){cu(this,B,u,C,p)};function ft(B,u){var C,p=B.G;if(p)for(C=[];p;p=p.G)C.push(p);if(B=B.M,p=u.type||u,typeof u=="string")u=new A(u,B);else if(u instanceof A)u.target=u.target||B;else{var S=u;u=new A(p,B),Bu(u,S)}S=!0;let P,j;if(C)for(j=C.length-1;j>=0;j--)P=u.g=C[j],S=ao(P,p,!0,u)&&S;if(P=u.g=B,S=ao(P,p,!0,u)&&S,S=ao(P,p,!1,u)&&S,C)for(j=0;j<C.length;j++)P=u.g=C[j],S=ao(P,p,!1,u)&&S}it.prototype.N=function(){if(it.Z.N.call(this),this.i){var B=this.i;for(const u in B.g){const C=B.g[u];for(let p=0;p<C.length;p++)ro(C[p]);delete B.g[u],B.h--}}this.G=null},it.prototype.J=function(B,u,C,p){return this.i.add(String(B),u,!1,C,p)},it.prototype.K=function(B,u,C,p){return this.i.add(String(B),u,!0,C,p)};function ao(B,u,C,p){if(u=B.i.g[String(u)],!u)return!0;u=u.concat();let S=!0;for(let P=0;P<u.length;++P){const j=u[P];if(j&&!j.da&&j.capture==C){const ie=j.listener,Ke=j.ha||j.src;j.fa&&Wa(B.i,j),S=ie.call(Ke,p)!==!1&&S}}return S&&!p.defaultPrevented}function jm(B,u){if(typeof B!="function")if(B&&typeof B.handleEvent=="function")B=c(B.handleEvent,B);else throw Error("Invalid listener argument");return Number(u)>2147483647?-1:o.setTimeout(B,u||0)}function fu(B){B.g=jm(()=>{B.g=null,B.i&&(B.i=!1,fu(B))},B.l);const u=B.h;B.h=null,B.m.apply(null,u)}class Km extends R{constructor(u,C){super(),this.m=u,this.l=C,this.h=null,this.i=!1,this.g=null}j(u){this.h=arguments,this.g?this.i=!0:fu(this)}N(){super.N(),this.g&&(o.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function br(B){R.call(this),this.h=B,this.g={}}f(br,R);var Cu=[];function du(B){io(B.g,function(u,C){this.g.hasOwnProperty(C)&&Za(u)},B),B.g={}}br.prototype.N=function(){br.Z.N.call(this),du(this)},br.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var nB=o.JSON.stringify,zm=o.JSON.parse,Qm=class{stringify(B){return o.JSON.stringify(B,void 0)}parse(B){return o.JSON.parse(B,void 0)}};function pu(){}function gu(){}var Nr={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function sB(){A.call(this,"d")}f(sB,A);function rB(){A.call(this,"c")}f(rB,A);var as={},mu=null;function Bo(){return mu=mu||new it}as.Ia="serverreachability";function _u(B){A.call(this,as.Ia,B)}f(_u,A);function Pr(B){const u=Bo();ft(u,new _u(u))}as.STAT_EVENT="statevent";function Eu(B,u){A.call(this,as.STAT_EVENT,B),this.stat=u}f(Eu,A);function Ct(B){const u=Bo();ft(u,new Eu(u,B))}as.Ja="timingevent";function Du(B,u){A.call(this,as.Ja,B),this.size=u}f(Du,A);function Fr(B,u){if(typeof B!="function")throw Error("Fn must not be null and must be a function");return o.setTimeout(function(){B()},u)}function Or(){this.g=!0}Or.prototype.ua=function(){this.g=!1};function Wm(B,u,C,p,S,P){B.info(function(){if(B.g)if(P){var j="",ie=P.split("&");for(let De=0;De<ie.length;De++){var Ke=ie[De].split("=");if(Ke.length>1){const Qe=Ke[0];Ke=Ke[1];const $t=Qe.split("_");j=$t.length>=2&&$t[1]=="type"?j+(Qe+"="+Ke+"&"):j+(Qe+"=redacted&")}}}else j=null;else j=P;return"XMLHTTP REQ ("+p+") [attempt "+S+"]: "+u+`
`+C+`
`+j})}function Ym(B,u,C,p,S,P,j){B.info(function(){return"XMLHTTP RESP ("+p+") [ attempt "+S+"]: "+u+`
`+C+`
`+P+" "+j})}function Vs(B,u,C,p){B.info(function(){return"XMLHTTP TEXT ("+u+"): "+Xm(B,C)+(p?" "+p:"")})}function $m(B,u){B.info(function(){return"TIMEOUT: "+u})}Or.prototype.info=function(){};function Xm(B,u){if(!B.g)return u;if(!u)return null;try{const P=JSON.parse(u);if(P){for(B=0;B<P.length;B++)if(Array.isArray(P[B])){var C=P[B];if(!(C.length<2)){var p=C[1];if(Array.isArray(p)&&!(p.length<1)){var S=p[0];if(S!="noop"&&S!="stop"&&S!="close")for(let j=1;j<p.length;j++)p[j]=""}}}}return nB(P)}catch{return u}}var lo={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},yu={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},wu;function iB(){}f(iB,pu),iB.prototype.g=function(){return new XMLHttpRequest},wu=new iB;function Lr(B){return encodeURIComponent(String(B))}function Zm(B){var u=1;B=B.split(":");const C=[];for(;u>0&&B.length;)C.push(B.shift()),u--;return B.length&&C.push(B.join(":")),C}function Tn(B,u,C,p){this.j=B,this.i=u,this.l=C,this.S=p||1,this.V=new br(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Tu}function Tu(){this.i=null,this.g="",this.h=!1}var Iu={},oB={};function aB(B,u,C){B.M=1,B.A=uo(Yt(u)),B.u=C,B.R=!0,Au(B,null)}function Au(B,u){B.F=Date.now(),co(B),B.B=Yt(B.A);var C=B.B,p=B.S;Array.isArray(p)||(p=[String(p)]),Mu(C.i,"t",p),B.C=0,C=B.j.L,B.h=new Tu,B.g=sh(B.j,C?u:null,!B.u),B.P>0&&(B.O=new Km(c(B.Y,B,B.g),B.P)),u=B.V,C=B.g,p=B.ba;var S="readystatechange";Array.isArray(S)||(S&&(Cu[0]=S.toString()),S=Cu);for(let P=0;P<S.length;P++){const j=lu(C,S[P],p||u.handleEvent,!1,u.h||u);if(!j)break;u.g[j.key]=j}u=B.J?ou(B.J):{},B.u?(B.v||(B.v="POST"),u["Content-Type"]="application/x-www-form-urlencoded",B.g.ea(B.B,B.v,B.u,u)):(B.v="GET",B.g.ea(B.B,B.v,null,u)),Pr(),Wm(B.i,B.v,B.B,B.l,B.S,B.u)}Tn.prototype.ba=function(B){B=B.target;const u=this.O;u&&vn(B)==3?u.j():this.Y(B)},Tn.prototype.Y=function(B){try{if(B==this.g)e:{const ie=vn(this.g),Ke=this.g.ya(),De=this.g.ca();if(!(ie<3)&&(ie!=3||this.g&&(this.h.h||this.g.la()||Ku(this.g)))){this.K||ie!=4||Ke==7||(Ke==8||De<=0?Pr(3):Pr(2)),BB(this);var u=this.g.ca();this.X=u;var C=e_(this);if(this.o=u==200,Ym(this.i,this.v,this.B,this.l,this.S,ie,u),this.o){if(this.U&&!this.L){t:{if(this.g){var p,S=this.g;if((p=S.g?S.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!D(p)){var P=p;break t}}P=null}if(B=P)Vs(this.i,this.l,B,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,lB(this,B);else{this.o=!1,this.m=3,Ct(12),Bs(this),xr(this);break e}}if(this.R){B=!0;let Qe;for(;!this.K&&this.C<C.length;)if(Qe=t_(this,C),Qe==oB){ie==4&&(this.m=4,Ct(14),B=!1),Vs(this.i,this.l,null,"[Incomplete Response]");break}else if(Qe==Iu){this.m=4,Ct(15),Vs(this.i,this.l,C,"[Invalid Chunk]"),B=!1;break}else Vs(this.i,this.l,Qe,null),lB(this,Qe);if(vu(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),ie!=4||C.length!=0||this.h.h||(this.m=1,Ct(16),B=!1),this.o=this.o&&B,!B)Vs(this.i,this.l,C,"[Invalid Chunked Response]"),Bs(this),xr(this);else if(C.length>0&&!this.W){this.W=!0;var j=this.j;j.g==this&&j.aa&&!j.P&&(j.j.info("Great, no buffering proxy detected. Bytes received: "+C.length),gB(j),j.P=!0,Ct(11))}}else Vs(this.i,this.l,C,null),lB(this,C);ie==4&&Bs(this),this.o&&!this.K&&(ie==4?Zu(this.j,this):(this.o=!1,co(this)))}else d_(this.g),u==400&&C.indexOf("Unknown SID")>0?(this.m=3,Ct(12)):(this.m=0,Ct(13)),Bs(this),xr(this)}}}catch{}finally{}};function e_(B){if(!vu(B))return B.g.la();const u=Ku(B.g);if(u==="")return"";let C="";const p=u.length,S=vn(B.g)==4;if(!B.h.i){if(typeof TextDecoder>"u")return Bs(B),xr(B),"";B.h.i=new o.TextDecoder}for(let P=0;P<p;P++)B.h.h=!0,C+=B.h.i.decode(u[P],{stream:!(S&&P==p-1)});return u.length=0,B.h.g+=C,B.C=0,B.h.g}function vu(B){return B.g?B.v=="GET"&&B.M!=2&&B.j.Aa:!1}function t_(B,u){var C=B.C,p=u.indexOf(`
`,C);return p==-1?oB:(C=Number(u.substring(C,p)),isNaN(C)?Iu:(p+=1,p+C>u.length?oB:(u=u.slice(p,p+C),B.C=p+C,u)))}Tn.prototype.cancel=function(){this.K=!0,Bs(this)};function co(B){B.T=Date.now()+B.H,Ru(B,B.H)}function Ru(B,u){if(B.D!=null)throw Error("WatchDog timer not null");B.D=Fr(c(B.aa,B),u)}function BB(B){B.D&&(o.clearTimeout(B.D),B.D=null)}Tn.prototype.aa=function(){this.D=null;const B=Date.now();B-this.T>=0?($m(this.i,this.B),this.M!=2&&(Pr(),Ct(17)),Bs(this),this.m=2,xr(this)):Ru(this,this.T-B)};function xr(B){B.j.I==0||B.K||Zu(B.j,B)}function Bs(B){BB(B);var u=B.O;u&&typeof u.dispose=="function"&&u.dispose(),B.O=null,du(B.V),B.g&&(u=B.g,B.g=null,u.abort(),u.dispose())}function lB(B,u){try{var C=B.j;if(C.I!=0&&(C.g==B||cB(C.h,B))){if(!B.L&&cB(C.h,B)&&C.I==3){try{var p=C.Ba.g.parse(u)}catch{p=null}if(Array.isArray(p)&&p.length==3){var S=p;if(S[0]==0){e:if(!C.v){if(C.g)if(C.g.F+3e3<B.F)go(C),Co(C);else break e;pB(C),Ct(18)}}else C.xa=S[1],0<C.xa-C.K&&S[2]<37500&&C.F&&C.A==0&&!C.C&&(C.C=Fr(c(C.Va,C),6e3));Nu(C.h)<=1&&C.ta&&(C.ta=void 0)}else cs(C,11)}else if((B.L||C.g==B)&&go(C),!D(u))for(S=C.Ba.g.parse(u),u=0;u<S.length;u++){let De=S[u];const Qe=De[0];if(!(Qe<=C.K))if(C.K=Qe,De=De[1],C.I==2)if(De[0]=="c"){C.M=De[1],C.ba=De[2];const $t=De[3];$t!=null&&(C.ka=$t,C.j.info("VER="+C.ka));const us=De[4];us!=null&&(C.za=us,C.j.info("SVER="+C.za));const Rn=De[5];Rn!=null&&typeof Rn=="number"&&Rn>0&&(p=1.5*Rn,C.O=p,C.j.info("backChannelRequestTimeoutMs_="+p)),p=C;const Sn=B.g;if(Sn){const _o=Sn.g?Sn.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(_o){var P=p.h;P.g||_o.indexOf("spdy")==-1&&_o.indexOf("quic")==-1&&_o.indexOf("h2")==-1||(P.j=P.l,P.g=new Set,P.h&&(uB(P,P.h),P.h=null))}if(p.G){const mB=Sn.g?Sn.g.getResponseHeader("X-HTTP-Session-Id"):null;mB&&(p.wa=mB,Ie(p.J,p.G,mB))}}C.I=3,C.l&&C.l.ra(),C.aa&&(C.T=Date.now()-B.F,C.j.info("Handshake RTT: "+C.T+"ms")),p=C;var j=B;if(p.na=nh(p,p.L?p.ba:null,p.W),j.L){Pu(p.h,j);var ie=j,Ke=p.O;Ke&&(ie.H=Ke),ie.D&&(BB(ie),co(ie)),p.g=j}else $u(p);C.i.length>0&&po(C)}else De[0]!="stop"&&De[0]!="close"||cs(C,7);else C.I==3&&(De[0]=="stop"||De[0]=="close"?De[0]=="stop"?cs(C,7):dB(C):De[0]!="noop"&&C.l&&C.l.qa(De),C.A=0)}}Pr(4)}catch{}}var n_=class{constructor(B,u){this.g=B,this.map=u}};function Su(B){this.l=B||10,o.PerformanceNavigationTiming?(B=o.performance.getEntriesByType("navigation"),B=B.length>0&&(B[0].nextHopProtocol=="hq"||B[0].nextHopProtocol=="h2")):B=!!(o.chrome&&o.chrome.loadTimes&&o.chrome.loadTimes()&&o.chrome.loadTimes().wasFetchedViaSpdy),this.j=B?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function bu(B){return B.h?!0:B.g?B.g.size>=B.j:!1}function Nu(B){return B.h?1:B.g?B.g.size:0}function cB(B,u){return B.h?B.h==u:B.g?B.g.has(u):!1}function uB(B,u){B.g?B.g.add(u):B.h=u}function Pu(B,u){B.h&&B.h==u?B.h=null:B.g&&B.g.has(u)&&B.g.delete(u)}Su.prototype.cancel=function(){if(this.i=Fu(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const B of this.g.values())B.cancel();this.g.clear()}};function Fu(B){if(B.h!=null)return B.i.concat(B.h.G);if(B.g!=null&&B.g.size!==0){let u=B.i;for(const C of B.g.values())u=u.concat(C.G);return u}return _(B.i)}var Ou=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function s_(B,u){if(B){B=B.split("&");for(let C=0;C<B.length;C++){const p=B[C].indexOf("=");let S,P=null;p>=0?(S=B[C].substring(0,p),P=B[C].substring(p+1)):S=B[C],u(S,P?decodeURIComponent(P.replace(/\+/g," ")):"")}}}function In(B){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let u;B instanceof In?(this.l=B.l,kr(this,B.j),this.o=B.o,this.g=B.g,Vr(this,B.u),this.h=B.h,hB(this,Gu(B.i)),this.m=B.m):B&&(u=String(B).match(Ou))?(this.l=!1,kr(this,u[1]||"",!0),this.o=Mr(u[2]||""),this.g=Mr(u[3]||"",!0),Vr(this,u[4]),this.h=Mr(u[5]||"",!0),hB(this,u[6]||"",!0),this.m=Mr(u[7]||"")):(this.l=!1,this.i=new Hr(null,this.l))}In.prototype.toString=function(){const B=[];var u=this.j;u&&B.push(Gr(u,Lu,!0),":");var C=this.g;return(C||u=="file")&&(B.push("//"),(u=this.o)&&B.push(Gr(u,Lu,!0),"@"),B.push(Lr(C).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),C=this.u,C!=null&&B.push(":",String(C))),(C=this.h)&&(this.g&&C.charAt(0)!="/"&&B.push("/"),B.push(Gr(C,C.charAt(0)=="/"?o_:i_,!0))),(C=this.i.toString())&&B.push("?",C),(C=this.m)&&B.push("#",Gr(C,B_)),B.join("")},In.prototype.resolve=function(B){const u=Yt(this);let C=!!B.j;C?kr(u,B.j):C=!!B.o,C?u.o=B.o:C=!!B.g,C?u.g=B.g:C=B.u!=null;var p=B.h;if(C)Vr(u,B.u);else if(C=!!B.h){if(p.charAt(0)!="/")if(this.g&&!this.h)p="/"+p;else{var S=u.h.lastIndexOf("/");S!=-1&&(p=u.h.slice(0,S+1)+p)}if(S=p,S==".."||S==".")p="";else if(S.indexOf("./")!=-1||S.indexOf("/.")!=-1){p=S.lastIndexOf("/",0)==0,S=S.split("/");const P=[];for(let j=0;j<S.length;){const ie=S[j++];ie=="."?p&&j==S.length&&P.push(""):ie==".."?((P.length>1||P.length==1&&P[0]!="")&&P.pop(),p&&j==S.length&&P.push("")):(P.push(ie),p=!0)}p=P.join("/")}else p=S}return C?u.h=p:C=B.i.toString()!=="",C?hB(u,Gu(B.i)):C=!!B.m,C&&(u.m=B.m),u};function Yt(B){return new In(B)}function kr(B,u,C){B.j=C?Mr(u,!0):u,B.j&&(B.j=B.j.replace(/:$/,""))}function Vr(B,u){if(u){if(u=Number(u),isNaN(u)||u<0)throw Error("Bad port number "+u);B.u=u}else B.u=null}function hB(B,u,C){u instanceof Hr?(B.i=u,l_(B.i,B.l)):(C||(u=Gr(u,a_)),B.i=new Hr(u,B.l))}function Ie(B,u,C){B.i.set(u,C)}function uo(B){return Ie(B,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),B}function Mr(B,u){return B?u?decodeURI(B.replace(/%25/g,"%2525")):decodeURIComponent(B):""}function Gr(B,u,C){return typeof B=="string"?(B=encodeURI(B).replace(u,r_),C&&(B=B.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),B):null}function r_(B){return B=B.charCodeAt(0),"%"+(B>>4&15).toString(16)+(B&15).toString(16)}var Lu=/[#\/\?@]/g,i_=/[#\?:]/g,o_=/[#\?]/g,a_=/[#\?@]/g,B_=/#/g;function Hr(B,u){this.h=this.g=null,this.i=B||null,this.j=!!u}function ls(B){B.g||(B.g=new Map,B.h=0,B.i&&s_(B.i,function(u,C){B.add(decodeURIComponent(u.replace(/\+/g," ")),C)}))}s=Hr.prototype,s.add=function(B,u){ls(this),this.i=null,B=Ms(this,B);let C=this.g.get(B);return C||this.g.set(B,C=[]),C.push(u),this.h+=1,this};function xu(B,u){ls(B),u=Ms(B,u),B.g.has(u)&&(B.i=null,B.h-=B.g.get(u).length,B.g.delete(u))}function ku(B,u){return ls(B),u=Ms(B,u),B.g.has(u)}s.forEach=function(B,u){ls(this),this.g.forEach(function(C,p){C.forEach(function(S){B.call(u,S,p,this)},this)},this)};function Vu(B,u){ls(B);let C=[];if(typeof u=="string")ku(B,u)&&(C=C.concat(B.g.get(Ms(B,u))));else for(B=Array.from(B.g.values()),u=0;u<B.length;u++)C=C.concat(B[u]);return C}s.set=function(B,u){return ls(this),this.i=null,B=Ms(this,B),ku(this,B)&&(this.h-=this.g.get(B).length),this.g.set(B,[u]),this.h+=1,this},s.get=function(B,u){return B?(B=Vu(this,B),B.length>0?String(B[0]):u):u};function Mu(B,u,C){xu(B,u),C.length>0&&(B.i=null,B.g.set(Ms(B,u),_(C)),B.h+=C.length)}s.toString=function(){if(this.i)return this.i;if(!this.g)return"";const B=[],u=Array.from(this.g.keys());for(let p=0;p<u.length;p++){var C=u[p];const S=Lr(C);C=Vu(this,C);for(let P=0;P<C.length;P++){let j=S;C[P]!==""&&(j+="="+Lr(C[P])),B.push(j)}}return this.i=B.join("&")};function Gu(B){const u=new Hr;return u.i=B.i,B.g&&(u.g=new Map(B.g),u.h=B.h),u}function Ms(B,u){return u=String(u),B.j&&(u=u.toLowerCase()),u}function l_(B,u){u&&!B.j&&(ls(B),B.i=null,B.g.forEach(function(C,p){const S=p.toLowerCase();p!=S&&(xu(this,p),Mu(this,S,C))},B)),B.j=u}function c_(B,u){const C=new Or;if(o.Image){const p=new Image;p.onload=h(An,C,"TestLoadImage: loaded",!0,u,p),p.onerror=h(An,C,"TestLoadImage: error",!1,u,p),p.onabort=h(An,C,"TestLoadImage: abort",!1,u,p),p.ontimeout=h(An,C,"TestLoadImage: timeout",!1,u,p),o.setTimeout(function(){p.ontimeout&&p.ontimeout()},1e4),p.src=B}else u(!1)}function u_(B,u){const C=new Or,p=new AbortController,S=setTimeout(()=>{p.abort(),An(C,"TestPingServer: timeout",!1,u)},1e4);fetch(B,{signal:p.signal}).then(P=>{clearTimeout(S),P.ok?An(C,"TestPingServer: ok",!0,u):An(C,"TestPingServer: server error",!1,u)}).catch(()=>{clearTimeout(S),An(C,"TestPingServer: error",!1,u)})}function An(B,u,C,p,S){try{S&&(S.onload=null,S.onerror=null,S.onabort=null,S.ontimeout=null),p(C)}catch{}}function h_(){this.g=new Qm}function fB(B){this.i=B.Sb||null,this.h=B.ab||!1}f(fB,pu),fB.prototype.g=function(){return new ho(this.i,this.h)};function ho(B,u){it.call(this),this.H=B,this.o=u,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}f(ho,it),s=ho.prototype,s.open=function(B,u){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=B,this.D=u,this.readyState=1,qr(this)},s.send=function(B){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const u={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};B&&(u.body=B),(this.H||o).fetch(new Request(this.D,u)).then(this.Pa.bind(this),this.ga.bind(this))},s.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Ur(this)),this.readyState=0},s.Pa=function(B){if(this.g&&(this.l=B,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=B.headers,this.readyState=2,qr(this)),this.g&&(this.readyState=3,qr(this),this.g)))if(this.responseType==="arraybuffer")B.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof o.ReadableStream<"u"&&"body"in B){if(this.j=B.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Hu(this)}else B.text().then(this.Oa.bind(this),this.ga.bind(this))};function Hu(B){B.j.read().then(B.Ma.bind(B)).catch(B.ga.bind(B))}s.Ma=function(B){if(this.g){if(this.o&&B.value)this.response.push(B.value);else if(!this.o){var u=B.value?B.value:new Uint8Array(0);(u=this.B.decode(u,{stream:!B.done}))&&(this.response=this.responseText+=u)}B.done?Ur(this):qr(this),this.readyState==3&&Hu(this)}},s.Oa=function(B){this.g&&(this.response=this.responseText=B,Ur(this))},s.Na=function(B){this.g&&(this.response=B,Ur(this))},s.ga=function(){this.g&&Ur(this)};function Ur(B){B.readyState=4,B.l=null,B.j=null,B.B=null,qr(B)}s.setRequestHeader=function(B,u){this.A.append(B,u)},s.getResponseHeader=function(B){return this.h&&this.h.get(B.toLowerCase())||""},s.getAllResponseHeaders=function(){if(!this.h)return"";const B=[],u=this.h.entries();for(var C=u.next();!C.done;)C=C.value,B.push(C[0]+": "+C[1]),C=u.next();return B.join(`\r
`)};function qr(B){B.onreadystatechange&&B.onreadystatechange.call(B)}Object.defineProperty(ho.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(B){this.m=B?"include":"same-origin"}});function Uu(B){let u="";return io(B,function(C,p){u+=p,u+=":",u+=C,u+=`\r
`}),u}function CB(B,u,C){e:{for(p in C){var p=!1;break e}p=!0}p||(C=Uu(C),typeof B=="string"?C!=null&&Lr(C):Ie(B,u,C))}function Oe(B){it.call(this),this.headers=new Map,this.L=B||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}f(Oe,it);var f_=/^https?$/i,C_=["POST","PUT"];s=Oe.prototype,s.Fa=function(B){this.H=B},s.ea=function(B,u,C,p){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+B);u=u?u.toUpperCase():"GET",this.D=B,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():wu.g(),this.g.onreadystatechange=d(c(this.Ca,this));try{this.B=!0,this.g.open(u,String(B),!0),this.B=!1}catch(P){qu(this,P);return}if(B=C||"",C=new Map(this.headers),p)if(Object.getPrototypeOf(p)===Object.prototype)for(var S in p)C.set(S,p[S]);else if(typeof p.keys=="function"&&typeof p.get=="function")for(const P of p.keys())C.set(P,p.get(P));else throw Error("Unknown input type for opt_headers: "+String(p));p=Array.from(C.keys()).find(P=>P.toLowerCase()=="content-type"),S=o.FormData&&B instanceof o.FormData,!(Array.prototype.indexOf.call(C_,u,void 0)>=0)||p||S||C.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[P,j]of C)this.g.setRequestHeader(P,j);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(B),this.v=!1}catch(P){qu(this,P)}};function qu(B,u){B.h=!1,B.g&&(B.j=!0,B.g.abort(),B.j=!1),B.l=u,B.o=5,Ju(B),fo(B)}function Ju(B){B.A||(B.A=!0,ft(B,"complete"),ft(B,"error"))}s.abort=function(B){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=B||7,ft(this,"complete"),ft(this,"abort"),fo(this))},s.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),fo(this,!0)),Oe.Z.N.call(this)},s.Ca=function(){this.u||(this.B||this.v||this.j?ju(this):this.Xa())},s.Xa=function(){ju(this)};function ju(B){if(B.h&&typeof i<"u"){if(B.v&&vn(B)==4)setTimeout(B.Ca.bind(B),0);else if(ft(B,"readystatechange"),vn(B)==4){B.h=!1;try{const P=B.ca();e:switch(P){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var u=!0;break e;default:u=!1}var C;if(!(C=u)){var p;if(p=P===0){let j=String(B.D).match(Ou)[1]||null;!j&&o.self&&o.self.location&&(j=o.self.location.protocol.slice(0,-1)),p=!f_.test(j?j.toLowerCase():"")}C=p}if(C)ft(B,"complete"),ft(B,"success");else{B.o=6;try{var S=vn(B)>2?B.g.statusText:""}catch{S=""}B.l=S+" ["+B.ca()+"]",Ju(B)}}finally{fo(B)}}}}function fo(B,u){if(B.g){B.m&&(clearTimeout(B.m),B.m=null);const C=B.g;B.g=null,u||ft(B,"ready");try{C.onreadystatechange=null}catch{}}}s.isActive=function(){return!!this.g};function vn(B){return B.g?B.g.readyState:0}s.ca=function(){try{return vn(this)>2?this.g.status:-1}catch{return-1}},s.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},s.La=function(B){if(this.g){var u=this.g.responseText;return B&&u.indexOf(B)==0&&(u=u.substring(B.length)),zm(u)}};function Ku(B){try{if(!B.g)return null;if("response"in B.g)return B.g.response;switch(B.F){case"":case"text":return B.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in B.g)return B.g.mozResponseArrayBuffer}return null}catch{return null}}function d_(B){const u={};B=(B.g&&vn(B)>=2&&B.g.getAllResponseHeaders()||"").split(`\r
`);for(let p=0;p<B.length;p++){if(D(B[p]))continue;var C=Zm(B[p]);const S=C[0];if(C=C[1],typeof C!="string")continue;C=C.trim();const P=u[S]||[];u[S]=P,P.push(C)}Hm(u,function(p){return p.join(", ")})}s.ya=function(){return this.o},s.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function Jr(B,u,C){return C&&C.internalChannelParams&&C.internalChannelParams[B]||u}function zu(B){this.za=0,this.i=[],this.j=new Or,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=Jr("failFast",!1,B),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=Jr("baseRetryDelayMs",5e3,B),this.Za=Jr("retryDelaySeedMs",1e4,B),this.Ta=Jr("forwardChannelMaxRetries",2,B),this.va=Jr("forwardChannelRequestTimeoutMs",2e4,B),this.ma=B&&B.xmlHttpFactory||void 0,this.Ua=B&&B.Rb||void 0,this.Aa=B&&B.useFetchStreams||!1,this.O=void 0,this.L=B&&B.supportsCrossDomainXhr||!1,this.M="",this.h=new Su(B&&B.concurrentRequestLimit),this.Ba=new h_,this.S=B&&B.fastHandshake||!1,this.R=B&&B.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=B&&B.Pb||!1,B&&B.ua&&this.j.ua(),B&&B.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&B&&B.detectBufferingProxy||!1,this.ia=void 0,B&&B.longPollingTimeout&&B.longPollingTimeout>0&&(this.ia=B.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}s=zu.prototype,s.ka=8,s.I=1,s.connect=function(B,u,C,p){Ct(0),this.W=B,this.H=u||{},C&&p!==void 0&&(this.H.OSID=C,this.H.OAID=p),this.F=this.X,this.J=nh(this,null,this.W),po(this)};function dB(B){if(Qu(B),B.I==3){var u=B.V++,C=Yt(B.J);if(Ie(C,"SID",B.M),Ie(C,"RID",u),Ie(C,"TYPE","terminate"),jr(B,C),u=new Tn(B,B.j,u),u.M=2,u.A=uo(Yt(C)),C=!1,o.navigator&&o.navigator.sendBeacon)try{C=o.navigator.sendBeacon(u.A.toString(),"")}catch{}!C&&o.Image&&(new Image().src=u.A,C=!0),C||(u.g=sh(u.j,null),u.g.ea(u.A)),u.F=Date.now(),co(u)}th(B)}function Co(B){B.g&&(gB(B),B.g.cancel(),B.g=null)}function Qu(B){Co(B),B.v&&(o.clearTimeout(B.v),B.v=null),go(B),B.h.cancel(),B.m&&(typeof B.m=="number"&&o.clearTimeout(B.m),B.m=null)}function po(B){if(!bu(B.h)&&!B.m){B.m=!0;var u=B.Ea;Le||E(),Fe||(Le(),Fe=!0),v.add(u,B),B.D=0}}function p_(B,u){return Nu(B.h)>=B.h.j-(B.m?1:0)?!1:B.m?(B.i=u.G.concat(B.i),!0):B.I==1||B.I==2||B.D>=(B.Sa?0:B.Ta)?!1:(B.m=Fr(c(B.Ea,B,u),eh(B,B.D)),B.D++,!0)}s.Ea=function(B){if(this.m)if(this.m=null,this.I==1){if(!B){this.V=Math.floor(Math.random()*1e5),B=this.V++;const S=new Tn(this,this.j,B);let P=this.o;if(this.U&&(P?(P=ou(P),Bu(P,this.U)):P=this.U),this.u!==null||this.R||(S.J=P,P=null),this.S)e:{for(var u=0,C=0;C<this.i.length;C++){t:{var p=this.i[C];if("__data__"in p.map&&(p=p.map.__data__,typeof p=="string")){p=p.length;break t}p=void 0}if(p===void 0)break;if(u+=p,u>4096){u=C;break e}if(u===4096||C===this.i.length-1){u=C+1;break e}}u=1e3}else u=1e3;u=Yu(this,S,u),C=Yt(this.J),Ie(C,"RID",B),Ie(C,"CVER",22),this.G&&Ie(C,"X-HTTP-Session-Id",this.G),jr(this,C),P&&(this.R?u="headers="+Lr(Uu(P))+"&"+u:this.u&&CB(C,this.u,P)),uB(this.h,S),this.Ra&&Ie(C,"TYPE","init"),this.S?(Ie(C,"$req",u),Ie(C,"SID","null"),S.U=!0,aB(S,C,null)):aB(S,C,u),this.I=2}}else this.I==3&&(B?Wu(this,B):this.i.length==0||bu(this.h)||Wu(this))};function Wu(B,u){var C;u?C=u.l:C=B.V++;const p=Yt(B.J);Ie(p,"SID",B.M),Ie(p,"RID",C),Ie(p,"AID",B.K),jr(B,p),B.u&&B.o&&CB(p,B.u,B.o),C=new Tn(B,B.j,C,B.D+1),B.u===null&&(C.J=B.o),u&&(B.i=u.G.concat(B.i)),u=Yu(B,C,1e3),C.H=Math.round(B.va*.5)+Math.round(B.va*.5*Math.random()),uB(B.h,C),aB(C,p,u)}function jr(B,u){B.H&&io(B.H,function(C,p){Ie(u,p,C)}),B.l&&io({},function(C,p){Ie(u,p,C)})}function Yu(B,u,C){C=Math.min(B.i.length,C);const p=B.l?c(B.l.Ka,B.l,B):null;e:{var S=B.i;let ie=-1;for(;;){const Ke=["count="+C];ie==-1?C>0?(ie=S[0].g,Ke.push("ofs="+ie)):ie=0:Ke.push("ofs="+ie);let De=!0;for(let Qe=0;Qe<C;Qe++){var P=S[Qe].g;const $t=S[Qe].map;if(P-=ie,P<0)ie=Math.max(0,S[Qe].g-100),De=!1;else try{P="req"+P+"_"||"";try{var j=$t instanceof Map?$t:Object.entries($t);for(const[us,Rn]of j){let Sn=Rn;a(Rn)&&(Sn=nB(Rn)),Ke.push(P+us+"="+encodeURIComponent(Sn))}}catch(us){throw Ke.push(P+"type="+encodeURIComponent("_badmap")),us}}catch{p&&p($t)}}if(De){j=Ke.join("&");break e}}j=void 0}return B=B.i.splice(0,C),u.G=B,j}function $u(B){if(!B.g&&!B.v){B.Y=1;var u=B.Da;Le||E(),Fe||(Le(),Fe=!0),v.add(u,B),B.A=0}}function pB(B){return B.g||B.v||B.A>=3?!1:(B.Y++,B.v=Fr(c(B.Da,B),eh(B,B.A)),B.A++,!0)}s.Da=function(){if(this.v=null,Xu(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var B=4*this.T;this.j.info("BP detection timer enabled: "+B),this.B=Fr(c(this.Wa,this),B)}},s.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,Ct(10),Co(this),Xu(this))};function gB(B){B.B!=null&&(o.clearTimeout(B.B),B.B=null)}function Xu(B){B.g=new Tn(B,B.j,"rpc",B.Y),B.u===null&&(B.g.J=B.o),B.g.P=0;var u=Yt(B.na);Ie(u,"RID","rpc"),Ie(u,"SID",B.M),Ie(u,"AID",B.K),Ie(u,"CI",B.F?"0":"1"),!B.F&&B.ia&&Ie(u,"TO",B.ia),Ie(u,"TYPE","xmlhttp"),jr(B,u),B.u&&B.o&&CB(u,B.u,B.o),B.O&&(B.g.H=B.O);var C=B.g;B=B.ba,C.M=1,C.A=uo(Yt(u)),C.u=null,C.R=!0,Au(C,B)}s.Va=function(){this.C!=null&&(this.C=null,Co(this),pB(this),Ct(19))};function go(B){B.C!=null&&(o.clearTimeout(B.C),B.C=null)}function Zu(B,u){var C=null;if(B.g==u){go(B),gB(B),B.g=null;var p=2}else if(cB(B.h,u))C=u.G,Pu(B.h,u),p=1;else return;if(B.I!=0){if(u.o)if(p==1){C=u.u?u.u.length:0,u=Date.now()-u.F;var S=B.D;p=Bo(),ft(p,new Du(p,C)),po(B)}else $u(B);else if(S=u.m,S==3||S==0&&u.X>0||!(p==1&&p_(B,u)||p==2&&pB(B)))switch(C&&C.length>0&&(u=B.h,u.i=u.i.concat(C)),S){case 1:cs(B,5);break;case 4:cs(B,10);break;case 3:cs(B,6);break;default:cs(B,2)}}}function eh(B,u){let C=B.Qa+Math.floor(Math.random()*B.Za);return B.isActive()||(C*=2),C*u}function cs(B,u){if(B.j.info("Error code "+u),u==2){var C=c(B.bb,B),p=B.Ua;const S=!p;p=new In(p||"//www.google.com/images/cleardot.gif"),o.location&&o.location.protocol=="http"||kr(p,"https"),uo(p),S?c_(p.toString(),C):u_(p.toString(),C)}else Ct(2);B.I=0,B.l&&B.l.pa(u),th(B),Qu(B)}s.bb=function(B){B?(this.j.info("Successfully pinged google.com"),Ct(2)):(this.j.info("Failed to ping google.com"),Ct(1))};function th(B){if(B.I=0,B.ja=[],B.l){const u=Fu(B.h);(u.length!=0||B.i.length!=0)&&(y(B.ja,u),y(B.ja,B.i),B.h.i.length=0,_(B.i),B.i.length=0),B.l.oa()}}function nh(B,u,C){var p=C instanceof In?Yt(C):new In(C);if(p.g!="")u&&(p.g=u+"."+p.g),Vr(p,p.u);else{var S=o.location;p=S.protocol,u=u?u+"."+S.hostname:S.hostname,S=+S.port;const P=new In(null);p&&kr(P,p),u&&(P.g=u),S&&Vr(P,S),C&&(P.h=C),p=P}return C=B.G,u=B.wa,C&&u&&Ie(p,C,u),Ie(p,"VER",B.ka),jr(B,p),p}function sh(B,u,C){if(u&&!B.L)throw Error("Can't create secondary domain capable XhrIo object.");return u=B.Aa&&!B.ma?new Oe(new fB({ab:C})):new Oe(B.ma),u.Fa(B.L),u}s.isActive=function(){return!!this.l&&this.l.isActive(this)};function rh(){}s=rh.prototype,s.ra=function(){},s.qa=function(){},s.pa=function(){},s.oa=function(){},s.isActive=function(){return!0},s.Ka=function(){};function mo(){}mo.prototype.g=function(B,u){return new vt(B,u)};function vt(B,u){it.call(this),this.g=new zu(u),this.l=B,this.h=u&&u.messageUrlParams||null,B=u&&u.messageHeaders||null,u&&u.clientProtocolHeaderRequired&&(B?B["X-Client-Protocol"]="webchannel":B={"X-Client-Protocol":"webchannel"}),this.g.o=B,B=u&&u.initMessageHeaders||null,u&&u.messageContentType&&(B?B["X-WebChannel-Content-Type"]=u.messageContentType:B={"X-WebChannel-Content-Type":u.messageContentType}),u&&u.sa&&(B?B["X-WebChannel-Client-Profile"]=u.sa:B={"X-WebChannel-Client-Profile":u.sa}),this.g.U=B,(B=u&&u.Qb)&&!D(B)&&(this.g.u=B),this.A=u&&u.supportsCrossDomainXhr||!1,this.v=u&&u.sendRawJson||!1,(u=u&&u.httpSessionIdParam)&&!D(u)&&(this.g.G=u,B=this.h,B!==null&&u in B&&(B=this.h,u in B&&delete B[u])),this.j=new Gs(this)}f(vt,it),vt.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},vt.prototype.close=function(){dB(this.g)},vt.prototype.o=function(B){var u=this.g;if(typeof B=="string"){var C={};C.__data__=B,B=C}else this.v&&(C={},C.__data__=nB(B),B=C);u.i.push(new n_(u.Ya++,B)),u.I==3&&po(u)},vt.prototype.N=function(){this.g.l=null,delete this.j,dB(this.g),delete this.g,vt.Z.N.call(this)};function ih(B){sB.call(this),B.__headers__&&(this.headers=B.__headers__,this.statusCode=B.__status__,delete B.__headers__,delete B.__status__);var u=B.__sm__;if(u){e:{for(const C in u){B=C;break e}B=void 0}(this.i=B)&&(B=this.i,u=u!==null&&B in u?u[B]:void 0),this.data=u}else this.data=B}f(ih,sB);function oh(){rB.call(this),this.status=1}f(oh,rB);function Gs(B){this.g=B}f(Gs,rh),Gs.prototype.ra=function(){ft(this.g,"a")},Gs.prototype.qa=function(B){ft(this.g,new ih(B))},Gs.prototype.pa=function(B){ft(this.g,new oh)},Gs.prototype.oa=function(){ft(this.g,"b")},mo.prototype.createWebChannel=mo.prototype.g,vt.prototype.send=vt.prototype.o,vt.prototype.open=vt.prototype.m,vt.prototype.close=vt.prototype.close,Id=function(){return new mo},Td=function(){return Bo()},wd=as,XB={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},lo.NO_ERROR=0,lo.TIMEOUT=8,lo.HTTP_ERROR=6,Oo=lo,yu.COMPLETE="complete",yd=yu,gu.EventType=Nr,Nr.OPEN="a",Nr.CLOSE="b",Nr.ERROR="c",Nr.MESSAGE="d",it.prototype.listen=it.prototype.J,Xr=gu,Oe.prototype.listenOnce=Oe.prototype.K,Oe.prototype.getLastError=Oe.prototype.Ha,Oe.prototype.getLastErrorCode=Oe.prototype.ya,Oe.prototype.getStatus=Oe.prototype.ca,Oe.prototype.getResponseJson=Oe.prototype.La,Oe.prototype.getResponseText=Oe.prototype.la,Oe.prototype.send=Oe.prototype.ea,Oe.prototype.setWithCredentials=Oe.prototype.Fa,Dd=Oe}).apply(typeof Eo<"u"?Eo:typeof self<"u"?self:typeof window<"u"?window:{});/*!
* re2js
* RE2JS is the JavaScript port of RE2, a regular expression engine that provides linear time matching
*
* @version v2.8.6
* @author Oleksii Vasyliev
* @homepage https://github.com/le0pard/re2js#readme
* @repository github:le0pard/re2js
* @license MIT
*/var ye,M=(ye=class{},H(ye,"FOLD_CASE",1),H(ye,"LITERAL",2),H(ye,"CLASS_NL",4),H(ye,"DOT_NL",8),H(ye,"ONE_LINE",16),H(ye,"NON_GREEDY",32),H(ye,"PERL_X",64),H(ye,"UNICODE_GROUPS",128),H(ye,"WAS_DOLLAR",256),H(ye,"LOOKBEHIND",512),H(ye,"MATCH_NL",ye.CLASS_NL|ye.DOT_NL),H(ye,"PERL",ye.CLASS_NL|ye.ONE_LINE|ye.PERL_X|ye.UNICODE_GROUPS),H(ye,"POSIX",0),H(ye,"UNANCHORED",0),H(ye,"ANCHOR_START",1),H(ye,"ANCHOR_BOTH",2),ye);const Hs={CASE_INSENSITIVE:1,DOTALL:2,MULTILINE:4,DISABLE_UNICODE_GROUPS:8,LONGEST_MATCH:16,LOOKBEHINDS:512},mi=128,ZB=new Int32Array(mi),el=new Int32Array(mi),Do=65535;for(let s=0;s<mi;s++)s>=97&&s<=122?ZB[s]=s-32:ZB[s]=s,s>=65&&s<=90?el[s]=s+32:el[s]=s;var JB,L=(JB=class{static toUpperCase(s){if(s<mi)return ZB[s];const e=String.fromCodePoint(s).toUpperCase(),t=e.codePointAt(0)>Do?2:1;if(e.length>t)return s;const n=String.fromCodePoint(e.codePointAt(0)).toLowerCase(),r=n.codePointAt(0)>Do?2:1;return n.length>r||n.codePointAt(0)!==s?s:e.codePointAt(0)}static toLowerCase(s){if(s<mi)return el[s];const e=String.fromCodePoint(s).toLowerCase(),t=e.codePointAt(0)>Do?2:1;if(e.length>t)return s;const n=String.fromCodePoint(e.codePointAt(0)).toUpperCase(),r=n.codePointAt(0)>Do?2:1;return n.length>r||n.codePointAt(0)!==s?s:e.codePointAt(0)}},H(JB,"CODES",new Map([["\x07",7],["\b",8],["	",9],[`
`,10],["\v",11],["\f",12],["\r",13],[" ",32],['"',34],["$",36],["&",38],["'",39],["(",40],[")",41],["*",42],["+",43],["-",45],[".",46],["0",48],["1",49],["2",50],["3",51],["4",52],["5",53],["6",54],["7",55],["8",56],["9",57],[":",58],["<",60],[">",62],["?",63],["A",65],["B",66],["C",67],["F",70],["P",80],["Q",81],["U",85],["Z",90],["[",91],["\\",92],["]",93],["^",94],["_",95],["`",96],["a",97],["b",98],["f",102],["i",105],["m",109],["n",110],["r",114],["s",115],["t",116],["v",118],["x",120],["z",122],["{",123],["|",124],["}",125]])),JB),g=class{constructor(s,e=!1){this.data=s,this.isStride1=e,this.SIZE=e?2:3}getLo(s){return this.data[s*this.SIZE]}getHi(s){return this.data[s*this.SIZE+1]}getStride(s){return this.isStride1?1:this.data[s*this.SIZE+2]}get length(){return this.data.length/this.SIZE}};const Ad=new Uint8Array(256);for(let s=0,e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-";s<64;s++)Ad[e.charCodeAt(s)]=s;const vd=s=>{const e=[];let t=0,n=0;for(let r=0;r<s.length;r++){let i=Ad[s.charCodeAt(r)];t|=(i&31)<<n,i&32?n+=5:(e.push(t),t=0,n=0)}return e},m=(s,e)=>{const t=vd(s),n=e?t.length/2:t.length/3,r=new Uint32Array(n*3);let i=0,o=0;for(let a=0;a<n;a++)i+=t[o++],r[a*3]=i,i+=t[o++],r[a*3+1]=i,r[a*3+2]=e?1:t[o++];return r},Dy=s=>{const e=vd(s),t=new Map;let n=0;for(let r=0;r<e.length;r+=2){n+=e[r];const i=e[r+1],o=i>>>1^-(i&1);t.set(n,n+o)}return t};var yo=class{constructor(s){this.initializer=s,this.cache=new Map}has(s){return s in this.initializer}get(s){if(this.cache.has(s))return this.cache.get(s);const e=this.initializer[s],t=e?e():null;return this.cache.set(s,t),t}},Nn,_t=(Nn=class{static get CASE_ORBIT(){return this._CASE_ORBIT||(this._CASE_ORBIT=Dy("rCgCIgCY+rQI4QiCuuBLgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCCgCBgCBgCBgCBgCBgCBgCB+7OB-BB-BB-BB-BB-BBskQB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BC-BB-BB-BB-BB-BB-BB-BByHBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBxHBCBBBCBBBCBBB3SBmMBkNBCBBBCBBB8MBCBBB6MB6MBCBBC+EB0MB2MBCBBB6MB+MBiGBmNBiNBCBBBmKBikzCBmNBqNBkIBsNBCBBBCBBBCBBB0NBCBBB0NDCBBB0NBCBBByNByNBCBBBCBBB2NBCBBDCBBCwDFCBCBDBCBCBDBCBCBDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB9EBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBCBDBCBBBhGBvDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBjICCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBH2iVBCBBBlKBwiVB+jVB+jVBCBBBlMBqEBuEBCBBBCBBBCBBBCBBBCBBB+hVB4hVB8hVBjNB7MC5MB5MCzMC1MB+0yCE5MB20yCC9MBu2yCBwyyCBo0yCChNBlNBo0yCBu-UBi0yCDlNC6-UBpNDrNIu+UDzNCm0yCBzNE0yyCBzNBpEBxNBxNBtEG1NLqxyCBkxyCnFoFrBCBBBCBBDCBBEkIBkIBkICoHHsCCqCBqCBqCCgEC+DB+DBmkOBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCC+BBgCBgCBgCBgCBgCBgCBgCBgCBrCBpCBpCBpCBmjOB-BB8BB-BB-BBgEB-BB-BByBBqgOBsDB-BBtwBB-BB-BB-BBsBBgDBCB-BB-BB-BBeB-BB-BB61OB-BB-BB-DB9DB9DBQB7DBmCE9CBrDBPBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBrFB-EBOBnHB3FB-FCCBBBNBCBBCjIBjIBjIBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB8kMB-BB6kMB-BB-BB-BB-BB-BB-BB-BB-BB-BBokMB-BB-BBkkMBkkMB-BB-BB-BB-BB-BB-BB-BB4jMB-BB-BB-BB-BB-BB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EBCBBBCBoiMBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBJCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBeBCBBBCBBBCBBBCBBBCBBBCBBBCBBBdBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDL-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-C64CgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOCgmOGgmODg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FDg8FBg8FBg8FhVg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBQBQBQBQBQBQDPBPBPBPBPBPjkC7mMB5mMBnmMBjmMBCBlmMB3lMBpiMBk8kCBCBBG-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FD-7FB-7FB-7F6FoglCEsuHRwjlCyDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCB0DBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBG1DD97OCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPEQCQCQCQCPCPCPCPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPB0EB0EBsFBsFBsFBsFBoGBoGBgIBgIBgHBgHB8HB8HDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQCSFPBPBzEBzEBRCxnOFSFrFBrFBrFBrFBREQBQClkOFPBPBnGBnGFQBQCljOCODPBPB-GB-GBNHSF-HB-HB7HB7HBRqJ53OE9tQBrmQH4Bc3BSgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfECBByZ0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzB34BgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CBCBBBt-UBruHBt+UB1iVBviVBCBBBCBBBCBBB3hVB5-UB9hVB7hVCCBBCCBBI9jVB9jVBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBICBBBCBBECBBN-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOC-lOG-lOzoeCBBBCBBBCBBBCBBBCBBBCBl8kCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBTCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBnECBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBKCBBBCBBBnglCBCBBBCBBBCBBBCBBBCBBECBBBvyyCDCBBBCBBBgDCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBn0yCB90yCB10yCBh0yCBn0yCCjxyCBzyyCBpxyCBg6BBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB-CBl0yCBvjlCBCBBBCBBBt2yCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBhkzCZCBB9a-5Bd-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCm6TCBB7gBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCH-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BmlBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvChDwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCFvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvC1DuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCCuCBuCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCCtCBtCk2BgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEO-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-D+CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCL-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-B74CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhrVgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BD1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BtxekCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjC")),this._CASE_ORBIT}static get Print(){return this._Print||(this._Print=new g(m("hB9CBjBLBCpWBDFBFGBCCCBSBCsMBClBBDxBBDCBC2BBJaBFFBSVBC-FBCvBBD6BBDkDBP6BBDwBBDOBCbBDCCBJBGfBIqCBCgFBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYBDCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPBLCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGBCCBCHBDBBDVBCGBCBBCEBDIBDBBDCBICBFBBCEBDRBLBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBGMBCCBCWBCPBDIBCCBCDBIBBCCBCBBDDBDJBIVBCCBCWBCJBCEBDIBCCBCDBIBBGCBCDBDJBCCBNMBCCBCyBBCCBCFBFPBDZBCCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBN5BBFcBmBBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDBhBnCBCjBBFmBBCjBBCOBCMBmBlGBCGGD4LBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBH1CBDFBD-TBCbBE4CBIVBKXBKTBNMBCCBCBBN9CBDJBHJBHNBCKBH4CBIqBBGlCBLeBCLBFLBFEEBoBBDEBMrBBFZBHKBE9BBDgCBCcBDKBHJBHNBDtBBDLBVsCBClFBJ7BBEOBE9BBGqBBDKBJqBBG1QBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBSXBJuBBSBBDaBCMBEhBBPgBBQrEBF5UBXKBWz4BBD9LBGsBBCGGD3BBIBBPXBKGBCGBCGBCGBCGBCGBCGBCGBC9DBjBZBC4CBN1GBbPBC+BBC1CBDmDBGqBBC9CBC1CBKvBBCszcBE2BBK7KBV3FBJ8GBV7BBEJBH3BBJlCBJLBHzDBMdBEtCBCKBFgBBC2BBKNBDJBDmDBZbBLFBDFBDFBKGBCGBC7BBF9DBDJBHj9KBNWBFwBBloItLBDpDBnBGBNEBGZBCEBCCCBCCBCCBoUBhBpBBHyBBCSBCDBFEBCmEBF9FBEFBDFBDFBDCBEGBCGBOBBDLBCZBCSBCBBCOBDNBjB6DBGCBFsBBE3CBCMBEwBwBBsBBjEcBEwBBQbBFjBBKdBGqBBGdBCkBBFNBrB9EBDJBHjBBFjBBFnBBJzBBMLBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBCnCBJIBxBSBCBBGgBBEaBGaBnB3BBFTBDxBBCBBGHBCCBCcBDCBFJBIIBI-BBhBmBBFLBK1BBEcBDaBGZBIDBNGBxCoCB4ByBBOyBBItBBJJBHlBBEcBJBBxGeBCpBBCCBDBBRFBJIBiBtBBJpBBXZBnBbBVWBKtCBFjBBK9BBCEBOYBIJBH0BBCRBJmBBK-CBCTBMRBCuBB-BGBCCCBCBCOBCKBH6BBGJBHDBCHBDBBDVBCGBCBBCEBCJBDBBDCBDHHGGBDGBEEBMJBCDDClBBCJBCDDCDBCJBCBBJBBe7CBCEBfnCBJJBnF1BBDlBBjBkCBMJBHMBU5BBHJBHTBdaBDOBFWB6F7BBlDyCBNHBDDDBGBCBBCdBCBBDLBKJBnCHBDtBBDKBcnCBJyCBOoCBIJB3CHB5ChBBPJBHIBCsBBCNBLcBEfBDVBCNBqCGBCBBCrBBECCBCCBHBJJBHFBCBBCkBBCBBCFBIJBHrBBFJB3HYBIQBCoBBEcB2CQQBwBBO6cBnDuDBCEBMjGBtyCiDBOvhBBRVBL68DBGmSB61G5BBn2B4RBIeBCJBFwCBCJBHdBDFBLlCBLJBCGBCUBGSBxN5BBnG6CBGYBDYBtBqCBF4BBIQBhCEBMGBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBDDBh7D8HBEzNBHWBQQBQtBBDWBKzDB9B1HBLmBBDpCBJvDBWlCB7DTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBD9VBQEBCOBxiBeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBENBDJBFBBhKeBS5BBGxOxOBoBB3GqBBFhGhGBdBCVBJBBhHGBCDBCBBCOBCkGBDPBqBrCBFJBFBByYjCBtC8BBjGDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBBvIrBBFjDBNOBDOBCOBCkBBLtFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBmgB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIBnkzVvHB",!1))),this._Print}static get Upper(){return this.CATEGORIES.get("Lu")}},H(Nn,"_CASE_ORBIT",null),H(Nn,"_Print",null),H(Nn,"CATEGORIES",new yo({C:()=>new g(m("AfBgDgBBOrWrWBHHBCBICCVuMuMnBBBzBBBE4B4BBGBcDBHQBXhGhGxBBB8BBBmDNB8BBByBBBQddBCCMEBhBGBsCiFiFJBBDBBXIICCBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBPMMBEB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKMMBDBbEByBPBDBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCB-FCBHBBHBBHBBECBIIIBLBDBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIB-BGGBLBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMBxhBPBXJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBF-6DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBrCHBxDUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIlkzVBxHvw-FB",!1)),Cc:()=>new g(m("AfgDgB",!0)),Cf:()=>new g(m("tFzqBzqBBEBXhGhGyBhMhMBxCxCs5D9-B9-BBDBbEByBEBCJBw03B6H6HBBBimEQQj7IPBhjiBDBwmFHBn0rYffB+CB",!1)),Cn:()=>new g(m("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBDBvzIBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-BB---BBB---BBB",!1)),Co:()=>new g(m("gg4B-nGh4hc9--BD9--B",!0)),Cs:()=>new g(m("gg2B--B",!0)),L:()=>new g(m("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICCiEEBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoCaBFDBuBqBBkBBBCiDBCQQBIIBLLBBBDRRCdBe4CBMZZBfBKBBFGGBUBFKKEYYBXBIKBGXBCGBRpBB7B1BBETTIJBQPBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNGB7BBBCCCBDBCXBCCCBIBCBBKDDBDBCWWBCBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNSSBkBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBkBFFkC4CBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBzC+C+CBtBBSHB3BdBOBBLrBBbjBBqBCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBhC1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBF1B1BB8zC8zCBjHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBxC2O2OBrBrBBDBGBBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBReBDlCByBIBDmDBDxCBVQBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBdRRBDBCJBLEBCoBBYCBCHBVWBEEEBwBBCEEBDDBDBDCCZCBDKBICBNFBDFBDFBKGBCGBCqBBCNBHyDBej9KBNWBFwBBloItLBDpDBnBGBNEBGCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBxB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOjBBnBbBKWB7HpBBHBBRFB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB1D-BBgBHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBqBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBGjCjCBLBhCBBCPPBNNB0mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBn7F0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFBmI9BBzEsBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCCBCBBCGBDEBKBBhHGBCDBCBBCOBCkGB8BjCBI1lB1lBBCBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),LC:()=>new g(m("hCZBHZB7BLLBVBCeBCiGBCDBFvGBDZBhGDBDBBECBCHHCCBCCCBSBCyCBCqEBJlFBClBBKoBB44ClBBCGGDqBBDCBhV1CBDFBjkCKBGqBBDCBhCrBBgCMBChBBmD1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGBmIFFDJBCEEBDBHGCBCBCFBFDDBCBGEBF1B1BB8zC8zCB6DBDmDBHDBEBBNlBBCGGzoetBBTbBnEtCBCWBEDBCsCBZBBE2Z2ZBpBBGIBIvCBh6TGBNEBqgBZBHZBmlBvCBhDjBBFjBB1DKBCOBCGBCBBCKBCOBCGBCBBk2ByBBOyBB+CVBLVB74C-BBhrV-BBhBYBDYBtpZ0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BJBCTBHFB2uCjCB",!1)),Ll:()=>new g(m("hDZB7BqBqBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDZBiGCCEEEBBBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBDCB5XFBjkCIBC2D2DBqBBgCMBChBBnD0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBBzIEEBEEcKFDBBJDBF2B2Bs1CvBBCEEBGCFCCBCCBEBGiDCBIICFFNlBBCGG0oesBCUaCoEMCBBBC+BCBGBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCbEE2ZqBBGIBIvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFB4vChBB",!1)),Lm:()=>new g(m("wVRBFLBPEBICCmEGG-OnHnHlFBBuIBBFgBgBKEEhFoFoF1mBgEgE2R72B72BsDkTkTxOFBvF+BBOjBjBBjBByVOORMBg-CBByHgGgG2OsBsBBDBGiDiDB+C+CBBB34bjnBjnBBEBvIzDzDdBB6DIBxCYYpDDBEBB2OXXqEtDtDWBBoDDBKngVngVuBBBh-BFBCpBBCIB0sBhBhB2K04D04DnrTDB9PCBpBBBnRMBhCBBCPPB9-P9-PBCBCGBCBByhM9BBqGGBud0Q0QsSAB",!1)),Lo:()=>new g(m("qFQQhIFFBCBxGBB7ZaBFDBuBfBCJBkBBBCiDBCZZBLLBBBDRRCdBe4CBMZZBfBWVBrBYBIKBGXBCGBRoBB8B1BBETTIJBROBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNFB8BBBCCCBDBCXBCCCBIBCBBKDDBDBYDBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNyDyDBnKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPByDrTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBpBkCkCBhBBC0BBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBxFuBBSHB3BdBOBBLrBBbjBBqBCBLdByDDBCFBCBBE7hB7hBBCB4-C3BBZWBKGBCGBCGBCGBCGBCGBCGBCGBoR2B2BF1CBJCCB4CBFGGBpBBC9CBSfBxBPBhQ-tGBhC0wUBC2jBBkCnBBJrIBFPBLBBjCyByBBkCBqFoDoDEGBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBuBEBDIBLEBCoBBYCBCHBVPBCFBEEEBwBBCEEBDDBDBDCCZBBEKBIPPBEBDFBDFBKGBCGByEiBBej9KBNWBFwBBloItLBDpDBkCCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBqDJBCsBBDeBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBhEtCBjDnBBJzBB9CzBBN2JBKVBLHB5EFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4FjBBnBDBCxJxJBoBBHBBRCBCBB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB0GHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBnBBCBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBB0BUBGSB0NnBB2MqCBGwFwFB0mHBqBfBiDyDBuwIiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBxzI2P2PBrBBiBiKiKBcBTrBBlPaBmHdBDwGwGBdBCCBCBBCGBDEBKiHiHBFBCDBCBBCOBCkGB8pBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Lt:()=>new g(m("lOGDnB2sH2sHBGBJHBJHBNQQwBAB",!1)),Lu:()=>new g(m("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBG+B+B9zCvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBB",!1)),M:()=>new g(m("gYvDB0IGBoIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCgBB3BCBCRBCGBLBBeCB5BCCBFBDBBDCBKLLBbbDCB5BCCBDBFBBDCBEffBEEMCB5BCCBGBCCBCCBVBBXFBCCB5BCCBFBDBBDCBICBLBBf8B8BBDBECBCDBKpBpBBDB4BCCBFBCCBCDBIBBMBBeCB5BCCBFBCCBCDBIBBMBBQNNBCB4BBBCGBCCBCDBKLLBeeBBBnCFFBEBCCCBGBTBB+BDDBFBNHBjDDDBHBMGBqCBBcECFBByBTBCBBGKBCjBBKlDlDBSBYDBFCBCCBDGBEDBOLBCLLBCBgWCBzdDBdCBeBBfBBhCfBKuBuBBBBC2D2DBjBjB3DLBFLB8GEB6BJBCcBDxBxBBsBBDLBVEBwBQBnBIBNCBfMB5BNBxBTB5ECBCUBFHHDCBnG-BBxWgBB--CCBuEhDhDBeBrRFBqDBB1udDBCJBhBBBxCBBxIEEFYYBDBF0C0CBzBzBBQBbRBOnBnBBGBaMBtBDBwBNBlBkCkCBMBNJJBuBuBBBBzBCCBBBDBBGBBCqBqBBDBGBBtHHBCBBx5TiXiXBOBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB7DCB2BOBqBDDBLLBCBuBKBI+B+BBBBlBNBRBBtBNNBBBxBNBJDBCBB9CLBHDD+ELBWDB4BBBCGBDBBDCBKLLBDDBFBEEBkCIBCDDCDBCEBCPPBzCzCBQBYyCyCBSBsHGBDIBcBBzCQBrDMBmDOBhIOB2HFBCBBDDBCCCBuEuEBFBDGBEddBIBpBGBCDBJKKBJBvBPBnGHBoGHBCHBzCVBCNB7DFBECCBCCBFBCjCjCBDBCBBCEB8KDBKBBCxBxBBFBEEBYmnFmnFHOBpmLRBhuCEB8BGB5gBCCB1BBIDByCMMBslTslTBizEizEBsBBDWB-QEBEFBJHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB",!1)),Mc:()=>new g(m("joC4B4BDCBJDBCBBzBBB7BCBHBBDBBLsBsB7BCBjC7B7BBBBJCCB2B2BB7B7BCHHBDDBLLnDBBCBBECBCCBLqBqBBBB+BDB+BBB7BCCBDBDBBCBBKBBdPPB7B7BBBBGCBCCBLrBrBBsCsCBBBHHBTBBrKBBgCsFsFBFFHDDBaaBLLBBBDGBWBBDFBDLLBBB5zBffiEIIBGBCBB7KDBDCBFBBCFBhHBB7BCCKCCBJJBEByExBxBGCCBDBCBB+BffFBBD9B9BDCBCEEBxBxBBGBJBBsFWW35EBB0-dBBD5C5CBzBzBBOBvEBBwBxBxBBFFBDDBBBvDBBDBBZuBuBCuDuDDBBGuHuHBCCBCCBCC0gZCCgEuBuBBBBFBB0DZZB8B8BxBCBKBBO+C+CBBBEBBCrFrFBBBgBBB7BBBCDBDBBDCBKLLB1C1CBBBIDDCDBCBBCmDmDBBBJBBErDrDBBBHCCBCBDuHuHBBBHDBDyDyDBBBJBBCuDuDCBBHoDoDCBBFmImIBBBK4H4HBEBCBBFDDCvEvEBBBJDBF1C1CeBB-BqGqGECCoGPPrDIID2G2GBDBFBBC-K-KBNNxBBBJBBCpvQpvQBBBlxD2BBpDBB0rYBBHFB",!1)),Me:()=>new g(m("okBBB1xF-wB-wBBCBCCBsshBCB",!1)),Mn:()=>new g(m("gYvDB0IEBqIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCfB4BCCFHBFEEBFBLBBe7B7BFDBJVVBbbDBB6BFFBFFBDDBBBEffBEEMBB6BFFBDBCBBFVVBXXBEBC7B7BDCCBCBJIIBMMBff+BNNzBEE4BCCBBBGCBCDBIBBMBBe7B7BDHHGBBVBBdBB6BBBFDBJVVBeepCIIBBBC7C7CDGBNHBjDDDBHBMGBqCBBcEC4BNBCEBCBBGKBCjBBKnDnDBCBCFBCBBDBBaBBFCBRDBODDBHHQgWgWBBBzdCBeBBfBBfBBhCBBCGBJDDBJBKuBuBBBBC2D2DBjBjB3DCBFBBKHHBBB8GBBD7B7BCGBCCCDHBHJBDxBxBBMBCeBDLBVDBxBCCBDBCGGpBIBNBBhBDBDBBCCB5BCCBEECCB7BHBDBB5ECBCMBCGBFHHEBBnG-BBxWMBFEEBKB--CCBuEhDhDBeBrRDBsDBB1udFFBIBhBBBxCBBxIEEFaaBGG4EBBbRBOnBnBBGBaKBvBCBxBDDBCBDBBoBkCkCBEBDBBDBBNJJwB0B0BCCBDBBGBBCrBrBBJJvHDDFx5Tx5TiXPBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB8D3B3BBNBqBDDBLLBBByBDBDBBI+B+BBBBlBEBCHB-BNNB1B1BBHBLDBDgDgDBBBDCCBHHD+E+EEHBWBB6BBBEmBmBBFBEEBnCFBOECPBB2CHBDCBCYY1CFBCFFBCCBvHvHBCBHBBCBBcBB2CHBDCCBrDrDCDDBEBCmDmDCDDBCBCEBkIIBCBBhIBBCFFxEDBDBBFhBhBBIBpBFBDDBJKKBEBDCBvBMBCBBnGCCBBBCqGqGBFBCFBCzCzCBUBDGBCBBCBB7DFBECCBCCBFBCpCpCBEEC8K8KBMMB1B1BBDBGCCYmnFmnFHOBpmLLBECBhuCEB8BGB5gBgCgCBCByC5lT5lTBizEizEBsBBDWBhRCBSHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB",!1)),N:()=>new g(m("wBJB5DBBGDDBBBitBJBnEJBnGJB9MJB3DJBFFBtDJB3DJB3DJBDFBvDMB0DJBJGBoDJBpDGBISBuDJBhDJB3DJBnCTBtIJBnCJBwWTBybCBwHJBHJBXJBtJJBhEKBmFJBHJB3FJB3CJBnEJBHJB3gBEEBEBHJBnGyBBDEB3W7BBvCVB3TdBqrBqYqYaIBPCB4KDBrEJBfHBCOBhBJBoBOBh7cJB9FJBhKFB7EJBnBJBnGJBXJB3CJB3MJB34UJBuPsBBN4BBSBB2KaBlBDBeJJnEEBrGJBvdHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBxBJBHJB3IeB-EJBrBDBxDGBnEdBhEJB9BJBxEJBITB8HJB3KJB3DJB3LJBnDJBHTBtCLBlNSB+CJB3UJB3CcBkHJBnCJB3BJBnLJBnDUBshBuDBimPJBnpCJB3CJBnEJBCGBvQJBnIWB+KCB6nXJBnuBTBNTBtDYB2iBxBBhqCJBnNJB3PJB4HJBtWIBhEJB4Y6BBCCBCDBtCsBBCOBjeMBk3CJB",!1)),Nd:()=>new g(m("wBJnxBJnEJnGJ9MJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJhDJ3DJnCJ3IJnCJn6BJnBJtJJhEJnFJHJ3FJ3CJnEJHJnuiBJnVJnBJnGJXJ3CJ3MJ34UJnsBJnkCJHJ9YJhEJ9BJxEJ3IJ3KJ3DJ3LJnDJHTtCJnNJnDJ3UJ3CJ3HJnCJ3BJnLJ3uQJnpCJ3CJnEJ3QJ37XJ12CxBhqCJnNJ3PJ4HJ2aJ30EJ",!0)),Nl:()=>new g(m("u3FCBwzCiBBDDB-zDaaBHBPCBs1dJBxyW0BBtOJJnEEBrhIuDBm8SCB",!1)),No:()=>new g(m("yFBBGDDBBB2pCFB5LFB5DCBmEGB6GGBSIByNJB2hBTB0jBJBhP20B20BEFBHJBnGPBqB3W3WB6BBvCVB3TdBqrB1kB1kBBCBrEJBfHBCOBhBJBoBOBxrdFBymWsBBiCDBSBB2KaBlBDB1pBHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBhLeB-EJBrBDBxDGBnETB8LTBmqBBBvNIBobSB0aUBn8SGB-YWBqhZTBNTBtDYBvqFIBid6BBCCBCDBtCsBBCOBjeMB",!1)),P:()=>new g(m("hBCBCFBCDBLBBEBBbCBCccCkBkBGEELBBEEE-VJJzOFBqBBB0BCCDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCmBmBBCBoCrCrCBDBFBBwDFBsFlTlTBHB4EuTuTtBBBvCCBoCBB+ECBCCBmBKB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBM9Z9ZBWBJTBCMBCLBfBBPBB6TDBeBB+hBNBwCBBgBJB0MVBgCDBhBBB8XDBCBBxDwEwEBtBBCfBDLBkNCBFJBDLBRNNjD7C7CjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HzqUzqUBxGxGBIBXiBBCNBCFFCBB2ECBCFBCDBLBBEBBbCBCccCCCBFB7MCB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDByO-J-JjBlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB",!1)),Pc:()=>new g(m("-Cg-Hg-HBUU-u3BBBZCBwHAB",!1)),Pd:()=>new g(m("tB9qB9qB0BiyDiyDmgBqgCqgCBEBiwDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J",!1)),Pe:()=>new g(m("pB0B0BgB+1D+1DC-6B-6BqtC4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECtBGCtNICEGCDBB-ozB6G6GeOCESSCCCrF0B0BgBGD",!1)),Pf:()=>new g(m("7F+6H+6HEddpuDCCFDDQEE",!1)),Pi:()=>new g(m("rFt7Ht7HDBBDaapuDCCFDDQEE",!1)),Po:()=>new g(m("hBCBCCBDECBLLBEEBcclCGGPBBI-V-VJzOzOBEBqB3B3BDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCxDxDrCEBFBBwDFBsFlTlTBHBmY9D9DBBBoCBB+ECBCCBmBFBCDB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBMjajaBJJBGBJIBDDBDCBEKBCCCBIB7kDDBCBBxDwEwEBFFBBBDDDBHBCBBCDDBLLBDBCJBDDBCCCBLBDCBtNCB6B+F+FjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HlxUlxUBFBDXXVBBDDBECBCDBICBHCCB2E2EBBBCCBDECBLLBEEBcclBDDB7M7MBBB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDB0ZlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB",!1)),Ps:()=>new g(m("oBzBzBgB-1D-1DC-6B-6B-rCEEnB4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECaTTCECtNICEGCDipzBipzB4GeeCMCESSCCCrFzBzBgBEEDAB",!1)),S:()=>new g(m("kBHHRCBgBCCcCCkBEBCBBDCCBCBDEEfgBgBrODBNNBGGBCCCBPB2DPPBxDxDsErIrIBBB3DCBDDDBvGvGLUUB4H4HIBBpEqLqLBHHB2H2H-DjEjEBGBlEwGwGqBmGmGiGCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WuLuLlL+E+EBgBBiLJBKIBhiBCCBBBMCBOCBOCBOBBmCOOoBCBOCBUhBB-BBBCDBCBBLCCBBBGFBCECFMMBFFBDBGDBC7B7BBFFB2LBFcBD+HBXKByCtCBXnTBtBwBBDeBLyMBX+BBFfBD1LBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBB8CBB0HBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BB6RWBKBBoDBB+EDBLDB+RCBiHPPB+9T+9TpEgBBuLPBhCBB3BHBtBDBjDCCBBBD7E7EHRRBBBgBCCcCCiEGBCGBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSmWmWBiKiKBGBnjC2kC2kCBbBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQQBgDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBrbaagBaagBaagBaagBaa9B-PB4BDBzBHBCNBCBBp2BwNwNttCEE+DiOiOBvIvIBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB",!1)),Sc:()=>new g(m("kB+D+DBCBqnB8D8DzPBBzPBBI2H2HoImSmS8sClmClmCBgBB37hBkuVkuVtD7E7E8GBBEBB3-HDB-4wBxtCxtC",!1)),Sk:()=>new g(m("+CCCoCHHFEEqQDBNNBGGBCCCBPB2DPPBjoBjoB15FCCBBBMCBOCBOCBOBB9kEBBkzdWBKBBoDBBxePPBniUniUBPB8bCCjF4g9B4g9BBDB",!1)),Sm:()=>new g(m("rBRRBBB+BCCuBFFmBgBgB-XwQwQBBB8xGOOoBCBOCBsEoBoBBDBHlClCBDBGBBFGDIgBgBBDDCgBgBBqIBhBBB7CffBXBpBFB2OKK3BHBwDxKxKBDBDeBLPBhIiEBX+BBFfBDhIBxBUBDFB9+zB5Z5ZCCBlFRRBBB+BCCkEHHBCBitDBBhrwBx+Bx+BagBgBagBgBagBgBagBgBat5Ft5FB-uC-uCBHB",!1)),So:()=>new g(m("mFDDFCCyerIrIBgEgEBvGvGLUUB4H4HkQ2L2LjEFBClElEwGqBqBoMCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WzWzW+EhBBiLJBKIBksBBBCDBCBBLCCBHHBEBCECFMMBPPCBBC7B7BBKKBDBDDBCBBCBBCGBCeBDBBCCCBdBtIHBFTBDGBDwCBCdBanBBHnCBXKByCtCBX2FBCIBC1BBJuDBC3HBtBrBBhC-HBhQvBBWBBHmBBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBBxKBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BBibDBLBBC+R+RBBBqqUPBuLPBhCBB3BHBuBCBlPEEFBBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSpgBpgBBGBnjC2kC2kCBGBFQBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQPBhDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBqlB-PB4BDBzBHBCNBCBBp2B96C96CiEyWyWBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E6HBG4WBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBB-B3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB",!1)),Z:()=>new g(m("gBgEgEgvFgsCgsCBJBeBBGwBwBh9DAB",!1)),Zl:()=>new g(m("ohIA",!0)),Zp:()=>new g(m("phIA",!0)),Zs:()=>new g(m("gBgEgEgvFgsCgsCBJBlBwBwBh9DAB",!1)),ASCII_Hex_Digit:()=>new g(m("wBJIFbF",!0)),Alphabetic:()=>new g(m("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICC3CeeBQBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoBNBCCCBCCBCCJaBFDBeKBG3BBCGBPlDBCHBFHBFCBLCBDRRBuBBOkDBZgBBKBBFGGBWBDSBUYBIKBGXBCGBIJJBoBBLLBEGBHrCBCPBCCBFOBOSBCHBDBBDVBCGBCEEBCBEHBDBBDBBCJJFBBCEBNBBLFFBBBCFBFBBDVBCGBCBBCBBCBBFEBFBBDBBFIIBCBCSSBEBMCBCIBCCBCVBCGBCBBCEBEIBCCBCBBEQQBCBWDBFCBCHBDBBDVBCGBCBBCEBEHBDBBDBBKBBFBBCEBORRBCCBEBECBCDBEBBCCCBEEBEEBBBELBFEBECBCCBEHHpBMBCCBCWBCPBEHBCCBCCBJBBCCBCBBDDBdDBCHBCCBCWBCJBCEBEHBCCBCCBJBBGCBCDBOCBNMBCCBCoBBDHBCCBCCBCGGBCBIEBXFBCCBCRBEXBCIBCDDBFBJFBCCCBGBTBBO5BBGGBH0B0BBECBDBCXBCCCBRBCCBDEBCHHPDBhBgCgCBGBCjBBFSBFPBCjBBkC2BBCDDBDBR-BBLDBDlBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBEKBITBMUBNTBNMBCCBCBBNzBBDSBPFFkC4CBIqBBGlCBLeBCLBFIBYdBDEBMrBBFZB3BbBF+BBDTBzBYYBMMBBByBzBBCOBCHB0BpBBDDBLrBBCKBP2BBXCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBUhBBM1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBFSSBnBBuZzBB34BkHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBCfBwB2O2OBBBaIBIEBDEBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBGHBEwDBoBIBDmDBDxCBVUBCgBBZzBBNjCBCtBtBBEBECCBBBLgBBGiBBOcBEyBBCLBQRRBOBLEBC2BBKNBTWBEkCBCCCZCBDPBDDBMFBDFBDFBKGBCGBCqBBCNBH6DBWj9KBNWBFwBBloItLBDpDBnBGBNEBGLBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmC0BBsIcBEwBBwBfBOdBGqBBGdBDjBBFHBCEBrB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCDBCBBGHBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOnBBjBbBEGGBVB7HpBBCBBEBBRFBzBCBEcBLJJBUBrBRBvBUBcWBKlCBsBEBL4BBKOOBXBYyBBSDBJiBBEKKB+BBCDBKBBLCCkBRBChBBDHHBCB-BGBCCCBCBCOBCJBI4BBYDBCHBDBBDVBCGBCBBCEBEHBDBBDBBEHHGGBdJBCDDClBBCJBCDDCDBCBBECCtBhCBCCBCDBVCBfhCBDBBC5F5FB0BBDGBaFBjB+BBCEE8B1BBDoCoCBZBDNBWGB6F4BBoD-BBgBHBDDDBGBCBBCdBCBBDBBDDB+CHBDtBBDFBCCCBccBxBBDJBSnCBGTTBnCBoDHB5CgBBgBIBCsBBCGBCyByBBcBDVBCNBqCGBCBBCrBBECCBCCBBBCDDBZZBEBCBBCkBBCBBCDBCYYBqBBlIWBKQBCoBBECBwDwCwCB4cBnDuDBSjGBtyCgDBQvhBBSFBa68DBGmSB61GuBBy2B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBF4BBIQBhCBBCNNBFBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBFi7Fi7FBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCVBJBBhHGBCDBCBBCOBCkGB8BjCBEEE1lBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1TZBHZBHZB3zD-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Dash:()=>new g(m("tB9qB9qB0BiyDiyDmgBqgCqgCBEB+BoBoBQnMnMlgDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J",!1)),Emoji:()=>new g(m("jBHHGJBwDFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDrGrGhFBBNBBPDDBIBsCZBCBBYVVDIBWBBvFhBBDvDBDBBCCBDyCBDCBCmIBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDDBEJBECCBEEDJBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB",!1)),Emoji_Component:()=>new g(m("jBHHGJB0+H2G2Gsp3B3+8B3+8BBYB8PEBxtBDBtzhY-CB",!1)),Emoji_Modifier:()=>new g(m("7-8DE",!0)),Emoji_Modifier_Base:()=>new g(m("9wJ8G8GRDB4jzD9B9BBBBDDDBBB2DBBDKBWSBEFFBBBCCBICCZqGqGBFFWFFBvFvFBBBEEB0CRRBBBKMMgSDDJHBHKKBIBDCB5B+B+BBCCBCCSCBCMBmHCBrBIB",!1)),Emoji_Presentation:()=>new g(m("64IBBuGDBEDDqQBBWBBzBLBsBUUOJJBSSBGGBJJGWWIBBCFFDIIFBBdkBkBCFFBBBC+B+BBBBZPP8aBB0BFFvlxDrGrG-FDDBIBsCZBCZZVDDBDBCCBWBBvFgBBNIBClCBCVBNqBBFEBNQBEEEBlCBCCCB5FBD+BBODBCXBTbbBOO3C0CBxBlCBHEEBBBDDBEDBMBBIIBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB",!1)),Extended_Pictographic:()=>new g(m("pFFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDoBoBBCBlDLBQBBQPPBmBmBBIBxDBBNBBPDDBIBU3BBcOBLVVDIBCDBKWBH7FBDvDBDBBCCBDyCBDCBCDBG9HBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDQBECCBEBDMB7GlBBNDB5BHBLFBpBHBfBBNDBDNBKmBBNuBBCJBC4FB5CHBPxEBhI9fB",!1)),Hex_Digit:()=>new g(m("wBJIFbFq1-BJIFbF",!0)),Lowercase:()=>new g(m("hDZBwBLLFlBlBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDiBBIBBfEBhDsBsBCEEDDBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBCDB5XFBjkCIBC2D2DB+FBiC0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBB6DOORMBuDEEBEEcKFDBBJDBFiBiBBOBFsasaBYBn6BvBBCEEBGCFCCBCCBGBEiDCBIICFFNlBBCGG0oesBCUaCBBBmEMCBBBC8BCBIBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCWDBCCCBBB2ZqBBCNBHvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBkODDBBBCpBBCIBmoByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFBmI9BB1lChBB",!1)),Math:()=>new g(m("rBRRBBBgBeeCuBuBFmBmBgB5W5WBBBDbbBDDBBBwQCBuwGccBBBMEEOPPBCBWEBMEBiCMBFEEBFFBDBTFFDJBCDDBEBHEEBDDBCCBBBCFBENBClClCBWBCFBCBBFBBFfBCHHBPPBqIBJDBVBB7CffBZBCZZMGB+NBBNJBFFBFBBDBBEEBPCCDFBMHBGBB6BCCeDBKCBxK-BBhI-PBxBUBDFB9+zB4Z4ZBEBCjFjFRCBeCCeCCkEHHBCBitDBBhrwBwoBwoBBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBBhwFDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB-uCIB",!1)),Quotation_Mark:()=>new g(m("iBFFkEQQ96HHBaBBowDqOqOBCBOCBixzBDB+FFF7CBB",!1)),Terminal_Punctuation:()=>new g(m("hBLLCMMBEE-ZJJiQ6B6BpCPPCCB1FsBsBBJBCsHsHB3B3BBEBCHBgBmImIB1nB1nBBtFtFFFB4JBB2YHBmY9D9DBBBoCBB+ECBEoBoBBCBDBB7JBBjLDBjFBBLBBCCBeCB8FEB-BBBldYYBKKBBBwlDCBzJOOFLLCBBEBBtNBB8ndBBuICBkHEB-LBB3CBBgD4E4EBBB0ECBgERRB6H6HnxUDDB6B6BBBBCDBqFLLCMMBEEiCDD7hBxBxBnkBoGoG3JBB5EFBlCFB6CDB5dEBtBDB+FGBxDDBgECBiEBBHRRB5C5CBDBtDrJrJB2D2DBBBNBBnLDBEOBqDBB6HCBmQCC8HBB4CBBFBB-MCBuBmUmUBrCrCBspBspBBDB6vRBBmEiCiCBBBLqRqRBoJoJBnwTnwTovHDB",!1)),Uppercase:()=>new g(m("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBGbbBOBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBBvgCZBHZBHZB",!1)),White_Space:()=>new g(m("JEBTlDlDbgvFgvFgsCKBeBBGwBwBh9DAB",!1))})),H(Nn,"SCRIPTS",new yo({Adlam:()=>new g(m("go6DrCFJFB",!0)),Ahom:()=>new g(m("g4lCaDOFW",!0)),Anatolian_Hieroglyphs:()=>new g(m("ggxCmS",!0)),Arabic:()=>new g(m("gwBEBCFBCNBCCBCfBCJBMZBCrDBChBBxCvBBxHhBBGqCBCcBxy8BtPBDvEBhBPBxDEBCmEBk7DeBkCFBJIBiBFBh43BDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB",!1)),Armenian:()=>new g(m("xpBlBDxBDCks9BE",!0)),Avestan:()=>new g(m("g4iC1BEG",!0)),Balinese:()=>new g(m("g4GsCCxB",!0)),Bamum:()=>new g(m("g1pB3CpowB4R",!0)),Bassa_Vah:()=>new g(m("w26CdDF",!0)),Batak:()=>new g(m("g+GzBJD",!0)),Bengali:()=>new g(m("gsCDBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYB",!1)),Beria_Erfe:()=>new g(m("g17CYDY",!0)),Bhaiksuki:()=>new g(m("ggnCICsBCNLc",!0)),Bopomofo:()=>new g(m("qXB6wLqBxDf",!0)),Brahmi:()=>new g(m("ggkCtCFjBKA",!0)),Braille:()=>new g(m("ggK-H",!0)),Buginese:()=>new g(m("gwGbDB",!0)),Buhid:()=>new g(m("g6FT",!0)),Canadian_Aboriginal:()=>new g(m("ggF-TxRlC7tgCP",!0)),Carian:()=>new g(m("g1gCwB",!0)),Caucasian_Albanian:()=>new g(m("wphCzBMA",!0)),Chakma:()=>new g(m("gokC0BCR",!0)),Cham:()=>new g(m("gwqB2BKNDJDD",!0)),Cherokee:()=>new g(m("g9E1CDFz7lBvC",!0)),Chorasmian:()=>new g(m("w9jCb",!0)),Common:()=>new g(m("AgCBbFBbuBBCOBCEBYgBgBiOmBBGEBDTB1DKKHCC+THHPEEhB9E9ElQiEiEB6mB6mB2MDBjJwvBwvBBBBoCBBsGBBCumBumBOIIBCBCFBCCBDmYmYBKBD2CBCKBEKBCOBShBB-BlBBCCBDFBCaBCQBqBCBF5UBXKBW-cBhIzTBDpEBhQ9CBzMUBCCCBXBQHBFDB8CBBE7C7CB0E0EBOBhBlBBKxBxBB+BBgBwCBwB5C5CBmFBhuG-BBhoWhBBnDCBmFJB1HhFhFsMPPBzuUzuUBxGxGBIBXiBBCSBCDB0ECCBeBbFBbKBLuBuBBhChCBFBCGBLEBjICBFsBBEIBxCMB0BsBBlHaBltuBDB96D8HBEzNBHWBQQBgDzDB9B1HBLmBBD9BBEQBJBBIdBF8BB2GTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBByjFjCBtC8BBjWrBBFjDBNOBDOBCOBCkBBLtFB5BZBCBBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBnghYffB+CB",!1)),Coptic:()=>new g(m("ifNxkKzDGG",!0)),Cuneiform:()=>new g(m("ggoC5cnDuDCEMjG",!0)),Cypriot:()=>new g(m("ggiCFBDCCBqBBCBBEDD",!1)),Cypro_Minoan:()=>new g(m("w8rCiD",!0)),Cyrillic:()=>new g(m("ggBkEBDoFBx6FKBhFtCtCojEfBhie-CBv8VBBhw4B9BBiBAB",!1)),Deseret:()=>new g(m("gghCvC",!0)),Devanagari:()=>new g(m("goCwCFODZh7nBfhwcJ",!0)),Dives_Akuru:()=>new g(m("gomCGBDDDBGBCBBCdBCBBDLBKJB",!1)),Dogra:()=>new g(m("ggmC7B",!0)),Duployan:()=>new g(m("ggvDqDGMEIIJDD",!0)),Egyptian_Hieroglyphs:()=>new g(m("ggsC1iBL68D",!0)),Elbasan:()=>new g(m("gohCnB",!0)),Elymaic:()=>new g(m("g-jCW",!0)),Ethiopic:()=>new g(m("gwEoCBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBnvGWBKGBCGBCGBCGBCGBCGBCGBCGBjpfFBDFBDFBKGBCGBylvCGBCDBCBBCOB",!1)),Garay:()=>new g(m("gqjClBEcJB",!0)),Georgian:()=>new g(m("glElBBCGGDqBBCDBx8CqBBDCBhiElBBCGG",!1)),Glagolitic:()=>new g(m("ggL-Ch9sDGCQDGCBCE",!0)),Gothic:()=>new g(m("w5gCa",!0)),Grantha:()=>new g(m("g4kCDBCHBDBBDVBCGBCBBCEBDIBDBBDCBDHHGGBDGBEEB",!1)),Greek:()=>new g(m("wbDBCCBDDBCFFCCCBBBCCCBSBC+BBPPBnpGEBzBEBFEB1ChKhKBUBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBoJ-xiB-xiB7uVuCBSgj0Bgj0BBkCB",!1)),Gujarati:()=>new g(m("h0CCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGB",!1)),Gunjala_Gondi:()=>new g(m("grnCFCBCkBCBCFIJ",!0)),Gurmukhi:()=>new g(m("hwCCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPB",!1)),Gurung_Khema:()=>new g(m("go4C5B",!0)),Han:()=>new g(m("g0LZBC4CBN1GBwBCCaIBPDBle-tGBhC-vUBhoWtLBDpDBpodBBNGBqgkB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Hangul:()=>new g(m("goE-HvxHBiI9CyDeiCei3dckUj9KNWFwBl9JeEFDFDFDC",!0)),Hanifi_Rohingya:()=>new g(m("gojCnBJJ",!0)),Hanunoo:()=>new g(m("g5FU",!0)),Hatran:()=>new g(m("gniCSCBGE",!0)),Hebrew:()=>new g(m("xsB2BBJaBFFBpp9BZBCEBCCCBCCBCCBIB",!1)),Hiragana:()=>new g(m("hiM1CBHCBi7-C+IBTeeBBBulQAB",!1)),Imperial_Aramaic:()=>new g(m("giiCVCI",!0)),Inherited:()=>new g(m("gYvDB2IBBlOKBbhXhXBCB8qEtBBDLBlPCBCMBCGBFHHEBBnG-BBtQBBjGgBB65DDBsDBBmrzBPBRNBwejHjH7iEl+uBl+uBBsBBDWBhRCBSHBDGBfDBz6rYvHB",!1)),Inscriptional_Pahlavi:()=>new g(m("g7iCSGH",!0)),Inscriptional_Parthian:()=>new g(m("g6iCVDH",!0)),Javanese:()=>new g(m("gsqBtCDJFB",!0)),Kaithi:()=>new g(m("gkkCiCLA",!0)),Kannada:()=>new g(m("gkDMCCCWCJCEDICCCDIBGCCDDJCC",!0)),Katakana:()=>new g(m("hlM5CBDCBxHPBxGuBBC3CBvgzBJBCsBBzisBDBCGBCBBCgJgJBBBzBPPBCB",!1)),Kawi:()=>new g(m("g4nCQCoBEc",!0)),Kayah_Li:()=>new g(m("goqBtBCA",!0)),Kharoshthi:()=>new g(m("gwiCDCBGHCCCcDCFJII",!0)),Khitan_Small_Script:()=>new g(m("k-7C84G84GB0OBqBAB",!1)),Khmer:()=>new g(m("g8F9CDJHJnPf",!0)),Khojki:()=>new g(m("gwkCRCuB",!0)),Khudawadi:()=>new g(m("w1kC6BGJ",!0)),Kirat_Rai:()=>new g(m("gq7C5B",!0)),Lao:()=>new g(m("h0DBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDB",!1)),Latin:()=>new g(m("hCZBHZBwBQQGWBCeBCgOBoBEB8wGlBBHwBBGDBGMBClCBiC-HByLOORMBuEBBHccSoBB42CfBj1elDBExCBVOBxZqBBCIBCDB38TGB7gBZBHZBmhCFBCpBBCIBm61BeBHFB",!1)),Lepcha:()=>new g(m("ggH3BEOEC",!0)),Limbu:()=>new g(m("goGeBCLBFLBFEEBKB",!1)),Linear_A:()=>new g(m("gwhC2JKVLH",!0)),Linear_B:()=>new g(m("gggCLCZCSCBCODNjB6D",!0)),Lisu:()=>new g(m("wmpBvBx1eA",!0)),Lycian:()=>new g(m("g0gCc",!0)),Lydian:()=>new g(m("gpiCZGA",!0)),Mahajani:()=>new g(m("wqkCmB",!0)),Makasar:()=>new g(m("g3nCY",!0)),Malayalam:()=>new g(m("goDMCCCyBCCCFFPDZ",!0)),Mandaic:()=>new g(m("giCbDA",!0)),Manichaean:()=>new g(m("g2iCmBFL",!0)),Marchen:()=>new g(m("wjnCfDVCN",!0)),Masaram_Gondi:()=>new g(m("gonCGBCBBCrBBECCBCCBHBJJB",!1)),Medefaidrin:()=>new g(m("gy7C6C",!0)),Meetei_Mayek:()=>new g(m("g3qBWqGtBDJ",!0)),Mende_Kikakui:()=>new g(m("gg6DkGDP",!0)),Meroitic_Cursive:()=>new g(m("gtiCXFTDtB",!0)),Meroitic_Hieroglyphs:()=>new g(m("gsiCf",!0)),Miao:()=>new g(m("g47CqCF4BIQ",!0)),Modi:()=>new g(m("gwlCkCMJ",!0)),Mongolian:()=>new g(m("ggGBBDCCBSBH4CBIqBB2t-BMB",!1)),Mro:()=>new g(m("gy6CeCJFB",!0)),Multani:()=>new g(m("g0kCGBCCCBCBCOBCKB",!1)),Myanmar:()=>new g(m("ggE-EhqmBeiDfxibT",!0)),Nabataean:()=>new g(m("gkiCeJI",!0)),Nag_Mundari:()=>new g(m("wm5DpB",!0)),Nandinagari:()=>new g(m("gtmCHDtBDK",!0)),New_Tai_Lue:()=>new g(m("gsGrBFZHKEB",!0)),Newa:()=>new g(m("gglC7CCE",!0)),Nko:()=>new g(m("g+B6BDC",!0)),Nushu:()=>new g(m("h-7CvsQvsQBqMB",!1)),Nyiakeng_Puachue_Hmong:()=>new g(m("go4DsBENDJFB",!0)),Ogham:()=>new g(m("g0Fc",!0)),Ol_Chiki:()=>new g(m("wiHvB",!0)),Ol_Onal:()=>new g(m("wu5DqBFA",!0)),Old_Hungarian:()=>new g(m("gkjCyBOyBIF",!0)),Old_Italic:()=>new g(m("g4gCjBKC",!0)),Old_North_Arabian:()=>new g(m("g0iCf",!0)),Old_Permic:()=>new g(m("w6gCqB",!0)),Old_Persian:()=>new g(m("g9gCjBFN",!0)),Old_Sogdian:()=>new g(m("g4jCnB",!0)),Old_South_Arabian:()=>new g(m("gziCf",!0)),Old_Turkic:()=>new g(m("ggjCoC",!0)),Old_Uyghur:()=>new g(m("w7jCZ",!0)),Oriya:()=>new g(m("h4CCCHDBDVCGCBCEDIDBDCICFBCEDR",!0)),Osage:()=>new g(m("wlhCjBFjB",!0)),Osmanya:()=>new g(m("gkhCdDJ",!0)),Pahawh_Hmong:()=>new g(m("g46ClCLJCGCUGS",!0)),Palmyrene:()=>new g(m("gjiCf",!0)),Pau_Cin_Hau:()=>new g(m("g2mC4B",!0)),Phags_Pa:()=>new g(m("giqB3B",!0)),Phoenician:()=>new g(m("goiCbEA",!0)),Psalter_Pahlavi:()=>new g(m("g8iCRIDNG",!0)),Rejang:()=>new g(m("wpqBjBMA",!0)),Runic:()=>new g(m("g1FqCEK",!0)),Samaritan:()=>new g(m("ggCtBDO",!0)),Saurashtra:()=>new g(m("gkqBlCJL",!0)),Sharada:()=>new g(m("gskC-ChsCH",!0)),Shavian:()=>new g(m("wihCvB",!0)),Siddham:()=>new g(m("gslC1BDlB",!0)),Sidetic:()=>new g(m("gqiCZ",!0)),SignWriting:()=>new g(m("gg2DrUQECO",!0)),Sinhala:()=>new g(m("hsDCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBt-gCTB",!1)),Sogdian:()=>new g(m("w5jCpB",!0)),Sora_Sompeng:()=>new g(m("wmkCYIJ",!0)),Soyombo:()=>new g(m("wymCyC",!0)),Sundanese:()=>new g(m("g8G-BhIH",!0)),Sunuwar:()=>new g(m("g+mChBPJ",!0)),Syloti_Nagri:()=>new g(m("ggqBsB",!0)),Syriac:()=>new g(m("g4BNC7BDCxIK",!0)),Tagalog:()=>new g(m("g4FVKA",!0)),Tagbanwa:()=>new g(m("g7FMCCCB",!0)),Tai_Le:()=>new g(m("wqGdDE",!0)),Tai_Tham:()=>new g(m("gxG+BCcDKHJHN",!0)),Tai_Viet:()=>new g(m("g0qBiCZE",!0)),Tai_Yo:()=>new g(m("g25DeCVJB",!0)),Takri:()=>new g(m("g0lC5BHJ",!0)),Tamil:()=>new g(m("i8CBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBm+kCxBBOAB",!1)),Tangsa:()=>new g(m("wz6CuCCJ",!0)),Tangut:()=>new g(m("g-7CgBgBB+3GBhQeBiDyDB",!1)),Telugu:()=>new g(m("ggDMCCCWCPDICCCDIBCCCBDDDJII",!0)),Thaana:()=>new g(m("g8BxB",!0)),Thai:()=>new g(m("hwD5BGb",!0)),Tibetan:()=>new g(m("g4DnCCjBFmBCjBCOCGFB",!0)),Tifinagh:()=>new g(m("wpL3BIBPA",!0)),Tirhuta:()=>new g(m("gklCnCJJ",!0)),Todhri:()=>new g(m("guhCzB",!0)),Tolong_Siki:()=>new g(m("wtnCrBFJ",!0)),Toto:()=>new g(m("w04De",!0)),Tulu_Tigalari:()=>new g(m("g8kCJBCDDClBBCJBCDDCDBCJBCBBJBB",!1)),Ugaritic:()=>new g(m("g8gCdCA",!0)),Unknown:()=>new g(m("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-FB",!1)),Vai:()=>new g(m("gopBrJ",!0)),Vithkuqi:()=>new g(m("wrhCKCOCGCBCKCOCGCB",!0)),Wancho:()=>new g(m("g24D5BGA",!0)),Warang_Citi:()=>new g(m("glmCyCNA",!0)),Yezidi:()=>new g(m("g0jCpBCCDB",!0)),Yi:()=>new g(m("ggoBskBE2B",!0)),Zanabazar_Square:()=>new g(m("gwmCnC",!0))})),H(Nn,"FOLD_CATEGORIES",new yo({L:()=>new g(m("laA",!0)),LC:()=>new g(m("laA",!0)),Ll:()=>new g(m("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGC3HrBrBCEEJHHCCBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHxC9zC9zCBuBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB",!1)),Lt:()=>new g(m("kOCCBCCBCClBCCtsHHBJHBJHBMQQwBAB",!1)),Lu:()=>new g(m("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpL2B2Bs1CvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB",!1)),M:()=>new g(m("5cgBgBlgHAB",!1)),Mn:()=>new g(m("5cgBgBlgHAB",!1)),Emoji:()=>new g(m("8mJA",!0)),Extended_Pictographic:()=>new g(m("8mJA",!0)),Lowercase:()=>new g(m("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHuBPBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB",!1)),Math:()=>new g(m("ycGDCHHFMMDDDCHHFAB",!1)),Uppercase:()=>new g(m("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpLiBiBBOBFsasaBYBn6BvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB",!1))})),H(Nn,"FOLD_SCRIPT",new yo({Common:()=>new g(m("8cgBgB",!1)),Greek:()=>new g(m("1FwUwU",!1)),Inherited:()=>new g(m("5cgBgBlgHAB",!1))})),Nn),we,Q=(we=class{static is32(e,t){let n=0,r=e.length;for(;n<r;){const i=n+Math.floor((r-n)/2),o=e.getLo(i),a=e.getHi(i);if(o<=t&&t<=a){const l=e.getStride(i);return(t-o)%l===0}t<o?r=i:n=i+1}return!1}static is(e,t){if(t<=we.MAX_LATIN1){for(let n=0;n<e.length;n++){if(t>e.getHi(n))continue;const r=e.getLo(n);if(t<r)return!1;const i=e.getStride(n);return(t-r)%i===0}return!1}return e.length>0&&t>=e.getLo(0)&&we.is32(e,t)}static isUpper(e){if(e<=we.MAX_LATIN1){const t=String.fromCodePoint(e);return t.toUpperCase()===t&&t.toLowerCase()!==t}return we.is(_t.Upper,e)}static isPrint(e){return e<=we.MAX_LATIN1?e>=32&&e<we.MAX_ASCII||e>=161&&e!==173:we.is(_t.Print,e)}static simpleFold(e){if(_t.CASE_ORBIT.has(e))return _t.CASE_ORBIT.get(e);const t=L.toLowerCase(e);return t!==e?t:L.toUpperCase(e)}static equalsIgnoreCase(e,t){if(e===t)return!0;if(e<0||t<0)return!1;if(e<=we.MAX_ASCII&&t<=we.MAX_ASCII)return 65<=e&&e<=90&&(e|=32),65<=t&&t<=90&&(t|=32),e===t;for(let n=we.simpleFold(e);n!==e;n=we.simpleFold(n))if(n===t)return!0;return!1}},H(we,"MAX_RUNE",1114111),H(we,"MAX_ASCII",127),H(we,"MAX_LATIN1",255),H(we,"MAX_BMP",65535),H(we,"MIN_FOLD",65),H(we,"MAX_FOLD",125251),H(we,"MIN_HIGH_SURROGATE",55296),H(we,"MAX_HIGH_SURROGATE",56319),H(we,"MIN_LOW_SURROGATE",56320),H(we,"MAX_LOW_SURROGATE",57343),H(we,"MIN_SUPPLEMENTARY_CODE_POINT",65536),we);const Ml=256,Rd=new Uint8Array(Ml);for(let s=0;s<Ml;s++)Rd[s]=97<=s&&s<=122||65<=s&&s<=90||48<=s&&s<=57||s===95?1:0;let RB=null,SB=null;var Re,$=(Re=class{static emptyInts(){return[]}static isByteArray(e){return Array.isArray(e)||e instanceof Uint8Array}static isalnum(e){return L.CODES.get("0")<=e&&e<=L.CODES.get("9")||L.CODES.get("a")<=e&&e<=L.CODES.get("z")||L.CODES.get("A")<=e&&e<=L.CODES.get("Z")}static unhex(e){return L.CODES.get("0")<=e&&e<=L.CODES.get("9")?e-L.CODES.get("0"):L.CODES.get("a")<=e&&e<=L.CODES.get("f")?e-L.CODES.get("a")+10:L.CODES.get("A")<=e&&e<=L.CODES.get("F")?e-L.CODES.get("A")+10:-1}static escapeRune(e){let t="";if(Q.isPrint(e))Re.METACHARACTERS.indexOf(String.fromCodePoint(e))>=0&&(t+="\\"),t+=String.fromCodePoint(e);else switch(e){case L.CODES.get('"'):t+='\\"';break;case L.CODES.get("\\"):t+="\\\\";break;case L.CODES.get("	"):t+="\\t";break;case L.CODES.get(`
`):t+="\\n";break;case L.CODES.get("\r"):t+="\\r";break;case L.CODES.get("\b"):t+="\\b";break;case L.CODES.get("\f"):t+="\\f";break;default:{let n=e.toString(16);e<256?(t+="\\x",n.length===1&&(t+="0"),t+=n):t+=`\\x{${n}}`;break}}return t}static stringToRunes(e){const t=String(e),n=[];let r=0;for(;r<t.length;){const i=t.codePointAt(r);n.push(i),r+=i>Q.MAX_BMP?2:1}return n}static runeToString(e){return String.fromCodePoint(e)}static isWordRune(e){return e<Ml?Rd[e]===1:!1}static emptyOpContext(e,t){let n=0;return e<0&&(n|=Re.EMPTY_BEGIN_TEXT|Re.EMPTY_BEGIN_LINE),e===10&&(n|=Re.EMPTY_BEGIN_LINE),t<0&&(n|=Re.EMPTY_END_TEXT|Re.EMPTY_END_LINE),t===10&&(n|=Re.EMPTY_END_LINE),Re.isWordRune(e)!==Re.isWordRune(t)?n|=Re.EMPTY_WORD_BOUNDARY:n|=Re.EMPTY_NO_WORD_BOUNDARY,n}static quoteMeta(e){return e.split("").map(t=>Re.METACHARACTERS.indexOf(t)>=0?`\\${t}`:t).join("")}static charCount(e){return e>Q.MAX_BMP?2:1}static toArray(e){const t=e.length,n=new Array(t);for(let r=0;r<t;r++)n[r]=e[r];return n}static stringToUtf8ByteArray(e){if(globalThis.TextEncoder)return RB||(RB=new TextEncoder),RB.encode(e);{let t=[],n=0;for(let r=0;r<e.length;r++){let i=e.charCodeAt(r);i<128?t[n++]=i:i<2048?(t[n++]=i>>6|192,t[n++]=i&63|128):(i&64512)===Q.MIN_HIGH_SURROGATE&&r+1<e.length&&(e.charCodeAt(r+1)&64512)===Q.MIN_LOW_SURROGATE?(i=Q.MIN_SUPPLEMENTARY_CODE_POINT+((i&1023)<<10)+(e.charCodeAt(++r)&1023),t[n++]=i>>18|240,t[n++]=i>>12&63|128,t[n++]=i>>6&63|128,t[n++]=i&63|128):(t[n++]=i>>12|224,t[n++]=i>>6&63|128,t[n++]=i&63|128)}return t}}static utf8ByteArrayToString(e){if(globalThis.TextDecoder){SB||(SB=new TextDecoder("utf-8"));const t=e instanceof Uint8Array?e:new Uint8Array(e);return SB.decode(t)}else{let t=[],n=0,r=0;for(;n<e.length;){let i=e[n++];if(i<128)t[r++]=String.fromCharCode(i);else if(i>191&&i<224){let o=e[n++];t[r++]=String.fromCharCode((i&31)<<6|o&63)}else if(i>239&&i<365){let o=e[n++],a=e[n++],l=e[n++],c=((i&7)<<18|(o&63)<<12|(a&63)<<6|l&63)-Q.MIN_SUPPLEMENTARY_CODE_POINT;t[r++]=String.fromCharCode(Q.MIN_HIGH_SURROGATE+(c>>10)),t[r++]=String.fromCharCode(Q.MIN_LOW_SURROGATE+(c&1023))}else{let o=e[n++],a=e[n++];t[r++]=String.fromCharCode((i&15)<<12|(o&63)<<6|a&63)}}return t.join("")}}},H(Re,"METACHARACTERS","\\.+*?()|[]{}^$"),H(Re,"EMPTY_BEGIN_LINE",1),H(Re,"EMPTY_END_LINE",2),H(Re,"EMPTY_BEGIN_TEXT",4),H(Re,"EMPTY_END_TEXT",8),H(Re,"EMPTY_WORD_BOUNDARY",16),H(Re,"EMPTY_NO_WORD_BOUNDARY",32),H(Re,"EMPTY_ALL",-1),Re);const Sd=(s=[],e=0)=>{const t=Object.create(null);for(let n=0;n<s.length;n++){const r=s[n],i=e+n;t[r]=i,t[i]=r}return Object.freeze(t)};var xn,As=(xn=class{getEncoding(){throw Error("not implemented")}asCharSequence(){throw Error("not implemented")}asBytes(){throw Error("not implemented")}length(){throw Error("not implemented")}isUTF8Encoding(){return this.getEncoding()===xn.Encoding.UTF_8}isUTF16Encoding(){return this.getEncoding()===xn.Encoding.UTF_16}},H(xn,"Encoding",Sd(["UTF_16","UTF_8"])),xn),bh=class extends As{constructor(s=null){super(),this.bytes=s}getEncoding(){return As.Encoding.UTF_8}asCharSequence(){return $.utf8ByteArrayToString(this.bytes)}asBytes(){return this.bytes}length(){return this.bytes.length}},yy=class extends As{constructor(s=null){super(),this.charSequence=s}getEncoding(){return As.Encoding.UTF_16}asCharSequence(){return this.charSequence}asBytes(){return $.stringToUtf8ByteArray(this.charSequence.toString())}length(){return this.charSequence.length}},gs=class{static utf16(s){return new yy(s)}static utf8(s){return $.isByteArray(s)?new bh(s):new bh($.stringToUtf8ByteArray(s))}},pt=class{static EOF(){return-8}constructor(){this.end=0}canCheckPrefix(){return!0}endPos(){return this.end}hasString(){return!1}hasAnyString(){return!1}prefixLength(){return 0}},wy=class extends pt{constructor(s,e=0,t=s.length){super(),this.bytes=s,this.start=e,this.end=t}hasString(s,e){const t=s.bytes;if(t.length===0)return!0;const n=this.indexOf(this.bytes,t,this.start+e);return n!==-1&&n<=this.end-t.length}hasAnyString(s,e){return s.ac8?s.ac8.searchUTF8(this.bytes,this.start+e,this.end):!1}step(s){if(s+=this.start,s>=this.end)return pt.EOF();const e=this.bytes[s]&255;if(e<128)return e<<3|1;if(e>=194&&e<=223&&s+1<this.end){const t=this.bytes[s+1]&255;return(t&192)!==128?e<<3|1:((e&31)<<6|t&63)<<3|2}else if(e>=224&&e<=239&&s+2<this.end){const t=this.bytes[s+1]&255;if((t&192)!==128)return e<<3|1;const n=this.bytes[s+2]&255;return(n&192)!==128?e<<3|1:((e&15)<<12|(t&63)<<6|n&63)<<3|3}else if(e>=240&&e<=244&&s+3<this.end){const t=this.bytes[s+1]&255;if((t&192)!==128)return e<<3|1;const n=this.bytes[s+2]&255;if((n&192)!==128)return e<<3|1;const r=this.bytes[s+3]&255;return(r&192)!==128?e<<3|1:((e&7)<<18|(t&63)<<12|(n&63)<<6|r&63)<<3|4}else return e<<3|1}index(s,e){e+=this.start;const t=this.indexOf(this.bytes,s.prefixUTF8,e);return t<0?t:t-e}context(s){s+=this.start;let e=-1;if(s>this.start&&s<=this.end){let n=s-1;if(e=this.bytes[n--],e>=128){let r=s-4;for(r<this.start&&(r=this.start);n>=r&&(this.bytes[n]&192)===128;)n--;n<this.start&&(n=this.start),e=this.step(n-this.start)>>3}}const t=s<this.end?this.step(s-this.start)>>3:-1;return $.emptyOpContext(e,t)}indexOf(s,e,t=0){let n=e.length;if(n===0)return t<=this.end?t:-1;const r=e[0];let i=this.end-n;const o=typeof s.indexOf=="function";let a=t;for(;a<=i;){if(o){if(a=s.indexOf(r,a),a===-1||a>i)return-1}else{for(;a<=i&&s[a]!==r;)a++;if(a>i)return-1}let l=!0;for(let c=1;c<n;c++)if(s[a+c]!==e[c]){l=!1;break}if(l)return a;a++}return-1}prefixLength(s){return s.prefixUTF8.length}},Ty=class extends pt{constructor(s,e=0,t=s.length){super(),this.charSequence=s,this.start=e,this.end=t}hasString(s,e){const t=this.charSequence.indexOf(s.str,this.start+e);return t!==-1&&t<=this.end-s.str.length}hasAnyString(s,e){return s.ac16?s.ac16.searchUTF16(this.charSequence,this.start+e,this.end):!1}step(s){if(s+=this.start,s>=this.end)return pt.EOF();const e=this.charSequence.charCodeAt(s);if(e<Q.MIN_HIGH_SURROGATE||e>Q.MAX_HIGH_SURROGATE||s+1>=this.end)return e<<3|1;const t=this.charSequence.charCodeAt(s+1);return t>=Q.MIN_LOW_SURROGATE&&t<=Q.MAX_LOW_SURROGATE?(e-Q.MIN_HIGH_SURROGATE)*1024+(t-Q.MIN_LOW_SURROGATE)+Q.MIN_SUPPLEMENTARY_CODE_POINT<<3|2:e<<3|1}index(s,e){e+=this.start;const t=this.charSequence.indexOf(s.prefix,e);return t<0||t>this.end-s.prefix.length?-1:t-e}context(s){s+=this.start;const e=s>this.start&&s<=this.end?this.charSequence.charCodeAt(s-1):-1,t=s<this.end?this.charSequence.charCodeAt(s):-1;return $.emptyOpContext(e,t)}prefixLength(s){return s.prefix.length}},Ae=class{static fromUTF8(s,e=0,t=s.length){return new wy(s,e,t)}static fromUTF16(s,e=0,t=s.length){return new Ty(s,e,t)}},ki=class extends Error{constructor(s){super(s),this.name="RE2JSException"}},Te=class extends ki{constructor(s,e=null){let t=`error parsing regexp: ${s}`;e&&(t+=`: \`${e}\``),super(t),this.name="RE2JSSyntaxException",this.message=t,this.error=s,this.input=e}getDescription(){return this.error}getPattern(){return this.input}},Iy=class extends ki{constructor(s){super(s),this.name="RE2JSCompileException"}},mt=class extends ki{constructor(s){super(s),this.name="RE2JSGroupException"}},Ay=class extends ki{constructor(s){super(s),this.name="RE2JSFlagsException"}},ni=class extends ki{constructor(s){super(s),this.name="RE2JSInternalException"}},Es,Nh=(Es=class{static quoteReplacement(e,t=!1){return t?e.indexOf("\\")<0&&e.indexOf("$")<0?e:e.split("").map(n=>{const r=n.codePointAt(0);return r===L.CODES.get("\\")||r===L.CODES.get("$")?`\\${n}`:n}).join(""):e.indexOf("$")<0?e:e.split("").map(n=>n.codePointAt(0)===L.CODES.get("$")?"$$":n).join("")}constructor(e,t){if(e===null)throw new Error("pattern is null");this.patternInput=e;const n=this.patternInput.re2();this.patternGroupCount=n.numberOfCapturingGroups(),this.groups=[],this.namedGroups=n.namedGroups,this.numberOfInstructions=n.numberOfInstructions(),t instanceof As?this.resetMatcherInput(t):$.isByteArray(t)?this.resetMatcherInput(gs.utf8(t)):this.resetMatcherInput(gs.utf16(t))}pattern(){return this.patternInput}reset(){return this.matcherInputLength=this.matcherInput.length(),this.appendPos=0,this.hasMatch=!1,this.hasGroups=!1,this.anchorFlag=0,this}resetMatcherInput(e){if(e===null)throw new Error("input is null");return e instanceof As||($.isByteArray(e)?e=gs.utf8(e):e=gs.utf16(e)),this.matcherInput=e,this.reset(),this}start(e=0){if(typeof e=="string"){const t=this.namedGroups[e];if(!Number.isFinite(t))throw new mt(`group '${e}' not found`);e=t}return this.loadGroup(e),this.groups[2*e]}end(e=0){if(typeof e=="string"){const t=this.namedGroups[e];if(!Number.isFinite(t))throw new mt(`group '${e}' not found`);e=t}return this.loadGroup(e),this.groups[2*e+1]}programSize(){return this.numberOfInstructions}group(e=0){if(typeof e=="string"){const r=this.namedGroups[e];if(!Number.isFinite(r))throw new mt(`group '${e}' not found`);e=r}const t=this.start(e),n=this.end(e);return t<0&&n<0?null:this.substring(t,n)}getNamedGroups(){if(!this.hasMatch)throw new mt("perhaps no match attempted");const e=Object.create(null);for(const t of Object.keys(this.namedGroups))e[t]=this.group(t);return e}groupCount(){return this.patternGroupCount}loadGroup(e){if(e<0||e>this.patternGroupCount)throw new mt(`Group index out of bounds: ${e}`);if(!this.hasMatch)throw new mt("perhaps no match attempted");if(e===0||this.hasGroups)return;const t=this.matcherInputLength,n=this.patternInput.re2().matchMachineInput(this.matcherInput,this.groups[0],t,this.anchorFlag,1+this.patternGroupCount);if(!n[0])throw new mt("inconsistency in matching group data");this.groups=n[1],this.hasGroups=!0}matches(){return this.genMatch(0,M.ANCHOR_BOTH)}lookingAt(){return this.genMatch(0,M.ANCHOR_START)}find(e=null){if(e!==null){if(e<0||e>this.matcherInputLength)throw new mt(`start index out of bounds: ${e}`);return this.reset(),this.genMatch(e,0)}if(e=0,this.hasMatch&&(e=this.groups[1],this.groups[0]===this.groups[1])){const t=(this.matcherInput.isUTF16Encoding()?Ae.fromUTF16(this.matcherInput.asCharSequence(),0,this.matcherInputLength):Ae.fromUTF8(this.matcherInput.asBytes(),0,this.matcherInputLength)).step(e);t<0?e++:e+=t&7}return this.genMatch(e,M.UNANCHORED)}genMatch(e,t){const n=this.patternInput.re2().matchMachineInput(this.matcherInput,e,this.matcherInputLength,t,1);return n[0]?(this.groups=n[1],this.hasMatch=!0,this.hasGroups=this.patternGroupCount===0,this.anchorFlag=t,!0):(this.hasMatch=!1,!1)}substring(e,t){return this.matcherInput.isUTF8Encoding()?$.utf8ByteArrayToString(this.matcherInput.asBytes().slice(e,t)):this.matcherInput.asCharSequence().substring(e,t).toString()}inputLength(){return this.matcherInputLength}appendReplacement(e,t=!1){let n="";const r=this.start(),i=this.end();return this.appendPos<r&&(n+=this.substring(this.appendPos,r)),this.appendPos=i,n+=t?this.appendReplacementInternalJava(e):this.appendReplacementInternalJs(e),n}appendReplacementInternalJava(e){let t="",n=0;const r=e.length;let i=0;for(;i<r;){const o=e.codePointAt(i);if(o===L.CODES.get("\\")){if(n<i&&(t+=e.substring(n,i)),i++,i>=r)throw new mt("character to be escaped is missing");n=i,i++;continue}if(o===L.CODES.get("$")){if(n<i&&(t+=e.substring(n,i)),i+1>=r)throw new mt("Illegal group reference: group index is missing");const a=e.codePointAt(i+1);if(L.CODES.get("0")<=a&&a<=L.CODES.get("9")){let l=a-L.CODES.get("0"),c=i+2;for(;c<r;c++){const f=e.codePointAt(c);if(f<L.CODES.get("0")||f>L.CODES.get("9")||l*10+f-L.CODES.get("0")>this.patternGroupCount)break;l=l*10+f-L.CODES.get("0")}if(l>this.patternGroupCount)throw new mt(`n > number of groups: ${l}`);const h=this.group(l);h!==null&&(t+=h),i=c,n=i}else if(a===L.CODES.get("{")){let l=i+2;for(;l<r&&e.codePointAt(l)!==L.CODES.get("}");)l++;if(l>=r)throw new mt("named capture group is missing trailing '}'");const c=e.substring(i+2,l),h=this.group(c);h!==null&&(t+=h),i=l+1,n=i}else throw new mt("Illegal group reference");continue}i++}return n<r&&(t+=e.substring(n,r)),t}appendReplacementInternalJs(e){let t="",n=0;const r=e.length;for(let i=0;i<r-1;i++)if(e.codePointAt(i)===L.CODES.get("$")){let o=e.codePointAt(i+1);if(L.CODES.get("$")===o){n<i&&(t+=e.substring(n,i)),t+="$",i++,n=i+1;continue}else if(L.CODES.get("&")===o){n<i&&(t+=e.substring(n,i));const a=this.group(0);a!==null?t+=a:t+="$&",i++,n=i+1;continue}else if(L.CODES.get("`")===o){n<i&&(t+=e.substring(n,i)),t+=this.substring(0,this.start(0)),i++,n=i+1;continue}else if(L.CODES.get("'")===o){n<i&&(t+=e.substring(n,i)),t+=this.substring(this.end(0),this.matcherInputLength),i++,n=i+1;continue}else if(L.CODES.get("1")<=o&&o<=L.CODES.get("9")){let a=o-L.CODES.get("0");for(n<i&&(t+=e.substring(n,i)),i+=2;i<r&&(o=e.codePointAt(i),!(o<L.CODES.get("0")||o>L.CODES.get("9")||a*10+o-L.CODES.get("0")>this.patternGroupCount));i++)a=a*10+o-L.CODES.get("0");if(a>this.patternGroupCount){t+=`$${a}`,n=i,i--;continue}const l=this.group(a);l!==null&&(t+=l),n=i,i--;continue}else if(o===L.CODES.get("<")){n<i&&(t+=e.substring(n,i)),i++;let a=i+1;for(;a<e.length&&e.codePointAt(a)!==L.CODES.get(">")&&e.codePointAt(a)!==L.CODES.get(" ");)a++;if(a===e.length||e.codePointAt(a)!==L.CODES.get(">")){t+=e.substring(i-1,a+1),n=a+1,i=a;continue}const l=e.substring(i+1,a);if(Object.prototype.hasOwnProperty.call(this.namedGroups,l)){const c=this.group(l);c!==null&&(t+=c)}else t+=`$<${l}>`;n=a+1,i=a;continue}}return n<r&&(t+=e.substring(n,r)),t}appendTail(){return this.substring(this.appendPos,this.matcherInputLength)}replaceAll(e,t=!1){return this.replace(e,!0,t)}replaceFirst(e,t=!1){return this.replace(e,!1,t)}replace(e,t=!0,n=!1){let r="";this.reset();const i=typeof e=="function",o=Object.keys(this.namedGroups).length>0;let a=null;if(i){if(this.groupCount()>=Es.MAX_REPLACER_ARGS)throw new mt("Too many capture groups to safely invoke replacer function");a=this.matcherInput.isUTF8Encoding()?this.matcherInput.asBytes():this.matcherInput.asCharSequence()}for(;this.find()&&(r+=i?this.appendReplacementFunc(e,o,a):this.appendReplacement(e,n),!!t););return r+=this.appendTail(),r}appendReplacementFunc(e,t,n){let r="";const i=this.start(),o=this.end();this.appendPos<i&&(r+=this.substring(this.appendPos,i)),this.appendPos=o;const a=this.buildReplacerArgs(i,t,n);return r+=String(e(...a)),r}buildReplacerArgs(e,t,n){const r=[this.group(0)],i=this.groupCount();for(let o=1;o<=i;o++){const a=this.start(o);a<0?r.push(void 0):r.push(this.substring(a,this.end(o)))}if(r.push(e),r.push(n),t){const o=this.getNamedGroups();for(const a in o)o[a]===null&&(o[a]=void 0);r.push(o)}return r}},H(Es,"MAX_REPLACER_ARGS",65535),Es),le,x=(le=class{static isRuneOp(e){return le.RUNE<=e&&e<=le.RUNE_ANY_NOT_NL}static escapeRunes(e){let t='"';for(let n of e)t+=$.escapeRune(n);return t+='"',t}constructor(e){this.op=e,this.out=0,this.arg=0,this.runes=[],this.next=null}matchRune(e){if(this.runes.length===1){const o=this.runes[0];return this.arg&M.FOLD_CASE?Q.equalsIgnoreCase(o,e):e===o}const t=this.runes.length;if(t===0)return!1;if(t===2||t===4||t===6||t===8){for(let o=0;o<t;o+=2){if(e<this.runes[o])return!1;if(e<=this.runes[o+1])return!0}return!1}let n=0,r=t>>1;for(;r>1;){const o=r>>1;n+=this.runes[n+o<<1]<=e?o:0,r-=o}n+=this.runes[n<<1]<=e?1:0;const i=n-1;return i>=0&&e<=this.runes[i<<1|1]}matchRunePos(e){if(this.runes.length===1){const o=this.runes[0];return this.arg&M.FOLD_CASE?Q.equalsIgnoreCase(o,e)?0:-1:e===o?0:-1}const t=this.runes.length;if(t===0)return-1;if(t===2||t===4||t===6||t===8){for(let o=0;o<t;o+=2){if(e<this.runes[o])return-1;if(e<=this.runes[o+1])return Math.floor(o/2)}return-1}let n=0,r=t>>1;for(;r>1;){const o=r>>1;n+=this.runes[n+o<<1]<=e?o:0,r-=o}n+=this.runes[n<<1]<=e?1:0;const i=n-1;return i>=0&&e<=this.runes[i<<1|1]?i:-1}toString(){switch(this.op){case le.ALT:return`alt -> ${this.out}, ${this.arg}`;case le.ALT_MATCH:return`altmatch -> ${this.out}, ${this.arg}`;case le.CAPTURE:return`cap ${this.arg} -> ${this.out}`;case le.EMPTY_WIDTH:return`empty ${this.arg} -> ${this.out}`;case le.MATCH:return`match${this.arg!==0?` ${this.arg}`:""}`;case le.FAIL:return"fail";case le.NOP:return`nop -> ${this.out}`;case le.LB_WRITE:return`lbwrite ${this.arg} -> ${this.out}`;case le.LB_CHECK:return`lbcheck ${this.arg} -> ${this.out}`;case le.RUNE:return this.runes===null?"rune <null>":["rune ",le.escapeRunes(this.runes),this.arg&M.FOLD_CASE?"/i":""," -> ",this.out].join("");case le.RUNE1:return`rune1 ${le.escapeRunes(this.runes)} -> ${this.out}`;case le.RUNE_ANY:return`any -> ${this.out}`;case le.RUNE_ANY_NOT_NL:return`anynotnl -> ${this.out}`;default:throw new Error("unhandled case in Inst.toString")}}},H(le,"ALT",1),H(le,"ALT_MATCH",2),H(le,"CAPTURE",3),H(le,"EMPTY_WIDTH",4),H(le,"FAIL",5),H(le,"MATCH",6),H(le,"NOP",7),H(le,"RUNE",8),H(le,"RUNE1",9),H(le,"RUNE_ANY",10),H(le,"RUNE_ANY_NOT_NL",11),H(le,"LB_WRITE",12),H(le,"LB_CHECK",13),le),Ph=class{constructor(s){this.sparse=new Int32Array(s),this.densePcs=new Int32Array(s),this.denseCaps=null,this.size=0,this.ncap=0}init(s){this.ncap=s;const e=this.densePcs.length*s;(!this.denseCaps||this.denseCaps.length<e)&&(this.denseCaps=new Int32Array(e))}contains(s){const e=this.sparse[s];return e<this.size&&this.densePcs[e]===s}isEmpty(){return this.size===0}add(s){const e=this.size++;return this.sparse[s]=e,this.densePcs[e]=s,e}clear(){this.size=0}toString(){let s="{";for(let e=0;e<this.size;e++)e!==0&&(s+=", "),s+=this.densePcs[e];return s+="}",s}},vy=class tl{static fromRE2(e){const t=new tl;return t.prog=e.prog,t.re2=e,t.q0=new Ph(t.prog.numInst()),t.q1=new Ph(t.prog.numInst()),t.matched=!1,t.matchcap=new Int32Array(t.prog.numCap<2?2:t.prog.numCap),t.ncap=0,t}static fromMachine(e){return tl.fromRE2(e.re2)}constructor(){this.prog=null,this.re2=null,this.q0=null,this.q1=null,this.matched=!1,this.matchcap=null,this.ncap=0,this.lbTable=null}init(e){this.ncap=e,e>this.matchcap.length?this.matchcap=new Int32Array(e).fill(-1):this.matchcap.fill(-1),this.q0.init(e),this.q1.init(e),this.prog.numLb>0&&((!this.lbTable||this.lbTable.length<this.prog.numLb+1)&&(this.lbTable=new Int32Array(this.prog.numLb+1)),this.lbTable.fill(-1))}submatches(){return this.ncap===0?$.emptyInts():$.toArray(this.matchcap.subarray(0,this.ncap))}match(e,t,n){const r=this.re2.cond;if(r===$.EMPTY_ALL||(n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return!1;this.matched=!1,this.matchcap.fill(-1);let i=this.prog.numLb>0?0:t,o=t,a=this.q0,l=this.q1,c=e.step(i),h=c>>3,f=c&7,d=-1,_=0;c!==pt.EOF()&&(c=e.step(i+f),d=c>>3,_=c&7);let y;for(i===0?y=$.emptyOpContext(-1,h):y=e.context(i);;){if(a.isEmpty()){if(r&$.EMPTY_BEGIN_TEXT&&i!==0||(n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&i!==0||this.matched)break;if(this.prog.numLb===0&&this.re2.prefix.length!==0&&d!==this.re2.prefixRune&&e.canCheckPrefix()){const J=e.index(this.re2,i);if(J<0)break;i+=J,c=e.step(i),h=c>>3,f=c&7,c=e.step(i+f),d=c>>3,_=c&7,y=e.context(i)}}if(i===0&&this.prog.numLb>0)for(let J=0;J<this.prog.lbStarts.length;J++)this.add(a,this.prog.lbStarts[J],i,this.matchcap,0,y);!this.matched&&(i===0||n===M.UNANCHORED)&&i>=o&&(this.ncap>0&&(this.matchcap[0]=i),this.add(a,this.prog.start,i,this.matchcap,0,y));const N=i+f;if(y=e.context(N),this.step(a,l,i,N,h,y,n,i===e.endPos()),f===0||this.ncap===0&&this.matched)break;i+=f,h=d,f=_,h!==-1&&(c=e.step(i+f),d=c>>3,_=c&7);const F=a;a=l,l=F}return l.clear(),this.matched}matchSet(e,t,n){const r=this.re2.cond;if(r===$.EMPTY_ALL)return[];if((n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return[];let i=this.prog.numLb>0?0:t,o=t,a=this.q0,l=this.q1,c=e.step(i),h=c>>3,f=c&7,d=-1,_=0;c!==pt.EOF()&&(c=e.step(i+f),d=c>>3,_=c&7);let y=i===0?$.emptyOpContext(-1,h):e.context(i);const N=new Set;for(;!(a.isEmpty()&&(r&$.EMPTY_BEGIN_TEXT&&i!==0||(n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&i!==0));){if(i===0&&this.prog.numLb>0)for(let te=0;te<this.prog.lbStarts.length;te++)this.add(a,this.prog.lbStarts[te],i,this.matchcap,0,y);(i===0||n===M.UNANCHORED)&&i>=o&&this.add(a,this.prog.start,i,this.matchcap,0,y);const F=i+f;y=e.context(F);for(let te=0;te<a.size;te++){const re=a.densePcs[te],ge=this.prog.inst[re],Le=te*this.ncap;let Fe=!1;switch(ge.op){case x.MATCH:if(n===M.ANCHOR_BOTH&&i!==e.endPos())break;N.add(ge.arg);break;case x.RUNE:Fe=ge.matchRune(h);break;case x.RUNE1:Fe=h===ge.runes[0];break;case x.RUNE_ANY:Fe=!0;break;case x.RUNE_ANY_NOT_NL:Fe=h!==10;break;default:continue}Fe&&this.add(l,ge.out,F,a.denseCaps,Le,y)}if(a.clear(),f===0)break;i+=f,h=d,f=_,h!==-1&&(c=e.step(i+f),d=c>>3,_=c&7);const J=a;a=l,l=J}return l.clear(),Array.from(N).sort((F,J)=>F-J)}step(e,t,n,r,i,o,a,l){const c=this.re2.longest;for(let h=0;h<e.size;h++){const f=e.densePcs[h],d=h*this.ncap;if(c&&this.matched&&this.ncap>0&&this.matchcap[0]<e.denseCaps[d])continue;const _=this.prog.inst[f];let y=!1;switch(_.op){case x.MATCH:if(a===M.ANCHOR_BOTH&&!l)break;if(this.ncap>0&&(!c||!this.matched||this.matchcap[1]<n)){e.denseCaps[d+1]=n;for(let N=0;N<this.ncap;N++)this.matchcap[N]=e.denseCaps[d+N]}c||(e.size=0),this.matched=!0;break;case x.RUNE:y=_.matchRune(i);break;case x.RUNE1:y=i===_.runes[0];break;case x.RUNE_ANY:y=!0;break;case x.RUNE_ANY_NOT_NL:y=i!==10;break;default:continue}y&&this.add(t,_.out,r,e.denseCaps,d,o)}e.clear()}add(e,t,n,r,i,o){for(;;){if(t===0||e.contains(t))return;const a=e.add(t),l=this.prog.inst[t];switch(l.op){case x.FAIL:return;case x.ALT:case x.ALT_MATCH:this.add(e,l.out,n,r,i,o),t=l.arg;continue;case x.EMPTY_WIDTH:if(!(l.arg&~o)){t=l.out;continue}return;case x.NOP:t=l.out;continue;case x.CAPTURE:if(l.arg<this.ncap){const c=r[i+l.arg];r[i+l.arg]=n,this.add(e,l.out,n,r,i,o),r[i+l.arg]=c;return}else{t=l.out;continue}case x.LB_WRITE:this.lbTable[Math.abs(l.arg)]=n,t=l.out;continue;case x.LB_CHECK:if(l.arg>0){if(this.lbTable[l.arg]===n){t=l.out;continue}}else if(this.lbTable[-l.arg]!==n){t=l.out;continue}return;case x.MATCH:case x.RUNE:case x.RUNE1:case x.RUNE_ANY:case x.RUNE_ANY_NOT_NL:if(this.ncap>0){const c=a*this.ncap;for(let h=0;h<this.ncap;h++)e.denseCaps[c+h]=r[i+h]}return;default:throw new ni("unhandled")}}}};const Fh=s=>{let e=-2128831035;for(let t=0;t<s.length;t++)e^=s[t],e=Math.imul(e,16777619);return e},Ry=(s,e)=>{if(s.length!==e.length)return!1;for(let t=0;t<s.length;t++)if(s[t]!==e[t])return!1;return!0};var Sy=class{constructor(s,e,t=[]){this.nfaStates=s,this.isMatch=e,this.matchIDs=t,this.nextLatin1=new Array(Q.MAX_LATIN1+1).fill(null),this.nextLatin1Anchored=new Array(Q.MAX_LATIN1+1).fill(null),this.transKeys=[],this.transVals=[],this.lastSeen=0}},cn,by=(cn=class{constructor(e,t=8388608){this.prog=e,this.stateCache=new Map,this.stateCount=0,this.startState=null,this.stateLimit=Math.max(1,Math.floor(t/cn.STATE_MEMORY_ESTIMATE)),this.cacheClears=0,this.failed=!1,this.clock=0}computeClosure(e){const t=new Set,n=[...e];let r=!1;const i=[];for(;n.length>0;){const a=n.pop();if(t.has(a))continue;t.add(a);const l=this.prog.getInst(a);switch(l.op){case x.MATCH:r=!0,i.includes(l.arg)||i.push(l.arg);break;case x.ALT:case x.ALT_MATCH:n.push(l.out),n.push(l.arg);break;case x.NOP:case x.CAPTURE:n.push(l.out);break;case x.EMPTY_WIDTH:case x.LB_WRITE:case x.LB_CHECK:return null}}const o=Int32Array.from(t).sort();return i.sort((a,l)=>a-l),{pcs:o,isMatch:r,matchIDs:i}}getState(e){const t=this.computeClosure(e);if(!t)return null;const n=t.pcs,r=Fh(n);let i=this.stateCache.get(r);if(i)for(let a=0;a<i.length;a++){const l=i[a];if(Ry(l.nfaStates,n))return l.lastSeen=++this.clock,l}else i=[],this.stateCache.set(r,i);if(this.failed)return null;if(this.stateCount>=this.stateLimit){if(this.cacheClears++,this.cacheClears>=cn.MAX_CACHE_CLEARS)return this.failed=!0,this.stateCache.clear(),this.stateCount=0,this.startState=null,null;this.evictCache(),i=this.stateCache.get(r),i||(i=[],this.stateCache.set(r,i))}const o=new Sy(n,t.isMatch,t.matchIDs);return o.lastSeen=++this.clock,i.push(o),this.stateCount++,o}evictCache(){const e=[];for(const o of this.stateCache.values())for(let a=0;a<o.length;a++)e.push(o[a]);e.sort((o,a)=>o.lastSeen-a.lastSeen);const t=Math.max(1,Math.floor(this.stateLimit/2)),n=e.length-t,r=e.slice(n),i=new Set(r);this.stateCache.clear(),this.stateCount=0;for(let o=0;o<r.length;o++){const a=r[o];a.nextLatin1.fill(null),a.nextLatin1Anchored.fill(null),a.transKeys.length=0,a.transVals.length=0;const l=Fh(a.nfaStates);let c=this.stateCache.get(l);c||(c=[],this.stateCache.set(l,c)),c.push(a),this.stateCount++}this.startState&&!i.has(this.startState)&&(this.startState=null)}step(e,t,n){if(t<=Q.MAX_LATIN1)if(n===M.UNANCHORED){const o=e.nextLatin1[t];if(o!==null)return o}else{const o=e.nextLatin1Anchored[t];if(o!==null)return o}else{const o=t+(n===M.UNANCHORED?0:Q.MAX_RUNE+1),a=e.transKeys,l=a.length;for(let c=0;c<l;c++)if(a[c]===o)return e.transVals[c]}const r=[];for(let o=0;o<e.nfaStates.length;o++){const a=e.nfaStates[o],l=this.prog.getInst(a);x.isRuneOp(l.op)&&l.matchRune(t)&&r.push(l.out)}n===M.UNANCHORED&&r.push(this.prog.start);const i=this.getState(r);if(t<=Q.MAX_LATIN1)n===M.UNANCHORED?e.nextLatin1[t]=i:e.nextLatin1Anchored[t]=i;else{const o=t+(n===M.UNANCHORED?0:Q.MAX_RUNE+1);e.transKeys.push(o),e.transVals.push(i)}return i}match(e,t,n){if((n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return!1;if(!this.startState&&(this.startState=this.getState([this.prog.start]),!this.startState))return null;let r=e.endPos(),i=this.startState;if(i.isMatch)if(n===M.ANCHOR_BOTH){if(t===r)return!0}else return!0;let o=t;for(;o<r;){const a=e.step(o),l=a>>3,c=a&7;if(c===0)break;if(i=n===M.UNANCHORED&&l<=Q.MAX_LATIN1&&i.nextLatin1[l]||this.step(i,l,n),i===null)return null;if(i.lastSeen=++this.clock,i.isMatch)if(n===M.ANCHOR_BOTH){if(o+c===r)return!0}else return!0;if(i.nfaStates.length===0&&n!==M.UNANCHORED)return!1;o+=c}return!1}matchSet(e,t,n){if((n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return[];if(!this.startState&&(this.startState=this.getState([this.prog.start]),!this.startState))return null;let r=e.endPos(),i=this.startState;const o=new Set,a=(c,h)=>{c.isMatch&&(n===M.ANCHOR_BOTH?h===r&&c.matchIDs.forEach(f=>o.add(f)):c.matchIDs.forEach(f=>o.add(f)))};a(i,t);let l=t;for(;l<r;){const c=e.step(l),h=c>>3,f=c&7;if(f===0)break;if(i=n===M.UNANCHORED&&h<=Q.MAX_LATIN1&&i.nextLatin1[h]||this.step(i,h,n),i===null)return null;if(i.lastSeen=++this.clock,l+=f,a(i,l),i.nfaStates.length===0&&n!==M.UNANCHORED)break}return Array.from(o).sort((c,h)=>c-h)}},H(cn,"MAX_CACHE_CLEARS",5),H(cn,"STATE_MEMORY_ESTIMATE",838),cn);const Ny=32,Py=500,bB=256,Fy=256*1024;var Oy=class{constructor(){this.end=0,this.cap=new Int32Array(0),this.matchcap=new Int32Array(0),this.ncap=0,this.jobPc=new Int32Array(bB),this.jobArg=new Uint8Array(bB),this.jobPos=new Int32Array(bB),this.jobLen=0,this.visited=new Uint32Array(0)}reset(s,e,t){this.end=e,this.jobLen=0,this.ncap=t;const n=s.numInst()*(e+1)+Ny-1>>>5;this.visited.length<n?this.visited=new Uint32Array(n):this.visited.fill(0,0,n),this.cap.length<t?this.cap=new Int32Array(t).fill(-1):this.cap.fill(-1,0,t),this.matchcap.length<t?this.matchcap=new Int32Array(t).fill(-1):this.matchcap.fill(-1,0,t)}shouldVisit(s,e){const t=s*(this.end+1)+e,n=t>>>5,r=1<<(t&31);return this.visited[n]&r?!1:(this.visited[n]|=r,!0)}push(s,e,t,n){if(s.prog.getInst(e).op!==x.FAIL&&(n||this.shouldVisit(e,t))){if(this.jobLen>=this.jobPc.length){const r=this.jobPc.length*2,i=new Int32Array(r);i.set(this.jobPc),this.jobPc=i;const o=new Uint8Array(r);o.set(this.jobArg),this.jobArg=o;const a=new Int32Array(r);a.set(this.jobPos),this.jobPos=a}this.jobPc[this.jobLen]=e,this.jobArg[this.jobLen]=n?1:0,this.jobPos[this.jobLen]=t,this.jobLen++}}tryBacktrack(s,e,t,n,r){const i=s.longest;for(this.push(s,t,n,!1);this.jobLen>0;){this.jobLen--;let o=this.jobPc[this.jobLen],a=this.jobArg[this.jobLen]===1,l=this.jobPos[this.jobLen],c=!0;for(;!(!c&&!this.shouldVisit(o,l));){c=!1;const h=s.prog.getInst(o);switch(h.op){case x.FAIL:throw new ni("unexpected InstFail");case x.ALT:if(a){a=!1,o=h.arg;continue}else{this.push(s,o,l,!0),o=h.out;continue}case x.ALT_MATCH:{const f=s.prog.getInst(h.out);if(x.isRuneOp(f.op)){this.push(s,h.arg,l,!1),o=h.arg,l=this.end;continue}this.push(s,h.out,this.end,!1),o=h.out;continue}case x.RUNE:{const f=e.step(l);if(f===pt.EOF()||!h.matchRune(f>>3))break;l+=f&7,o=h.out;continue}case x.RUNE1:{const f=e.step(l);if(f===pt.EOF()||f>>3!==h.runes[0])break;l+=f&7,o=h.out;continue}case x.RUNE_ANY_NOT_NL:{const f=e.step(l);if(f===pt.EOF()||f>>3===10)break;l+=f&7,o=h.out;continue}case x.RUNE_ANY:{const f=e.step(l);if(f===pt.EOF())break;l+=f&7,o=h.out;continue}case x.CAPTURE:if(a){this.cap[h.arg]=l;break}else{h.arg<this.ncap&&(this.push(s,o,this.cap[h.arg],!0),this.cap[h.arg]=l),o=h.out;continue}case x.EMPTY_WIDTH:{const f=e.context(l);if(h.arg&~f)break;o=h.out;continue}case x.NOP:o=h.out;continue;case x.MATCH:{if(r===M.ANCHOR_BOTH&&l!==this.end)break;if(this.ncap===0)return!0;this.ncap>1&&(this.cap[1]=l);const f=this.matchcap[1];if((f===-1||i&&l>0&&l>f)&&this.matchcap.set(this.cap),!i||l===this.end)return!0;break}case x.LB_WRITE:case x.LB_CHECK:throw new ni("Backtracker cannot evaluate Lookbehind instructions");default:throw new ni("bad inst")}break}}return i&&this.matchcap.length>1&&this.matchcap[1]>=0}};const wo=[];var To=class bd{static shouldBacktrack(e){return e.numInst()<=Py}static maxBitStateLen(e){return bd.shouldBacktrack(e)?Math.floor(Fy/e.numInst()):0}static execute(e,t,n,r,i){const o=e.cond;if(o===$.EMPTY_ALL||(r===M.ANCHOR_START||r===M.ANCHOR_BOTH)&&n!==0||o&$.EMPTY_BEGIN_TEXT&&n!==0)return null;const a=wo.length>0?wo.pop():new Oy,l=t.endPos();a.reset(e.prog,l,i);let c=!1;if(o&$.EMPTY_BEGIN_TEXT||r===M.ANCHOR_START||r===M.ANCHOR_BOTH)a.ncap>0&&(a.cap[0]=n),a.tryBacktrack(e,t,e.prog.start,n,r)&&(c=!0);else{let f=-1;for(;n<=l&&f!==0;n+=f){if(e.prefix.length>0){const _=t.index(e,n);if(_<0)break;n+=_}if(a.ncap>0&&(a.cap[0]=n),a.tryBacktrack(e,t,e.prog.start,n,r)){c=!0;break}const d=t.step(n);f=d===pt.EOF()?0:d&7}}if(!c)return wo.push(a),null;const h=i===0?[]:$.toArray(a.matchcap.subarray(0,i));return wo.push(a),h}},Oh=class{constructor(s){this.sparse=new Uint32Array(s),this.dense=new Uint32Array(s),this.size=0,this.nextIndex=0}empty(){return this.nextIndex>=this.size}next(){return this.dense[this.nextIndex++]}clear(){this.size=0,this.nextIndex=0}contains(s){return s<this.sparse.length&&this.sparse[s]<this.size&&this.dense[this.sparse[s]]===s}insert(s){this.contains(s)||this.insertNew(s)}insertNew(s){s>=this.sparse.length||(this.sparse[s]=this.size,this.dense[this.size]=s,this.size++)}};const Ly=(s,e,t,n)=>{const r=s.length,i=e.length;let o=0,a=0;const l=[],c=[];let h=!0,f=-1;const d=_=>{const y=_?s:e,N=_?o:a,F=_?t:n;return f>0&&y[N]<=l[f]?!1:(l.push(y[N],y[N+1]),_?o+=2:a+=2,f+=2,c.push(F),!0)};for(;o<r||a<i;)if(a>=i?h=d(!0):o>=r||e[a]<s[o]?h=d(!1):h=d(!0),!h)return null;return{merged:l,next:c}};var xy=class{constructor(s){this.start=s.start,this.numCap=s.numCap,this.inst=new Array(s.inst.length);for(let e=0;e<s.inst.length;e++){const t=s.inst[e],n=new x(t.op);n.out=t.out,n.arg=t.arg,n.runes=t.runes?t.runes.slice():[],n.next=null,this.inst[e]=n}}};const ky=s=>{const e=new xy(s);for(let t=0;t<e.inst.length;t++){const n=e.inst[t];if(n.op!==x.ALT&&n.op!==x.ALT_MATCH)continue;let r="out",i="arg",o=e.inst[n[i]];if(o.op!==x.ALT&&o.op!==x.ALT_MATCH&&(r="arg",i="out",o=e.inst[n[i]],o.op!==x.ALT&&o.op!==x.ALT_MATCH))continue;const a=e.inst[n[r]];if(a.op===x.ALT||a.op===x.ALT_MATCH)continue;let l="out",c="arg",h=!1;o.out===t?h=!0:o.arg===t&&(h=!0,l="arg",c="out"),h&&(o[l]=n[r]),n[r]===o[l]&&(n[i]=o[c])}return e},Vy=s=>{if(s.inst.length>=1e3)return null;const e=new Oh(s.inst.length),t=new Oh(s.inst.length),n=new Array(s.inst.length),r=new Array(s.inst.length).fill(!1),i=o=>{let a=!0;const l=s.inst[o];if(t.contains(o))return!0;switch(t.insert(o),l.op){case x.ALT:case x.ALT_MATCH:{a=i(l.out)&&i(l.arg);let c=r[l.out],h=r[l.arg];if(c&&h)return!1;if(h){const y=l.out;l.out=l.arg,l.arg=y;const N=c;c=h,h=N}c&&(r[o]=!0,l.op=x.ALT_MATCH);const f=n[l.out]||[],d=n[l.arg]||[],_=Ly(f,d,l.out,l.arg);if(!_)return!1;n[o]=_.merged,l.next=new Uint32Array(_.next);break}case x.CAPTURE:case x.EMPTY_WIDTH:case x.NOP:a=i(l.out),r[o]=r[l.out],n[o]=n[l.out]?n[l.out].slice():[],l.next=new Uint32Array(Math.floor(n[o].length/2)+1).fill(l.out);break;case x.MATCH:case x.FAIL:r[o]=l.op===x.MATCH;break;case x.RUNE:{if(r[o]=!1,l.next&&l.next.length>0)break;if(e.insert(l.out),!l.runes||l.runes.length===0){n[o]=[],l.next=new Uint32Array([l.out]);break}let c=[];if(l.runes.length===1&&l.arg&M.FOLD_CASE){const h=l.runes[0];c.push(h,h);for(let f=Q.simpleFold(h);f!==h;f=Q.simpleFold(f))c.push(f,f);c.sort((f,d)=>f-d)}else for(let h=0;h<l.runes.length;h++)c.push(l.runes[h]);n[o]=c,l.next=new Uint32Array(Math.floor(c.length/2)+1).fill(l.out),l.op=x.RUNE;break}case x.RUNE1:{if(r[o]=!1,l.next&&l.next.length>0)break;e.insert(l.out);let c=[];if(l.arg&M.FOLD_CASE){const h=l.runes[0];c.push(h,h);for(let f=Q.simpleFold(h);f!==h;f=Q.simpleFold(f))c.push(f,f);c.sort((f,d)=>f-d)}else c.push(l.runes[0],l.runes[0]);n[o]=c,l.next=new Uint32Array(Math.floor(c.length/2)+1).fill(l.out),l.op=x.RUNE;break}case x.RUNE_ANY:if(r[o]=!1,l.next&&l.next.length>0)break;e.insert(l.out),n[o]=[0,Q.MAX_RUNE],l.next=new Uint32Array([l.out]);break;case x.RUNE_ANY_NOT_NL:if(r[o]=!1,l.next&&l.next.length>0)break;e.insert(l.out),n[o]=[0,9,11,Q.MAX_RUNE],l.next=new Uint32Array(Math.floor(n[o].length/2)+1).fill(l.out);break}return a};for(e.clear(),e.insert(s.start);!e.empty();)if(t.clear(),!i(e.next()))return null;for(let o=0;o<s.inst.length;o++)n[o]&&(s.inst[o].runes=n[o]);return s},My=(s,e)=>{for(let t=0;t<e.inst.length;t++){const n=e.inst[t];switch(n.op){case x.ALT:case x.ALT_MATCH:case x.RUNE:break;case x.CAPTURE:case x.EMPTY_WIDTH:case x.NOP:case x.MATCH:case x.FAIL:s.inst[t].next=null;break;case x.RUNE1:case x.RUNE_ANY:case x.RUNE_ANY_NOT_NL:s.inst[t].next=null,s.inst[t].op=n.op,s.inst[t].runes=n.runes?n.runes.slice():[];break}}};var Lh=class Nd{static compile(e){if(e.start===0||e.numLb>0)return null;const t=e.inst[e.start];if(t.op!==x.EMPTY_WIDTH||!(t.arg&$.EMPTY_BEGIN_TEXT))return null;let n=!1;for(let i=0;i<e.inst.length;i++)if(e.inst[i].op===x.ALT||e.inst[i].op===x.ALT_MATCH){n=!0;break}for(let i=0;i<e.inst.length;i++){const o=e.inst[i],a=e.inst[o.out].op;switch(o.op){case x.ALT:case x.ALT_MATCH:if(a===x.MATCH||e.inst[o.arg].op===x.MATCH)return null;break;case x.EMPTY_WIDTH:if(a===x.MATCH){if((o.arg&$.EMPTY_END_TEXT)===$.EMPTY_END_TEXT)continue;return null}break;default:if(a===x.MATCH&&n)return null;break}}let r=ky(e);return r=Vy(r),r!==null&&My(r,e),r}static next(e,t){const n=e.matchRunePos(t);return n>=0?e.next[n]:e.op===x.ALT_MATCH?e.out:0}static execute(e,t,n,r,i){const o=e.onepass;if(!o)return null;const a=new Int32Array(i).fill(-1);let l=!1,c=t.step(n),h=c>>3,f=c&7,d=pt.EOF(),_=-1,y=0;c!==pt.EOF()&&(d=t.step(n+f),d!==pt.EOF()&&(_=d>>3,y=d&7));let N=n===0?$.emptyOpContext(-1,h):t.context(n),F=o.start,J;for(;;){switch(J=o.inst[F],F=J.out,J.op){case x.MATCH:return r===M.ANCHOR_BOTH&&n!==t.endPos()?null:(l=!0,a.length>0&&(a[0]=0,a[1]=n),i===0?[]:$.toArray(a));case x.RUNE:if(!J.matchRune(h))return null;break;case x.RUNE1:if(h!==J.runes[0])return null;break;case x.RUNE_ANY:break;case x.RUNE_ANY_NOT_NL:if(h===10)return null;break;case x.ALT:case x.ALT_MATCH:F=Nd.next(J,h);continue;case x.FAIL:return null;case x.NOP:continue;case x.EMPTY_WIDTH:if(J.arg&~N)return null;continue;case x.CAPTURE:J.arg<a.length&&(a[J.arg]=n);continue;default:throw new ni("bad inst")}if(f===0)break;N=$.emptyOpContext(h,_),n+=f,h=_,f=y,h!==-1&&(d=t.step(n+f),d!==pt.EOF()?(_=d>>3,y=d&7):(_=-1,y=0))}return l?i===0?[]:$.toArray(a):null}},Z,I=(Z=class{static isPseudoOp(e){return e>=Z.Op.LEFT_PAREN}static emptySubs(){return[]}static quoteIfHyphen(e){return e===L.CODES.get("-")?"\\":""}static fromRegexp(e){const t=new Z(e.op);return t.flags=e.flags,t.subs=e.subs,t.runes=e.runes,t.cap=e.cap,t.min=e.min,t.max=e.max,t.name=e.name,t.namedGroups=e.namedGroups,t.lb=e.lb,t}constructor(e){this.op=e,this.flags=0,this.subs=Z.emptySubs(),this.runes=[],this.min=0,this.max=0,this.cap=0,this.name=null,this.namedGroups=Object.create(null),this.lb=0}reinit(){this.flags=0,this.subs=Z.emptySubs(),this.runes=[],this.cap=0,this.min=0,this.max=0,this.name=null,this.namedGroups=Object.create(null),this.lb=0}toString(){return this.appendTo()}appendTo(){let e="";switch(this.op){case Z.Op.NO_MATCH:e+="[^\\x00-\\x{10FFFF}]";break;case Z.Op.EMPTY_MATCH:e+="(?:)";break;case Z.Op.STAR:case Z.Op.PLUS:case Z.Op.QUEST:case Z.Op.REPEAT:{const t=this.subs[0];switch(t.op>Z.Op.CAPTURE||t.op===Z.Op.LITERAL&&t.runes.length>1?e+=`(?:${t.appendTo()})`:e+=t.appendTo(),this.op){case Z.Op.STAR:e+="*";break;case Z.Op.PLUS:e+="+";break;case Z.Op.QUEST:e+="?";break;case Z.Op.REPEAT:e+=`{${this.min}`,this.min!==this.max&&(e+=",",this.max>=0&&(e+=this.max)),e+="}";break}this.flags&M.NON_GREEDY&&(e+="?");break}case Z.Op.CONCAT:for(let t of this.subs)t.op===Z.Op.ALTERNATE?e+=`(?:${t.appendTo()})`:e+=t.appendTo();break;case Z.Op.ALTERNATE:{let t="";for(let n of this.subs)e+=t,t="|",e+=n.appendTo();break}case Z.Op.LITERAL:this.flags&M.FOLD_CASE&&(e+="(?i:");for(let t of this.runes)e+=$.escapeRune(t);this.flags&M.FOLD_CASE&&(e+=")");break;case Z.Op.ANY_CHAR_NOT_NL:e+="(?-s:.)";break;case Z.Op.ANY_CHAR:e+="(?s:.)";break;case Z.Op.PLB:e+=`(?<=${this.subs[0].appendTo()})`;break;case Z.Op.NLB:e+=`(?<!${this.subs[0].appendTo()})`;break;case Z.Op.CAPTURE:this.name===null||this.name.length===0?e+="(":e+=`(?P<${this.name}>`,this.subs[0].op!==Z.Op.EMPTY_MATCH&&(e+=this.subs[0].appendTo()),e+=")";break;case Z.Op.BEGIN_TEXT:e+="\\A";break;case Z.Op.END_TEXT:this.flags&M.WAS_DOLLAR?e+="(?-m:$)":e+="\\z";break;case Z.Op.BEGIN_LINE:e+="^";break;case Z.Op.END_LINE:e+="$";break;case Z.Op.WORD_BOUNDARY:e+="\\b";break;case Z.Op.NO_WORD_BOUNDARY:e+="\\B";break;case Z.Op.CHAR_CLASS:if(this.runes.length%2!==0){e+="[invalid char class]";break}if(e+="[",this.runes.length===0)e+="^\\x00-\\x{10FFFF}";else if(this.runes[0]===0&&this.runes[this.runes.length-1]===Q.MAX_RUNE){e+="^";for(let t=1;t<this.runes.length-1;t+=2){const n=this.runes[t]+1,r=this.runes[t+1]-1;e+=Z.quoteIfHyphen(n),e+=$.escapeRune(n),n!==r&&(e+="-",e+=Z.quoteIfHyphen(r),e+=$.escapeRune(r))}}else for(let t=0;t<this.runes.length;t+=2){const n=this.runes[t],r=this.runes[t+1];e+=Z.quoteIfHyphen(n),e+=$.escapeRune(n),n!==r&&(e+="-",e+=Z.quoteIfHyphen(r),e+=$.escapeRune(r))}e+="]";break;default:e+=this.op;break}return e}maxCap(){let e=0;if(this.op===Z.Op.CAPTURE&&(e=this.cap),this.subs!==null)for(let t of this.subs){const n=t.maxCap();e<n&&(e=n)}return e}equals(e){if(!(e!==null&&e instanceof Z)||this.op!==e.op)return!1;switch(this.op){case Z.Op.END_TEXT:if((this.flags&M.WAS_DOLLAR)!==(e.flags&M.WAS_DOLLAR))return!1;break;case Z.Op.LITERAL:case Z.Op.CHAR_CLASS:if(this.runes===null&&e.runes===null)break;if(this.runes===null||e.runes===null||this.runes.length!==e.runes.length)return!1;for(let t=0;t<this.runes.length;t++)if(this.runes[t]!==e.runes[t])return!1;break;case Z.Op.ALTERNATE:case Z.Op.CONCAT:if(this.subs.length!==e.subs.length)return!1;for(let t=0;t<this.subs.length;++t)if(!this.subs[t].equals(e.subs[t]))return!1;break;case Z.Op.STAR:case Z.Op.PLUS:case Z.Op.QUEST:if((this.flags&M.NON_GREEDY)!==(e.flags&M.NON_GREEDY)||!this.subs[0].equals(e.subs[0]))return!1;break;case Z.Op.REPEAT:if((this.flags&M.NON_GREEDY)!==(e.flags&M.NON_GREEDY)||this.min!==e.min||this.max!==e.max||!this.subs[0].equals(e.subs[0]))return!1;break;case Z.Op.CAPTURE:if(this.cap!==e.cap||(this.name===null?e.name!==null:this.name!==e.name)||!this.subs[0].equals(e.subs[0]))return!1;break;case Z.Op.PLB:case Z.Op.NLB:if(this.lb!==e.lb||!this.subs[0].equals(e.subs[0]))return!1;break}return!0}},H(Z,"Op",Sd(["NO_MATCH","EMPTY_MATCH","LITERAL","CHAR_CLASS","ANY_CHAR_NOT_NL","ANY_CHAR","BEGIN_LINE","END_LINE","BEGIN_TEXT","END_TEXT","WORD_BOUNDARY","NO_WORD_BOUNDARY","CAPTURE","STAR","PLUS","QUEST","REPEAT","CONCAT","ALTERNATE","PLB","NLB","LEFT_PAREN","VERTICAL_BAR"])),Z),xh=class{constructor(s){this.next=[Object.create(null)],this.fail=[0],this.match=[!1];for(const t of s){let n=0;for(let r=0;r<t.length;r++){const i=t[r];i in this.next[n]||(this.next.push(Object.create(null)),this.fail.push(0),this.match.push(!1),this.next[n][i]=this.next.length-1),n=this.next[n][i]}this.match[n]=!0}const e=[];for(const t in this.next[0])if(Object.prototype.hasOwnProperty.call(this.next[0],t)){const n=this.next[0][t];this.fail[n]=0,e.push(n)}for(;e.length>0;){const t=e.shift();for(const n in this.next[t])if(Object.prototype.hasOwnProperty.call(this.next[t],n)){const r=this.next[t][n];let i=this.fail[t];for(;i!==0&&!(n in this.next[i]);)i=this.fail[i];n in this.next[i]?this.fail[r]=this.next[i][n]:this.fail[r]=0,this.match[r]=this.match[r]||this.match[this.fail[r]],e.push(r)}}}searchUTF16(s,e,t){let n=0;for(let r=e;r<t;r++){const i=s.charCodeAt(r);for(;n!==0&&!(i in this.next[n]);)n=this.fail[n];if(i in this.next[n]&&(n=this.next[n][i]),this.match[n])return!0}return!1}searchUTF8(s,e,t){let n=0;for(let r=e;r<t;r++){const i=s[r];for(;n!==0&&!(i in this.next[n]);)n=this.fail[n];if(i in this.next[n]&&(n=this.next[n][i]),this.match[n])return!0}return!1}},nn,pe=(nn=class{constructor(e){this.type=e,this.subs=[],this.str="",this.bytes=null,this.ac16=null,this.ac8=null}eval(e,t){switch(this.type){case nn.Type.NONE:return!0;case nn.Type.EXACT:return e.hasString(this,t);case nn.Type.AND:for(let n=0;n<this.subs.length;n++)if(!this.subs[n].eval(e,t))return!1;return!0;case nn.Type.OR:if(this.ac16&&this.ac8)return e.hasAnyString(this,t);for(let n=0;n<this.subs.length;n++)if(this.subs[n].eval(e,t))return!0;return!1;default:return!0}}},H(nn,"Type",{NONE:0,EXACT:1,AND:2,OR:3}),nn),Gy=class Bn{static build(e){const t=Bn.fromRegexp(e);return Bn.simplify(t)}static fromRegexp(e){if(!e)return new pe(pe.Type.NONE);switch(e.op){case I.Op.PLB:case I.Op.NLB:case I.Op.NO_MATCH:case I.Op.EMPTY_MATCH:case I.Op.BEGIN_LINE:case I.Op.END_LINE:case I.Op.BEGIN_TEXT:case I.Op.END_TEXT:case I.Op.WORD_BOUNDARY:case I.Op.NO_WORD_BOUNDARY:case I.Op.CHAR_CLASS:case I.Op.ANY_CHAR_NOT_NL:case I.Op.ANY_CHAR:return new pe(pe.Type.NONE);case I.Op.LITERAL:{if(e.runes.length===0||e.flags&M.FOLD_CASE)return new pe(pe.Type.NONE);const t=new pe(pe.Type.EXACT);let n="";for(let r=0;r<e.runes.length;r++)n+=String.fromCodePoint(e.runes[r]);return t.str=n,t.bytes=$.stringToUtf8ByteArray(t.str),t}case I.Op.CAPTURE:case I.Op.PLUS:return Bn.fromRegexp(e.subs[0]);case I.Op.REPEAT:return e.min>=1?Bn.fromRegexp(e.subs[0]):new pe(pe.Type.NONE);case I.Op.CONCAT:{const t=new pe(pe.Type.AND);for(const n of e.subs)t.subs.push(Bn.fromRegexp(n));return t}case I.Op.ALTERNATE:{const t=new pe(pe.Type.OR);for(const n of e.subs)t.subs.push(Bn.fromRegexp(n));return t}default:return new pe(pe.Type.NONE)}}static simplify(e){if(e.type===pe.Type.EXACT||e.type===pe.Type.NONE)return e;if(e.type===pe.Type.AND){const t=[];for(const n of e.subs){const r=Bn.simplify(n);if(r.type!==pe.Type.NONE)if(r.type===pe.Type.AND)for(let i=0;i<r.subs.length;i++)t.push(r.subs[i]);else t.push(r)}return t.length===0?new pe(pe.Type.NONE):t.length===1?t[0]:(e.subs=t,e)}if(e.type===pe.Type.OR){const t=[];for(const o of e.subs){const a=Bn.simplify(o);if(a.type===pe.Type.NONE)return new pe(pe.Type.NONE);if(a.type===pe.Type.OR)for(let l=0;l<a.subs.length;l++)t.push(a.subs[l]);else t.push(a)}if(t.length===0)return new pe(pe.Type.NONE);if(t.length===1)return t[0];const n=new Set,r=[];for(const o of t)o.type===pe.Type.EXACT?n.has(o.str)||(n.add(o.str),r.push(o)):r.push(o);e.subs=r;let i=!0;for(const o of r)if(o.type!==pe.Type.EXACT){i=!1;break}return i&&r.length>1&&(e.ac16=new xh(r.map(o=>{const a=[];for(let l=0;l<o.str.length;l++)a.push(o.str.charCodeAt(l));return a})),e.ac8=new xh(r.map(o=>o.bytes))),e}return e}},kt=class{constructor(s=0,e=0){this.head=s,this.tail=e}},Hy=class{constructor(){this.inst=[],this.start=0,this.numCap=2,this.lbStarts=[],this.numLb=0}getInst(s){return this.inst[s]}numInst(){return this.inst.length}addInst(s){this.inst.push(new x(s))}skipNop(s){let e=this.inst[s];for(;e.op===x.NOP||e.op===x.CAPTURE;)e=this.inst[s],s=e.out;return e}prefix(){let s="",e=this.skipNop(this.start);if(!x.isRuneOp(e.op)||e.runes.length!==1)return[e.op===x.MATCH,s];for(;x.isRuneOp(e.op)&&e.runes.length===1&&!(e.arg&M.FOLD_CASE);)s+=String.fromCodePoint(e.runes[0]),e=this.skipNop(e.out);return[e.op===x.MATCH,s]}startCond(){let s=0,e=this.start;e:for(;;){const t=this.inst[e];switch(t.op){case x.EMPTY_WIDTH:s|=t.arg;break;case x.FAIL:return-1;case x.CAPTURE:case x.NOP:break;default:break e}e=t.out}return s}patch(s,e){let t=s.head;for(;t!==0;){const n=this.inst[t>>1];t&1?(t=n.arg,n.arg=e):(t=n.out,n.out=e)}}append(s,e){if(s.head===0)return e;if(e.head===0)return s;const t=this.inst[s.tail>>1];return s.tail&1?t.arg=e.head:t.out=e.head,new kt(s.head,e.tail)}toString(){let s="";for(let e=0;e<this.inst.length;e++){const t=s.length;s+=e,e===this.start&&(s+="*"),s+="        ".substring(s.length-t),s+=this.inst[e],s+=`
`}return s}},Io=class{constructor(s=0,e=new kt,t=!1){this.i=s,this.out=e,this.nullable=t}},Uy=class qs{static ANY_RUNE_NOT_NL(){return[0,L.CODES.get(`
`)-1,L.CODES.get(`
`)+1,Q.MAX_RUNE]}static ANY_RUNE(){return[0,Q.MAX_RUNE]}static compileRegexp(e){const t=new qs,n=t.compile(e);return t.prog.patch(n.out,t.newInst(x.MATCH).i),t.prog.start=n.i,t.prog}static compileSet(e){const t=new qs;if(e.length===0)return t.prog.start=t.newInst(x.FAIL).i,t.prog;let n=[];for(let i=0;i<e.length;i++){const o=t.compile(e[i]),a=t.newInst(x.MATCH);t.prog.getInst(a.i).arg=i,t.prog.patch(o.out,a.i),n.push(o.i)}let r=n[0];for(let i=1;i<n.length;i++){const o=t.newInst(x.ALT),a=t.prog.getInst(o.i);a.out=r,a.arg=n[i],r=o.i}return t.prog.start=r,t.prog}constructor(){this.prog=new Hy,this.newInst(x.FAIL)}newInst(e){return this.prog.addInst(e),new Io(this.prog.numInst()-1,new kt,!0)}nop(){const e=this.newInst(x.NOP);return e.out=new kt(e.i<<1,e.i<<1),e}fail(){return new Io}cap(e){const t=this.newInst(x.CAPTURE);return t.out=new kt(t.i<<1,t.i<<1),this.prog.getInst(t.i).arg=e,this.prog.numCap<e+1&&(this.prog.numCap=e+1),t}cat(e,t){return e.i===0||t.i===0?this.fail():(this.prog.patch(e.out,t.i),new Io(e.i,t.out,e.nullable&&t.nullable))}alt(e,t){if(e.i===0)return t;if(t.i===0)return e;const n=this.newInst(x.ALT),r=this.prog.getInst(n.i);return r.out=e.i,r.arg=t.i,n.out=this.prog.append(e.out,t.out),n.nullable=e.nullable||t.nullable,n}loop(e,t){const n=this.newInst(x.ALT),r=this.prog.getInst(n.i);return t?(r.arg=e.i,n.out=new kt(n.i<<1,n.i<<1)):(r.out=e.i,n.out=new kt(n.i<<1|1,n.i<<1|1)),this.prog.patch(e.out,n.i),n}quest(e,t){const n=this.newInst(x.ALT),r=this.prog.getInst(n.i);return t?(r.arg=e.i,n.out=new kt(n.i<<1,n.i<<1)):(r.out=e.i,n.out=new kt(n.i<<1|1,n.i<<1|1)),n.out=this.prog.append(n.out,e.out),n}star(e,t){return e.nullable?this.quest(this.plus(e,t),t):this.loop(e,t)}plus(e,t){return new Io(e.i,this.loop(e,t).out,e.nullable)}empty(e){const t=this.newInst(x.EMPTY_WIDTH);return this.prog.getInst(t.i).arg=e,t.out=new kt(t.i<<1,t.i<<1),t}rune(e,t){const n=this.newInst(x.RUNE);n.nullable=!1;const r=this.prog.getInst(n.i);return r.runes=e,t&=M.FOLD_CASE,(e.length!==1||Q.simpleFold(e[0])===e[0])&&(t&=-2),r.arg=t,n.out=new kt(n.i<<1,n.i<<1),!(t&M.FOLD_CASE)&&e.length===1||e.length===2&&e[0]===e[1]?r.op=x.RUNE1:e.length===2&&e[0]===0&&e[1]===Q.MAX_RUNE?r.op=x.RUNE_ANY:e.length===4&&e[0]===0&&e[1]===L.CODES.get(`
`)-1&&e[2]===L.CODES.get(`
`)+1&&e[3]===Q.MAX_RUNE&&(r.op=x.RUNE_ANY_NOT_NL),n}lookBehind(e,t){const n=this.newInst(x.LB_WRITE);this.prog.getInst(n.i).arg=t;const r=this.rune(qs.ANY_RUNE(),0),i=this.star(r,!0),o=this.cat(i,e);this.prog.patch(o.out,n.i);const a=this.newInst(x.LB_CHECK);return this.prog.getInst(a.i).arg=t,this.prog.lbStarts.push(o.i),Math.abs(t)>this.prog.numLb&&(this.prog.numLb=Math.abs(t)),a.out=new kt(a.i<<1,a.i<<1),a}compile(e){switch(e.op){case I.Op.NO_MATCH:return this.fail();case I.Op.EMPTY_MATCH:return this.nop();case I.Op.LITERAL:if(e.runes.length===0)return this.nop();{let t=null;for(let n of e.runes){const r=this.rune([n],e.flags);t=t===null?r:this.cat(t,r)}return t}case I.Op.CHAR_CLASS:return this.rune(e.runes,e.flags);case I.Op.ANY_CHAR_NOT_NL:return this.rune(qs.ANY_RUNE_NOT_NL(),0);case I.Op.ANY_CHAR:return this.rune(qs.ANY_RUNE(),0);case I.Op.BEGIN_LINE:return this.empty($.EMPTY_BEGIN_LINE);case I.Op.END_LINE:return this.empty($.EMPTY_END_LINE);case I.Op.BEGIN_TEXT:return this.empty($.EMPTY_BEGIN_TEXT);case I.Op.END_TEXT:return this.empty($.EMPTY_END_TEXT);case I.Op.WORD_BOUNDARY:return this.empty($.EMPTY_WORD_BOUNDARY);case I.Op.NO_WORD_BOUNDARY:return this.empty($.EMPTY_NO_WORD_BOUNDARY);case I.Op.PLB:case I.Op.NLB:return this.lookBehind(this.compile(e.subs[0]),e.lb);case I.Op.CAPTURE:{const t=this.cap(e.cap<<1),n=this.compile(e.subs[0]),r=this.cap(e.cap<<1|1);return this.cat(this.cat(t,n),r)}case I.Op.STAR:return this.star(this.compile(e.subs[0]),(e.flags&M.NON_GREEDY)!==0);case I.Op.PLUS:return this.plus(this.compile(e.subs[0]),(e.flags&M.NON_GREEDY)!==0);case I.Op.QUEST:return this.quest(this.compile(e.subs[0]),(e.flags&M.NON_GREEDY)!==0);case I.Op.CONCAT:if(e.subs.length===0)return this.nop();{let t=null;for(let n of e.subs){const r=this.compile(n);t=t===null?r:this.cat(t,r)}return t}case I.Op.ALTERNATE:if(e.subs.length===0)return this.nop();{let t=null;for(let n of e.subs){const r=this.compile(n);t=t===null?r:this.alt(t,r)}return t}default:throw new Iy("regexp: unhandled case in compile")}}},qy=class Rt{static simplify(e){if(e===null)return null;switch(e.op){case I.Op.PLB:case I.Op.NLB:case I.Op.CAPTURE:{const t=Rt.simplify(e.subs[0]);if(t!==e.subs[0]){const n=I.fromRegexp(e);return n.runes=[],n.subs=[t],n}return e}case I.Op.CONCAT:case I.Op.ALTERNATE:{const t=[];let n=!1;for(let r=0;r<e.subs.length;r++){const i=e.subs[r],o=Rt.simplify(i);if(o!==i&&(n=!0),e.op===I.Op.CONCAT){if(o.op===I.Op.NO_MATCH)return new I(I.Op.NO_MATCH);if(o.op===I.Op.EMPTY_MATCH){n=!0;continue}if(o.op===I.Op.CONCAT){n=!0;for(let a=0;a<o.subs.length;a++)t.push(o.subs[a]);continue}}else if(e.op===I.Op.ALTERNATE){if(o.op===I.Op.NO_MATCH){n=!0;continue}if(o.op===I.Op.ALTERNATE){n=!0;for(let a=0;a<o.subs.length;a++)t.push(o.subs[a]);continue}}t.push(o)}if(n){if(t.length===0)return new I(e.op===I.Op.CONCAT?I.Op.EMPTY_MATCH:I.Op.NO_MATCH);if(t.length===1)return t[0];const r=I.fromRegexp(e);return r.runes=[],r.subs=t,r}return e}case I.Op.CHAR_CLASS:return e.runes===null?e:e.runes.length===0?new I(I.Op.NO_MATCH):e.runes.length===2&&e.runes[0]===0&&e.runes[1]===Q.MAX_RUNE?new I(I.Op.ANY_CHAR):e.runes.length===4&&e.runes[0]===0&&e.runes[1]===L.CODES.get(`
`)-1&&e.runes[2]===L.CODES.get(`
`)+1&&e.runes[3]===Q.MAX_RUNE?new I(I.Op.ANY_CHAR_NOT_NL):e;case I.Op.STAR:case I.Op.PLUS:case I.Op.QUEST:{const t=Rt.simplify(e.subs[0]);return Rt.simplify1(e.op,e.flags,t,e)}case I.Op.REPEAT:{if(e.min===0&&e.max===0)return new I(I.Op.EMPTY_MATCH);const t=Rt.simplify(e.subs[0]);if(e.max===-1){if(e.min===0)return Rt.simplify1(I.Op.STAR,e.flags,t,null);if(e.min===1)return Rt.simplify1(I.Op.PLUS,e.flags,t,null);const r=new I(I.Op.CONCAT),i=[];for(let o=0;o<e.min-1;o++)i.push(t);return i.push(Rt.simplify1(I.Op.PLUS,e.flags,t,null)),r.subs=i.slice(0),Rt.simplify(r)}if(e.min===1&&e.max===1)return t;let n=null;if(e.min>0){n=[];for(let r=0;r<e.min;r++)n.push(t)}if(e.max>e.min){let r=Rt.simplify1(I.Op.QUEST,e.flags,t,null);for(let i=e.min+1;i<e.max;i++){const o=new I(I.Op.CONCAT);o.subs=[t,r],r=Rt.simplify1(I.Op.QUEST,e.flags,o,null)}if(n===null)return r;n.push(r)}if(n!==null){const r=new I(I.Op.CONCAT);return r.subs=n.slice(0),Rt.simplify(r)}return new I(I.Op.NO_MATCH)}}return e}static simplify1(e,t,n,r){if(n.op===I.Op.EMPTY_MATCH)return n;if(n.op===I.Op.NO_MATCH)return e===I.Op.PLUS?n:new I(I.Op.EMPTY_MATCH);if(e===n.op&&(t&M.NON_GREEDY)===(n.flags&M.NON_GREEDY))return n;if(r!==null&&r.op===e&&(r.flags&M.NON_GREEDY)===(t&M.NON_GREEDY)&&n===r.subs[0])return r;const i=new I(e);return i.flags=t,i.subs=[n],i}},he=class{constructor(s,e){this.sign=s,this.cls=e}};const kh=[48,57],Vh=[9,10,12,13,32,32],Mh=[48,57,65,90,95,95,97,122],Gh=new Map([["\\d",new he(1,kh)],["\\D",new he(-1,kh)],["\\s",new he(1,Vh)],["\\S",new he(-1,Vh)],["\\w",new he(1,Mh)],["\\W",new he(-1,Mh)]]),Hh=[48,57,65,90,97,122],Uh=[65,90,97,122],qh=[0,127],Jh=[9,9,32,32],jh=[0,31,127,127],Kh=[48,57],zh=[33,126],Qh=[97,122],Wh=[32,126],Yh=[33,47,58,64,91,96,123,126],$h=[9,13,32,32],Xh=[65,90],Zh=[48,57,65,90,95,95,97,122],ef=[48,57,65,70,97,102],tf=new Map([["[:alnum:]",new he(1,Hh)],["[:^alnum:]",new he(-1,Hh)],["[:alpha:]",new he(1,Uh)],["[:^alpha:]",new he(-1,Uh)],["[:ascii:]",new he(1,qh)],["[:^ascii:]",new he(-1,qh)],["[:blank:]",new he(1,Jh)],["[:^blank:]",new he(-1,Jh)],["[:cntrl:]",new he(1,jh)],["[:^cntrl:]",new he(-1,jh)],["[:digit:]",new he(1,Kh)],["[:^digit:]",new he(-1,Kh)],["[:graph:]",new he(1,zh)],["[:^graph:]",new he(-1,zh)],["[:lower:]",new he(1,Qh)],["[:^lower:]",new he(-1,Qh)],["[:print:]",new he(1,Wh)],["[:^print:]",new he(-1,Wh)],["[:punct:]",new he(1,Yh)],["[:^punct:]",new he(-1,Yh)],["[:space:]",new he(1,$h)],["[:^space:]",new he(-1,$h)],["[:upper:]",new he(1,Xh)],["[:^upper:]",new he(-1,Xh)],["[:word:]",new he(1,Zh)],["[:^word:]",new he(-1,Zh)],["[:xdigit:]",new he(1,ef)],["[:^xdigit:]",new he(-1,ef)]]);var bn=class Fn{static charClassToString(e,t){let n="[";for(let r=0;r<t;r+=2){r>0&&(n+=" ");const i=e[r],o=e[r+1];i===o?n+=`0x${i.toString(16)}`:n+=`0x${i.toString(16)}-0x${o.toString(16)}`}return n+="]",n}static cmp(e,t,n,r){const i=e[t]-n;return i!==0?i:r-e[t+1]}static qsortIntPair(e,t,n){const r=((t+n)/2|0)&-2,i=e[r],o=e[r+1];let a=t,l=n;for(;a<=l;){for(;a<n&&Fn.cmp(e,a,i,o)<0;)a+=2;for(;l>t&&Fn.cmp(e,l,i,o)>0;)l-=2;if(a<=l){if(a!==l){let c=e[a];e[a]=e[l],e[l]=c,c=e[a+1],e[a+1]=e[l+1],e[l+1]=c}a+=2,l-=2}}t<l&&Fn.qsortIntPair(e,t,l),a<n&&Fn.qsortIntPair(e,a,n)}constructor(e=$.emptyInts()){this.r=e,this.len=e.length}toArray(){return this.len===this.r.length?this.r:this.r.slice(0,this.len)}cleanClass(){if(this.len<4)return this;Fn.qsortIntPair(this.r,0,this.len-2);let e=2;for(let t=2;t<this.len;t+=2){const n=this.r[t],r=this.r[t+1];if(n<=this.r[e-1]+1){r>this.r[e-1]&&(this.r[e-1]=r);continue}this.r[e]=n,this.r[e+1]=r,e+=2}return this.len=e,this}appendLiteral(e,t){return t&M.FOLD_CASE?this.appendFoldedRange(e,e):this.appendRange(e,e)}appendRange(e,t){if(this.len>0){for(let n=2;n<=4;n+=2)if(this.len>=n){const r=this.r[this.len-n],i=this.r[this.len-n+1];if(e<=i+1&&r<=t+1)return e<r&&(this.r[this.len-n]=e),t>i&&(this.r[this.len-n+1]=t),this}}return this.r[this.len++]=e,this.r[this.len++]=t,this}appendFoldedRange(e,t){if(e<=Q.MIN_FOLD&&t>=Q.MAX_FOLD)return this.appendRange(e,t);if(t<Q.MIN_FOLD||e>Q.MAX_FOLD)return this.appendRange(e,t);e<Q.MIN_FOLD&&(this.appendRange(e,Q.MIN_FOLD-1),e=Q.MIN_FOLD),t>Q.MAX_FOLD&&(this.appendRange(Q.MAX_FOLD+1,t),t=Q.MAX_FOLD);for(let n=e;n<=t;n++){this.appendRange(n,n);for(let r=Q.simpleFold(n);r!==n;r=Q.simpleFold(r))this.appendRange(r,r)}return this}appendClass(e){for(let t=0;t<e.length;t+=2)this.appendRange(e[t],e[t+1]);return this}appendFoldedClass(e){for(let t=0;t<e.length;t+=2)this.appendFoldedRange(e[t],e[t+1]);return this}appendNegatedClass(e){let t=0;for(let n=0;n<e.length;n+=2){const r=e[n],i=e[n+1];t<=r-1&&this.appendRange(t,r-1),t=i+1}return t<=Q.MAX_RUNE&&this.appendRange(t,Q.MAX_RUNE),this}appendTable(e){for(let t=0;t<e.length;++t){const n=e.getLo(t),r=e.getHi(t),i=e.getStride(t);if(i===1){this.appendRange(n,r);continue}for(let o=n;o<=r;o+=i)this.appendRange(o,o)}return this}appendNegatedTable(e){let t=0;for(let n=0;n<e.length;++n){const r=e.getLo(n),i=e.getHi(n),o=e.getStride(n);if(o===1){t<=r-1&&this.appendRange(t,r-1),t=i+1;continue}for(let a=r;a<=i;a+=o)t<=a-1&&this.appendRange(t,a-1),t=a+1}return t<=Q.MAX_RUNE&&this.appendRange(t,Q.MAX_RUNE),this}appendTableWithSign(e,t){return t<0?this.appendNegatedTable(e):this.appendTable(e)}negateClass(){let e=0,t=0;for(let n=0;n<this.len;n+=2){const r=this.r[n],i=this.r[n+1];e<=r-1&&(this.r[t]=e,this.r[t+1]=r-1,t+=2),e=i+1}return this.len=t,e<=Q.MAX_RUNE&&(this.r[this.len++]=e,this.r[this.len++]=Q.MAX_RUNE),this}appendClassWithSign(e,t){return t<0?this.appendNegatedClass(e):this.appendClass(e)}appendGroup(e,t){let n=e.cls;return t&&(n=new Fn().appendFoldedClass(n).cleanClass().toArray()),this.appendClassWithSign(n,e.sign)}toString(){return Fn.charClassToString(this.r,this.len)}},Jy=class{constructor(s){this.str=s,this.position=0}pos(){return this.position}rewindTo(s){this.position=s}more(){return this.position<this.str.length}peek(){return this.str.codePointAt(this.position)}skip(s){this.position+=s}skipString(s){this.position+=s.length}pop(){const s=this.str.codePointAt(this.position);return this.position+=$.charCount(s),s}lookingAt(s){return this.str.startsWith(s,this.position)}rest(){return this.str.substring(this.position)}from(s){return this.str.substring(s,this.position)}toString(){return this.rest()}},U,jy=(U=class{static unicodeTable(e){return e==="Any"?{tab:U.ANY_TABLE,fold:U.ANY_TABLE,sign:1}:e==="Ascii"?{tab:U.ASCII_TABLE,fold:U.ASCII_FOLD_TABLE,sign:1}:e==="Assigned"?{tab:_t.CATEGORIES.get("Cn"),fold:_t.CATEGORIES.get("Cn"),sign:-1}:e==="Lc"?{tab:_t.CATEGORIES.get("LC"),fold:_t.FOLD_CATEGORIES.get("LC"),sign:1}:_t.CATEGORIES.has(e)?{tab:_t.CATEGORIES.get(e),fold:_t.FOLD_CATEGORIES.get(e),sign:1}:_t.SCRIPTS.has(e)?{tab:_t.SCRIPTS.get(e),fold:_t.FOLD_SCRIPT.get(e),sign:1}:null}static minFoldRune(e){if(e<Q.MIN_FOLD||e>Q.MAX_FOLD)return e;let t=e;const n=e;for(e=Q.simpleFold(e);e!==n;e=Q.simpleFold(e))t>e&&(t=e);return t}static leadingRegexp(e){if(e.op===I.Op.EMPTY_MATCH)return null;if(e.op===I.Op.CONCAT&&e.subs.length>0){const t=e.subs[0];return t.op===I.Op.EMPTY_MATCH?null:t}return e}static literalRegexp(e,t){const n=new I(I.Op.LITERAL);return n.flags=t,n.runes=$.stringToRunes(e),n}static parse(e,t){return new U(e,t).parseInternal()}static parseRepeat(e){const t=e.pos();if(!e.more()||!e.lookingAt("{"))return-1;e.skip(1);const n=U.parseInt(e);if(n===-1||!e.more())return-1;let r;if(!e.lookingAt(","))r=n;else{if(e.skip(1),!e.more())return-1;if(e.lookingAt("}"))r=-1;else if((r=U.parseInt(e))===-1)return-1}if(!e.more()||!e.lookingAt("}"))return-1;if(e.skip(1),n<0||n>1e3||r===-2||r>1e3||r>=0&&n>r)throw new Te(U.ERR_INVALID_REPEAT_SIZE,e.from(t));return n<<16|r&Q.MAX_BMP}static isValidCaptureName(e){if(e.length===0)return!1;for(let t=0;t<e.length;t++){const n=e.codePointAt(t);if(n!==L.CODES.get("_")&&!$.isalnum(n))return!1}return!0}static parseInt(e){const t=e.pos();for(;e.more()&&e.peek()>=L.CODES.get("0")&&e.peek()<=L.CODES.get("9");)e.skip(1);const n=e.from(t);return n.length===0||n.length>1&&n.codePointAt(0)===L.CODES.get("0")?-1:n.length>8?-2:parseInt(n,10)}static isCharClass(e){return e.op===I.Op.LITERAL&&e.runes.length===1||e.op===I.Op.CHAR_CLASS||e.op===I.Op.ANY_CHAR_NOT_NL||e.op===I.Op.ANY_CHAR}static matchRune(e,t){switch(e.op){case I.Op.LITERAL:return e.runes.length===1&&e.runes[0]===t;case I.Op.CHAR_CLASS:for(let n=0;n<e.runes.length;n+=2)if(e.runes[n]<=t&&t<=e.runes[n+1])return!0;return!1;case I.Op.ANY_CHAR_NOT_NL:return t!==L.CODES.get(`
`);case I.Op.ANY_CHAR:return!0}return!1}static mergeCharClass(e,t){switch(e.op){case I.Op.ANY_CHAR:break;case I.Op.ANY_CHAR_NOT_NL:U.matchRune(t,L.CODES.get(`
`))&&(e.op=I.Op.ANY_CHAR);break;case I.Op.CHAR_CLASS:t.op===I.Op.LITERAL?e.runes=new bn(e.runes).appendLiteral(t.runes[0],t.flags).toArray():e.runes=new bn(e.runes).appendClass(t.runes).toArray();break;case I.Op.LITERAL:if(t.runes[0]===e.runes[0]&&t.flags===e.flags)break;e.op=I.Op.CHAR_CLASS,e.runes=new bn().appendLiteral(e.runes[0],e.flags).appendLiteral(t.runes[0],t.flags).toArray();break}}static parseEscape(e){const t=e.pos();if(e.skip(1),!e.more())throw new Te(U.ERR_TRAILING_BACKSLASH);let n=e.pop();e:switch(n){case L.CODES.get("1"):case L.CODES.get("2"):case L.CODES.get("3"):case L.CODES.get("4"):case L.CODES.get("5"):case L.CODES.get("6"):case L.CODES.get("7"):if(!e.more()||e.peek()<L.CODES.get("0")||e.peek()>L.CODES.get("7"))break;case L.CODES.get("0"):{let r=n-L.CODES.get("0");for(let i=1;i<3&&!(!e.more()||e.peek()<L.CODES.get("0")||e.peek()>L.CODES.get("7"));i++)r=r*8+e.peek()-L.CODES.get("0"),e.skip(1);return r}case L.CODES.get("x"):{if(!e.more())break;if(n=e.pop(),n===L.CODES.get("{")){let o=0,a=0;for(;;){if(!e.more())break e;if(n=e.pop(),n===L.CODES.get("}"))break;const l=$.unhex(n);if(l<0||(a=a*16+l,a>Q.MAX_RUNE))break e;o++}if(o===0)break e;return a}const r=$.unhex(n);if(!e.more())break;n=e.pop();const i=$.unhex(n);if(r<0||i<0)break;return r*16+i}case L.CODES.get("a"):return L.CODES.get("\x07");case L.CODES.get("f"):return L.CODES.get("\f");case L.CODES.get("n"):return L.CODES.get(`
`);case L.CODES.get("r"):return L.CODES.get("\r");case L.CODES.get("t"):return L.CODES.get("	");case L.CODES.get("v"):return L.CODES.get("\v");default:if(n<=Q.MAX_ASCII&&!$.isalnum(n))return n;break}throw new Te(U.ERR_INVALID_ESCAPE,e.from(t))}static parseClassChar(e,t){if(!e.more())throw new Te(U.ERR_MISSING_BRACKET,e.from(t));return e.lookingAt("\\")?U.parseEscape(e):e.pop()}static concatRunes(e,t){for(let n=0;n<t.length;n++)e.push(t[n]);return e}static hasCapture(e){if(e===null)return!1;if(e.op===I.Op.CAPTURE)return!0;if(e.subs){for(let t of e.subs)if(U.hasCapture(t))return!0}return!1}constructor(e,t=0){this.wholeRegexp=e,this.flags=t,this.numCap=0,this.namedGroups=Object.create(null),this.stack=[],this.free=null,this.numRegexp=0,this.numRunes=0,this.repeats=0,this.height=null,this.size=null,this.nlb=0}newRegexp(e){let t=this.free;return t!==null&&t.subs!==null&&t.subs.length>0?(this.free=t.subs[0],t.reinit(),t.op=e):(t=new I(e),this.numRegexp+=1),t}reuse(e){this.height!==null&&this.height.has(e)&&this.height.delete(e),e.subs!==null&&e.subs.length>0&&(e.subs[0]=this.free),this.free=e}checkLimits(e){if(this.numRunes>U.MAX_RUNES)throw new Te(U.ERR_LARGE);this.checkSize(e),this.checkHeight(e)}checkSize(e){if(this.size===null){if(this.repeats===0&&(this.repeats=1),e.op===I.Op.REPEAT){let t=e.max;t===-1&&(t=e.min),t<=0&&(t=1),t>Math.floor(U.MAX_SIZE/this.repeats)?this.repeats=U.MAX_SIZE:this.repeats*=t}if(this.numRegexp<Math.floor(U.MAX_SIZE/this.repeats))return;this.size=new Map;for(let t of this.stack)this.checkSize(t)}if(this.calcSize(e,!0)>U.MAX_SIZE)throw new Te(U.ERR_LARGE)}calcSize(e,t=!1){if(!t&&this.size!==null&&this.size.has(e))return this.size.get(e);let n=0;switch(e.op){case I.Op.LITERAL:n=e.runes.length;break;case I.Op.PLB:case I.Op.NLB:case I.Op.CAPTURE:case I.Op.STAR:n=2+this.calcSize(e.subs[0]);break;case I.Op.PLUS:case I.Op.QUEST:n=1+this.calcSize(e.subs[0]);break;case I.Op.CONCAT:for(let r of e.subs)n=n+this.calcSize(r);break;case I.Op.ALTERNATE:for(let r of e.subs)n=n+this.calcSize(r);e.subs.length>1&&(n=n+e.subs.length-1);break;case I.Op.REPEAT:{let r=this.calcSize(e.subs[0]);if(e.max===-1){e.min===0?n=2+r:n=1+e.min*r;break}n=e.max*r+(e.max-e.min);break}}return n=Math.max(1,n),this.size===null&&(this.size=new Map),this.size.set(e,n),n}checkHeight(e){if(!(this.numRegexp<U.MAX_HEIGHT)){if(this.height===null){this.height=new Map;for(let t of this.stack)this.checkHeight(t)}if(this.calcHeight(e,!0)>U.MAX_HEIGHT)throw new Te(U.ERR_NESTING_DEPTH)}}calcHeight(e,t=!1){if(!t&&this.height!==null&&this.height.has(e))return this.height.get(e);let n=1;for(let r of e.subs){const i=this.calcHeight(r);n<1+i&&(n=1+i)}return this.height===null&&(this.height=new Map),this.height.set(e,n),n}pop(){return this.stack.pop()}popToPseudo(){const e=this.stack.length;let t=e;for(;t>0&&!I.isPseudoOp(this.stack[t-1].op);)t--;const n=this.stack.slice(t,e);return this.stack=this.stack.slice(0,t),n}push(e){if(this.numRunes+=e.runes.length,e.op===I.Op.CHAR_CLASS&&e.runes.length===2&&e.runes[0]===e.runes[1]){if(this.maybeConcat(e.runes[0],this.flags&-2))return null;e.op=I.Op.LITERAL,e.runes=[e.runes[0]],e.flags=this.flags&-2}else if(e.op===I.Op.CHAR_CLASS&&e.runes.length===4&&e.runes[0]===e.runes[1]&&e.runes[2]===e.runes[3]&&Q.simpleFold(e.runes[0])===e.runes[2]&&Q.simpleFold(e.runes[2])===e.runes[0]||e.op===I.Op.CHAR_CLASS&&e.runes.length===2&&e.runes[0]+1===e.runes[1]&&Q.simpleFold(e.runes[0])===e.runes[1]&&Q.simpleFold(e.runes[1])===e.runes[0]){if(this.maybeConcat(e.runes[0],this.flags|M.FOLD_CASE))return null;e.op=I.Op.LITERAL,e.runes=[e.runes[0]],e.flags=this.flags|M.FOLD_CASE}else this.maybeConcat(-1,0);return this.stack.push(e),this.checkLimits(e),e}maybeConcat(e,t){const n=this.stack.length;if(n<2)return!1;const r=this.stack[n-1],i=this.stack[n-2];return r.op!==I.Op.LITERAL||i.op!==I.Op.LITERAL||(r.flags&M.FOLD_CASE)!==(i.flags&M.FOLD_CASE)?!1:(i.runes=U.concatRunes(i.runes,r.runes),e>=0?(r.runes=[e],r.flags=t,!0):(this.pop(),this.reuse(r),!1))}newLiteral(e,t){const n=this.newRegexp(I.Op.LITERAL);return n.flags=t,t&M.FOLD_CASE&&(e=U.minFoldRune(e)),n.runes=[e],n}literal(e){this.push(this.newLiteral(e,this.flags))}op(e){const t=this.newRegexp(e);return t.flags=this.flags,this.push(t)}repeat(e,t,n,r,i,o){let a=this.flags;if(a&M.PERL_X&&(i.more()&&i.lookingAt("?")&&(i.skip(1),a^=M.NON_GREEDY),o!==-1))throw new Te(U.ERR_INVALID_REPEAT_OP,i.from(o));const l=this.stack.length;if(l===0)throw new Te(U.ERR_MISSING_REPEAT_ARGUMENT,i.from(r));const c=this.stack[l-1];if(I.isPseudoOp(c.op))throw new Te(U.ERR_MISSING_REPEAT_ARGUMENT,i.from(r));const h=this.newRegexp(e);if(h.min=t,h.max=n,h.flags=a,h.subs=[c],this.stack[l-1]=h,this.checkLimits(h),e===I.Op.REPEAT&&(t>=2||n>=2)&&!this.repeatIsValid(h,1e3))throw new Te(U.ERR_INVALID_REPEAT_SIZE,i.from(r))}repeatIsValid(e,t){if(e.op===I.Op.REPEAT){let n=e.max;if(n===0)return!0;if(n<0&&(n=e.min),n>t)return!1;n>0&&(t=Math.trunc(t/n))}for(let n of e.subs)if(!this.repeatIsValid(n,t))return!1;return!0}concat(){this.maybeConcat(-1,0);const e=this.popToPseudo();return e.length===0?this.push(this.newRegexp(I.Op.EMPTY_MATCH)):this.push(this.collapse(e,I.Op.CONCAT))}alternate(){const e=this.popToPseudo();return e.length>0&&this.cleanAlt(e[e.length-1]),e.length===0?this.push(this.newRegexp(I.Op.NO_MATCH)):this.push(this.collapse(e,I.Op.ALTERNATE))}cleanAlt(e){e.op===I.Op.CHAR_CLASS&&(e.runes=new bn(e.runes).cleanClass().toArray(),e.runes.length===2&&e.runes[0]===0&&e.runes[1]===Q.MAX_RUNE?(e.runes=[],e.op=I.Op.ANY_CHAR):e.runes.length===4&&e.runes[0]===0&&e.runes[1]===L.CODES.get(`
`)-1&&e.runes[2]===L.CODES.get(`
`)+1&&e.runes[3]===Q.MAX_RUNE&&(e.runes=[],e.op=I.Op.ANY_CHAR_NOT_NL))}collapse(e,t){if(e.length===1)return e[0];let n=0;for(let a of e)n+=a.op===t?a.subs.length:1;let r=new Array(n).fill(null),i=0;for(let a of e)if(a.op===t){for(let l=0;l<a.subs.length;l++)r[i++]=a.subs[l];this.reuse(a)}else r[i++]=a;let o=this.newRegexp(t);if(o.subs=r,t===I.Op.ALTERNATE&&(o.subs=this.factor(o.subs),o.subs.length===1)){const a=o;o=o.subs[0],this.reuse(a)}return o}factor(e){if(e.length<2)return e;let t=0,n=e.length,r=0,i=null,o=0,a=0,l=0;for(let h=0;h<=n;h++){let f=null,d=0,_=0;if(h<n){let y=e[t+h];if(y.op===I.Op.CONCAT&&y.subs.length>0&&(y=y.subs[0]),y.op===I.Op.LITERAL&&(f=y.runes,d=y.runes.length,_=y.flags&M.FOLD_CASE),_===a){let N=0;for(;N<o&&N<d&&i[N]===f[N];)N++;if(N>0){o=N;continue}}}if(h!==l)if(h===l+1)e[r++]=e[t+l];else{const y=this.newRegexp(I.Op.LITERAL);y.flags=a,y.runes=i.slice(0,o);for(let J=l;J<h;J++)e[t+J]=this.removeLeadingString(e[t+J],o),this.checkLimits(e[t+J]);const N=this.collapse(e.slice(t+l,t+h),I.Op.ALTERNATE),F=this.newRegexp(I.Op.CONCAT);F.subs=[y,N],e[r++]=F}l=h,i=f,o=d,a=_}n=r,t=0,l=0,r=0;let c=null;for(let h=0;h<=n;h++){let f=null;if(!(h<n&&(f=U.leadingRegexp(e[t+h]),c!==null&&c.equals(f)&&(U.isCharClass(c)||c.op===I.Op.REPEAT&&c.min===c.max&&U.isCharClass(c.subs[0]))))){if(h!==l)if(h===l+1)e[r++]=e[t+l];else{const d=c;for(let N=l;N<h;N++){const F=N!==l;e[t+N]=this.removeLeadingRegexp(e[t+N],F),this.checkLimits(e[t+N])}const _=this.collapse(e.slice(t+l,t+h),I.Op.ALTERNATE),y=this.newRegexp(I.Op.CONCAT);y.subs=[d,_],e[r++]=y}l=h,c=f}}n=r,t=0,l=0,r=0;for(let h=0;h<=n;h++)if(!(h<n&&U.isCharClass(e[t+h]))){if(h!==l)if(h===l+1)e[r++]=e[t+l];else{let f=l;for(let _=l+1;_<h;_++){const y=e[t+f],N=e[t+_];(y.op<N.op||y.op===N.op&&(y.runes!==null?y.runes.length:0)<(N.runes!==null?N.runes.length:0))&&(f=_)}const d=e[t+l];e[t+l]=e[t+f],e[t+f]=d;for(let _=l+1;_<h;_++)U.mergeCharClass(e[t+l],e[t+_]),this.reuse(e[t+_]);this.cleanAlt(e[t+l]),e[r++]=e[t+l]}h<n&&(e[r++]=e[t+h]),l=h+1}n=r,t=0,l=0,r=0;for(let h=0;h<n;++h)h+1<n&&e[t+h].op===I.Op.EMPTY_MATCH&&e[t+h+1].op===I.Op.EMPTY_MATCH||(e[r++]=e[t+h]);return n=r,t=0,e.slice(t,n)}removeLeadingString(e,t){if(e.op===I.Op.CONCAT&&e.subs.length>0){const n=this.removeLeadingString(e.subs[0],t);if(e.subs[0]=n,n.op===I.Op.EMPTY_MATCH)switch(this.reuse(n),e.subs.length){case 0:case 1:e.op=I.Op.EMPTY_MATCH,e.subs=I.emptySubs();break;case 2:{const r=e;e=e.subs[1],this.reuse(r);break}default:e.subs=e.subs.slice(1,e.subs.length);break}return e}return e.op===I.Op.LITERAL&&(e.runes=e.runes.slice(t,e.runes.length),e.runes.length===0&&(e.op=I.Op.EMPTY_MATCH)),e}removeLeadingRegexp(e,t){if(e.op===I.Op.CONCAT&&e.subs.length>0){switch(t&&this.reuse(e.subs[0]),e.subs=e.subs.slice(1,e.subs.length),e.subs.length){case 0:e.op=I.Op.EMPTY_MATCH,e.subs=I.emptySubs();break;case 1:{const n=e;e=e.subs[0],this.reuse(n);break}}return e}return t&&this.reuse(e),this.newRegexp(I.Op.EMPTY_MATCH)}parseInternal(){if(this.flags&M.LITERAL)return U.literalRegexp(this.wholeRegexp,this.flags);let e=-1,t=-1,n=-1;const r=new Jy(this.wholeRegexp);for(;r.more();){let i=-1;e:switch(r.peek()){case L.CODES.get("("):if(this.flags&M.LOOKBEHIND){if(r.lookingAt("(?<=")){this.parsePosLookBehind(),r.skip(4);break}if(r.lookingAt("(?<!")){this.parseNegLookBehind(),r.skip(4);break}}if(this.flags&M.PERL_X&&r.lookingAt("(?")){this.parsePerlFlags(r);break}this.op(I.Op.LEFT_PAREN).cap=++this.numCap,r.skip(1);break;case L.CODES.get("|"):this.parseVerticalBar(),r.skip(1);break;case L.CODES.get(")"):this.parseRightParen(),r.skip(1);break;case L.CODES.get("^"):this.flags&M.ONE_LINE?this.op(I.Op.BEGIN_TEXT):this.op(I.Op.BEGIN_LINE),r.skip(1);break;case L.CODES.get("$"):this.flags&M.ONE_LINE?this.op(I.Op.END_TEXT).flags|=M.WAS_DOLLAR:this.op(I.Op.END_LINE),r.skip(1);break;case L.CODES.get("."):this.flags&M.DOT_NL?this.op(I.Op.ANY_CHAR):this.op(I.Op.ANY_CHAR_NOT_NL),r.skip(1);break;case L.CODES.get("["):this.parseClass(r);break;case L.CODES.get("*"):case L.CODES.get("+"):case L.CODES.get("?"):{i=r.pos();let o=null;switch(r.pop()){case L.CODES.get("*"):o=I.Op.STAR;break;case L.CODES.get("+"):o=I.Op.PLUS;break;case L.CODES.get("?"):o=I.Op.QUEST;break}this.repeat(o,t,n,i,r,e);break}case L.CODES.get("{"):{i=r.pos();const o=U.parseRepeat(r);if(o<0){r.rewindTo(i),this.literal(r.pop());break}t=o>>16,n=(o&Q.MAX_BMP)<<16>>16,this.repeat(I.Op.REPEAT,t,n,i,r,e);break}case L.CODES.get("\\"):{const o=r.pos();if(r.skip(1),this.flags&M.PERL_X&&r.more())switch(r.pop()){case L.CODES.get("A"):this.op(I.Op.BEGIN_TEXT);break e;case L.CODES.get("b"):this.op(I.Op.WORD_BOUNDARY);break e;case L.CODES.get("B"):this.op(I.Op.NO_WORD_BOUNDARY);break e;case L.CODES.get("C"):throw new Te(U.ERR_INVALID_ESCAPE,"\\C");case L.CODES.get("Q"):{let c=r.rest();const h=c.indexOf("\\E");h>=0?(c=c.substring(0,h),r.skipString(c),r.skipString("\\E")):r.skipString(c);let f=0;for(;f<c.length;){const d=c.codePointAt(f);this.literal(d),f+=$.charCount(d)}break e}case L.CODES.get("z"):this.op(I.Op.END_TEXT);break e;default:r.rewindTo(o);break}else r.rewindTo(o);const a=this.newRegexp(I.Op.CHAR_CLASS);if(a.flags=this.flags,r.lookingAt("\\p")||r.lookingAt("\\P")){const c=new bn;if(this.parseUnicodeClass(r,c)){a.runes=c.toArray(),this.push(a);break e}}const l=new bn;if(this.parsePerlClassEscape(r,l)){a.runes=l.toArray(),this.push(a);break e}r.rewindTo(o),this.reuse(a),this.literal(U.parseEscape(r));break}default:this.literal(r.pop());break}e=i}if(this.concat(),this.swapVerticalBar()&&this.pop(),this.alternate(),this.stack.length!==1)throw new Te(U.ERR_MISSING_PAREN,this.wholeRegexp);return this.stack[0].namedGroups=this.namedGroups,this.stack[0]}parsePerlFlags(e){const t=e.pos(),n=e.rest();if(n.startsWith("(?P<")||n.startsWith("(?<")){const a=n.charAt(2)==="P"?4:3,l=n.indexOf(">");if(l<0)throw new Te(U.ERR_INVALID_NAMED_CAPTURE,n);const c=n.substring(a,l);if(e.skipString(c),e.skip(a+1),!U.isValidCaptureName(c))throw new Te(U.ERR_INVALID_NAMED_CAPTURE,n.substring(0,l+1));const h=this.op(I.Op.LEFT_PAREN);if(h.cap=++this.numCap,this.namedGroups[c])throw new Te(U.ERR_DUPLICATE_NAMED_CAPTURE,c);this.namedGroups[c]=this.numCap,h.name=c;return}e.skip(2);let r=this.flags,i=1,o=!1;e:for(;e.more();){const a=e.pop();switch(a){case L.CODES.get("i"):r|=M.FOLD_CASE,o=!0;break;case L.CODES.get("m"):r&=-17,o=!0;break;case L.CODES.get("s"):r|=M.DOT_NL,o=!0;break;case L.CODES.get("U"):r|=M.NON_GREEDY,o=!0;break;case L.CODES.get("-"):if(i<0)break e;i=-1,r=~r,o=!1;break;case L.CODES.get(":"):case L.CODES.get(")"):if(i<0){if(!o)break e;r=~r}a===L.CODES.get(":")&&this.op(I.Op.LEFT_PAREN),this.flags=r;return;default:break e}}throw new Te(U.ERR_INVALID_PERL_OP,e.from(t))}parsePosLookBehind(){const e=this.newRegexp(I.Op.LEFT_PAREN);return e.flags=this.flags,e.lb=++this.nlb,this.push(e)}parseNegLookBehind(){const e=this.newRegexp(I.Op.LEFT_PAREN);return e.flags=this.flags,e.lb=-++this.nlb,this.push(e)}parseVerticalBar(){this.concat(),this.swapVerticalBar()||this.op(I.Op.VERTICAL_BAR)}swapVerticalBar(){const e=this.stack.length;if(e>=3&&this.stack[e-2].op===I.Op.VERTICAL_BAR&&U.isCharClass(this.stack[e-1])&&U.isCharClass(this.stack[e-3])){let t=this.stack[e-1],n=this.stack[e-3];if(t.op>n.op){const r=n;n=t,t=r,this.stack[e-3]=n}return U.mergeCharClass(n,t),this.reuse(t),this.pop(),!0}if(e>=2){const t=this.stack[e-1],n=this.stack[e-2];if(n.op===I.Op.VERTICAL_BAR)return e>=3&&this.cleanAlt(this.stack[e-3]),this.stack[e-2]=t,this.stack[e-1]=n,!0}return!1}parseRightParen(){if(this.concat(),this.swapVerticalBar()&&this.pop(),this.alternate(),this.stack.length<2)throw new Te(U.ERR_UNEXPECTED_PAREN,this.wholeRegexp);const e=this.pop(),t=this.pop();if(t.op!==I.Op.LEFT_PAREN)throw new Te(U.ERR_UNEXPECTED_PAREN,this.wholeRegexp);if(this.flags=t.flags,t.lb!==0){if(U.hasCapture(e))throw new Te(U.ERR_INVALID_CAPTURE_IN_LOOKBEHIND,this.wholeRegexp);t.lb>0?t.op=I.Op.PLB:t.op=I.Op.NLB,t.subs=[e],this.push(t);return}t.cap===0?this.push(e):(t.op=I.Op.CAPTURE,t.subs=[e],this.push(t))}parsePerlClassEscape(e,t){const n=e.pos();if(!(this.flags&M.PERL_X)||!e.more()||e.pop()!==L.CODES.get("\\")||!e.more())return!1;e.pop();const r=e.from(n),i=Gh.has(r)?Gh.get(r):null;return i===null?!1:(t.appendGroup(i,(this.flags&M.FOLD_CASE)!==0),!0)}parseNamedClass(e,t){const n=e.rest(),r=n.indexOf(":]");if(r<0)return!1;const i=n.substring(0,r+2);e.skipString(i);const o=tf.has(i)?tf.get(i):null;if(o===null)throw new Te(U.ERR_INVALID_CHAR_RANGE,i);return t.appendGroup(o,(this.flags&M.FOLD_CASE)!==0),!0}parseUnicodeClass(e,t){const n=e.pos();if(!(this.flags&M.UNICODE_GROUPS)||!e.lookingAt("\\p")&&!e.lookingAt("\\P"))return!1;e.skip(1);let r=1,i=e.pop();if(i===L.CODES.get("P")&&(r=-1),!e.more())throw e.rewindTo(n),new Te(U.ERR_INVALID_CHAR_RANGE,e.rest());i=e.pop();let o;if(i!==L.CODES.get("{"))o=$.runeToString(i);else{const h=e.rest(),f=h.indexOf("}");if(f<0)throw e.rewindTo(n),new Te(U.ERR_INVALID_CHAR_RANGE,e.rest());o=h.substring(0,f),e.skipString(o),e.skip(1)}o.length!==0&&o.codePointAt(0)===L.CODES.get("^")&&(r=0-r,o=o.substring(1));const a=U.unicodeTable(o);if(a===null)throw new Te(U.ERR_INVALID_CHAR_RANGE,e.from(n));a.sign<0&&(r=0-r);const l=a.tab,c=a.fold;if(!(this.flags&M.FOLD_CASE)||c===null)t.appendTableWithSign(l,r);else{const h=new bn().appendTable(l).appendTable(c).cleanClass().toArray();t.appendClassWithSign(h,r)}return!0}parseClass(e){const t=e.pos();e.skip(1);const n=this.newRegexp(I.Op.CHAR_CLASS);n.flags=this.flags;const r=new bn;let i=1;e.more()&&e.lookingAt("^")&&(i=-1,e.skip(1),this.flags&M.CLASS_NL||r.appendRange(L.CODES.get(`
`),L.CODES.get(`
`)));let o=!0;for(;!e.more()||e.peek()!==L.CODES.get("]")||o;){if(e.more()&&e.lookingAt("-")&&!(this.flags&M.PERL_X)&&!o){const h=e.rest();if(h==="-"||!h.startsWith("-]"))throw e.rewindTo(t),new Te(U.ERR_INVALID_CHAR_RANGE,e.rest())}o=!1;const a=e.pos();if(e.lookingAt("[:")){if(this.parseNamedClass(e,r))continue;e.rewindTo(a)}if(this.parseUnicodeClass(e,r)||this.parsePerlClassEscape(e,r))continue;e.rewindTo(a);const l=U.parseClassChar(e,t);let c=l;if(e.more()&&e.lookingAt("-")){if(e.skip(1),e.more()&&e.lookingAt("]"))e.skip(-1);else if(c=U.parseClassChar(e,t),c<l)throw new Te(U.ERR_INVALID_CHAR_RANGE,e.from(a))}this.flags&M.FOLD_CASE?r.appendFoldedRange(l,c):r.appendRange(l,c)}e.skip(1),r.cleanClass(),i<0&&r.negateClass(),n.runes=r.toArray(),this.push(n)}},H(U,"ERR_INTERNAL_ERROR","regexp/syntax: internal error"),H(U,"ERR_INVALID_CHAR_RANGE","invalid character class range"),H(U,"ERR_INVALID_ESCAPE","invalid escape sequence"),H(U,"ERR_INVALID_NAMED_CAPTURE","invalid named capture"),H(U,"ERR_INVALID_PERL_OP","invalid or unsupported Perl syntax"),H(U,"ERR_INVALID_REPEAT_OP","invalid nested repetition operator"),H(U,"ERR_INVALID_REPEAT_SIZE","invalid repeat count"),H(U,"ERR_MISSING_BRACKET","missing closing ]"),H(U,"ERR_MISSING_PAREN","missing closing )"),H(U,"ERR_MISSING_REPEAT_ARGUMENT","missing argument to repetition operator"),H(U,"ERR_TRAILING_BACKSLASH","trailing backslash at end of expression"),H(U,"ERR_DUPLICATE_NAMED_CAPTURE","duplicate capture group name"),H(U,"ERR_UNEXPECTED_PAREN","unexpected )"),H(U,"ERR_NESTING_DEPTH","expression nests too deeply"),H(U,"ERR_LARGE","expression too large"),H(U,"ERR_INVALID_CAPTURE_IN_LOOKBEHIND","invalid capture in lookbehind"),H(U,"MAX_HEIGHT",1e3),H(U,"MAX_SIZE",3355443),H(U,"MAX_RUNES",33554432),H(U,"ANY_TABLE",new g(new Uint32Array([0,Q.MAX_RUNE,1]))),H(U,"ASCII_TABLE",new g(new Uint32Array([0,127,1]))),H(U,"ASCII_FOLD_TABLE",new g(new Uint32Array([0,127,1,383,383,1,8490,8490,1]))),U),Ky=class fs{static initTest(e){const t=fs.compile(e),n=new fs(t.expr,t.prog,t.numSubexp,t.longest);return n.cond=t.cond,n.prefix=t.prefix,n.prefixUTF8=t.prefixUTF8,n.prefixComplete=t.prefixComplete,n.prefixRune=t.prefixRune,n.prefilter=t.prefilter,n}static compile(e){return fs.compileImpl(e,M.PERL,!1)}static compilePOSIX(e){return fs.compileImpl(e,M.POSIX,!0)}static compileImpl(e,t,n){let r=jy.parse(e,t);const i=r.maxCap();r=qy.simplify(r);const o=Gy.build(r),a=Uy.compileRegexp(r),l=new fs(e,a,i,n);l.prefilter=o.type===pe.Type.NONE?null:o;const[c,h]=a.prefix();return l.prefixComplete=c,l.prefix=h,l.prefixUTF8=$.stringToUtf8ByteArray(l.prefix),l.prefix.length>0&&(l.prefixRune=l.prefix.codePointAt(0)),l.namedGroups=r.namedGroups,l}static match(e,t){return fs.compile(e).match(t)}constructor(e,t,n=0,r=0){this.expr=e,this.prog=t,this.numSubexp=n,this.longest=r,this.cond=t.startCond(),this.prefix=null,this.prefixUTF8=null,this.prefixComplete=!1,this.prefixRune=0,this.machinePool=[],this.dfa=new by(this.prog),this.onepass=Lh.compile(this.prog),this.prefilter=null}matchPrefixComplete(e,t,n,r){if((n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return null;let i=-1,o=-1;const a=e.prefixLength(this);if(n===M.UNANCHORED){const l=e.index(this,t);if(l<0)return null;i=t+l,o=i+a}else if(n===M.ANCHOR_BOTH){if(e.endPos()!==a||e.index(this,0)!==0)return null;i=0,o=a}else if(n===M.ANCHOR_START){if(e.index(this,0)!==0)return null;i=0,o=a}if(i<0)return null;if(r>0){const l=new Int32Array(r).fill(-1);return l[0]=i,l[1]=o,Array.from(l)}return[]}executeEngine(e,t,n,r){if(this.prefixComplete&&(r===0||this.numSubexp===0))return this.matchPrefixComplete(e,t,n,r);if(this.prefilter!==null&&n===M.UNANCHORED&&!this.prefilter.eval(e,t))return null;if(this.onepass!==null)return Lh.execute(this,e,t,n,r);if(r>0)return this.prog.numLb===0&&e.endPos()<=To.maxBitStateLen(this.prog)?To.execute(this,e,t,n,r):this.doExecuteNFA(e,t,n,r);if(this.prog.numLb===0){const i=this.dfa.match(e,t,n);if(i!==null)return i?[]:null;if(e.endPos()<=To.maxBitStateLen(this.prog))return To.execute(this,e,t,n,r)}return this.doExecuteNFA(e,t,n,r)}numberOfCapturingGroups(){return this.numSubexp}numberOfInstructions(){return this.prog.numInst()}get(){return this.machinePool.length>0?this.machinePool.pop():null}reset(){this.machinePool.length=0}put(e){this.machinePool.push(e)}toString(){return this.expr}doExecuteNFA(e,t,n,r){let i=this.get();i||(i=vy.fromRE2(this)),i.init(r);const o=i.match(e,t,n)?i.submatches():null;return this.put(i),o}match(e){return this.executeEngine(Ae.fromUTF16(e),0,M.UNANCHORED,0)!==null}matchWithGroup(e,t,n,r,i){return e instanceof As||($.isByteArray(e)?e=gs.utf8(e):e=gs.utf16(e)),this.matchMachineInput(e,t,n,r,i)}matchMachineInput(e,t,n,r,i){if(t>n)return[!1,null];const o=e.isUTF16Encoding()?Ae.fromUTF16(e.asCharSequence(),0,n):Ae.fromUTF8(e.asBytes(),0,n),a=this.executeEngine(o,t,r,2*i);return a===null?[!1,null]:[!0,a]}matchUTF8(e){return this.executeEngine(Ae.fromUTF8(e),0,M.UNANCHORED,0)!==null}replaceAll(e,t){return this.replaceAllFunc(e,()=>t,2*e.length+1)}replaceFirst(e,t){return this.replaceAllFunc(e,()=>t,1)}replaceAllFunc(e,t,n){let r=0,i=0,o="";const a=Ae.fromUTF16(e);let l=0;for(;i<=e.length;){const c=this.executeEngine(a,i,M.UNANCHORED,2);if(c===null||c.length===0)break;o+=e.substring(r,c[0]),(c[1]>r||c[0]===0)&&(o+=t(e.substring(c[0],c[1])),l++),r=c[1];const h=a.step(i)&7;if(i+h>c[1]?i+=h:i+1>c[1]?i++:i=c[1],l>=n)break}return o+=e.substring(r),o}pad(e){if(e===null)return null;let t=(1+this.numSubexp)*2;if(e.length<t){let n=new Array(t).fill(-1);for(let r=0;r<e.length;r++)n[r]=e[r];e=n}return e}allMatches(e,t,n=r=>r){let r=[];const i=e.endPos();t<0&&(t=i+1);let o=0,a=0,l=-1;for(;a<t&&o<=i;){const c=this.executeEngine(e,o,M.UNANCHORED,this.prog.numCap);if(c===null||c.length===0)break;let h=!0;if(c[1]===o){c[0]===l&&(h=!1);const f=e.step(o);f<0?o=i+1:o+=f&7}else o=c[1];l=c[1],h&&(r.push(n(this.pad(c))),a++)}return r}findUTF8(e){const t=this.executeEngine(Ae.fromUTF8(e),0,M.UNANCHORED,2);return t===null?null:e.slice(t[0],t[1])}findUTF8Index(e){const t=this.executeEngine(Ae.fromUTF8(e),0,M.UNANCHORED,2);return t===null?null:t.slice(0,2)}find(e){const t=this.executeEngine(Ae.fromUTF16(e),0,M.UNANCHORED,2);return t===null?"":e.substring(t[0],t[1])}findIndex(e){return this.executeEngine(Ae.fromUTF16(e),0,M.UNANCHORED,2)}findUTF8Submatch(e){const t=this.executeEngine(Ae.fromUTF8(e),0,M.UNANCHORED,this.prog.numCap);if(t===null)return null;const n=new Array(1+this.numSubexp).fill(null);for(let r=0;r<n.length;r++)2*r<t.length&&t[2*r]>=0&&(n[r]=e.slice(t[2*r],t[2*r+1]));return n}findUTF8SubmatchIndex(e){return this.pad(this.executeEngine(Ae.fromUTF8(e),0,M.UNANCHORED,this.prog.numCap))}findSubmatch(e){const t=this.executeEngine(Ae.fromUTF16(e),0,M.UNANCHORED,this.prog.numCap);if(t===null)return null;const n=new Array(1+this.numSubexp).fill(null);for(let r=0;r<n.length;r++)2*r<t.length&&t[2*r]>=0&&(n[r]=e.substring(t[2*r],t[2*r+1]));return n}findSubmatchIndex(e){return this.pad(this.executeEngine(Ae.fromUTF16(e),0,M.UNANCHORED,this.prog.numCap))}findAllUTF8(e,t){const n=this.allMatches(Ae.fromUTF8(e),t,r=>e.slice(r[0],r[1]));return n.length===0?null:n}findAllUTF8Index(e,t){const n=this.allMatches(Ae.fromUTF8(e),t,r=>r.slice(0,2));return n.length===0?null:n}findAll(e,t){const n=this.allMatches(Ae.fromUTF16(e),t,r=>e.substring(r[0],r[1]));return n.length===0?null:n}findAllIndex(e,t){const n=this.allMatches(Ae.fromUTF16(e),t,r=>r.slice(0,2));return n.length===0?null:n}findAllUTF8Submatch(e,t){const n=this.allMatches(Ae.fromUTF8(e),t,r=>{let i=new Array(r.length/2|0).fill(null);for(let o=0;o<i.length;o++)r[2*o]>=0&&(i[o]=e.slice(r[2*o],r[2*o+1]));return i});return n.length===0?null:n}findAllUTF8SubmatchIndex(e,t){const n=this.allMatches(Ae.fromUTF8(e),t);return n.length===0?null:n}findAllSubmatch(e,t){const n=this.allMatches(Ae.fromUTF16(e),t,r=>{let i=new Array(r.length/2|0).fill(null);for(let o=0;o<i.length;o++)r[2*o]>=0&&(i[o]=e.substring(r[2*o],r[2*o+1]));return i});return n.length===0?null:n}findAllSubmatchIndex(e,t){const n=this.allMatches(Ae.fromUTF16(e),t);return n.length===0?null:n}},zy=class Js{static isHexadecimal(e){return"0"<=e&&e<="9"||"A"<=e&&e<="F"||"a"<=e&&e<="f"}static translate(e){let t="";if(e instanceof RegExp&&(e.ignoreCase&&(t+="i"),e.multiline&&(t+="m"),e.dotAll&&(t+="s"),e=e.source),typeof e!="string")return e;let n="",r=!1,i=e.length;i===0&&(n="(?:)",r=!0);let o=!1,a=0;for(;a<i;){let c=e[a];if(c==="\\"){if(a+1<i)switch(c=e[a+1],c){case"\\":n+="\\\\",a+=2;continue;case"c":if(a+2<i){let d=e[a+2].charCodeAt(0);if(d>=65&&d<=90||d>=97&&d<=122){let _=d%32;n+="\\x",n+=(_>>4).toString(16).toUpperCase(),n+=(_&15).toString(16).toUpperCase(),a+=3,r=!0;continue}}n+="c",a+=2,r=!0;continue;case"u":if(a+2<i){if(e[a+2]==="{"){let d=a+3,_=!1,y=!1;for(;d<i;){const N=e[d];if(N==="}"){y=!0;break}if(!Js.isHexadecimal(N))break;_=!0,d++}if(y&&_){n+="\\x",a+=2,r=!0;continue}}else if(a+5<i){let d=!0;for(let _=0;_<4;_++)if(!Js.isHexadecimal(e[a+2+_])){d=!1;break}if(d){n+="\\x{"+e.substring(a+2,a+6)+"}",a+=6,r=!0;continue}}}n+="u",a+=2,r=!0;continue;case"x":{let d=!1;if(a+2<i&&e[a+2]==="{"){let _=a+3,y=!1,N=!1;for(;_<i;){const F=e[_];if(F==="}"){N=!0;break}if(!Js.isHexadecimal(F))break;y=!0,_++}N&&y&&(d=!0)}else a+3<i&&Js.isHexadecimal(e[a+2])&&Js.isHexadecimal(e[a+3])&&(d=!0);d?(n+="\\x",a+=2):(n+="x",a+=2,r=!0);continue}case"n":case"r":case"t":case"a":case"f":case"v":case"d":case"D":case"s":case"S":case"w":case"W":case"b":case"B":case"p":case"P":case"A":case"z":case"Q":case"E":case"0":case"1":case"2":case"3":case"4":case"5":case"6":case"7":n+="\\"+c,a+=2;continue;default:{let d=e.codePointAt(a+1);if(d>=48&&d<=57||d>=65&&d<=90||d>=97&&d<=122){let _=$.charCount(d);n+=e.substring(a+1,a+1+_),a+=_+1,r=!0}else{n+="\\";let _=$.charCount(d);n+=e.substring(a+1,a+1+_),a+=_+1}continue}}}else if(c==="/"){n+="\\/",a+=1,r=!0;continue}else if(c==="[")o=!0;else if(c==="]")o=!1;else if(!o&&c==="("&&a+2<i&&e[a+1]==="?"&&e[a+2]==="<"&&a+3<i&&!"=!>)".includes(e[a+3])){n+="(?P<",a+=3,r=!0;continue}let h=e.codePointAt(a),f=$.charCount(h);n+=e.substring(a,a+f),a+=f}const l=r?n:e;return t.length>0?`(?${t})${l}`:l}},Me,Gl=(Me=class{static quote(e){return $.quoteMeta(e)}static quoteReplacement(e,t=!1){return Nh.quoteReplacement(e,t)}static translateRegExp(e){return zy.translate(e)}static compile(e,t=0){let n=e;if(t&Me.CASE_INSENSITIVE&&(n=`(?i)${n}`),t&Me.DOTALL&&(n=`(?s)${n}`),t&Me.MULTILINE&&(n=`(?m)${n}`),t&-544)throw new Ay("Flags should only be a combination of MULTILINE, DOTALL, CASE_INSENSITIVE, DISABLE_UNICODE_GROUPS, LONGEST_MATCH, LOOKBEHINDS");let r=M.PERL;t&Me.DISABLE_UNICODE_GROUPS&&(r&=-129),t&Me.LOOKBEHINDS&&(r|=M.LOOKBEHIND);const i=new Me(e,t);return i.re2Input=Ky.compileImpl(n,r,(t&Me.LONGEST_MATCH)!==0),i}static matches(e,t){return Me.compile(e).testExact(t)}static initTest(e,t,n){if(e==null)throw new Error("pattern is null");if(n==null)throw new Error("re2 is null");const r=new Me(e,t);return r.re2Input=n,r}constructor(e,t){this.patternInput=e,this.flagsInput=t,this.re2Input=null}reset(){this.re2Input.reset()}flags(){return this.flagsInput}pattern(){return this.patternInput}re2(){return this.re2Input}matches(e){return this.testExact(e)}matcher(e){return $.isByteArray(e)&&(e=gs.utf8(e)),new Nh(this,e)}test(e){return $.isByteArray(e)?this.re2Input.matchUTF8(e):this.re2Input.match(e)}testExact(e){const t=$.isByteArray(e)?Ae.fromUTF8(e):Ae.fromUTF16(e);return this.re2Input.executeEngine(t,0,M.ANCHOR_BOTH,0)!==null}exec(e){const t=this.matcher(e);if(!t.find())return null;const n=[t.group(0)];for(let i=1;i<=t.groupCount();i++){const o=t.group(i);n.push(o===null?void 0:o)}n.index=t.start(0),n.input=e;const r=this.namedGroups();if(Object.keys(r).length>0){const i=t.getNamedGroups();for(const o in i)i[o]===null&&(i[o]=void 0);n.groups=i}else n.groups=void 0;return n}split(e,t=0){const n=this.matcher(e),r=[];let i=0,o=0;for(;n.find();){if(o===0&&n.end()===0){o=n.end();continue}if(t>0&&r.length===t-1)break;if(o===n.start()){if(t===0){i+=1,o=n.end();continue}}else for(;i>0;)r.push(""),i-=1;r.push(n.substring(o,n.start())),o=n.end()}if(t===0&&o!==n.inputLength()){for(;i>0;)r.push(""),i-=1;r.push(n.substring(o,n.inputLength()))}return(t!==0||r.length===0&&!(o===n.inputLength()&&o>0))&&r.push(n.substring(o,n.inputLength())),r}*matchAll(e){const t=this.matcher(e);for(;t.find();){const n=[t.group(0)];for(let i=1;i<=t.groupCount();i++){const o=t.group(i);n.push(o===null?void 0:o)}n.index=t.start(0),n.input=e;const r=this.namedGroups();if(Object.keys(r).length>0){const i=t.getNamedGroups();for(const o in i)i[o]===null&&(i[o]=void 0);n.groups=i}else n.groups=void 0;yield n}}toString(){return this.patternInput}programSize(){return this.re2Input.numberOfInstructions()}groupCount(){return this.re2Input.numberOfCapturingGroups()}namedGroups(){return this.re2Input.namedGroups}equals(e){return this===e?!0:e===null||this.constructor!==e.constructor?!1:this.flagsInput===e.flagsInput&&this.patternInput===e.patternInput}},H(Me,"CASE_INSENSITIVE",Hs.CASE_INSENSITIVE),H(Me,"DOTALL",Hs.DOTALL),H(Me,"MULTILINE",Hs.MULTILINE),H(Me,"DISABLE_UNICODE_GROUPS",Hs.DISABLE_UNICODE_GROUPS),H(Me,"LONGEST_MATCH",Hs.LONGEST_MATCH),H(Me,"LOOKBEHINDS",Hs.LOOKBEHINDS),Me);/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qy{constructor(e,t,n){this.alias=e,this.aggregateType=t,this.fieldPath=n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let pr="12.19.0";function Wy(s){pr=s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vs=new da("@firebase/firestore");function js(){return vs.logLevel}function z(s,...e){if(vs.logLevel<=Be.DEBUG){const t=e.map(Hl);vs.debug(`Firestore (${pr}): ${s}`,...t)}}function _n(s,...e){if(vs.logLevel<=Be.ERROR){const t=e.map(Hl);vs.error(`Firestore (${pr}): ${s}`,...t)}}function Kt(s,...e){if(vs.logLevel<=Be.WARN){const t=e.map(Hl);vs.warn(`Firestore (${pr}): ${s}`,...t)}}function Hl(s){if(typeof s=="string")return s;try{return function(t){return JSON.stringify(t)}(s)}catch{return s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function X(s,e,t){let n="Unexpected state";typeof e=="string"?n=e:t=e,Pd(s,n,t)}function Pd(s,e,t){let n=`FIRESTORE (${pr}) INTERNAL ASSERTION FAILED: ${e} (ID: ${s.toString(16)})`;if(t!==void 0)try{n+=" CONTEXT: "+JSON.stringify(t)}catch{n+=" CONTEXT: "+t}throw _n(n),new Error(n)}function W(s,e,t,n){let r="Unexpected state";typeof t=="string"?r=t:n=t,s||Pd(e,r,n)}function se(s,e){return s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yy(s){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(s);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let n=0;n<s;n++)t[n]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ul{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let n="";for(;n.length<20;){const r=Yy(40);for(let i=0;i<r.length;++i)n.length<20&&r[i]<t&&(n+=e.charAt(r[i]%62))}return n}}function ae(s,e){return s<e?-1:s>e?1:0}function nl(s,e){const t=Math.min(s.length,e.length);for(let n=0;n<t;n++){const r=s.charAt(n),i=e.charAt(n);if(r!==i)return NB(r)===NB(i)?ae(r,i):NB(r)?1:-1}return ae(s.length,e.length)}const $y=55296,Xy=57343;function NB(s){const e=s.charCodeAt(0);return e>=$y&&e<=Xy}function rr(s,e,t){return s.length===e.length&&s.every((n,r)=>t(n,e[r]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ke=class sl{constructor(e,t){this.comparator=e,this.root=t||Mn.EMPTY}insert(e,t){return new sl(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,Mn.BLACK,null,null))}remove(e){return new sl(this.comparator,this.root.remove(e,this.comparator).copy(null,null,Mn.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const n=this.comparator(e,t.key);if(n===0)return t.value;n<0?t=t.left:n>0&&(t=t.right)}return null}indexOf(e){let t=0,n=this.root;for(;!n.isEmpty();){const r=this.comparator(e,n.key);if(r===0)return t+n.left.size;r<0?n=n.left:(t+=n.left.size+1,n=n.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,n)=>(e(t,n),!1))}toString(){const e=[];return this.inorderTraversal((t,n)=>(e.push(`${t}:${n}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Ao(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Ao(this.root,e,this.comparator,!1)}getReverseIterator(){return new Ao(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Ao(this.root,e,this.comparator,!0)}},Ao=class{constructor(e,t,n,r){this.isReverse=r,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?n(e.key,t):1,t&&r&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}},Mn=class ln{constructor(e,t,n,r,i){this.key=e,this.value=t,this.color=n??ln.RED,this.left=r??ln.EMPTY,this.right=i??ln.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,n,r,i){return new ln(e??this.key,t??this.value,n??this.color,r??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,n){let r=this;const i=n(e,r.key);return r=i<0?r.copy(null,null,null,r.left.insert(e,t,n),null):i===0?r.copy(null,t,null,null,null):r.copy(null,null,null,null,r.right.insert(e,t,n)),r.fixUp()}removeMin(){if(this.left.isEmpty())return ln.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let n,r=this;if(t(e,r.key)<0)r.left.isEmpty()||r.left.isRed()||r.left.left.isRed()||(r=r.moveRedLeft()),r=r.copy(null,null,null,r.left.remove(e,t),null);else{if(r.left.isRed()&&(r=r.rotateRight()),r.right.isEmpty()||r.right.isRed()||r.right.left.isRed()||(r=r.moveRedRight()),t(e,r.key)===0){if(r.right.isEmpty())return ln.EMPTY;n=r.right.min(),r=r.copy(n.key,n.value,null,null,r.right.removeMin())}r=r.copy(null,null,null,null,r.right.remove(e,t))}return r.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,ln.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,ln.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw X(43730,{key:this.key,value:this.value});if(this.right.isRed())throw X(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw X(27949);return e+(this.isRed()?0:1)}};Mn.EMPTY=null,Mn.RED=!0,Mn.BLACK=!1;Mn.EMPTY=new class{constructor(){this.size=0}get key(){throw X(57766)}get value(){throw X(16141)}get color(){throw X(16727)}get left(){throw X(29726)}get right(){throw X(36894)}copy(e,t,n,r,i){return this}insert(e,t,n){return new Mn(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ue{constructor(e){this.comparator=e,this.data=new ke(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,n)=>(e(t),!1))}forEachInRange(e,t){const n=this.data.getIteratorFrom(e[0]);for(;n.hasNext();){const r=n.getNext();if(this.comparator(r.key,e[1])>=0)return;t(r.key)}}forEachWhile(e,t){let n;for(n=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();n.hasNext();)if(!e(n.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new nf(this.data.getIterator())}getIteratorFrom(e){return new nf(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(n=>{t=t.add(n)}),t}isEqual(e){if(!(e instanceof Ue)||this.size!==e.size)return!1;const t=this.data.getIterator(),n=e.data.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=n.getNext().key;if(this.comparator(r,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new Ue(this.comparator);return t.data=e,t}}class nf{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const O={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class G extends yn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zt="__name__";class Xt{constructor(e,t,n){t===void 0?t=0:t>e.length&&X(637,{offset:t,range:e.length}),n===void 0?n=e.length-t:n>e.length-t&&X(1746,{length:n,range:e.length-t}),this.segments=e,this.offset=t,this.len=n}get length(){return this.len}isEqual(e){return Xt.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Xt?e.forEach(n=>{t.push(n)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,n=this.limit();t<n;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const n=Math.min(e.length,t.length);for(let r=0;r<n;r++){const i=Xt.compareSegments(e.get(r),t.get(r));if(i!==0)return i}return ae(e.length,t.length)}static compareSegments(e,t){const n=Xt.isNumericId(e),r=Xt.isNumericId(t);return n&&!r?-1:!n&&r?1:n&&r?Xt.extractNumericId(e).compare(Xt.extractNumericId(t)):nl(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return Vn.fromString(e.substring(4,e.length-2))}}class Ce extends Xt{construct(e,t,n){return new Ce(e,t,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toStringWithLeadingSlash(){return`/${this.canonicalString()}`}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const n of e){if(n.indexOf("//")>=0)throw new G(O.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);t.push(...n.split("/").filter(r=>r.length>0))}return new Ce(t)}static emptyPath(){return new Ce([])}}const Zy=/^[_a-zA-Z][_a-zA-Z0-9]*$/;let Ft=class Ks extends Xt{construct(e,t,n){return new Ks(e,t,n)}static isValidIdentifier(e){return Zy.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Ks.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Zt}static keyField(){return new Ks([Zt])}static fromServerFormat(e){const t=[];let n="",r=0;const i=()=>{if(n.length===0)throw new G(O.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(n),n=""};let o=!1;for(;r<e.length;){const a=e[r];if(a==="\\"){if(r+1===e.length)throw new G(O.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const l=e[r+1];if(l!=="\\"&&l!=="."&&l!=="`")throw new G(O.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);n+=l,r+=2}else a==="`"?(o=!o,r++):a!=="."||o?(n+=a,r++):(i(),r++)}if(i(),o)throw new G(O.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Ks(t)}static emptyPath(){return new Ks([])}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nt{constructor(e){this.fields=e,e.sort(Ft.comparator)}static empty(){return new Nt([])}unionWith(e){let t=new Ue(Ft.comparator);for(const n of this.fields)t=t.add(n);for(const n of e)t=t.add(n);return new Nt(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return rr(this.fields,e.fields,(t,n)=>t.isEqual(n))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jo(s){let e=0;for(const t in s)Object.prototype.hasOwnProperty.call(s,t)&&e++;return e}function ss(s,e){for(const t in s)Object.prototype.hasOwnProperty.call(s,t)&&e(t,s[t])}function Fd(s,e){const t=[];for(const n in s)Object.prototype.hasOwnProperty.call(s,n)&&t.push(e(s[n],n,s));return t}function Od(s){for(const e in s)if(Object.prototype.hasOwnProperty.call(s,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Y{constructor(e){this.path=e}static fromPath(e){return new Y(Ce.fromString(e))}static fromName(e){return new Y(Ce.fromString(e).popFirst(5))}static empty(){return new Y(Ce.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&Ce.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return Ce.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new Y(new Ce(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ld(s,e,t){if(!t)throw new G(O.INVALID_ARGUMENT,`Function ${s}() cannot be called with an empty ${e}.`)}function ew(s,e,t,n){if(e===!0&&n===!0)throw new G(O.INVALID_ARGUMENT,`${s} and ${t} cannot be used together.`)}function sf(s){if(!Y.isDocumentKey(s))throw new G(O.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${s} has ${s.length}.`)}function rf(s){if(Y.isDocumentKey(s))throw new G(O.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${s} has ${s.length}.`)}function Vi(s){return typeof s=="object"&&s!==null&&(Object.getPrototypeOf(s)===Object.prototype||Object.getPrototypeOf(s)===null)}function _a(s){if(s===void 0)return"undefined";if(s===null)return"null";if(typeof s=="string")return s.length>20&&(s=`${s.substring(0,20)}...`),JSON.stringify(s);if(typeof s=="number"||typeof s=="boolean")return""+s;if(typeof s=="object"){if(s instanceof Array)return"an array";{const e=function(n){return n.constructor?n.constructor.name:null}(s);return e?`a custom ${e} object`:"an object"}}return typeof s=="function"?"a function":X(12329,{type:typeof s})}function ut(s,e){if("_delegate"in s&&(s=s._delegate),!(s instanceof e)){if(e.name===s.constructor.name)throw new G(O.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=_a(s);throw new G(O.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return s}function tw(s,e){if(e<=0)throw new G(O.INVALID_ARGUMENT,`Function ${s}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function He(s,e){const t={typeString:s};return e&&(t.value=e),t}function Mi(s,e){if(!Vi(s))throw new G(O.INVALID_ARGUMENT,"JSON must be an object");let t;for(const n in e)if(e[n]){const r=e[n].typeString,i="value"in e[n]?{value:e[n].value}:void 0;if(!(n in s)){t=`JSON missing required field: '${n}'`;break}const o=s[n];if(r&&typeof o!==r){t=`JSON field '${n}' must be a ${r}.`;break}if(i!==void 0&&o!==i.value){t=`Expected '${n}' field to equal '${i.value}'`;break}}if(t)throw new G(O.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const of=-62135596800,af=1e6;class _e{static now(){return _e.fromMillis(Date.now())}static fromDate(e){return _e.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),n=Math.floor((e-1e3*t)*af);return new _e(t,n)}static fromInstant(e){if(!e||typeof e.t!="bigint")throw new G(O.INVALID_ARGUMENT,"Invalid Temporal.Instant object provided.");return _e._fromEpochNanoseconds(e.t)}static _fromEpochNanoseconds(e){let t,n;if(e>=0n)t=Number(e/1000000000n),n=Number(e%1000000000n);else{const r=e%1000000000n;r===0n?(t=Number(e/1000000000n),n=0):(t=Number(e/1000000000n-1n),n=Number(r+1000000000n))}return new _e(t,n)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new G(O.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new G(O.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<of)throw new G(O.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new G(O.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/af}toInstant(){if(typeof Temporal>"u"||!Temporal.Instant)throw new G(O.FAILED_PRECONDITION,"The Temporal object is not available in the current environment.");const e=1000000000n*BigInt(this.seconds)+BigInt(this.nanoseconds);return Temporal.Instant.__PRIVATE_fromEpochNanoseconds(e)}_compareTo(e){return this.seconds===e.seconds?ae(this.nanoseconds,e.nanoseconds):ae(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:_e._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(Mi(e,_e._jsonSchema))return new _e(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-of;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}_e._jsonSchemaVersion="firestore/timestamp/1.0",_e._jsonSchema={type:He("string",_e._jsonSchemaVersion),seconds:He("number"),nanoseconds:He("number")};/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xd extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Je{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(r){try{return atob(r)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new xd("Invalid base64 string: "+i):i}}(e);return new Je(t)}static fromUint8Array(e){const t=function(r){let i="";for(let o=0;o<r.length;++o)i+=String.fromCharCode(r[o]);return i}(e);return new Je(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const n=new Uint8Array(t.length);for(let r=0;r<t.length;r++)n[r]=t.charCodeAt(r);return n}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return ae(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}Je.EMPTY_BYTE_STRING=new Je("");const nw=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Kn(s){if(W(!!s,39018),typeof s=="string"){let e=0;const t=nw.exec(s);if(W(!!t,46558,{timestamp:s}),t[1]){let r=t[1];r=(r+"000000000").substr(0,9),e=Number(r)}const n=new Date(s);return{seconds:Math.floor(n.getTime()/1e3),nanos:e}}return{seconds:Pe(s.seconds),nanos:Pe(s.nanos)}}function Pe(s){return typeof s=="number"?s:typeof s=="string"?Number(s):0}function zn(s){return typeof s=="string"?Je.fromBase64String(s):Je.fromUint8Array(s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kd="server_timestamp",Vd="__type__",Md="__previous_value__",Gd="__local_write_time__";function Gi(s){var t,n;return((n=(((t=s==null?void 0:s.mapValue)==null?void 0:t.fields)||{})[Vd])==null?void 0:n.stringValue)===kd}function Hi(s){const e=s.mapValue.fields[Md];return Gi(e)?Hi(e):e}function ir(s){const e=Kn(s.mapValue.fields[Gd].timestampValue);return new _e(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sw{constructor(e,t,n,r,i,o,a,l,c,h,f,d,_){this.databaseId=e,this.appId=t,this.persistenceKey=n,this.host=r,this.ssl=i,this.forceLongPolling=o,this.autoDetectLongPolling=a,this.longPollingOptions=l,this.useFetchStreams=c,this.isUsingEmulator=h,this.apiKey=f,this._customHeaders=d,this.grpcFlowControlWindow=_}}const Ko="(default)";class _i{constructor(e,t){this.projectId=e,this.database=t||Ko}static empty(){return new _i("","")}get isDefaultDatabase(){return this.database===Ko}isEqual(e){return e instanceof _i&&e.projectId===this.projectId&&e.database===this.database}}function rw(s,e){if(!Object.prototype.hasOwnProperty.apply(s.options,["projectId"]))throw new G(O.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new _i(s.options.projectId,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ql=-1;function Ui(s){return s==null}function Ei(s){return s===0&&1/s==-1/0}function iw(s){return typeof s=="number"&&Number.isInteger(s)&&!Ei(s)&&s<=Number.MAX_SAFE_INTEGER&&s>=Number.MIN_SAFE_INTEGER}function ow(s){return typeof s=="string"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hd="__type__",aw="__max__",vo={mapValue:{}},Ud="__vector__",Di="value",or={nullValue:"NULL_VALUE"},Tt={booleanValue:!0},et={booleanValue:!1};function je(s){return"nullValue"in s?0:"booleanValue"in s?1:"integerValue"in s||"doubleValue"in s?2:"timestampValue"in s?3:"stringValue"in s?5:"bytesValue"in s?6:"referenceValue"in s?7:"geoPointValue"in s?8:"arrayValue"in s?9:"mapValue"in s?Gi(s)?4:Bw(s)?9007199254740991:Qo(s)?10:11:X(28295,{value:s})}function Gt(s,e,t){if(s===e)return!0;const n=je(s);if(n!==je(e))return!1;switch(n){case 0:case 9007199254740991:return!0;case 1:return s.booleanValue===e.booleanValue;case 4:return ir(s).isEqual(ir(e));case 3:return function(i,o){if(typeof i.timestampValue=="string"&&typeof o.timestampValue=="string"&&i.timestampValue.length===o.timestampValue.length)return i.timestampValue===o.timestampValue;const a=Kn(i.timestampValue),l=Kn(o.timestampValue);return a.seconds===l.seconds&&a.nanos===l.nanos}(s,e);case 5:return s.stringValue===e.stringValue;case 6:return function(i,o){return zn(i.bytesValue).isEqual(zn(o.bytesValue))}(s,e);case 7:return s.referenceValue===e.referenceValue;case 8:return function(i,o){return Pe(i.geoPointValue.latitude)===Pe(o.geoPointValue.latitude)&&Pe(i.geoPointValue.longitude)===Pe(o.geoPointValue.longitude)}(s,e);case 2:return function(i,o,a){if("integerValue"in i&&"integerValue"in o)return Pe(i.integerValue)===Pe(o.integerValue);let l,c;if("doubleValue"in i&&"doubleValue"in o)l=Pe(i.doubleValue),c=Pe(o.doubleValue);else{if(!(a!=null&&a.i))return!1;l=Pe(i.integerValue??i.doubleValue),c=Pe(o.integerValue??o.doubleValue)}return l===c?!!(a!=null&&a.o)||Ei(l)===Ei(c):!!(a===void 0||a.u)&&isNaN(l)&&isNaN(c)}(s,e,t);case 9:return rr(s.arrayValue.values||[],e.arrayValue.values||[],(r,i)=>Gt(r,i,t));case 10:case 11:return function(i,o,a){const l=i.mapValue.fields||{},c=o.mapValue.fields||{};if(jo(l)!==jo(c))return!1;for(const h in l)if(l.hasOwnProperty(h)&&(c[h]===void 0||!Gt(l[h],c[h],a)))return!1;return!0}(s,e,t);default:return X(52216,{left:s})}}function yi(s,e){return(s.values||[]).find(t=>Gt(t,e))!==void 0}function It(s,e){if(s===e)return 0;const t=je(s),n=je(e);if(t!==n)return ae(t,n);switch(t){case 0:case 9007199254740991:return 0;case 1:return ae(s.booleanValue,e.booleanValue);case 2:return function(i,o){const a=Pe(i.integerValue||i.doubleValue),l=Pe(o.integerValue||o.doubleValue);return a<l?-1:a>l?1:a===l?0:isNaN(a)?isNaN(l)?0:-1:1}(s,e);case 3:return Bf(s.timestampValue,e.timestampValue);case 4:return Bf(ir(s),ir(e));case 5:return nl(s.stringValue,e.stringValue);case 6:return function(i,o){const a=zn(i),l=zn(o);return a.compareTo(l)}(s.bytesValue,e.bytesValue);case 7:return function(i,o){const a=i.split("/"),l=o.split("/");for(let c=0;c<a.length&&c<l.length;c++){const h=ae(a[c],l[c]);if(h!==0)return h}return ae(a.length,l.length)}(s.referenceValue,e.referenceValue);case 8:return function(i,o){const a=ae(Pe(i.latitude),Pe(o.latitude));return a!==0?a:ae(Pe(i.longitude),Pe(o.longitude))}(s.geoPointValue,e.geoPointValue);case 9:return lf(s.arrayValue,e.arrayValue);case 10:return function(i,o){var d,_,y,N;const a=i.fields||{},l=o.fields||{},c=(d=a[Di])==null?void 0:d.arrayValue,h=(_=l[Di])==null?void 0:_.arrayValue,f=ae(((y=c==null?void 0:c.values)==null?void 0:y.length)||0,((N=h==null?void 0:h.values)==null?void 0:N.length)||0);return f!==0?f:lf(c,h)}(s.mapValue,e.mapValue);case 11:return function(i,o){if(i===vo.mapValue&&o===vo.mapValue)return 0;if(i===vo.mapValue)return 1;if(o===vo.mapValue)return-1;const a=i.fields||{},l=Object.keys(a),c=o.fields||{},h=Object.keys(c);l.sort(),h.sort();for(let f=0;f<l.length&&f<h.length;++f){const d=nl(l[f],h[f]);if(d!==0)return d;const _=It(a[l[f]],c[h[f]]);if(_!==0)return _}return ae(l.length,h.length)}(s.mapValue,e.mapValue);default:throw X(23264,{l:t})}}function Bf(s,e){if(typeof s=="string"&&typeof e=="string"&&s.length===e.length)return ae(s,e);const t=Kn(s),n=Kn(e),r=ae(t.seconds,n.seconds);return r!==0?r:ae(t.nanos,n.nanos)}function lf(s,e){const t=s.values||[],n=e.values||[];for(let r=0;r<t.length&&r<n.length;++r){const i=It(t[r],n[r]);if(i!==void 0&&i!==0)return i}return ae(t.length,n.length)}function ar(s){return rl(s)}function rl(s){return"nullValue"in s?"null":"booleanValue"in s?""+s.booleanValue:"integerValue"in s?""+s.integerValue:"doubleValue"in s?""+s.doubleValue:"timestampValue"in s?function(t){const n=Kn(t);return`time(${n.seconds},${n.nanos})`}(s.timestampValue):"stringValue"in s?s.stringValue:"bytesValue"in s?function(t){return zn(t).toBase64()}(s.bytesValue):"referenceValue"in s?function(t){return Y.fromName(t).toString()}(s.referenceValue):"geoPointValue"in s?function(t){return`geo(${t.latitude},${t.longitude})`}(s.geoPointValue):"arrayValue"in s?function(t){let n="[",r=!0;for(const i of t.values||[])r?r=!1:n+=",",n+=rl(i);return n+"]"}(s.arrayValue):"mapValue"in s?function(t){const n=Object.keys(t.fields||{}).sort();let r="{",i=!0;for(const o of n)i?i=!1:r+=",",r+=`${o}:${rl(t.fields[o])}`;return r+"}"}(s.mapValue):X(61005,{value:s})}function Lo(s){switch(je(s)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=Hi(s);return e?16+Lo(e):16;case 5:return 2*s.stringValue.length;case 6:return zn(s.bytesValue).approximateByteSize();case 7:return s.referenceValue.length;case 9:return function(n){return(n.values||[]).reduce((r,i)=>r+Lo(i),0)}(s.arrayValue);case 10:case 11:return function(n){let r=0;return ss(n.fields,(i,o)=>{r+=i.length+Lo(o)}),r}(s.mapValue);default:throw X(13486,{value:s})}}function zo(s,e){return{referenceValue:`projects/${s.projectId}/databases/${s.database}/documents/${e.path.canonicalString()}`}}function en(s){return!!s&&"integerValue"in s}function ms(s){return!!s&&"doubleValue"in s}function Qn(s){return en(s)||ms(s)}function Br(s){return!!s&&"arrayValue"in s}function Pt(s){return!!s&&"nullValue"in s}function At(s){return!!s&&"doubleValue"in s&&isNaN(Number(s.doubleValue))}function Ds(s){return!!s&&"mapValue"in s}function Qo(s){var t,n;return((n=(((t=s==null?void 0:s.mapValue)==null?void 0:t.fields)||{})[Hd])==null?void 0:n.stringValue)===Ud}function il(s){var e,t;return(t=(((e=s==null?void 0:s.mapValue)==null?void 0:e.fields)||{})[Di])==null?void 0:t.arrayValue}function si(s){if(s.geoPointValue)return{geoPointValue:{...s.geoPointValue}};if(s.timestampValue&&typeof s.timestampValue=="object")return{timestampValue:{...s.timestampValue}};if(s.mapValue){const e={mapValue:{fields:{}}};return ss(s.mapValue.fields,(t,n)=>e.mapValue.fields[t]=si(n)),e}if(s.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(s.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=si(s.arrayValue.values[t]);return e}return{...s}}function Bw(s){return(((s.mapValue||{}).fields||{}).__type__||{}).stringValue===aw}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nt{constructor(e){this.value=e}static empty(){return new nt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let n=0;n<e.length-1;++n)if(t=(t.mapValue.fields||{})[e.get(n)],!Ds(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=si(t)}setAll(e){let t=Ft.emptyPath(),n={},r=[];e.forEach((o,a)=>{if(!t.isImmediateParentOf(a)){const l=this.getFieldsMap(t);this.applyChanges(l,n,r),n={},r=[],t=a.popLast()}o?n[a.lastSegment()]=si(o):r.push(a.lastSegment())});const i=this.getFieldsMap(t);this.applyChanges(i,n,r)}delete(e){const t=this.field(e.popLast());Ds(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return Gt(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let n=0;n<e.length;++n){let r=t.mapValue.fields[e.get(n)];Ds(r)&&r.mapValue.fields||(r={mapValue:{fields:{}}},t.mapValue.fields[e.get(n)]=r),t=r}return t.mapValue.fields}applyChanges(e,t,n){ss(t,(r,i)=>e[r]=i);for(const r of n)delete e[r]}clone(){return new nt(si(this.value))}}function qd(s){const e=[];return ss(s.fields,(t,n)=>{const r=new Ft([t]);if(Ds(n)){const i=qd(n.mapValue).fields;if(i.length===0)e.push(r);else for(const o of i)e.push(r.child(o))}else e.push(r)}),new Nt(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ea(s,e){if(s.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Ei(e)?"-0":e}}function Jl(s){return{integerValue:""+s}}function Da(s,e,t){return iw(e)?Jl(e):Ea(s,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ya{constructor(){this._=void 0}}function lw(s,e,t){return s instanceof wi?function(r,i){const o={fields:{[Vd]:{stringValue:kd},[Gd]:{timestampValue:{seconds:r.seconds,nanos:r.nanoseconds}}}};return i&&Gi(i)&&(i=Hi(i)),i&&(o.fields[Md]=i),{mapValue:o}}(t,e):s instanceof lr?jd(s,e):s instanceof Ti?Kd(s,e):s instanceof cr?function(r,i){const o=Jd(r,i),a=$o(o)+$o(r.h);return en(o)&&en(r.h)?Jl(a):Ea(r.serializer,a)}(s,e):s instanceof Wo?function(r,i){return cf(r,i,Math.min)}(s,e):s instanceof Yo?function(r,i){return cf(r,i,Math.max)}(s,e):void 0}function cw(s,e,t){return s instanceof lr?jd(s,e):s instanceof Ti?Kd(s,e):t}function Jd(s,e){return s instanceof cr?Qn(e)?e:{integerValue:0}:null}class wi extends ya{}class lr extends ya{constructor(e){super(),this.elements=e}}function jd(s,e){const t=zd(e);for(const n of s.elements)t.some(r=>Gt(r,n))||t.push(n);return{arrayValue:{values:t}}}class Ti extends ya{constructor(e){super(),this.elements=e}}function Kd(s,e){let t=zd(e);for(const n of s.elements)t=t.filter(r=>!Gt(r,n));return{arrayValue:{values:t}}}class jl extends ya{constructor(e,t){super(),this.serializer=e,this.h=t}}class cr extends jl{}class Wo extends jl{}class Yo extends jl{}function cf(s,e,t){if(!Qn(e))return s.h;const n=t($o(e),$o(s.h));return en(e)&&en(s.h)?Jl(n):Ea(s.serializer,n)}function $o(s){return Pe(s.integerValue||s.doubleValue)}function zd(s){return Br(s)&&s.arrayValue.values?s.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kl{constructor(e,t){this.field=e,this.transform=t}}function uw(s,e){return s.field.isEqual(e.field)&&function(n,r){return n instanceof lr&&r instanceof lr||n instanceof Ti&&r instanceof Ti?rr(n.elements,r.elements,Gt):n instanceof cr&&r instanceof cr||n instanceof Wo&&r instanceof Wo||n instanceof Yo&&r instanceof Yo?Gt(n.h,r.h):n instanceof wi&&r instanceof wi}(s.transform,e.transform)}class hw{constructor(e,t){this.version=e,this.transformResults=t}}class st{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new st}static exists(e){return new st(void 0,e)}static updateTime(e){return new st(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function xo(s,e){return s.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(s.updateTime):s.exists===void 0||s.exists===e.isFoundDocument()}class wa{}function Qd(s,e){if(!s.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return s.isNoDocument()?new Ta(s.key,st.none()):new qi(s.key,s.data,st.none());{const t=s.data,n=nt.empty();let r=new Ue(Ft.comparator);for(let i of e.fields)if(!r.has(i)){let o=t.field(i);o===null&&i.length>1&&(i=i.popLast(),o=t.field(i)),o===null?n.delete(i):n.set(i,o),r=r.add(i)}return new rs(s.key,n,new Nt(r.toArray()),st.none())}}function fw(s,e,t){s instanceof qi?function(r,i,o){const a=r.value.clone(),l=hf(r.fieldTransforms,i,o.transformResults);a.setAll(l),i.convertToFoundDocument(o.version,a).setHasCommittedMutations()}(s,e,t):s instanceof rs?function(r,i,o){if(!xo(r.precondition,i))return void i.convertToUnknownDocument(o.version);const a=hf(r.fieldTransforms,i,o.transformResults),l=i.data;l.setAll(Wd(r)),l.setAll(a),i.convertToFoundDocument(o.version,l).setHasCommittedMutations()}(s,e,t):function(r,i,o){i.convertToNoDocument(o.version).setHasCommittedMutations()}(0,e,t)}function ri(s,e,t,n){return s instanceof qi?function(i,o,a,l){if(!xo(i.precondition,o))return a;const c=i.value.clone(),h=ff(i.fieldTransforms,l,o);return c.setAll(h),o.convertToFoundDocument(o.version,c).setHasLocalMutations(),null}(s,e,t,n):s instanceof rs?function(i,o,a,l){if(!xo(i.precondition,o))return a;const c=ff(i.fieldTransforms,l,o),h=o.data;return h.setAll(Wd(i)),h.setAll(c),o.convertToFoundDocument(o.version,h).setHasLocalMutations(),a===null?null:a.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(f=>f.field))}(s,e,t,n):function(i,o,a){return xo(i.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):a}(s,e,t)}function Cw(s,e){let t=null;for(const n of s.fieldTransforms){const r=e.data.field(n.field),i=Jd(n.transform,r||null);i!=null&&(t===null&&(t=nt.empty()),t.set(n.field,i))}return t||null}function uf(s,e){return s.type===e.type&&!!s.key.isEqual(e.key)&&!!s.precondition.isEqual(e.precondition)&&!!function(n,r){return n===void 0&&r===void 0||!(!n||!r)&&rr(n,r,(i,o)=>uw(i,o))}(s.fieldTransforms,e.fieldTransforms)&&(s.type===0?s.value.isEqual(e.value):s.type!==1||s.data.isEqual(e.data)&&s.fieldMask.isEqual(e.fieldMask))}class qi extends wa{constructor(e,t,n,r=[]){super(),this.key=e,this.value=t,this.precondition=n,this.fieldTransforms=r,this.type=0}getFieldMask(){return null}}class rs extends wa{constructor(e,t,n,r,i=[]){super(),this.key=e,this.data=t,this.fieldMask=n,this.precondition=r,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function Wd(s){const e=new Map;return s.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const n=s.data.field(t);e.set(t,n)}}),e}function hf(s,e,t){const n=new Map;W(s.length===t.length,32656,{T:t.length,P:s.length});for(let r=0;r<t.length;r++){const i=s[r],o=i.transform,a=e.data.field(i.field);n.set(i.field,cw(o,a,t[r]))}return n}function ff(s,e,t){const n=new Map;for(const r of s){const i=r.transform,o=t.data.field(r.field);n.set(r.field,lw(i,o,e))}return n}class Ta extends wa{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Yd extends wa{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ur{constructor(e,t){this.position=e,this.inclusive=t}}function Cf(s,e,t){let n=0;for(let r=0;r<s.position.length;r++){const i=e[r],o=s.position[r];if(i.field.isKeyField()?n=Y.comparator(Y.fromName(o.referenceValue),t.key):n=It(o,t.data.field(i.field)),i.dir==="desc"&&(n*=-1),n!==0)break}return n}function df(s,e){if(s===null)return e===null;if(e===null||s.inclusive!==e.inclusive||s.position.length!==e.position.length)return!1;for(let t=0;t<s.position.length;t++)if(!Gt(s.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $d{}class Ge extends $d{constructor(e,t,n){super(),this.field=e,this.op=t,this.value=n}static create(e,t,n){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,n):new pw(e,t,n):t==="array-contains"?new _w(e,n):t==="in"?new Ew(e,n):t==="not-in"?new Dw(e,n):t==="array-contains-any"?new yw(e,n):new Ge(e,t,n)}static createKeyFieldInFilter(e,t,n){return t==="in"?new gw(e,n):new mw(e,n)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(It(t,this.value)):t!==null&&je(this.value)===je(t)&&this.matchesComparison(It(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return X(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class zt extends $d{constructor(e,t){super(),this.filters=e,this.op=t,this.I=null}static create(e,t){return new zt(e,t)}matches(e){return Xd(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.I!==null||(this.I=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.I}getFilters(){return Object.assign([],this.filters)}}function Xd(s){return s.op==="and"}function Zd(s){return dw(s)&&Xd(s)}function dw(s){for(const e of s.filters)if(e instanceof zt)return!1;return!0}function ol(s){if(s instanceof Ge)return s.field.canonicalString()+s.op.toString()+ar(s.value);if(Zd(s))return s.filters.map(e=>ol(e)).join(",");{const e=s.filters.map(t=>ol(t)).join(",");return`${s.op}(${e})`}}function ep(s,e){return s instanceof Ge?function(n,r){return r instanceof Ge&&n.op===r.op&&n.field.isEqual(r.field)&&Gt(n.value,r.value)}(s,e):s instanceof zt?function(n,r){return r instanceof zt&&n.op===r.op&&n.filters.length===r.filters.length?n.filters.reduce((i,o,a)=>i&&ep(o,r.filters[a]),!0):!1}(s,e):void X(19439)}function tp(s){return s instanceof Ge?function(t){return`${t.field.canonicalString()} ${t.op} ${ar(t.value)}`}(s):s instanceof zt?function(t){return t.op.toString()+" {"+t.getFilters().map(tp).join(" ,")+"}"}(s):"Filter"}class pw extends Ge{constructor(e,t,n){super(e,t,n),this.key=Y.fromName(n.referenceValue)}matches(e){const t=Y.comparator(e.key,this.key);return this.matchesComparison(t)}}class gw extends Ge{constructor(e,t){super(e,"in",t),this.keys=np("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class mw extends Ge{constructor(e,t){super(e,"not-in",t),this.keys=np("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function np(s,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map(n=>Y.fromName(n.referenceValue))}class _w extends Ge{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return Br(t)&&yi(t.arrayValue,this.value)}}class Ew extends Ge{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&yi(this.value.arrayValue,t)}}class Dw extends Ge{constructor(e,t){super(e,"not-in",t)}matches(e){if(yi(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!yi(this.value.arrayValue,t)}}class yw extends Ge{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!Br(t)||!t.arrayValue.values)&&t.arrayValue.values.some(n=>yi(this.value.arrayValue,n))}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ii{constructor(e,t="asc"){this.field=e,this.dir=t}}function ww(s,e){return s.dir===e.dir&&s.field.isEqual(e.field)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ne{static fromTimestamp(e){return new ne(e)}static min(){return new ne(new _e(0,0))}static max(){return new ne(new _e(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xe{constructor(e,t,n,r,i,o,a){this.key=e,this.documentType=t,this.version=n,this.readTime=r,this.createTime=i,this.data=o,this.documentState=a}static newInvalidDocument(e){return new Xe(e,0,ne.min(),ne.min(),ne.min(),nt.empty(),0)}static newFoundDocument(e,t,n,r){return new Xe(e,1,t,ne.min(),n,r,0)}static newNoDocument(e,t){return new Xe(e,2,t,ne.min(),ne.min(),nt.empty(),0)}static newUnknownDocument(e,t){return new Xe(e,3,t,ne.min(),ne.min(),nt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(ne.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=nt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=nt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ne.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof Xe&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Xe(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ai=-1;function Tw(s,e){const t=s.toTimestamp().seconds,n=s.toTimestamp().nanoseconds+1,r=ne.fromTimestamp(n===1e9?new _e(t+1,0):new _e(t,n));return new Wn(r,Y.empty(),e)}function Iw(s){return new Wn(s.readTime,s.key,Ai)}class Wn{constructor(e,t,n){this.readTime=e,this.documentKey=t,this.largestBatchId=n}static min(){return new Wn(ne.min(),Y.empty(),Ai)}static max(){return new Wn(ne.max(),Y.empty(),Ai)}}function Aw(s,e){let t=s.readTime.compareTo(e.readTime);return t!==0?t:(t=Y.comparator(s.documentKey,e.documentKey),t!==0?t:ae(s.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vw{constructor(e,t=null,n=[],r=[],i=null,o=null,a=null){this.path=e,this.collectionGroup=t,this.orderBy=n,this.filters=r,this.limit=i,this.startAt=o,this.endAt=a,this.R=null}}function pf(s,e=null,t=[],n=[],r=null,i=null,o=null){return new vw(s,e,t,n,r,i,o)}function sp(s){const e=se(s);if(e.R===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(n=>ol(n)).join(","),t+="|ob:",t+=e.orderBy.map(n=>function(i){return i.field.canonicalString()+i.dir}(n)).join(","),Ui(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(n=>ar(n)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(n=>ar(n)).join(",")),e.R=t}return e.R}function rp(s,e){if(s.limit!==e.limit||s.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<s.orderBy.length;t++)if(!ww(s.orderBy[t],e.orderBy[t]))return!1;if(s.filters.length!==e.filters.length)return!1;for(let t=0;t<s.filters.length;t++)if(!ep(s.filters[t],e.filters[t]))return!1;return s.collectionGroup===e.collectionGroup&&!!s.path.isEqual(e.path)&&!!df(s.startAt,e.startAt)&&df(s.endAt,e.endAt)}function ds(s){return!!s.isCorePipeline}function ip(s){return!!s.path&&Y.isDocumentKey(s.path)&&s.collectionGroup===null&&s.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class is{constructor(e,t=null,n=[],r=[],i=null,o="F",a=null,l=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=n,this.filters=r,this.limit=i,this.limitType=o,this.startAt=a,this.endAt=l,this.A=null,this.V=null,this.m=null,this.startAt,this.endAt}}function Rw(s,e,t,n,r,i,o,a){return new is(s,e,t,n,r,i,o,a)}function Ia(s){return new is(s)}function gf(s){return s.filters.length===0&&s.limit===null&&s.startAt==null&&s.endAt==null&&(s.explicitOrderBy.length===0||s.explicitOrderBy.length===1&&s.explicitOrderBy[0].field.isKeyField())}function Sw(s){return Y.isDocumentKey(s.path)&&s.collectionGroup===null&&s.filters.length===0}function zl(s){return s.collectionGroup!==null}function Xs(s){const e=se(s);if(e.A===null){e.A=[];const t=new Set;for(const i of e.explicitOrderBy)e.A.push(i),t.add(i.field.canonicalString());const n=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(o){let a=new Ue(Ft.comparator);return o.filters.forEach(l=>{l.getFlattenedFilters().forEach(c=>{c.isInequality()&&(a=a.add(c.field))})}),a})(e).forEach(i=>{t.has(i.canonicalString())||i.isKeyField()||e.A.push(new Ii(i,n))}),t.has(Ft.keyField().canonicalString())||e.A.push(new Ii(Ft.keyField(),n))}return e.A}function sn(s){const e=se(s);return e.V||(e.V=op(e,Xs(s))),e.V}function bw(s){const e=se(s);return e.m||(e.m=op(e,s.explicitOrderBy)),e.m}function op(s,e){if(s.limitType==="F")return pf(s.path,s.collectionGroup,e,s.filters,s.limit,s.startAt,s.endAt);{e=e.map(r=>{const i=r.dir==="desc"?"asc":"desc";return new Ii(r.field,i)});const t=s.endAt?new ur(s.endAt.position,s.endAt.inclusive):null,n=s.startAt?new ur(s.startAt.position,s.startAt.inclusive):null;return pf(s.path,s.collectionGroup,e,s.filters,s.limit,t,n)}}function al(s,e){const t=s.filters.concat([e]);return new is(s.path,s.collectionGroup,s.explicitOrderBy.slice(),t,s.limit,s.limitType,s.startAt,s.endAt)}function Nw(s,e){const t=s.explicitOrderBy.concat([e]);return new is(s.path,s.collectionGroup,t,s.filters.slice(),s.limit,s.limitType,s.startAt,s.endAt)}function Xo(s,e,t){return new is(s.path,s.collectionGroup,s.explicitOrderBy.slice(),s.filters.slice(),e,t,s.startAt,s.endAt)}function Pw(s,e){return new is(s.path,s.collectionGroup,s.explicitOrderBy.slice(),s.filters.slice(),s.limit,s.limitType,e,s.endAt)}function Fw(s,e){return new is(s.path,s.collectionGroup,s.explicitOrderBy.slice(),s.filters.slice(),s.limit,s.limitType,s.startAt,e)}function Ow(s,e){return rp(sn(s),sn(e))&&s.limitType===e.limitType}function ii(s){return`Query(target=${function(t){let n=t.path.canonicalString();return t.collectionGroup!==null&&(n+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(n+=`, filters: [${t.filters.map(r=>tp(r)).join(", ")}]`),Ui(t.limit)||(n+=", limit: "+t.limit),t.orderBy.length>0&&(n+=`, orderBy: [${t.orderBy.map(r=>function(o){return`${o.field.canonicalString()} (${o.dir})`}(r)).join(", ")}]`),t.startAt&&(n+=", startAt: ",n+=t.startAt.inclusive?"b:":"a:",n+=t.startAt.position.map(r=>ar(r)).join(",")),t.endAt&&(n+=", endAt: ",n+=t.endAt.inclusive?"a:":"b:",n+=t.endAt.position.map(r=>ar(r)).join(",")),`Target(${n})`}(sn(s))}; limitType=${s.limitType})`}function Aa(s,e){return e.isFoundDocument()&&function(n,r){const i=r.key.path;return n.collectionGroup!==null?r.key.hasCollectionId(n.collectionGroup)&&n.path.isPrefixOf(i):Y.isDocumentKey(n.path)?n.path.isEqual(i):n.path.isImmediateParentOf(i)}(s,e)&&function(n,r){for(const i of Xs(n))if(!i.field.isKeyField()&&r.data.field(i.field)===null)return!1;return!0}(s,e)&&function(n,r){for(const i of n.filters)if(!i.matches(r))return!1;return!0}(s,e)&&function(n,r){return!(n.startAt&&!function(o,a,l){const c=Cf(o,a,l);return o.inclusive?c<=0:c<0}(n.startAt,Xs(n),r)||n.endAt&&!function(o,a,l){const c=Cf(o,a,l);return o.inclusive?c>=0:c>0}(n.endAt,Xs(n),r))}(s,e)}function Ql(s){return(e,t)=>{let n=!1;for(const r of Xs(s)){const i=Lw(r,e,t);if(i!==0)return i;n=n||r.field.isKeyField()}return 0}}function Lw(s,e,t){const n=s.field.isKeyField()?Y.comparator(e.key,t.key):function(i,o,a){const l=o.data.field(i),c=a.data.field(i);return l!==null&&c!==null?It(l,c):X(42886)}(s.field,e,t);switch(s.dir){case"asc":return n;case"desc":return-1*n;default:return X(19790,{direction:s.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xw{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Ve,ue;function ap(s){switch(s){case O.OK:return X(64938);case O.CANCELLED:case O.UNKNOWN:case O.DEADLINE_EXCEEDED:case O.RESOURCE_EXHAUSTED:case O.INTERNAL:case O.UNAVAILABLE:case O.UNAUTHENTICATED:return!1;case O.INVALID_ARGUMENT:case O.NOT_FOUND:case O.ALREADY_EXISTS:case O.PERMISSION_DENIED:case O.FAILED_PRECONDITION:case O.ABORTED:case O.OUT_OF_RANGE:case O.UNIMPLEMENTED:case O.DATA_LOSS:return!0;default:return X(15467,{code:s})}}function Bp(s){if(s===void 0)return _n("GRPC error has no .code"),O.UNKNOWN;switch(s){case Ve.OK:return O.OK;case Ve.CANCELLED:return O.CANCELLED;case Ve.UNKNOWN:return O.UNKNOWN;case Ve.DEADLINE_EXCEEDED:return O.DEADLINE_EXCEEDED;case Ve.RESOURCE_EXHAUSTED:return O.RESOURCE_EXHAUSTED;case Ve.INTERNAL:return O.INTERNAL;case Ve.UNAVAILABLE:return O.UNAVAILABLE;case Ve.UNAUTHENTICATED:return O.UNAUTHENTICATED;case Ve.INVALID_ARGUMENT:return O.INVALID_ARGUMENT;case Ve.NOT_FOUND:return O.NOT_FOUND;case Ve.ALREADY_EXISTS:return O.ALREADY_EXISTS;case Ve.PERMISSION_DENIED:return O.PERMISSION_DENIED;case Ve.FAILED_PRECONDITION:return O.FAILED_PRECONDITION;case Ve.ABORTED:return O.ABORTED;case Ve.OUT_OF_RANGE:return O.OUT_OF_RANGE;case Ve.UNIMPLEMENTED:return O.UNIMPLEMENTED;case Ve.DATA_LOSS:return O.DATA_LOSS;default:return X(39323,{code:s})}}(ue=Ve||(Ve={}))[ue.OK=0]="OK",ue[ue.CANCELLED=1]="CANCELLED",ue[ue.UNKNOWN=2]="UNKNOWN",ue[ue.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",ue[ue.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",ue[ue.NOT_FOUND=5]="NOT_FOUND",ue[ue.ALREADY_EXISTS=6]="ALREADY_EXISTS",ue[ue.PERMISSION_DENIED=7]="PERMISSION_DENIED",ue[ue.UNAUTHENTICATED=16]="UNAUTHENTICATED",ue[ue.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",ue[ue.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",ue[ue.ABORTED=10]="ABORTED",ue[ue.OUT_OF_RANGE=11]="OUT_OF_RANGE",ue[ue.UNIMPLEMENTED=12]="UNIMPLEMENTED",ue[ue.INTERNAL=13]="INTERNAL",ue[ue.UNAVAILABLE=14]="UNAVAILABLE",ue[ue.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fs{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),n=this.inner[t];if(n!==void 0){for(const[r,i]of n)if(this.equalsFn(r,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const n=this.mapKeyFn(e),r=this.inner[n];if(r===void 0)return this.inner[n]=[[e,t]],void this.innerSize++;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return void(r[i]=[e,t]);r.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),n=this.inner[t];if(n===void 0)return!1;for(let r=0;r<n.length;r++)if(this.equalsFn(n[r][0],e))return n.length===1?delete this.inner[t]:n.splice(r,1),this.innerSize--,!0;return!1}forEach(e){ss(this.inner,(t,n)=>{for(const[r,i]of n)e(r,i)})}isEmpty(){return Od(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kw=new ke(Y.comparator);function Dt(){return kw}const lp=new ke(Y.comparator);function zs(...s){let e=lp;for(const t of s)e=e.insert(t.key,t);return e}function cp(s){let e=lp;return s.forEach((t,n)=>e=e.insert(t,n.overlayedDocument)),e}function On(){return oi()}function up(){return oi()}function oi(){return new Fs(s=>s.toString(),(s,e)=>s.isEqual(e))}const Vw=new ke(Y.comparator),Mw=new Ue(Y.comparator);function oe(...s){let e=Mw;for(const t of s)e=e.add(t);return e}const Gw=new Ue(ae);function Hw(){return Gw}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Uw(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qw=new Vn([4294967295,4294967295],0);function mf(s){const e=Uw().encode(s),t=new Ed;return t.update(e),new Uint8Array(t.digest())}function _f(s){const e=new DataView(s.buffer),t=e.getUint32(0,!0),n=e.getUint32(4,!0),r=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new Vn([t,n],0),new Vn([r,i],0)]}class Wl{constructor(e,t,n){if(this.bitmap=e,this.padding=t,this.hashCount=n,t<0||t>=8)throw new Zr(`Invalid padding: ${t}`);if(n<0)throw new Zr(`Invalid hash count: ${n}`);if(e.length>0&&this.hashCount===0)throw new Zr(`Invalid hash count: ${n}`);if(e.length===0&&t!==0)throw new Zr(`Invalid padding when bitmap length is 0: ${t}`);this.p=8*e.length-t,this.S=Vn.fromNumber(this.p)}v(e,t,n){let r=e.add(t.multiply(Vn.fromNumber(n)));return r.compare(qw)===1&&(r=new Vn([r.getBits(0),r.getBits(1)],0)),r.modulo(this.S).toNumber()}D(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.p===0)return!1;const t=mf(e),[n,r]=_f(t);for(let i=0;i<this.hashCount;i++){const o=this.v(n,r,i);if(!this.D(o))return!1}return!0}static create(e,t,n){const r=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),o=new Wl(i,r,t);return n.forEach(a=>o.insert(a)),o}insert(e){if(this.p===0)return;const t=mf(e),[n,r]=_f(t);for(let i=0;i<this.hashCount;i++){const o=this.v(n,r,i);this.C(o)}}C(e){const t=Math.floor(e/8),n=e%8;this.bitmap[t]|=1<<n}}class Zr extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ji{constructor(e,t,n,r,i,o){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=n,this.documentUpdates=r,this.augmentedDocumentUpdates=i,this.resolvedLimboDocuments=o}static createSynthesizedRemoteEventForCurrentChange(e,t,n){const r=new Map;return r.set(e,ji.createSynthesizedTargetChangeForCurrentChange(e,t,n)),new Ji(ne.min(),r,new ke(ae),Dt(),Dt(),oe())}}class ji{constructor(e,t,n,r,i){this.resumeToken=e,this.current=t,this.addedDocuments=n,this.modifiedDocuments=r,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,n){return new ji(n,t,oe(),oe(),oe())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ko{constructor(e,t,n,r){this.F=e,this.removedTargetIds=t,this.key=n,this.O=r}}class hp{constructor(e,t){this.targetId=e,this.M=t}}class fp{constructor(e,t,n=Je.EMPTY_BYTE_STRING,r=null){this.state=e,this.targetIds=t,this.resumeToken=n,this.cause=r}}class Ef{constructor(e){this.targetId=e,this.N=0,this.L=Df(),this.B=Je.EMPTY_BYTE_STRING,this.U=!1,this.k=!0}get current(){return this.U}get resumeToken(){return this.B}get q(){return this.N!==0}get $(){return this.k}K(e){e.approximateByteSize()>0&&(this.k=!0,this.B=e)}W(){let e=oe(),t=oe(),n=oe();return this.L.forEach((r,i)=>{switch(i){case 0:e=e.add(r);break;case 2:t=t.add(r);break;case 1:n=n.add(r);break;default:X(38017,{changeType:i})}}),new ji(this.B,this.U,e,t,n)}G(){this.k=!1,this.L=Df()}j(e,t){this.k=!0,this.L=this.L.insert(e,t)}H(e){this.k=!0,this.L=this.L.remove(e)}J(){this.N+=1}Y(){this.N-=1,W(this.N>=0,3241,{N:this.N,targetId:this.targetId})}Z(){this.k=!0,this.U=!0}}const Kr="WatchChangeAggregator";class Jw{constructor(e){this.X=e,this.ee=new Map,this.te=Dt(),this.ne=Ro(),this.re=Dt(),this.ie=Ro(),this.se=new ke(ae)}_e(e){for(const t of e.F)e.O&&e.O.isFoundDocument()?this.oe(t,e.O):this.ae(t,e.key,e.O);for(const t of e.removedTargetIds)this.ae(t,e.key,e.O)}ue(e){this.forEachTarget(e,t=>{const n=this.ee.get(t);if(n)switch(e.state){case 0:this.ce(t)&&n.K(e.resumeToken);break;case 1:n.Y(),n.q||n.G(),n.K(e.resumeToken);break;case 2:n.Y(),n.q||this.removeTarget(t);break;case 3:this.ce(t)&&(n.Z(),n.K(e.resumeToken));break;case 4:this.ce(t)&&(this.le(t),n.K(e.resumeToken));break;default:X(56790,{state:e.state})}else z(Kr,`handleTargetChange received targetChange for untracked target ID (${t}) with state (${e.state})`)})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ee.forEach((n,r)=>{this.ce(r)&&t(r)})}Ee(e){var t;return ds(e)?e.getPipelineSourceType()==="documents"&&((t=e.getPipelineDocuments())==null?void 0:t.length)===1:ip(e)}he(e){const t=e.targetId,n=e.M.count,r=this.Te(t);if(r){const i=r.target;if(this.Ee(i))if(n===0){const o=new Y(ds(i)?Ce.fromString(i.getPipelineDocuments()[0]):i.path);this.ae(t,o,Xe.newNoDocument(o,ne.min()))}else W(n===1,20013,"Single document existence filter with count: "+n);else{const o=this.Pe(t);if(o!==n){const a=this.Ie(e),l=a?this.Re(a,e,o):1;if(l!==0){this.le(t);const c=l===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.se=this.se.insert(t,c)}}}}}Ie(e){const t=e.M.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:n="",padding:r=0},hashCount:i=0}=t;let o,a;try{o=zn(n).toUint8Array()}catch(l){if(l instanceof xd)return Kt("Decoding the base64 bloom filter in existence filter failed ("+l.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw l}try{a=new Wl(o,r,i)}catch(l){return Kt(l instanceof Zr?"BloomFilter error: ":"Applying bloom filter failed: ",l),null}return a.p===0?null:a}Re(e,t,n){return t.M.count===n-this.de(e,t.targetId)?0:2}de(e,t){const n=this.X.getRemoteKeysForTarget(t);let r=0;return n.forEach(i=>{const o=this.X.Ve(),a=`projects/${o.projectId}/databases/${o.database}/documents/${i.path.canonicalString()}`;e.mightContain(a)||(this.ae(t,i,null),r++)}),r}fe(e){const t=new Map;this.ee.forEach((i,o)=>{const a=this.Te(o);if(a){if(i.current&&this.Ee(a.target)){const l=ds(a.target)?Ce.fromString(a.target.getPipelineDocuments()[0]):a.target.path,c=new Y(l);this.me(c).has(o)||this.pe(o,c)||this.ae(o,c,Xe.newNoDocument(c,e))}i.$&&(t.set(o,i.W()),i.G())}});let n=oe();this.ie.forEach((i,o)=>{let a=!0;o.forEachWhile(l=>{const c=this.Te(l);return!c||c.purpose==="TargetPurposeLimboResolution"||(a=!1,!1)}),a&&(n=n.add(i))}),this.te.forEach((i,o)=>o.setReadTime(e)),this.re.forEach((i,o)=>o.setReadTime(e));const r=new Ji(e,t,this.se,this.te,this.re,n);return this.te=Dt(),this.ne=Ro(),this.re=Dt(),this.ie=Ro(),this.se=new ke(ae),r}oe(e,t){const n=this.ee.get(e);if(!n||!this.ce(e))return void z(Kr,`addDocumentToTarget received document for unknown inactive target (${e})`);const r=this.pe(e,t.key)?2:0;n.j(t.key,r),ds(this.Te(e).target)&&this.Te(e).target.getPipelineFlavor()!=="exact"?this.re=this.re.insert(t.key,t):this.te=this.te.insert(t.key,t),this.ne=this.ne.insert(t.key,this.me(t.key).add(e)),this.ie=this.ie.insert(t.key,this.ge(t.key).add(e))}ae(e,t,n){const r=this.ee.get(e);r&&this.ce(e)?(this.pe(e,t)?r.j(t,1):r.H(t),this.ie=this.ie.insert(t,this.ge(t).delete(e)),this.ie=this.ie.insert(t,this.ge(t).add(e)),n&&(ds(this.Te(e).target)&&this.Te(e).target.getPipelineFlavor()!=="exact"?this.re=this.re.insert(t,n):this.te=this.te.insert(t,n))):z(Kr,`removeDocumentFromTarget received document for unknown or inactive target (${e})`)}removeTarget(e){this.ee.delete(e)}Pe(e){const t=this.ee.get(e);if(!t)return 0;const n=t.W();return this.X.getRemoteKeysForTarget(e).size+n.addedDocuments.size-n.removedDocuments.size}J(e){let t=this.ee.get(e);t||(z(Kr,`recordPendingTargetRequest set up tracking for target ID ${e}`),t=new Ef(e),this.ee.set(e,t)),t.J()}ge(e){let t=this.ie.get(e);return t||(t=new Ue(ae),this.ie=this.ie.insert(e,t)),t}me(e){let t=this.ne.get(e);return t||(t=new Ue(ae),this.ne=this.ne.insert(e,t)),t}ce(e){const t=this.Te(e)!==null;return t||z(Kr,"Detected inactive target",e),t}Te(e){const t=this.ee.get(e);return t===void 0||t.q?null:this.X.ye(e)}le(e){this.ee.set(e,new Ef(e)),this.X.getRemoteKeysForTarget(e).forEach(t=>{this.ae(e,t,null)})}pe(e,t){return this.X.getRemoteKeysForTarget(e).has(t)}}function Ro(){return new ke(Y.comparator)}function Df(){return new ke(Y.comparator)}const jw={asc:"ASCENDING",desc:"DESCENDING"},Kw={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},zw={and:"AND",or:"OR"};class Qw{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function Bl(s,e){return s.useProto3Json||Ui(e)?e:{value:e}}function ai(s,e){return s.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Yl(s){const e=Kn(s);return new _e(e.seconds,e.nanos)}function Cp(s,e){return s.useProto3Json?e.toBase64():e.toUint8Array()}function Vo(s,e){return ai(s,e.toTimestamp())}function Ot(s){return W(!!s,49232),ne.fromTimestamp(Yl(s))}function $l(s,e){return ll(s,e).canonicalString()}function ll(s,e){const t=function(r){return new Ce(["projects",r.projectId,"databases",r.database])}(s).child("documents");return e===void 0?t:t.child(e)}function dp(s){const e=Ce.fromString(s);return W(yp(e),10190,{key:e.toString()}),e}function vi(s,e){return $l(s.databaseId,e.path)}function Bi(s,e){const t=dp(e);if(t.get(1)!==s.databaseId.projectId)throw new G(O.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+s.databaseId.projectId);if(t.get(3)!==s.databaseId.database)throw new G(O.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+s.databaseId.database);return new Y(gp(t))}function pp(s,e){return $l(s.databaseId,e)}function Ww(s){const e=dp(s);return e.length===4?Ce.emptyPath():gp(e)}function cl(s){return new Ce(["projects",s.databaseId.projectId,"databases",s.databaseId.database]).canonicalString()}function gp(s){return W(s.length>4&&s.get(4)==="documents",29091,{key:s.toString()}),s.popFirst(5)}function yf(s,e,t){return{name:vi(s,e),fields:t.value.mapValue.fields}}function Yw(s,e){return"found"in e?function(n,r){W(!!r.found,43571),r.found.name,r.found.updateTime;const i=Bi(n,r.found.name),o=Ot(r.found.updateTime),a=r.found.createTime?Ot(r.found.createTime):ne.min(),l=new nt({mapValue:{fields:r.found.fields}});return Xe.newFoundDocument(i,o,a,l)}(s,e):"missing"in e?function(n,r){W(!!r.missing,3894),W(!!r.readTime,22933);const i=Bi(n,r.missing),o=Ot(r.readTime);return Xe.newNoDocument(i,o)}(s,e):X(7234,{result:e})}function $w(s,e){let t;if("targetChange"in e){e.targetChange;const n=function(c){return c==="NO_CHANGE"?0:c==="ADD"?1:c==="REMOVE"?2:c==="CURRENT"?3:c==="RESET"?4:X(39313,{state:c})}(e.targetChange.targetChangeType||"NO_CHANGE"),r=e.targetChange.targetIds||[],i=function(c,h){return c.useProto3Json?(W(h===void 0||typeof h=="string",58123),Je.fromBase64String(h||"")):(W(h===void 0||h instanceof Buffer||h instanceof Uint8Array,16193),Je.fromUint8Array(h||new Uint8Array))}(s,e.targetChange.resumeToken),o=e.targetChange.cause,a=o&&function(c){const h=c.code===void 0?O.UNKNOWN:Bp(c.code);return new G(h,c.message||"")}(o);t=new fp(n,r,i,a||null)}else if("documentChange"in e){e.documentChange;const n=e.documentChange;n.document,n.document.name,n.document.updateTime;const r=Bi(s,n.document.name),i=Ot(n.document.updateTime),o=n.document.createTime?Ot(n.document.createTime):ne.min(),a=new nt({mapValue:{fields:n.document.fields}}),l=Xe.newFoundDocument(r,i,o,a),c=n.targetIds||[],h=n.removedTargetIds||[];t=new ko(c,h,l.key,l)}else if("documentDelete"in e){e.documentDelete;const n=e.documentDelete;n.document;const r=Bi(s,n.document),i=n.readTime?Ot(n.readTime):ne.min(),o=Xe.newNoDocument(r,i),a=n.removedTargetIds||[];t=new ko([],a,o.key,o)}else if("documentRemove"in e){e.documentRemove;const n=e.documentRemove;n.document;const r=Bi(s,n.document),i=n.removedTargetIds||[];t=new ko([],i,r,null)}else{if(!("filter"in e))return X(11601,{we:e});{e.filter;const n=e.filter;n.targetId;const{count:r=0,unchangedNames:i}=n,o=new xw(r,i),a=n.targetId;t=new hp(a,o)}}return t}function mp(s,e){let t;if(e instanceof qi)t={update:yf(s,e.key,e.value)};else if(e instanceof Ta)t={delete:vi(s,e.key)};else if(e instanceof rs)t={update:yf(s,e.key,e.data),updateMask:aT(e.fieldMask)};else{if(!(e instanceof Yd))return X(16599,{be:e.type});t={verify:vi(s,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(n=>function(i,o){const a=o.transform;if(a instanceof wi)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(a instanceof lr)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:a.elements}};if(a instanceof Ti)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:a.elements}};if(a instanceof cr)return{fieldPath:o.field.canonicalString(),increment:a.h};if(a instanceof Wo)return{fieldPath:o.field.canonicalString(),minimum:a.h};if(a instanceof Yo)return{fieldPath:o.field.canonicalString(),maximum:a.h};throw X(20930,{transform:o.transform})}(0,n))),e.precondition.isNone||(t.currentDocument=function(r,i){return i.updateTime!==void 0?{updateTime:Vo(r,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:X(27497)}(s,e.precondition)),t}function Xw(s,e){return s&&s.length>0?(W(e!==void 0,14353),s.map(t=>function(r,i){let o=r.updateTime?Ot(r.updateTime):Ot(i);return o.isEqual(ne.min())&&(o=Ot(i)),new hw(o,r.transformResults||[])}(t,e))):[]}function Zw(s,e){return{documents:[pp(s,e.path)]}}function _p(s,e){const t={structuredQuery:{}},n=e.path;let r;e.collectionGroup!==null?(r=n,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(r=n.popLast(),t.structuredQuery.from=[{collectionId:n.lastSegment()}]),t.parent=pp(s,r);const i=function(c){if(c.length!==0)return Dp(zt.create(c,"and"))}(e.filters);i&&(t.structuredQuery.where=i);const o=function(c){if(c.length!==0)return c.map(h=>function(d){return{field:Ln(d.field),direction:rT(d.dir)}}(h))}(e.orderBy);o&&(t.structuredQuery.orderBy=o);const a=Bl(s,e.limit);return a!==null&&(t.structuredQuery.limit=a),e.startAt&&(t.structuredQuery.startAt=function(c){return{before:c.inclusive,values:c.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(c){return{before:!c.inclusive,values:c.position}}(e.endAt)),{Se:t,parent:r}}function eT(s,e,t,n){const{Se:r,parent:i}=_p(s,e),o={},a=[];let l=0;return t.forEach(c=>{const h="aggregate_"+l++;o[h]=c.alias,c.aggregateType==="count"?a.push({alias:h,count:{}}):c.aggregateType==="avg"?a.push({alias:h,avg:{field:Ln(c.fieldPath)}}):c.aggregateType==="sum"&&a.push({alias:h,sum:{field:Ln(c.fieldPath)}})}),{request:{structuredAggregationQuery:{aggregations:a,structuredQuery:r.structuredQuery},parent:r.parent},ve:o,parent:i}}function tT(s){let e=Ww(s.parent);const t=s.structuredQuery,n=t.from?t.from.length:0;let r=null;if(n>0){W(n===1,65062);const h=t.from[0];h.allDescendants?r=h.collectionId:e=e.child(h.collectionId)}let i=[];t.where&&(i=function(f){const d=Ep(f);return d instanceof zt&&Zd(d)?d.getFilters():[d]}(t.where));let o=[];t.orderBy&&(o=function(f){return f.map(d=>function(y){return new Ii(Qs(y.field),function(F){switch(F){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(y.direction))}(d))}(t.orderBy));let a=null;t.limit&&(a=function(f){let d;return d=typeof f=="object"?f.value:f,Ui(d)?null:d}(t.limit));let l=null;t.startAt&&(l=function(f){const d=!!f.before,_=f.values||[];return new ur(_,d)}(t.startAt));let c=null;return t.endAt&&(c=function(f){const d=!f.before,_=f.values||[];return new ur(_,d)}(t.endAt)),Rw(e,r,o,i,a,"F",l,c)}function nT(s,e){const t=function(r){switch(r){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return X(28987,{purpose:r})}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function sT(s,e){return{structuredPipeline:{pipeline:{stages:e.stages.map(t=>t._toProto(s))}}}}function Ep(s){return s.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const n=Qs(t.unaryFilter.field);return Ge.create(n,"==",{doubleValue:NaN});case"IS_NULL":const r=Qs(t.unaryFilter.field);return Ge.create(r,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=Qs(t.unaryFilter.field);return Ge.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=Qs(t.unaryFilter.field);return Ge.create(o,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return X(61313);default:return X(60726)}}(s):s.fieldFilter!==void 0?function(t){return Ge.create(Qs(t.fieldFilter.field),function(r){switch(r){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return X(58110);default:return X(50506)}}(t.fieldFilter.op),t.fieldFilter.value)}(s):s.compositeFilter!==void 0?function(t){return zt.create(t.compositeFilter.filters.map(n=>Ep(n)),function(r){switch(r){case"AND":return"and";case"OR":return"or";default:return X(1026)}}(t.compositeFilter.op))}(s):X(30097,{filter:s})}function rT(s){return jw[s]}function iT(s){return Kw[s]}function oT(s){return zw[s]}function Ln(s){return{fieldPath:s.canonicalString()}}function Qs(s){return Ft.fromServerFormat(s.fieldPath)}function Dp(s){return s instanceof Ge?function(t){if(t.op==="=="){if(At(t.value))return{unaryFilter:{field:Ln(t.field),op:"IS_NAN"}};if(Pt(t.value))return{unaryFilter:{field:Ln(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(At(t.value))return{unaryFilter:{field:Ln(t.field),op:"IS_NOT_NAN"}};if(Pt(t.value))return{unaryFilter:{field:Ln(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Ln(t.field),op:iT(t.op),value:t.value}}}(s):s instanceof zt?function(t){const n=t.getFilters().map(r=>Dp(r));return n.length===1?n[0]:{compositeFilter:{op:oT(t.op),filters:n}}}(s):X(54877,{filter:s})}function aT(s){const e=[];return s.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function yp(s){return s.length>=4&&s.get(0)==="projects"&&s.get(2)==="databases"}function wp(s){return!!s&&typeof s._toProto=="function"&&s._protoValueType==="ProtoValue"}function Ri(s,e){const t={fields:{}};return e.forEach((n,r)=>{if(typeof r!="string")throw new Error(`Cannot encode map with non-string key: ${r}`);t.fields[r]=n._toProto(s)}),{mapValue:t}}function Tp(s){return{stringValue:s}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function va(s){return new Qw(s,!0)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bt{constructor(e){this._byteString=e}static fromBase64String(e){try{return new bt(Je.fromBase64String(e))}catch(t){throw new G(O.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new bt(Je.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:bt._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(Mi(e,bt._jsonSchema))return bt.fromBase64String(e.bytes)}}bt._jsonSchemaVersion="firestore/bytes/1.0",bt._jsonSchema={type:He("string",bt._jsonSchemaVersion),bytes:He("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ki{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new G(O.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Ft(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}function BT(){return new Ki(Zt)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gr{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rn{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new G(O.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new G(O.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return ae(this._lat,e._lat)||ae(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:rn._jsonSchemaVersion}}static fromJSON(e){if(Mi(e,rn._jsonSchema))return new rn(e.latitude,e.longitude)}}rn._jsonSchemaVersion="firestore/geoPoint/1.0",rn._jsonSchema={type:He("string",rn._jsonSchemaVersion),latitude:He("number"),longitude:He("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class at{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}at.UNAUTHENTICATED=new at(null),at.GOOGLE_CREDENTIALS=new at("google-credentials-uid"),at.FIRST_PARTY=new at("first-party-uid"),at.MOCK_USER=new at("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jt{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ip{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class lT{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(at.UNAUTHENTICATED))}shutdown(){}}class cT{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class uT{constructor(e){this.De=e,this.currentUser=at.UNAUTHENTICATED,this.xe=0,this.forceRefresh=!1,this.auth=null}start(e,t){W(this.Ce===void 0,42304);let n=this.xe;const r=l=>this.xe!==n?(n=this.xe,t(l)):Promise.resolve();let i=new Jt;this.Ce=()=>{this.xe++,this.currentUser=this.Fe(),i.resolve(),i=new Jt,e.enqueueRetryable(()=>r(this.currentUser))};const o=()=>{const l=i;e.enqueueRetryable(async()=>{await l.promise,await r(this.currentUser)})},a=l=>{z("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=l,this.Ce&&(this.auth.addAuthTokenListener(this.Ce),o())};this.De.onInit(l=>a(l)),setTimeout(()=>{if(!this.auth){const l=this.De.getImmediate({optional:!0});l?a(l):(z("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new Jt)}},0),o()}getToken(){const e=this.xe,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(n=>this.xe!==e?(z("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):n?(W(typeof n.accessToken=="string",31837,{Oe:n}),new Ip(n.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.Ce&&this.auth.removeAuthTokenListener(this.Ce),this.Ce=void 0}Fe(){const e=this.auth&&this.auth.getUid();return W(e===null||typeof e=="string",2055,{Me:e}),new at(e)}}class hT{constructor(e,t,n){this.Ne=e,this.Le=t,this.Be=n,this.type="FirstParty",this.user=at.FIRST_PARTY,this.Ue=new Map}ke(){return this.Be?this.Be():null}get headers(){this.Ue.set("X-Goog-AuthUser",this.Ne);const e=this.ke();return e&&this.Ue.set("Authorization",e),this.Le&&this.Ue.set("X-Goog-Iam-Authorization-Token",this.Le),this.Ue}}class fT{constructor(e,t,n){this.Ne=e,this.Le=t,this.Be=n}getToken(){return Promise.resolve(new hT(this.Ne,this.Le,this.Be))}start(e,t){e.enqueueRetryable(()=>t(at.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class wf{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class CT{constructor(e,t){this.qe=t,this.forceRefresh=!1,this.appCheck=null,this.$e=null,this.Ke=null,zC(e)&&e.settings.appCheckToken&&(this.Ke=e.settings.appCheckToken)}start(e,t){W(this.Ce===void 0,3512);const n=i=>{i.error!=null&&z("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const o=i.token!==this.$e;return this.$e=i.token,z("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?t(i.token):Promise.resolve()};this.Ce=i=>{e.enqueueRetryable(()=>n(i))};const r=i=>{z("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.Ce&&this.appCheck.addTokenListener(this.Ce)};this.qe.onInit(i=>r(i)),setTimeout(()=>{if(!this.appCheck){const i=this.qe.getImmediate({optional:!0});i?r(i):z("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.Ke)return Promise.resolve(new wf(this.Ke));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(W(typeof t.token=="string",44558,{tokenResult:t}),this.$e=t.token,new wf(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.Ce&&this.appCheck.removeTokenListener(this.Ce),this.Ce=void 0}}function Ap(s){const e={};return s.timeoutSeconds!==void 0&&(e.timeoutSeconds=s.timeoutSeconds),e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dT{Qe(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tf="ConnectivityMonitor";class If{constructor(){this.We=()=>this.Ge(),this.ze=()=>this.je(),this.He=[],this.Je()}Qe(e){this.He.push(e)}shutdown(){window.removeEventListener("online",this.We),window.removeEventListener("offline",this.ze)}Je(){window.addEventListener("online",this.We),window.addEventListener("offline",this.ze)}Ge(){z(Tf,"Network connectivity changed: AVAILABLE");for(const e of this.He)e(0)}je(){z(Tf,"Network connectivity changed: UNAVAILABLE");for(const e of this.He)e(1)}static Ye(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let So=null;function ul(){return So===null?So=function(){return 268435456+Math.round(2147483648*Math.random())}():So++,"0x"+So.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const PB="RestConnection",pT={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class gT{get Ze(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",n=encodeURIComponent(this.databaseId.projectId),r=encodeURIComponent(this.databaseId.database);this.Xe=t+"://"+e.host,this.et=`projects/${n}/databases/${r}`,this.tt=this.databaseId.database===Ko?`project_id=${n}`:`project_id=${n}&database_id=${r}`}nt(e,t,n,r,i){const o=ul(),a=this.rt(e,t.toUriEncodedString());z(PB,`Sending RPC '${e}' ${o}:`,a,n);const l={"google-cloud-resource-prefix":this.et,"x-goog-request-params":this.tt};this.it(l,r,i);const{host:c}=new URL(a),h=qC(c);return this.st(e,a,l,n,h).then(f=>(z(PB,`Received RPC '${e}' ${o}: `,f),f),f=>{throw Kt(PB,`RPC '${e}' ${o} failed with error: `,f,"url: ",a,"request:",n),f})}_t(e,t,n,r,i,o){return this.nt(e,t,n,r,i)}it(e,t,n){if(e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+pr}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((r,i)=>e[i]=r),n&&n.headers.forEach((r,i)=>e[i]=r),this.databaseInfo._customHeaders)for(const r of Object.keys(this.databaseInfo._customHeaders))e[r]=this.databaseInfo._customHeaders[r]}rt(e,t){const n=pT[e];let r=`${this.Xe}/v1/${t}:${n}`;return this.databaseInfo.apiKey&&(r=`${r}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),r}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mT{constructor(e){this.ot=e.ot,this.ut=e.ut}ct(e){this.lt=e}Et(e){this.ht=e}Tt(e){this.Pt=e}onMessage(e){this.It=e}close(){this.ut()}send(e){this.ot(e)}Rt(){this.lt()}At(){this.ht()}Vt(e){this.Pt(e)}dt(e){this.It(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ot="WebChannelConnection",zr=(s,e,t)=>{s.listen(e,n=>{try{t(n)}catch(r){setTimeout(()=>{throw r},0)}})};class Zs extends gT{constructor(e){super(e),this.ft=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static gt(){if(!Zs.yt){const e=Td();zr(e,wd.STAT_EVENT,t=>{t.stat===XB.PROXY?z(ot,"STAT_EVENT: detected buffering proxy"):t.stat===XB.NOPROXY&&z(ot,"STAT_EVENT: detected no buffering proxy")}),Zs.yt=!0}}st(e,t,n,r,i){const o=ul();return new Promise((a,l)=>{const c=new Dd;c.setWithCredentials(!0),c.listenOnce(yd.COMPLETE,()=>{try{switch(c.getLastErrorCode()){case Oo.NO_ERROR:const f=c.getResponseJson();z(ot,`XHR for RPC '${e}' ${o} received:`,JSON.stringify(f)),a(f);break;case Oo.TIMEOUT:z(ot,`RPC '${e}' ${o} timed out`),l(new G(O.DEADLINE_EXCEEDED,"Request time out"));break;case Oo.HTTP_ERROR:const d=c.getStatus();if(z(ot,`RPC '${e}' ${o} failed with status:`,d,"response text:",c.getResponseText()),d>0){let _=c.getResponseJson();Array.isArray(_)&&(_=_[0]);const y=_==null?void 0:_.error;if(y&&y.status&&y.message){const N=function(J){const te=J.toLowerCase().replace(/_/g,"-");return Object.values(O).indexOf(te)>=0?te:O.UNKNOWN}(y.status);l(new G(N,y.message))}else l(new G(O.UNKNOWN,"Server responded with status "+c.getStatus()))}else l(new G(O.UNAVAILABLE,"Connection failed."));break;default:X(9055,{wt:e,streamId:o,bt:c.getLastErrorCode(),St:c.getLastError()})}}finally{z(ot,`RPC '${e}' ${o} completed.`)}});const h=JSON.stringify(r);z(ot,`RPC '${e}' ${o} sending request:`,r),c.send(t,"POST",h,n,15)})}vt(e,t,n){const r=ul(),i=[this.Xe,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=this.createWebChannelTransport(),a={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},l=this.longPollingOptions.timeoutSeconds;l!==void 0&&(a.longPollingTimeout=Math.round(1e3*l)),this.useFetchStreams&&(a.useFetchStreams=!0),this.it(a.initMessageHeaders,t,n),a.encodeInitMessageHeaders=!0;const c=i.join("");z(ot,`Creating RPC '${e}' stream ${r}: ${c}`,a);const h=o.createWebChannel(c,a);this.Dt(h);let f=!1,d=!1;const _=new mT({ot:y=>{d?z(ot,`Not sending because RPC '${e}' stream ${r} is closed:`,y):(f||(z(ot,`Opening RPC '${e}' stream ${r} transport.`),h.open(),f=!0),z(ot,`RPC '${e}' stream ${r} sending:`,y),h.send(y))},ut:()=>h.close()});return zr(h,Xr.EventType.OPEN,()=>{d||(z(ot,`RPC '${e}' stream ${r} transport opened.`),_.Rt())}),zr(h,Xr.EventType.CLOSE,()=>{d||(d=!0,z(ot,`RPC '${e}' stream ${r} transport closed`),_.Vt(),this.xt(h))}),zr(h,Xr.EventType.ERROR,y=>{d||(d=!0,Kt(ot,`RPC '${e}' stream ${r} transport errored. Name:`,y.name,"Message:",y.message),_.Vt(new G(O.UNAVAILABLE,"The operation could not be completed")))}),zr(h,Xr.EventType.MESSAGE,y=>{var N;if(!d){const F=y.data[0];W(!!F,16349);const J=F,te=(J==null?void 0:J.error)||((N=J[0])==null?void 0:N.error);if(te){z(ot,`RPC '${e}' stream ${r} received error:`,te);const re=te.status;let ge=function(v){const E=Ve[v];if(E!==void 0)return Bp(E)}(re),Le=te.message;re==="NOT_FOUND"&&Le.includes("database")&&Le.includes("does not exist")&&Le.includes(this.databaseId.database)&&Kt(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),ge===void 0&&(ge=O.INTERNAL,Le="Unknown error status: "+re+" with message "+te.message),d=!0,_.Vt(new G(ge,Le)),h.close()}else z(ot,`RPC '${e}' stream ${r} received:`,F),_.dt(F)}}),Zs.gt(),setTimeout(()=>{_.At()},0),_}terminate(){this.ft.forEach(e=>e.close()),this.ft=[]}Dt(e){this.ft.push(e)}xt(e){this.ft=this.ft.filter(t=>t===e)}it(e,t,n){super.it(e,t,n),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return Id()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _T(s){return new Zs(s)}Zs.yt=!1;class Xl{constructor(e,t,n=1e3,r=1.5,i=6e4){this.Ct=e,this.timerId=t,this.Ft=n,this.Ot=r,this.Mt=i,this.Nt=0,this.Lt=null,this.Bt=Date.now(),this.reset()}reset(){this.Nt=0}Ut(){this.Nt=this.Mt}kt(e){this.cancel();const t=Math.floor(this.Nt+this.qt()),n=Math.max(0,Date.now()-this.Bt),r=Math.max(0,t-n);r>0&&z("ExponentialBackoff",`Backing off for ${r} ms (base delay: ${this.Nt} ms, delay with jitter: ${t} ms, last attempt: ${n} ms ago)`),this.Lt=this.Ct.enqueueAfterDelay(this.timerId,r,()=>(this.Bt=Date.now(),e())),this.Nt*=this.Ot,this.Nt<this.Ft&&(this.Nt=this.Ft),this.Nt>this.Mt&&(this.Nt=this.Mt)}$t(){this.Lt!==null&&(this.Lt.skipDelay(),this.Lt=null)}cancel(){this.Lt!==null&&(this.Lt.cancel(),this.Lt=null)}qt(){return(Math.random()-.5)*this.Nt}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Af="PersistentStream";class vp{constructor(e,t,n,r,i,o,a,l){this.Ct=e,this.Kt=n,this.Qt=r,this.connection=i,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=a,this.listener=l,this.state=0,this.Wt=0,this.Gt=null,this.zt=null,this.stream=null,this.jt=0,this.Ht=new Xl(e,t)}Jt(){return this.state===1||this.state===5||this.Yt()}Yt(){return this.state===2||this.state===3}start(){this.jt=0,this.state!==4?this.auth():this.Zt()}async stop(){this.Jt()&&await this.close(0)}Xt(){this.state=0,this.Ht.reset()}en(){this.Yt()&&this.Gt===null&&(this.Gt=this.Ct.enqueueAfterDelay(this.Kt,6e4,()=>this.tn()))}nn(e){this.rn(),this.stream.send(e)}async tn(){if(this.Yt())return this.close(0)}rn(){this.Gt&&(this.Gt.cancel(),this.Gt=null)}sn(){this.zt&&(this.zt.cancel(),this.zt=null)}async close(e,t){this.rn(),this.sn(),this.Ht.cancel(),this.Wt++,e!==4?this.Ht.reset():t&&t.code===O.RESOURCE_EXHAUSTED?(_n(t.toString()),_n("Using maximum backoff delay to prevent overloading the backend."),this.Ht.Ut()):t&&t.code===O.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this._n(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Tt(t)}_n(){}auth(){this.state=1;const e=this.an(this.Wt),t=this.Wt;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([n,r])=>{this.Wt===t&&this.un(n,r)},n=>{e(()=>{const r=new G(O.UNKNOWN,"Fetching auth token failed: "+n.message);return this.cn(r)})})}un(e,t){const n=this.an(this.Wt);this.stream=this.En(e,t),this.stream.ct(()=>{n(()=>this.listener.ct())}),this.stream.Et(()=>{n(()=>(this.state=2,this.zt=this.Ct.enqueueAfterDelay(this.Qt,1e4,()=>(this.Yt()&&(this.state=3),Promise.resolve())),this.listener.Et()))}),this.stream.Tt(r=>{n(()=>this.cn(r))}),this.stream.onMessage(r=>{n(()=>++this.jt==1?this.hn(r):this.onNext(r))})}Zt(){this.state=5,this.Ht.kt(async()=>{this.state=0,this.start()})}cn(e){return z(Af,`close with error: ${e}`),this.stream=null,this.close(4,e)}an(e){return t=>{this.Ct.enqueueAndForget(()=>this.Wt===e?t():(z(Af,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class ET extends vp{constructor(e,t,n,r,i,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,n,r,o),this.serializer=i}En(e,t){return this.connection.vt("Listen",e,t)}hn(e){return this.onNext(e)}onNext(e){this.Ht.reset();const t=$w(this.serializer,e),n=function(i){if(!("targetChange"in i))return ne.min();const o=i.targetChange;return o.targetIds&&o.targetIds.length?ne.min():o.readTime?Ot(o.readTime):ne.min()}(e);return this.listener.Tn(t,n)}Pn(e){const t={};t.database=cl(this.serializer),t.addTarget=function(i,o){let a;const l=o.target;if(a=ds(l)?{pipelineQuery:sT(i,l)}:ip(l)?{documents:Zw(i,l)}:{query:_p(i,l).Se},a.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){a.resumeToken=Cp(i,o.resumeToken);const c=Bl(i,o.expectedCount);c!==null&&(a.expectedCount=c)}else if(o.snapshotVersion.compareTo(ne.min())>0){a.readTime=ai(i,o.snapshotVersion.toTimestamp());const c=Bl(i,o.expectedCount);c!==null&&(a.expectedCount=c)}return a}(this.serializer,e);const n=nT(this.serializer,e);n&&(t.labels=n),this.nn(t)}In(e){const t={};t.database=cl(this.serializer),t.removeTarget=e,this.nn(t)}}class DT extends vp{constructor(e,t,n,r,i,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,n,r,o),this.serializer=i}get Rn(){return this.jt>0}start(){this.lastStreamToken=void 0,super.start()}_n(){this.Rn&&this.An([])}En(e,t){return this.connection.vt("Write",e,t)}hn(e){return W(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,W(!e.writeResults||e.writeResults.length===0,55816),this.listener.Vn()}onNext(e){W(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.Ht.reset();const t=Xw(e.writeResults,e.commitTime),n=Ot(e.commitTime);return this.listener.dn(n,t)}fn(){const e={};e.database=cl(this.serializer),this.nn(e)}An(e){const t={streamToken:this.lastStreamToken,writes:e.map(n=>mp(this.serializer,n))};this.nn(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yT{}class wT extends yT{constructor(e,t,n,r){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=n,this.serializer=r,this.mn=!1}pn(){if(this.mn)throw new G(O.FAILED_PRECONDITION,"The client has already been terminated.")}nt(e,t,n,r){return this.pn(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,o])=>this.connection.nt(e,ll(t,n),r,i,o)).catch(i=>{throw i.name==="FirebaseError"?(i.code===O.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new G(O.UNKNOWN,i.toString())})}_t(e,t,n,r,i){return this.pn(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,a])=>this.connection._t(e,ll(t,n),r,o,a,i)).catch(o=>{throw o.name==="FirebaseError"?(o.code===O.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new G(O.UNKNOWN,o.toString())})}terminate(){this.mn=!0,this.connection.terminate()}}function TT(s,e,t,n){return new wT(s,e,t,n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const IT="ComponentProvider",vf=new Map;function AT(s,e,t,n,r){return new sw(s,e,t,r.host,r.ssl,r.experimentalForceLongPolling,r.experimentalAutoDetectLongPolling,Ap(r.experimentalLongPollingOptions),r.useFetchStreams,r.isUsingEmulator,n,r._customHeaders,r.grpcFlowControlWindow)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rf={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},Rp=41943040;class Et{static withCacheSize(e){return new Et(e,Et.DEFAULT_COLLECTION_PERCENTILE,Et.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,n){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=n}}Et.DEFAULT_COLLECTION_PERCENTILE=10,Et.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,Et.DEFAULT=new Et(Rp,Et.DEFAULT_COLLECTION_PERCENTILE,Et.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),Et.DISABLED=new Et(-1,0,0);/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ra{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=n=>this.gn(n),this.yn=n=>t.writeSequenceNumber(n))}gn(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.yn&&this.yn(e),e}}Ra.wn=-1;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vT="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class RT{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function mr(s){if(s.code!==O.FAILED_PRECONDITION||s.message!==vT)throw s;z("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&X(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new V((n,r)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(n,r)},this.catchCallback=i=>{this.wrapFailure(t,i).next(n,r)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof V?t:V.resolve(t)}catch(t){return V.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):V.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):V.reject(t)}static resolve(e){return new V((t,n)=>{t(e)})}static reject(e){return new V((t,n)=>{n(e)})}static waitFor(e){return new V((t,n)=>{let r=0,i=0,o=!1;e.forEach(a=>{++r,a.next(()=>{++i,o&&i===r&&t()},l=>n(l))}),o=!0,i===r&&t()})}static or(e){let t=V.resolve(!1);for(const n of e)t=t.next(r=>r?V.resolve(r):n());return t}static forEach(e,t){const n=[];return e.forEach((r,i)=>{n.push(t.call(this,r,i))}),this.waitFor(n)}static mapArray(e,t){return new V((n,r)=>{const i=e.length,o=new Array(i);let a=0;for(let l=0;l<i;l++){const c=l;t(e[c]).next(h=>{o[c]=h,++a,a===i&&n(o)},h=>r(h))}})}static doWhile(e,t){return new V((n,r)=>{const i=()=>{e()===!0?t().next(()=>{i()},r):n()};i()})}}function ST(s){const e=s.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function _r(s){return s.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sf="LruGarbageCollector",bT=1048576;function bf([s,e],[t,n]){const r=ae(s,t);return r===0?ae(e,n):r}class NT{constructor(e){this.Yn=e,this.buffer=new Ue(bf),this.Zn=0}Xn(){return++this.Zn}er(e){const t=[e,this.Xn()];if(this.buffer.size<this.Yn)this.buffer=this.buffer.add(t);else{const n=this.buffer.last();bf(t,n)<0&&(this.buffer=this.buffer.delete(n).add(t))}}get maxValue(){return this.buffer.last()[0]}}class PT{constructor(e,t,n){this.garbageCollector=e,this.asyncQueue=t,this.localStore=n,this.tr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.nr(6e4)}stop(){this.tr&&(this.tr.cancel(),this.tr=null)}get started(){return this.tr!==null}nr(e){z(Sf,`Garbage collection scheduled in ${e}ms`),this.tr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.tr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){_r(t)?z(Sf,"Ignoring IndexedDB error during garbage collection: ",t):await mr(t)}await this.nr(3e5)})}}class FT{constructor(e,t){this.rr=e,this.params=t}calculateTargetCount(e,t){return this.rr.ir(e).next(n=>Math.floor(t/100*n))}nthSequenceNumber(e,t){if(t===0)return V.resolve(Ra.wn);const n=new NT(t);return this.rr.forEachTarget(e,r=>n.er(r.sequenceNumber)).next(()=>this.rr.sr(e,r=>n.er(r))).next(()=>n.maxValue)}removeTargets(e,t,n){return this.rr.removeTargets(e,t,n)}removeOrphanedDocuments(e,t){return this.rr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(z("LruGarbageCollector","Garbage collection skipped; disabled"),V.resolve(Rf)):this.getCacheSize(e).next(n=>n<this.params.cacheSizeCollectionThreshold?(z("LruGarbageCollector",`Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),Rf):this._r(e,t))}getCacheSize(e){return this.rr.getCacheSize(e)}_r(e,t){let n,r,i,o,a,l,c;const h=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(f=>(f>this.params.maximumSequenceNumbersToCollect?(z("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${f}`),r=this.params.maximumSequenceNumbersToCollect):r=f,o=Date.now(),this.nthSequenceNumber(e,r))).next(f=>(n=f,a=Date.now(),this.removeTargets(e,n,t))).next(f=>(i=f,l=Date.now(),this.removeOrphanedDocuments(e,n))).next(f=>(c=Date.now(),js()<=Be.DEBUG&&z("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-h}ms
	Determined least recently used ${r} in `+(a-o)+`ms
	Removed ${i} targets in `+(l-a)+`ms
	Removed ${f} documents in `+(c-l)+`ms
Total Duration: ${c-h}ms`),V.resolve({didRun:!0,sequenceNumbersCollected:r,targetsRemoved:i,documentsRemoved:f})))}}function OT(s,e){return new FT(s,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sp="firestore.googleapis.com",Nf=!0;class Pf{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new G(O.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=Sp,this.ssl=Nf}else this.host=e.host,this.ssl=e.ssl??Nf;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e._customHeaders&&(this._customHeaders={...e._customHeaders}),e.cacheSizeBytes===void 0)this.cacheSizeBytes=Rp;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<bT)throw new G(O.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}if(ew("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Ap(e.experimentalLongPollingOptions??{}),function(n){if(n.timeoutSeconds!==void 0){if(isNaN(n.timeoutSeconds))throw new G(O.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (must not be NaN)`);if(n.timeoutSeconds<5)throw new G(O.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (minimum allowed value is 5)`);if(n.timeoutSeconds>30)throw new G(O.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams,e.grpcFlowControlWindow!==void 0){if(typeof e.grpcFlowControlWindow!="number"||e.grpcFlowControlWindow<=0||e.grpcFlowControlWindow>2147483647||!Number.isInteger(e.grpcFlowControlWindow))throw new G(O.INVALID_ARGUMENT,"grpcFlowControlWindow must be a positive integer and cannot exceed 2147483647");this.grpcFlowControlWindow=e.grpcFlowControlWindow}}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(n,r){return n.timeoutSeconds===r.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams&&this.grpcFlowControlWindow===e.grpcFlowControlWindow&&function(n,r){if(n===r)return!0;if(!n||!r)return!1;const i=Object.keys(n),o=Object.keys(r);if(i.length!==o.length)return!1;for(const a of i)if(n[a]!==r[a])return!1;return!0}(this._customHeaders,e._customHeaders)}}let Sa=class{constructor(e,t,n,r){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=n,this._app=r,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Pf({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new G(O.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new G(O.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Pf(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(n){if(!n)return new lT;switch(n.type){case"firstParty":return new fT(n.sessionIndex||"0",n.iamToken||null,n.authTokenFactory||null);case"provider":return n.client;default:throw new G(O.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const n=vf.get(t);n&&(z(IT,"Removing Datastore"),vf.delete(t),n.terminate())}(this),Promise.resolve()}};function LT(s,e,t,n={}){var c;s=ut(s,Sa);const r=qC(e),i=s._getSettings(),o={...i,emulatorOptions:s._getEmulatorOptions()},a=`${e}:${t}`;r&&Q_(`https://${a}`),i.host!==Sp&&i.host!==a&&Kt("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const l={...i,host:a,ssl:r,emulatorOptions:n};if(!sr(l,o)&&(s._setSettings(l),n.mockUserToken)){let h,f;if(typeof n.mockUserToken=="string")h=n.mockUserToken,f=at.MOCK_USER;else{h=b_(n.mockUserToken,(c=s._app)==null?void 0:c.options.projectId);const d=n.mockUserToken.sub||n.mockUserToken.user_id;if(!d)throw new G(O.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");f=new at(d)}s._authCredentials=new cT(new Ip(h,f))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wt{constructor(e,t,n){this.converter=t,this._query=n,this.type="query",this.firestore=e}withConverter(e){return new Wt(this.firestore,e,this._query)}}class Ne{constructor(e,t,n){this.converter=t,this._key=n,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Gn(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Ne(this.firestore,e,this._key)}toJSON(){return{type:Ne._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,n){if(Mi(t,Ne._jsonSchema))return new Ne(e,n||null,new Y(Ce.fromString(t.referencePath)))}}Ne._jsonSchemaVersion="firestore/documentReference/1.0",Ne._jsonSchema={type:He("string",Ne._jsonSchemaVersion),referencePath:He("string")};class Gn extends Wt{constructor(e,t,n){super(e,t,Ia(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Ne(this.firestore,null,new Y(e))}withConverter(e){return new Gn(this.firestore,e,this._path)}}function K0(s,e,...t){if(s=qe(s),Ld("collection","path",e),s instanceof Sa){const n=Ce.fromString(e,...t);return rf(n),new Gn(s,null,n)}{if(!(s instanceof Ne||s instanceof Gn))throw new G(O.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const n=s._path.child(Ce.fromString(e,...t));return rf(n),new Gn(s.firestore,null,n)}}function xT(s,e,...t){if(s=qe(s),arguments.length===1&&(e=Ul.newId()),Ld("doc","path",e),s instanceof Sa){const n=Ce.fromString(e,...t);return sf(n),new Ne(s,null,new Y(n))}{if(!(s instanceof Ne||s instanceof Gn))throw new G(O.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const n=s._path.child(Ce.fromString(e,...t));return sf(n),new Ne(s.firestore,s instanceof Gn?s.converter:null,new Y(n))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wt{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(n,r){if(n.length!==r.length)return!1;for(let i=0;i<n.length;++i)if(n[i]!==r[i])return!1;return!0}(this._values,e._values)}toJSON(){return{type:wt._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(Mi(e,wt._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(t=>typeof t=="number"))return new wt(e.vectorValues);throw new G(O.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}wt._jsonSchemaVersion="firestore/vectorValue/1.0",wt._jsonSchema={type:He("string",wt._jsonSchemaVersion),vectorValues:He("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kT=/^__.*__$/;class VT{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return this.fieldMask!==null?new rs(e,this.data,this.fieldMask,t,this.fieldTransforms):new qi(e,this.data,t,this.fieldTransforms)}}class bp{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return new rs(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function Np(s){switch(s){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw X(40011,{dataSource:s})}}class ba{constructor(e,t,n,r,i,o){this.settings=e,this.databaseId=t,this.serializer=n,this.ignoreUndefinedProperties=r,i===void 0&&this.validatePath(),this.fieldTransforms=i||[],this.fieldMask=o||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}contextWith(e){return new ba({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}childContextForField(e){var r;const t=(r=this.path)==null?void 0:r.child(e),n=this.contextWith({path:t,arrayElement:!1});return n.validatePathSegment(e),n}childContextForFieldPath(e){var r;const t=(r=this.path)==null?void 0:r.child(e),n=this.contextWith({path:t,arrayElement:!1});return n.validatePath(),n}childContextForArray(e){return this.contextWith({path:void 0,arrayElement:!0})}createError(e){return Zo(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}validatePath(){if(this.path)for(let e=0;e<this.path.length;e++)this.validatePathSegment(this.path.get(e))}validatePathSegment(e){if(e.length===0)throw this.createError("Document fields must not be empty");if(Np(this.dataSource)&&kT.test(e))throw this.createError('Document fields cannot begin and end with "__"')}}class MT{constructor(e,t,n){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=n||va(e)}createContext(e,t,n,r=!1){return new ba({dataSource:e,methodName:t,targetDoc:n,path:Ft.emptyPath(),arrayElement:!1,hasConverter:r},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Er(s){const e=s._freezeSettings(),t=va(s._databaseId);return new MT(s._databaseId,!!e.ignoreUndefinedProperties,t)}function Zl(s,e,t,n,r,i={}){const o=s.createContext(i.merge||i.mergeFields?2:0,e,t,r);sc("Data must be an object, but it was:",o,n);const a=Lp(n,o);let l,c;if(i.merge)l=new Nt(o.fieldMask),c=o.fieldTransforms;else if(i.mergeFields){const h=[];for(const f of i.mergeFields){const d=Yn(e,f,t);if(!o.contains(d))throw new G(O.INVALID_ARGUMENT,`Field '${d}' is specified in your field mask but missing from your input data.`);Mp(h,d)||h.push(d)}l=new Nt(h),c=o.fieldTransforms.filter(f=>l.covers(f.field))}else l=null,c=o.fieldTransforms;return new VT(new nt(a),l,c)}class zi extends gr{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.createError(`${this._methodName}() can only appear at the top level of your update data`):e.createError(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof zi}}function GT(s,e,t){return new ba({dataSource:3,targetDoc:e.settings.targetDoc,methodName:s._methodName,arrayElement:t},e.databaseId,e.serializer,e.ignoreUndefinedProperties)}class ec extends gr{_toFieldTransform(e){return new Kl(e.path,new wi)}isEqual(e){return e instanceof ec}}class tc extends gr{constructor(e,t){super(e),this.ar=t}_toFieldTransform(e){const t=GT(this,e,!0),n=this.ar.map(i=>En(i,t)),r=new lr(n);return new Kl(e.path,r)}isEqual(e){return e instanceof tc&&sr(this.ar,e.ar)}}class nc extends gr{constructor(e,t){super(e),this.ur=t}_toFieldTransform(e){const t=new cr(e.serializer,Da(e.serializer,this.ur));return new Kl(e.path,t)}isEqual(e){return e instanceof nc&&(this.ur===e.ur||Number.isNaN(this.ur)&&Number.isNaN(e.ur))}}function Pp(s,e,t,n){const r=s.createContext(1,e,t);sc("Data must be an object, but it was:",r,n);const i=[],o=nt.empty();ss(n,(l,c)=>{const h=Vp(e,l,t);c=qe(c);const f=r.childContextForFieldPath(h);if(c instanceof zi)i.push(h);else{const d=En(c,f);d!=null&&(i.push(h),o.set(h,d))}});const a=new Nt(i);return new bp(o,a,r.fieldTransforms)}function Fp(s,e,t,n,r,i){const o=s.createContext(1,e,t),a=[Yn(e,n,t)],l=[r];if(i.length%2!=0)throw new G(O.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let d=0;d<i.length;d+=2)a.push(Yn(e,i[d])),l.push(i[d+1]);const c=[],h=nt.empty();for(let d=a.length-1;d>=0;--d)if(!Mp(c,a[d])){const _=a[d];let y=l[d];y=qe(y);const N=o.childContextForFieldPath(_);if(y instanceof zi)c.push(_);else{const F=En(y,N);F!=null&&(c.push(_),h.set(_,F))}}const f=new Nt(c);return new bp(h,f,o.fieldTransforms)}function Op(s,e,t,n=!1){return En(t,s.createContext(n?4:3,e))}function En(s,e,t){if(kp(s=qe(s)))return sc("Unsupported field value:",e,s),Lp(s,e);if(s instanceof gr)return function(r,i){if(!Np(i.dataSource))throw i.createError(`${r._methodName}() can only be used with update() and set()`);if(!i.path)throw i.createError(`${r._methodName}() is not currently supported inside arrays`);const o=r._toFieldTransform(i);o&&i.fieldTransforms.push(o)}(s,e),null;if(s===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),s instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.createError("Nested arrays are not supported");return function(r,i){const o=[];let a=0;for(const l of r){let c=En(l,i.childContextForArray(a));c==null&&(c={nullValue:"NULL_VALUE"}),o.push(c),a++}return{arrayValue:{values:o}}}(s,e)}return function(r,i,o){if((r=qe(r))===null)return{nullValue:"NULL_VALUE"};if(typeof r=="number")return Da(i.serializer,r);if(typeof r=="boolean")return{booleanValue:r};if(typeof r=="string")return{stringValue:r};if(r instanceof Date){const a=_e.fromDate(r);return{timestampValue:ai(i.serializer,a)}}if(r instanceof _e){const a=new _e(r.seconds,1e3*Math.floor(r.nanoseconds/1e3));return{timestampValue:ai(i.serializer,a)}}if(xp(r)){const a=_e.fromInstant(r),l=new _e(a.seconds,1e3*Math.floor(a.nanoseconds/1e3));return{timestampValue:ai(i.serializer,l)}}if(r instanceof rn)return{geoPointValue:{latitude:r.latitude,longitude:r.longitude}};if(r instanceof bt)return{bytesValue:Cp(i.serializer,r._byteString)};if(r instanceof Ne){const a=i.databaseId,l=r.firestore._databaseId;if(!l.isEqual(a))throw i.createError(`Document reference is for database ${l.projectId}/${l.database} but should be for database ${a.projectId}/${a.database}`);return{referenceValue:$l(r.firestore._databaseId||i.databaseId,r._key.path)}}if(r instanceof wt)return function(l,c){const h=l instanceof wt?l.toArray():l;return{mapValue:{fields:{[Hd]:{stringValue:Ud},[Di]:{arrayValue:{values:h.map(d=>{if(typeof d!="number")throw c.createError("VectorValues must only contain numeric values.");return Ea(c.serializer,d)})}}}}}}(r,i);if(wp(r))return r._toProto(i.serializer);throw i.createError(`Unsupported field value: ${_a(r)}`)}(s,e)}function Lp(s,e){const t={};return Od(s)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):ss(s,(n,r)=>{const i=En(r,e.childContextForField(n));i!=null&&(t[n]=i)}),{mapValue:{fields:t}}}function xp(s){if(typeof s!="object"||s===null)return!1;if(typeof Temporal<"u"&&typeof Temporal.Instant=="function"&&s instanceof Temporal.Instant)return!0;const e=s;return e[Symbol.toStringTag]==="Temporal.Instant"&&typeof e.t=="bigint"}function kp(s){return!(typeof s!="object"||s===null||s instanceof Array||s instanceof Date||s instanceof _e||s instanceof rn||s instanceof bt||s instanceof Ne||s instanceof gr||s instanceof wt||xp(s)||wp(s))}function sc(s,e,t){if(!kp(t)||!Vi(t)){const n=_a(t);throw n==="an object"?e.createError(s+" a custom object"):e.createError(s+" "+n)}}function Yn(s,e,t){if((e=qe(e))instanceof Ki)return e._internalPath;if(typeof e=="string")return Vp(s,e);throw Zo("Field path arguments must be of type string or ",s,!1,void 0,t)}const HT=new RegExp("[~\\*/\\[\\]]");function Vp(s,e,t){if(e.search(HT)>=0)throw Zo(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,s,!1,void 0,t);try{return new Ki(...e.split("."))._internalPath}catch{throw Zo(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,s,!1,void 0,t)}}function Zo(s,e,t,n,r){const i=n&&!n.isEmpty(),o=r!==void 0;let a=`Function ${e}() called with invalid data`;t&&(a+=" (via `toFirestore()`)"),a+=". ";let l="";return(i||o)&&(l+=" (found",i&&(l+=` in field ${n}`),o&&(l+=` in document ${r}`),l+=")"),new G(O.INVALID_ARGUMENT,a+s+l)}function Mp(s,e){return s.some(t=>t.isEqual(e))}function Gp(s){return typeof s._readUserData=="function"}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ht{constructor(e){this.optionDefinitions=e}_getKnownOptions(e,t){const n=nt.empty();for(const r in this.optionDefinitions)if(this.optionDefinitions.hasOwnProperty(r)){const i=this.optionDefinitions[r];if(r in e){const o=e[r];let a;i.nestedOptions&&Vi(o)?a={mapValue:{fields:new ht(i.nestedOptions).getOptionsProto(t,o)}}:o&&(a=En(o,t)??void 0),a&&n.set(Ft.fromServerFormat(i.serverName),a)}}return n}getOptionsProto(e,t,n){const r=this._getKnownOptions(t,e);if(n){const i=new Map(Fd(n,(o,a)=>[Ft.fromServerFormat(a),o!==void 0?En(o,e):null]));r.setAll(i)}return r.value.mapValue.fields??{}}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function UT(s){return typeof s=="object"&&s!==null&&!!("nullValue"in s&&(s.nullValue===null||s.nullValue==="NULL_VALUE")||"booleanValue"in s&&(s.booleanValue===null||typeof s.booleanValue=="boolean")||"integerValue"in s&&(s.integerValue===null||typeof s.integerValue=="number"||typeof s.integerValue=="string")||"doubleValue"in s&&(s.doubleValue===null||typeof s.doubleValue=="number")||"timestampValue"in s&&(s.timestampValue===null||function(t){return typeof t=="object"&&t!==null&&"seconds"in t&&(t.seconds===null||typeof t.seconds=="number"||typeof t.seconds=="string")&&"nanos"in t&&(t.nanos===null||typeof t.nanos=="number")}(s.timestampValue))||"stringValue"in s&&(s.stringValue===null||typeof s.stringValue=="string")||"bytesValue"in s&&(s.bytesValue===null||s.bytesValue instanceof Uint8Array)||"referenceValue"in s&&(s.referenceValue===null||typeof s.referenceValue=="string")||"geoPointValue"in s&&(s.geoPointValue===null||function(t){return typeof t=="object"&&t!==null&&"latitude"in t&&(t.latitude===null||typeof t.latitude=="number")&&"longitude"in t&&(t.longitude===null||typeof t.longitude=="number")}(s.geoPointValue))||"arrayValue"in s&&(s.arrayValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("values"in t)||t.values!==null&&!Array.isArray(t.values))}(s.arrayValue))||"mapValue"in s&&(s.mapValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("fields"in t)||t.fields!==null&&!Vi(t.fields))}(s.mapValue))||"fieldReferenceValue"in s&&(s.fieldReferenceValue===null||typeof s.fieldReferenceValue=="string")||"functionValue"in s&&(s.functionValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("name"in t)||t.name!==null&&typeof t.name!="string"||!("args"in t)||t.args!==null&&!Array.isArray(t.args))}(s.functionValue))||"pipelineValue"in s&&(s.pipelineValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("stages"in t)||t.stages!==null&&!Array.isArray(t.stages))}(s.pipelineValue)))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function z0(){return new zi("deleteField")}function Q0(){return new ec("serverTimestamp")}function W0(...s){return new tc("arrayUnion",s)}function Y0(s){return new nc("increment",s)}function qT(s){return new wt(s)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function q(s){let e;return s instanceof Os?s:(e=Vi(s)?QT(s):s instanceof Array?WT(s):Hp(s,void 0),e)}function FB(s){if(s instanceof Os)return s;if(s instanceof wt)return Si(s);if(Array.isArray(s))return Si(qT(s));throw new Error("Unsupported value: "+typeof s)}function rc(s){return ow(s)?Mo(s):q(s)}class Os{constructor(){this._protoValueType="ProtoValue"}add(e){return new k("add",[this,q(e)],"add")}asBoolean(){if(this instanceof $n)return this;if(this instanceof yr)return new qp(this);if(this instanceof Dr)return new zT(this);if(this instanceof k)return new Up(this);throw new G("invalid-argument",`Conversion of type ${typeof this} to BooleanExpression not supported.`)}subtract(e){return new k("subtract",[this,q(e)],"subtract")}multiply(e){return new k("multiply",[this,q(e)],"multiply")}divide(e){return new k("divide",[this,q(e)],"divide")}mod(e){return new k("mod",[this,q(e)],"mod")}equal(e){return new k("equal",[this,q(e)],"equal").asBoolean()}notEqual(e){return new k("not_equal",[this,q(e)],"notEqual").asBoolean()}lessThan(e){return new k("less_than",[this,q(e)],"lessThan").asBoolean()}lessThanOrEqual(e){return new k("less_than_or_equal",[this,q(e)],"lessThanOrEqual").asBoolean()}greaterThan(e){return new k("greater_than",[this,q(e)],"greaterThan").asBoolean()}greaterThanOrEqual(e){return new k("greater_than_or_equal",[this,q(e)],"greaterThanOrEqual").asBoolean()}arrayConcat(e,...t){const n=[e,...t].map(r=>q(r));return new k("array_concat",[this,...n],"arrayConcat")}arrayContains(e){return new k("array_contains",[this,q(e)],"arrayContains").asBoolean()}arrayContainsAll(e){const t=Array.isArray(e)?new ei(e.map(q),"arrayContainsAll"):e;return new k("array_contains_all",[this,t],"arrayContainsAll").asBoolean()}arrayContainsAny(e){const t=Array.isArray(e)?new ei(e.map(q),"arrayContainsAny"):e;return new k("array_contains_any",[this,t],"arrayContainsAny").asBoolean()}arrayReverse(){return new k("array_reverse",[this])}arrayLength(){return new k("array_length",[this],"arrayLength")}equalAny(e){const t=Array.isArray(e)?new ei(e.map(q),"equalAny"):e;return new k("equal_any",[this,t],"equalAny").asBoolean()}notEqualAny(e){const t=Array.isArray(e)?new ei(e.map(q),"notEqualAny"):e;return new k("not_equal_any",[this,t],"notEqualAny").asBoolean()}exists(){return new k("exists",[this],"exists").asBoolean()}charLength(){return new k("char_length",[this],"charLength")}like(e){return new k("like",[this,q(e)],"like").asBoolean()}regexContains(e){return new k("regex_contains",[this,q(e)],"regexContains").asBoolean()}regexFind(e){return new k("regex_find",[this,q(e)],"regexFind")}regexFindAll(e){return new k("regex_find_all",[this,q(e)],"regexFindAll")}regexMatch(e){return new k("regex_match",[this,q(e)],"regexMatch").asBoolean()}stringContains(e){return new k("string_contains",[this,q(e)],"stringContains").asBoolean()}startsWith(e){return new k("starts_with",[this,q(e)],"startsWith").asBoolean()}endsWith(e){return new k("ends_with",[this,q(e)],"endsWith").asBoolean()}toLower(){return new k("to_lower",[this],"toLower")}toUpper(){return new k("to_upper",[this],"toUpper")}trim(e){const t=[this];return e&&t.push(q(e)),new k("trim",t,"trim")}ltrim(e){const t=[this];return e&&t.push(q(e)),new k("ltrim",t,"ltrim")}rtrim(e){const t=[this];return e&&t.push(q(e)),new k("rtrim",t,"rtrim")}type(){return new k("type",[this])}isType(e){return new k("is_type",[this,Si(e)],"isType").asBoolean()}stringConcat(e,...t){const n=[e,...t].map(q);return new k("string_concat",[this,...n],"stringConcat")}stringIndexOf(e){return new k("string_index_of",[this,q(e)],"stringIndexOf")}stringRepeat(e){return new k("string_repeat",[this,q(e)],"stringRepeat")}stringReplaceAll(e,t){return new k("string_replace_all",[this,q(e),q(t)],"stringReplaceAll")}stringReplaceOne(e,t){return new k("string_replace_one",[this,q(e),q(t)],"stringReplaceOne")}concat(e,...t){const n=[e,...t].map(q);return new k("concat",[this,...n],"concat")}reverse(){return new k("reverse",[this],"reverse")}arrayFilter(e,t){return new k("array_filter",[this,q(e),t],"arrayFilter")}arrayTransform(e,t){return new k("array_transform",[this,q(e),t],"arrayTransform")}arrayTransformWithIndex(e,t,n){return new k("array_transform",[this,q(e),q(t),n],"arrayTransformWithIndex")}arraySlice(e,t){const n=[this,q(e)];return t!==void 0&&n.push(q(t)),new k("array_slice",n,"arraySlice")}arrayFirst(){return new k("array_first",[this],"arrayFirst")}arrayFirstN(e){return new k("array_first_n",[this,q(e)],"arrayFirstN")}arrayLast(){return new k("array_last",[this],"arrayLast")}arrayLastN(e){return new k("array_last_n",[this,q(e)],"arrayLastN")}arrayMaximum(){return new k("maximum",[this],"arrayMaximum")}arrayMaximumN(e){return new k("maximum_n",[this,q(e)],"arrayMaximumN")}arrayMinimum(){return new k("minimum",[this],"arrayMinimum")}arrayMinimumN(e){return new k("minimum_n",[this,q(e)],"arrayMinimumN")}arrayIndexOf(e){return new k("array_index_of",[this,q(e),q("first")],"arrayIndexOf")}arrayLastIndexOf(e){return new k("array_index_of",[this,q(e),q("last")],"arrayLastIndexOf")}arrayIndexOfAll(e){return new k("array_index_of_all",[this,q(e)],"arrayIndexOfAll")}byteLength(){return new k("byte_length",[this],"byteLength")}ceil(){return new k("ceil",[this])}floor(){return new k("floor",[this])}abs(){return new k("abs",[this])}exp(){return new k("exp",[this])}mapGet(e){return new k("map_get",[this,Si(e)],"mapGet")}mapSet(e,t,...n){const r=[this,q(e),q(t),...n.map(q)];return new k("map_set",r,"mapSet")}mapKeys(){return new k("map_keys",[this],"mapKeys")}mapValues(){return new k("map_values",[this],"mapValues")}mapEntries(){return new k("map_entries",[this],"mapEntries")}getField(e){return new k("get_field",[this,q(e)],"get_field")}count(){return St._create("count",[this],"count")}sum(){return St._create("sum",[this],"sum")}average(){return St._create("average",[this],"average")}minimum(){return St._create("minimum",[this],"minimum")}maximum(){return St._create("maximum",[this],"maximum")}first(){return St._create("first",[this],"first")}last(){return St._create("last",[this],"last")}arrayAgg(){return St._create("array_agg",[this],"arrayAgg")}arrayAggDistinct(){return St._create("array_agg_distinct",[this],"arrayAggDistinct")}countDistinct(){return St._create("count_distinct",[this],"countDistinct")}logicalMaximum(e,...t){const n=[e,...t];return new k("maximum",[this,...n.map(q)],"logicalMaximum")}logicalMinimum(e,...t){const n=[e,...t];return new k("minimum",[this,...n.map(q)],"minimum")}vectorLength(){return new k("vector_length",[this],"vectorLength")}cosineDistance(e){return new k("cosine_distance",[this,FB(e)],"cosineDistance")}dotProduct(e){return new k("dot_product",[this,FB(e)],"dotProduct")}euclideanDistance(e){return new k("euclidean_distance",[this,FB(e)],"euclideanDistance")}unixMicrosToTimestamp(){return new k("unix_micros_to_timestamp",[this],"unixMicrosToTimestamp")}timestampToUnixMicros(){return new k("timestamp_to_unix_micros",[this],"timestampToUnixMicros")}unixMillisToTimestamp(){return new k("unix_millis_to_timestamp",[this],"unixMillisToTimestamp")}timestampToUnixMillis(){return new k("timestamp_to_unix_millis",[this],"timestampToUnixMillis")}unixSecondsToTimestamp(){return new k("unix_seconds_to_timestamp",[this],"unixSecondsToTimestamp")}timestampToUnixSeconds(){return new k("timestamp_to_unix_seconds",[this],"timestampToUnixSeconds")}timestampAdd(e,t){return new k("timestamp_add",[this,q(e),q(t)],"timestampAdd")}timestampSubtract(e,t){return new k("timestamp_subtract",[this,q(e),q(t)],"timestampSubtract")}timestampDiff(e,t){return new k("timestamp_diff",[this,rc(e),q(t)],"timestampDiff")}timestampExtract(e,t){const n=[this,q(e)];return t&&n.push(q(t)),new k("timestamp_extract",n,"timestampExtract")}documentId(){return new k("document_id",[this],"documentId")}parent(){return new k("parent",[this],"parent")}substring(e,t){const n=q(e);return new k("substring",t===void 0?[this,n]:[this,n,q(t)],"substring")}arrayGet(e){return new k("array_get",[this,q(e)],"arrayGet")}isError(){return new k("is_error",[this],"isError").asBoolean()}ifError(e){const t=new k("if_error",[this,q(e)],"ifError");return e instanceof $n?t.asBoolean():t}isAbsent(){return new k("is_absent",[this],"isAbsent").asBoolean()}mapRemove(e){return new k("map_remove",[this,q(e)],"mapRemove")}mapMerge(e,...t){const n=q(e),r=t.map(q);return new k("map_merge",[this,n,...r],"mapMerge")}pow(e){return new k("pow",[this,q(e)])}trunc(e){return e===void 0?new k("trunc",[this]):new k("trunc",[this,q(e)],"trunc")}round(e){return e===void 0?new k("round",[this]):new k("round",[this,q(e)],"round")}collectionId(){return new k("collection_id",[this])}length(){return new k("length",[this])}ln(){return new k("ln",[this])}sqrt(){return new k("sqrt",[this])}stringReverse(){return new k("string_reverse",[this])}ifAbsent(e){return new k("if_absent",[this,q(e)],"ifAbsent")}ifNull(e){return new k("if_null",[this,q(e)],"ifNull")}coalesce(e,...t){return new k("coalesce",[this,q(e),...t.map(q)],"coalesce")}join(e){return new k("join",[this,q(e)],"join")}log10(){return new k("log10",[this])}arraySum(){return new k("sum",[this])}split(e){return new k("split",[this,q(e)])}timestampTruncate(e,t){const n=[this,q(e)];return t&&n.push(q(t)),new k("timestamp_trunc",n)}ascending(){return YT(this)}descending(){return $T(this)}as(e){return new jT(this,e,"as")}}class St{constructor(e,t){this.name=e,this.params=t,this.exprType="AggregateFunction",this._protoValueType="ProtoValue"}static _create(e,t,n){const r=new St(e,t);return r._methodName=n,r}as(e){return new JT(this,e,"as")}_toProto(e){return{functionValue:{name:this.name,args:this.params.map(t=>t._toProto(e))}}}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,this.params.forEach(t=>t._readUserData(e))}}class JT{constructor(e,t,n){this.aggregate=e,this.alias=t,this._methodName=n}_readUserData(e){this.aggregate._readUserData(e)}}class jT{constructor(e,t,n){this.expr=e,this.alias=t,this._methodName=n,this.exprType="AliasedExpression",this.selectable=!0}_readUserData(e){this.expr._readUserData(e)}}class ei extends Os{constructor(e,t){super(),this.cr=e,this._methodName=t,this.expressionType="ListOfExpressions"}_toProto(e){return{arrayValue:{values:this.cr.map(t=>t._toProto(e))}}}_readUserData(e){this.cr.forEach(t=>t._readUserData(e))}}class Dr extends Os{constructor(e,t){super(),this.fieldPath=e,this._methodName=t,this.expressionType="Field",this.selectable=!0}get _fieldPath(){return this.fieldPath}get fieldName(){return this.fieldPath.canonicalString()}get alias(){return this.fieldName}get expr(){return this}geoDistance(e){return new k("geo_distance",[this,q(e)],"geoDistance")}_toProto(e){return{fieldReferenceValue:this.fieldPath.canonicalString()}}_readUserData(e){}}function Mo(s){return KT(s,"field")}function KT(s,e){return new Dr(typeof s=="string"?Zt===s?BT()._internalPath:Yn("field",s):s._internalPath,e)}class yr extends Os{constructor(e,t){super(),this.value=e,this._methodName=t,this.expressionType="Constant"}static _fromProto(e){const t=new yr(e,void 0);return t._protoValue=e,t}_toProto(e){return W(this._protoValue!==void 0,237),this._protoValue}_getValue(){return this._protoValue}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,UT(this._protoValue)||(this._protoValue=En(this.value,e))}}function Si(s,e){return Hp(s,"constant")}function Hp(s,e){const t=new yr(s,e);return typeof s=="boolean"?new qp(t):t}class k extends Os{constructor(e,t,n,r){super(),this.name=e,this.params=t,this.expressionType="Function",this._optionsProto=void 0,n!==void 0&&(this._methodName=n),r!==void 0&&(this._options=r)}get _optionsUtil(){return new ht({})}_toProto(e){const t={functionValue:{name:this.name,args:this.params.map(n=>n._toProto(e))}};return this._optionsProto&&(t.functionValue.options=this._optionsProto),t}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,this.params.forEach(t=>t._readUserData(e)),this._options&&(this._optionsProto=this._optionsUtil.getOptionsProto(e,this._options))}}class $n extends Os{get _methodName(){return this._expr._methodName}countIf(){return St._create("count_if",[this],"countIf")}not(){return new k("not",[this],"not").asBoolean()}conditional(e,t){return new k("conditional",[this,e,t],"conditional")}ifError(e){const t=q(e),n=new k("if_error",[this,t],"ifError");return t instanceof $n?n.asBoolean():n}_toProto(e){return this._expr._toProto(e)}_readUserData(e){this._expr._readUserData(e)}}class Up extends $n{constructor(e){super(),this._expr=e,this.expressionType="Function"}}class qp extends $n{constructor(e){super(),this._expr=e,this.expressionType="Constant"}_getValue(){return this._expr._getValue()}}class zT extends $n{constructor(e){super(),this._expr=e,this.expressionType="Field"}}function QT(s,e){const t=[];for(const n in s)if(Object.prototype.hasOwnProperty.call(s,n)){const r=s[n];t.push(Si(n)),t.push(q(r))}return new k("map",t,"map")}function WT(s){return function(t,n){return new k("array",t.map(r=>q(r)),n)}(s,"array")}function YT(s){return new Jp(rc(s),"ascending","ascending")}function $T(s){return new Jp(rc(s),"descending","descending")}class Jp{constructor(e,t,n){this.expr=e,this.direction=t,this._methodName=n,this._protoValueType="ProtoValue"}_toProto(e){return{mapValue:{fields:{direction:Tp(this.direction),expression:this.expr._toProto(e)}}}}_readUserData(e){this.expr._readUserData(e)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xt{constructor(e){this.optionsProto=void 0,{rawOptions:this.rawOptions,...this.knownOptions}=e}_readUserData(e){this.optionsProto=this._optionsUtil.getOptionsProto(e,this.knownOptions,this.rawOptions)}_toProto(e){return{name:this._name,options:this.optionsProto}}}class jp extends xt{get _name(){return"add_fields"}get _optionsUtil(){return new ht({})}constructor(e,t){super(t),this.fields=e}_toProto(e){return{...super._toProto(e),args:[Ri(e,this.fields)]}}_readUserData(e){super._readUserData(e),Xn(this.fields,e)}}class Kp extends xt{get _name(){return"aggregate"}get _optionsUtil(){return new ht({})}constructor(e,t,n){super(n),this.groups=e,this.accumulators=t}_toProto(e){return{...super._toProto(e),args:[Ri(e,this.accumulators),Ri(e,this.groups)]}}_readUserData(e){super._readUserData(e),Xn(this.groups,e),Xn(this.accumulators,e)}}class zp extends xt{get _name(){return"distinct"}get _optionsUtil(){return new ht({})}constructor(e,t){super(t),this.groups=e}_toProto(e){return{...super._toProto(e),args:[Ri(e,this.groups)]}}_readUserData(e){super._readUserData(e),Xn(this.groups,e)}}class Na extends xt{get _name(){return"collection"}get _optionsUtil(){return new ht({forceIndex:{serverName:"force_index"}})}constructor(e,t){super(t),this.hr=e.startsWith("/")?e:"/"+e}_toProto(e){return{...super._toProto(e),args:[{referenceValue:this.hr}]}}_readUserData(e){super._readUserData(e)}}class Pa extends xt{get _name(){return"collection_group"}get _optionsUtil(){return new ht({forceIndex:{serverName:"force_index"}})}constructor(e,t){super(t),this.collectionId=e}_toProto(e){return{...super._toProto(e),args:[{referenceValue:""},{stringValue:this.collectionId}]}}_readUserData(e){super._readUserData(e)}}class ic extends xt{get _name(){return"database"}get _optionsUtil(){return new ht({})}_toProto(e){return{...super._toProto(e)}}_readUserData(e){super._readUserData(e)}}class oc extends xt{get _name(){return"documents"}get _optionsUtil(){return new ht({})}constructor(e,t){if(super(t),!e||e.length===0)throw new G(O.INVALID_ARGUMENT,"Empty document paths are not allowed in DocumentsSource");const n=e.map(i=>i.startsWith("/")?i:"/"+i),r=new Set(n);if(r.size!==n.length)throw new G(O.INVALID_ARGUMENT,"Duplicate document paths are not allowed in DocumentsSource");this.Tr=n,this.Pr=r}_toProto(e){return{...super._toProto(e),args:this.Tr.map(t=>({referenceValue:t}))}}_readUserData(e){super._readUserData(e)}}class Fa extends xt{get _name(){return"where"}get _optionsUtil(){return new ht({})}constructor(e,t){super(t),this.condition=e}_toProto(e){return{...super._toProto(e),args:[this.condition._toProto(e)]}}_readUserData(e){super._readUserData(e),Xn(this.condition,e)}}class Rs extends xt{get _name(){return"limit"}get _optionsUtil(){return new ht({})}constructor(e,t){W(!isNaN(e)&&e!==1/0&&e!==-1/0,34860),super(t),this.limit=e}_toProto(e){return{...super._toProto(e),args:[Da(e,this.limit)]}}}class Ff extends xt{get _name(){return"offset"}get _optionsUtil(){return new ht({})}constructor(e,t){super(t),this.offset=e}_toProto(e){return{...super._toProto(e),args:[Da(e,this.offset)]}}}class XT extends xt{get _name(){return"select"}get _optionsUtil(){return new ht({})}constructor(e,t){super(t),this.selections=e}_toProto(e){return{...super._toProto(e),args:[Ri(e,this.selections)]}}_readUserData(e){super._readUserData(e),Xn(this.selections,e)}}class hn extends xt{get _name(){return"sort"}get _optionsUtil(){return new ht({})}constructor(e,t){super(t),this.orderings=e}_toProto(e){return{...super._toProto(e),args:this.orderings.map(t=>t._toProto(e))}}_readUserData(e){super._readUserData(e),Xn(this.orderings,e)}}class ac extends xt{get _name(){return"replace_with"}get _optionsUtil(){return new ht({})}constructor(e,t){super(t),this.map=e}_toProto(e){return{...super._toProto(e),args:[this.map._toProto(e),Tp(ac.Ir)]}}_readUserData(e){super._readUserData(e),Xn(this.map,e)}}ac.Ir="full_replace";function Xn(s,e){return Gp(s)?s._readUserData(e):Array.isArray(s)?s.forEach(t=>t._readUserData(e)):s instanceof Map?s.forEach(t=>t._readUserData(e)):Object.values(s).forEach(t=>t._readUserData(e)),s}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class li{constructor(e,t,n,r){this._db=e,this.userDataReader=t,this._userDataWriter=n,this.stages=r}Vr(e,t){const n=this.userDataReader.createContext(3,e);return Gp(t)?t._readUserData(n):Array.isArray(t)?t.forEach(r=>r._readUserData(n)):t.forEach(r=>r._readUserData(n)),t}where(e){const t=this.stages.map(n=>n);return this.Vr("where",e),t.push(new Fa(e,{})),new li(this._db,this.userDataReader,this._userDataWriter,t)}limit(e){const t=this.stages.map(n=>n);return t.push(new Rs(e,{})),new li(this._db,this.userDataReader,this._userDataWriter,t)}sort(e,...t){const n=this.stages.map(r=>r);return"orderings"in e?n.push(new hn(this.Vr("sort",e.orderings),{})):n.push(new hn(this.Vr("sort",[e,...t]),{})),new li(this._db,this.userDataReader,this._userDataWriter,n)}dr(e){return{pipeline:{stages:this.stages.map(t=>t._toProto(e))}}}}// Copyright 2024 Google LLC* @license
class dt{constructor(e,t,n){this.serializer=e,this.stages=t,this.listenOptions=n,this.isCorePipeline=!0}getPipelineCollection(){return Oa(this)}getPipelineCollectionGroup(){return Bc(this)}getPipelineCollectionId(){return ZT(this)}getPipelineDocuments(){return hl(this)}getPipelineFlavor(){return function(t){let n="exact";return t.stages.forEach((r,i)=>{r._name!==zp.name&&r._name!==Kp.name||(n="keyless"),r._name===XT.name&&n==="exact"&&(n="augmented"),r._name===jp.name&&i<t.stages.length-1&&n==="exact"&&(n="augmented")}),n}(this)}getPipelineSourceType(){return Hn(this)}}function Hn(s){const e=s.stages[0];return e instanceof Na||e instanceof Pa||e instanceof ic||e instanceof oc?e._name:"unknown"}function Oa(s){if(Hn(s)==="collection")return s.stages[0].hr}function Bc(s){if(Hn(s)==="collection_group")return s.stages[0].collectionId}function ZT(s){switch(Hn(s)){case"collection":return Ce.fromString(Oa(s)).lastSegment();case"collection_group":return Bc(s);default:return}}function hl(s){if(Hn(s)==="documents")return s.stages[0].Tr}class T{constructor(e,t){this.type=e,this.value=t}static mr(){return new T("ERROR",void 0)}static pr(){return new T("UNSET",void 0)}static gr(){return new T("NULL",or)}static newValue(e){return Pt(e)?new T("NULL",or):function(n){return!!n&&"booleanValue"in n}(e)?new T("BOOLEAN",e):en(e)?new T("INT",e):ms(e)?new T("DOUBLE",e):function(n){return!!n&&"timestampValue"in n&&!!n.timestampValue}(e)?new T("TIMESTAMP",e):function(n){return!!n&&"stringValue"in n}(e)?new T("STRING",e):function(n){return!!n&&"bytesValue"in n}(e)?new T("BYTES",e):e.referenceValue?new T("REFERENCE",e):e.geoPointValue?new T("GEO_POINT",e):Br(e)?new T("ARRAY",e):Qo(e)?new T("VECTOR",e):Ds(e)?new T("MAP",e):new T("ERROR",void 0)}yr(){return this.type==="ERROR"||this.type==="UNSET"}wr(){return this.type==="NULL"}}function ci(s){if(!s.yr())return s.value}function Qp(s){return s instanceof $n?s._expr:s}function ee(s){if((s=Qp(s))instanceof Dr)return new eI(s);if(s instanceof yr)return new tI(s);if(s instanceof ei)return new nI(s);if(s instanceof k){if(s.name==="add")return new iI(s);if(s.name==="subtract")return new oI(s);if(s.name==="multiply")return new aI(s);if(s.name==="divide")return new BI(s);if(s.name==="mod")return new lI(s);if(s.name==="and")return new cI(s);if(s.name==="equal")return new yI(s);if(s.name==="not_equal")return new wI(s);if(s.name==="less_than")return new TI(s);if(s.name==="less_than_or_equal")return new II(s);if(s.name==="greater_than")return new AI(s);if(s.name==="greater_than_or_equal")return new vI(s);if(s.name==="array_concat")return new RI(s);if(s.name==="array_reverse")return new SI(s);if(s.name==="array_contains")return new bI(s);if(s.name==="array_contains_all")return new NI(s);if(s.name==="array_contains_any")return new PI(s);if(s.name==="array_length")return new FI(s);if(s.name==="array_element")return new OI(s);if(s.name==="equal_any")return new Wp(s);if(s.name==="not_equal_any")return new hI(s);if(s.name==="is_nan")return new fI(s);if(s.name==="is_not_nan")return new CI(s);if(s.name==="is_null")return new dI(s);if(s.name==="is_not_null")return new pI(s);if(s.name==="is_error")return new gI(s);if(s.name==="exists")return new mI(s);if(s.name==="not")return new La(s);if(s.name==="or")return new uI(s);if(s.name==="xor")return new lc(s);if(s.name==="conditional")return new _I(s);if(s.name==="maximum")return new EI(s);if(s.name==="minimum")return new DI(s);if(s.name==="reverse")return new LI(s);if(s.name==="replace_first")return new xI(s);if(s.name==="replace_all")return new kI(s);if(s.name==="char_length")return new VI(s);if(s.name==="byte_length")return new MI(s);if(s.name==="like")return new GI(s);if(s.name==="regex_contains")return new HI(s);if(s.name==="regex_match")return new UI(s);if(s.name==="string_contains")return new qI(s);if(s.name==="starts_with")return new JI(s);if(s.name==="ends_with")return new jI(s);if(s.name==="to_lower")return new KI(s);if(s.name==="to_upper")return new zI(s);if(s.name==="trim")return new QI(s);if(s.name==="string_concat")return new WI(s);if(s.name==="map_get")return new YI(s);if(s.name==="cosine_distance")return new $I(s);if(s.name==="dot_product")return new XI(s);if(s.name==="euclidean_distance")return new ZI(s);if(s.name==="vector_length")return new eA(s);if(s.name==="unix_micros_to_timestamp")return new iA(s);if(s.name==="timestamp_to_unix_micros")return new BA(s);if(s.name==="unix_millis_to_timestamp")return new oA(s);if(s.name==="timestamp_to_unix_millis")return new lA(s);if(s.name==="unix_seconds_to_timestamp")return new aA(s);if(s.name==="timestamp_to_unix_seconds")return new cA(s);if(s.name==="timestamp_add")return new uA(s);if(s.name==="timestamp_subtract")return new hA(s)}throw new Error(`Unknown Expr : ${s}`)}class eI{constructor(e){this.expr=e}evaluate(e,t){if(this.expr.fieldName===Zt)return T.newValue({referenceValue:vi(e.serializer,t.key)});if(this.expr.fieldName==="__update_time__")return T.newValue({timestampValue:Vo(e.serializer,t.version)});if(this.expr.fieldName==="__create_time__")return T.newValue({timestampValue:Vo(e.serializer,t.createTime)});const n=t.data.field(this.expr._fieldPath);return n?Gi(n)?T.newValue(function(i,o){if(i.serverTimestampBehavior==="estimate")return{timestampValue:Vo(i.serializer,ne.fromTimestamp(ir(o)))};if(i.serverTimestampBehavior==="previous"){const a=Hi(o);if(a)return a}return{nullValue:"NULL_VALUE"}}(e,n)):T.newValue(n):T.pr()}}class tI{constructor(e){this.expr=e}evaluate(e,t){return T.newValue(this.expr._getValue())}}class nI{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.cr.map(r=>ee(r).evaluate(e,t));return n.some(r=>r.yr())?T.mr():T.newValue({arrayValue:{values:n.map(r=>r.value)}})}}function rt(s){return ms(s)?Number(s.doubleValue):Number(s.integerValue)}function on(s){return BigInt(s.integerValue)}const sI=BigInt("0x7fffffffffffffff"),rI=-BigInt("0x8000000000000000");class Qi{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length>=2,24778);const n=ee(this.expr.params[0]).evaluate(e,t),r=ee(this.expr.params[1]).evaluate(e,t);let i=this.br(n,r);for(const o of this.expr.params.slice(2)){const a=ee(o).evaluate(e,t);i=this.br(i,a)}return i}br(e,t){if(e.yr()||t.yr())return T.mr();if(e.wr()||t.wr())return T.gr();const n=e.value,r=t.value;if(!ms(n)&&!en(n)||!ms(r)&&!en(r))return T.mr();if(ms(n)||ms(r)){const i=this.Sr(n,r);return i?T.newValue(i):T.mr()}if(en(n)&&en(r)){const i=this.vr(n,r);return i===void 0?T.mr():typeof i=="number"?T.newValue({doubleValue:i}):i<rI||i>sI?T.mr():T.newValue({integerValue:`${i}`})}return T.mr()}}function Dn(s,e){return je(s)!==je(e)?"TYPE_MISMATCH":At(s)||At(e)?"NOT_EQ":Pt(s)&&Pt(e)?"EQ":Pt(s)||Pt(e)?"NULL":Br(s)&&Br(e)?function(n,r){var o,a,l;if(((o=n.values)==null?void 0:o.length)!==((a=r.values)==null?void 0:a.length))return"NOT_EQ";let i=!1;for(let c=0;c<(((l=n.values)==null?void 0:l.length)??0);c++){const h=n.values[c],f=r.values[c];switch(Dn(h,f)){case"EQ":break;case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":i=!0;break;default:X(44609,{Dr:h,Cr:f})}}return i?"NULL":"EQ"}(s.arrayValue,e.arrayValue):Qo(s)&&Qo(e)||Ds(s)&&Ds(e)?function(n,r){const i=n.fields||{},o=r.fields||{};if(jo(i)!==jo(o))return"NOT_EQ";let a=!1;for(const l in i)if(i.hasOwnProperty(l)){if(o[l]===void 0)return"NOT_EQ";switch(Dn(i[l],o[l])){case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":a=!0}}return a?"NULL":"EQ"}(s.mapValue,e.mapValue):function(n,r){return Gt(n,r,{u:!1,i:!0,o:!0})}(s,e)?"EQ":"NOT_EQ"}class iI extends Qi{vr(e,t){return on(e)+on(t)}Sr(e,t){return{doubleValue:rt(e)+rt(t)}}}class oI extends Qi{constructor(e){super(e),this.expr=e}vr(e,t){return on(e)-on(t)}Sr(e,t){return{doubleValue:rt(e)-rt(t)}}}class aI extends Qi{constructor(e){super(e),this.expr=e}vr(e,t){return on(e)*on(t)}Sr(e,t){return{doubleValue:rt(e)*rt(t)}}}class BI extends Qi{constructor(e){super(e),this.expr=e}vr(e,t){const n=on(t);if(n!==BigInt(0))return on(e)/n}Sr(e,t){const n=rt(t);return n===0?{doubleValue:Ei(n)?Number.NEGATIVE_INFINITY:Number.POSITIVE_INFINITY}:{doubleValue:rt(e)/n}}}class lI extends Qi{constructor(e){super(e),this.expr=e}vr(e,t){const n=on(t);if(n!==BigInt(0))return on(e)%n}Sr(e,t){const n=rt(t);if(n!==0)return{doubleValue:rt(e)%n}}}class cI{constructor(e){this.expr=e}evaluate(e,t){var i;let n=!1,r=!1;for(const o of this.expr.params){const a=ee(o).evaluate(e,t);switch(a.type){case"BOOLEAN":if(!((i=a.value)!=null&&i.booleanValue))return T.newValue(et);break;case"NULL":r=!0;break;default:n=!0}}return n?T.mr():r?T.gr():T.newValue(Tt)}}class La{constructor(e){this.expr=e}evaluate(e,t){var r;W(this.expr.params.length===1,9634);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BOOLEAN":return T.newValue({booleanValue:!((r=n.value)!=null&&r.booleanValue)});case"NULL":return T.gr();default:return T.mr()}}}class uI{constructor(e){this.expr=e}evaluate(e,t){var i;let n=!1,r=!1;for(const o of this.expr.params){const a=ee(o).evaluate(e,t);switch(a.type){case"BOOLEAN":if((i=a.value)!=null&&i.booleanValue)return T.newValue(Tt);break;case"NULL":r=!0;break;default:n=!0}}return n?T.mr():r?T.gr():T.newValue(et)}}class lc{constructor(e){this.expr=e}evaluate(e,t){var i;let n=!1,r=!1;for(const o of this.expr.params){const a=ee(o).evaluate(e,t);switch(a.type){case"BOOLEAN":n=lc.xor(n,!!((i=a.value)!=null&&i.booleanValue));break;case"NULL":r=!0;break;default:return T.mr()}}return r?T.gr():T.newValue({booleanValue:n})}static xor(e,t){return(e||t)&&!(e&&t)}}class Wp{constructor(e){this.expr=e}evaluate(e,t){var o,a;W(this.expr.params.length===2,55094);let n=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"NULL":n=!0;break;case"ERROR":case"UNSET":return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return T.mr()}if(n)return T.gr();for(const l of((a=(o=i.value)==null?void 0:o.arrayValue)==null?void 0:a.values)??[])switch(Pt(r.value)&&Pt(l)?"EQ":Dn(r.value,l)){case"EQ":return T.newValue(Tt);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:X(44608,{value:r.value,candidate:l})}return n?T.gr():T.newValue(et)}}class hI{constructor(e){this.expr=e}evaluate(e,t){return new La(new k("not",[new k("equal_any",this.expr.params)])).evaluate(e,t)}}class fI{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===1,23322);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"INT":return T.newValue(et);case"DOUBLE":return T.newValue({booleanValue:isNaN(rt(n.value))});case"NULL":return T.gr();default:return T.mr()}}}class CI{constructor(e){this.expr=e}evaluate(e,t){return W(this.expr.params.length===1,50406),new La(new k("not",[new k("is_nan",this.expr.params)])).evaluate(e,t)}}class dI{constructor(e){this.expr=e}evaluate(e,t){switch(W(this.expr.params.length===1,23123),ee(this.expr.params[0]).evaluate(e,t).type){case"NULL":return T.newValue(Tt);case"UNSET":case"ERROR":return T.mr();default:return T.newValue(et)}}}class pI{constructor(e){this.expr=e}evaluate(e,t){return W(this.expr.params.length===1,23167),new La(new k("not",[new k("is_null",this.expr.params)])).evaluate(e,t)}}class gI{constructor(e){this.expr=e}evaluate(e,t){return W(this.expr.params.length===1,5228),ee(this.expr.params[0]).evaluate(e,t).type==="ERROR"?T.newValue(Tt):T.newValue(et)}}class mI{constructor(e){this.expr=e}evaluate(e,t){switch(W(this.expr.params.length===1,6877),ee(this.expr.params[0]).evaluate(e,t).type){case"ERROR":return T.mr();case"UNSET":return T.newValue(et);default:return T.newValue(Tt)}}}class _I{constructor(e){this.expr=e}evaluate(e,t){var r;W(this.expr.params.length===3,11706);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BOOLEAN":return(r=n.value)!=null&&r.booleanValue?ee(this.expr.params[1]).evaluate(e,t):ee(this.expr.params[2]).evaluate(e,t);case"NULL":return ee(this.expr.params[2]).evaluate(e,t);default:return T.mr()}}}class EI{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map(i=>ee(i).evaluate(e,t));let r;for(const i of n)switch(i.type){case"ERROR":case"UNSET":case"NULL":continue;default:r=r===void 0||It(i.value,r.value)>0?i:r}return r===void 0?T.gr():r}}class DI{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map(i=>ee(i).evaluate(e,t));let r;for(const i of n)switch(i.type){case"ERROR":case"UNSET":case"NULL":continue;default:r=r===void 0||It(i.value,r.value)<0?i:r}return r===void 0?T.gr():r}}class wr{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===2,31033,`${this.expr.name}() function should have exactly 2 params`);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"ERROR":case"UNSET":return T.mr()}const r=ee(this.expr.params[1]).evaluate(e,t);switch(r.type){case"ERROR":case"UNSET":return T.mr()}return this.Fr(n,r)}}class yI extends wr{constructor(e){super(e),this.expr=e}Fr(e,t){if(e.wr()&&t.wr())return T.newValue(Tt);if(e.wr()||t.wr()||At(e.value)||At(t.value)||je(e.value)!==je(t.value))return T.newValue(et);switch(Dn(e.value,t.value)){case"EQ":return T.newValue(Tt);case"NOT_EQ":return T.newValue(et);case"NULL":return T.gr();default:X(44615,{left:e,right:t})}}}class wI extends wr{constructor(e){super(e),this.expr=e}Fr(e,t){switch(Dn(e.value,t.value)){case"EQ":return T.newValue(et);case"NOT_EQ":case"TYPE_MISMATCH":return T.newValue(Tt);case"NULL":return T.gr();default:X(44614,{left:e,right:t})}}}class TI extends wr{constructor(e){super(e),this.expr=e}Fr(e,t){return je(e.value)!==je(t.value)||At(e.value)||At(t.value)?T.newValue(et):T.newValue({booleanValue:It(e.value,t.value)<0})}}class II extends wr{constructor(e){super(e),this.expr=e}Fr(e,t){return je(e.value)!==je(t.value)||At(e.value)||At(t.value)?T.newValue(et):Dn(e.value,t.value)==="EQ"?T.newValue(Tt):T.newValue({booleanValue:It(e.value,t.value)<0})}}class AI extends wr{constructor(e){super(e),this.expr=e}Fr(e,t){return je(e.value)!==je(t.value)||At(e.value)||At(t.value)?T.newValue(et):T.newValue({booleanValue:It(e.value,t.value)>0})}}class vI extends wr{constructor(e){super(e),this.expr=e}Fr(e,t){return je(e.value)!==je(t.value)||At(e.value)||At(t.value)?T.newValue(et):Dn(e.value,t.value)==="EQ"?T.newValue(Tt):T.newValue({booleanValue:It(e.value,t.value)>0})}}class RI{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class SI{constructor(e){this.expr=e}evaluate(e,t){var r;W(this.expr.params.length===1,216);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return T.gr();case"ARRAY":{const i=((r=n.value.arrayValue)==null?void 0:r.values)??[];return T.newValue({arrayValue:{values:[...i].reverse()}})}default:return T.mr()}}}class bI{constructor(e){this.expr=e}evaluate(e,t){return W(this.expr.params.length===2,52884),new Wp(new k("eq_any",[this.expr.params[1],this.expr.params[0]])).evaluate(e,t)}}class NI{constructor(e){this.expr=e}evaluate(e,t){var l,c,h,f;W(this.expr.params.length===2,1392);let n=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"ARRAY":break;case"NULL":n=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return T.mr()}if(n)return T.gr();const o=((c=(l=i.value)==null?void 0:l.arrayValue)==null?void 0:c.values)??[],a=((f=(h=r.value)==null?void 0:h.arrayValue)==null?void 0:f.values)??[];for(const d of o){let _=!1;n=!1;for(const y of a){switch(Pt(d)&&Pt(y)?"EQ":Dn(d,y)){case"EQ":_=!0;break;case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:X(44613,{value:y,search:d})}if(_)break}if(!_)return T.newValue(et)}return T.newValue(Tt)}}class PI{constructor(e){this.expr=e}evaluate(e,t){var l,c,h,f;W(this.expr.params.length===2,2680);let n=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"ARRAY":break;case"NULL":n=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return T.mr()}if(n)return T.gr();const o=((c=(l=i.value)==null?void 0:l.arrayValue)==null?void 0:c.values)??[],a=((f=(h=r.value)==null?void 0:h.arrayValue)==null?void 0:f.values)??[];for(const d of a)for(const _ of o)switch(Pt(d)&&Pt(_)?"EQ":Dn(d,_)){case"EQ":return T.newValue(Tt);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:X(60403,{value:d,search:_})}return n?T.gr():T.newValue(et)}}class FI{constructor(e){this.expr=e}evaluate(e,t){var r,i,o;W(this.expr.params.length===1,38605);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return T.gr();case"ARRAY":return T.newValue({integerValue:`${((o=(i=(r=n.value)==null?void 0:r.arrayValue)==null?void 0:i.values)==null?void 0:o.length)??0}`});default:return T.mr()}}}class OI{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class LI{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,1508);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return T.gr();case"BYTES":{const o=(r=n.value)==null?void 0:r.bytesValue;if(typeof o=="string"){const a=Je.fromBase64String(o).toUint8Array();return a.reverse(),T.newValue({bytesValue:Je.fromUint8Array(a).toBase64()})}return T.newValue({bytesValue:new Uint8Array(o).reverse()})}case"STRING":{const o=(i=n.value)==null?void 0:i.stringValue,a=new Intl.__PRIVATE_Segmenter(void 0,{granularity:"grapheme"}).segment(o),l=Array.from(a,c=>c.segment).reverse();return T.newValue({stringValue:l.join("")})}default:return T.mr()}}}class xI{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class kI{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class VI{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===1,19400);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return T.gr();case"STRING":{const r=function(o){let a=0;for(let l=0;l<o.length;l++){const c=o.codePointAt(l);if(c===void 0)return;if(c<=65535)if(c>=55296&&c<=57343)if(c<=56319){const h=o.codePointAt(l+1);h!==void 0&&h>=56320&&h<=57343?(a+=1,l++):a+=1}else a+=1;else a+=1;else{if(!(c<=1114111))return;a+=1,l++}}return a}(n.value.stringValue);return r===void 0?T.mr():T.newValue({integerValue:r})}default:return T.mr()}}}class MI{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,8486);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BYTES":{const o=(r=n.value)==null?void 0:r.bytesValue;return typeof o=="string"?T.newValue({integerValue:Je.fromBase64String(o).toUint8Array().length}):T.newValue({integerValue:new Uint8Array(o).length})}case"STRING":{const o=function(l){let c=0;for(let h=0;h<l.length;h++){const f=l.codePointAt(h);if(f===void 0)return;if(f>=55296&&f<=57343){if(!(f<=56319))return;{const d=l.codePointAt(h+1);if(d===void 0||!(d>=56320&&d<=57343))return;c+=4,h++}}else if(f<=127)c+=1;else if(f<=2047)c+=2;else if(f<=65535)c+=3;else{if(!(f<=1114111))return;c+=4,h++}}return c}((i=n.value)==null?void 0:i.stringValue);return o===void 0?T.mr():T.newValue({integerValue:o})}case"NULL":return T.gr();default:return T.mr()}}}class Tr{constructor(e){this.expr=e}evaluate(e,t){var o,a;W(this.expr.params.length===2,39773,`${this.expr.name}() function should have exactly two parameters`);let n=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"STRING":break;case"NULL":n=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"STRING":break;case"NULL":n=!0;break;default:return T.mr()}return n?T.gr():this.Or((o=r.value)==null?void 0:o.stringValue,(a=i.value)==null?void 0:a.stringValue)}}class GI extends Tr{Or(e,t){try{const n=function(o){let a="";for(let l=0;l<o.length;l++){const c=o.charAt(l);switch(c){case"_":a+=".";break;case"%":a+=".*";break;case"\\":case".":case"*":case"?":case"+":case"^":case"$":case"|":case"(":case")":case"[":case"]":case"{":case"}":a+="\\"+c;break;default:a+=c}}return"^"+a+"$"}(t),r=Gl.compile(n);return T.newValue({booleanValue:r.matches(e)})}catch(n){return Kt(`Invalid LIKE pattern converted to regex: ${t}, returning error. Error: ${n}`),T.mr()}}}class HI extends Tr{Or(e,t){try{const n=Gl.compile(t);return T.newValue({booleanValue:n.test(e)})}catch{return Kt(`Invalid regex pattern found in regex_contains: ${t}, returning error`),T.mr()}}}class UI extends Tr{Or(e,t){try{return T.newValue({booleanValue:Gl.compile(t).matches(e)})}catch{return Kt(`Invalid regex pattern found in regex_match: ${t}, returning error`),T.mr()}}}class qI extends Tr{Or(e,t){return T.newValue({booleanValue:e.includes(t)})}}class JI extends Tr{Or(e,t){return T.newValue({booleanValue:e.startsWith(t)})}}class jI extends Tr{Or(e,t){return T.newValue({booleanValue:e.endsWith(t)})}}class KI{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,29079);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return T.newValue({stringValue:(i=(r=n.value)==null?void 0:r.stringValue)==null?void 0:i.toLowerCase()});case"NULL":return T.gr();default:return T.mr()}}}class zI{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,60487);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return T.newValue({stringValue:(i=(r=n.value)==null?void 0:r.stringValue)==null?void 0:i.toUpperCase()});case"NULL":return T.gr();default:return T.mr()}}}class QI{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,28544);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return T.newValue({stringValue:(i=(r=n.value)==null?void 0:r.stringValue)==null?void 0:i.trim()});case"NULL":return T.gr();default:return T.mr()}}}class WI{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map(o=>ee(o).evaluate(e,t));let r="",i=!1;for(const o of n)switch(o.type){case"STRING":r+=o.value.stringValue;break;case"NULL":i=!0;break;default:return T.mr()}return i?T.gr():T.newValue({stringValue:r})}}class YI{constructor(e){this.expr=e}evaluate(e,t){var o,a,l,c;W(this.expr.params.length===2,4483);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"UNSET":return T.pr();case"MAP":break;default:return T.mr()}const r=ee(this.expr.params[1]).evaluate(e,t);if(r.type!=="STRING")return T.mr();const i=(c=(a=(o=n.value)==null?void 0:o.mapValue)==null?void 0:a.fields)==null?void 0:c[(l=r.value)==null?void 0:l.stringValue];return i===void 0?T.pr():T.newValue(i)}}class cc{constructor(e){this.expr=e}evaluate(e,t){var c,h;W(this.expr.params.length===2,25231,`${this.expr.name}() function should have exactly 2 params`);let n=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"VECTOR":break;case"NULL":n=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"VECTOR":break;case"NULL":n=!0;break;default:return T.mr()}if(n)return T.gr();const o=il(r.value),a=il(i.value);if(o===void 0||a===void 0||((c=o.values)==null?void 0:c.length)!==((h=a.values)==null?void 0:h.length))return T.mr();const l=this.Mr(o,a);return l===void 0||isNaN(l)?T.mr():T.newValue({doubleValue:l})}}class $I extends cc{Mr(e,t){const n=(e==null?void 0:e.values)??[],r=(t==null?void 0:t.values)??[];if(n.length===0)return;let i=0,o=0,a=0;for(let c=0;c<n.length;c++){if(!Qn(n[c])||!Qn(r[c]))return;const h=rt(n[c]),f=rt(r[c]);i+=h*f,o+=h*h,a+=f*f}const l=Math.sqrt(o)*Math.sqrt(a);if(l!==0)return 1-Math.max(-1,Math.min(1,i/l))}}class XI extends cc{Mr(e,t){const n=(e==null?void 0:e.values)??[],r=(t==null?void 0:t.values)??[];if(n.length===0)return 0;let i=0;for(let o=0;o<n.length;o++){if(!Qn(n[o])||!Qn(r[o]))return;i+=rt(n[o])*rt(r[o])}return i}}class ZI extends cc{Mr(e,t){const n=(e==null?void 0:e.values)??[],r=(t==null?void 0:t.values)??[];if(n.length===0)return 0;let i=0;for(let o=0;o<n.length;o++){if(!Qn(n[o])||!Qn(r[o]))return;const a=rt(n[o]),l=rt(r[o]);i+=Math.pow(a-l,2)}return Math.sqrt(i)}}class eA{constructor(e){this.expr=e}evaluate(e,t){var r;W(this.expr.params.length===1,39044);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"VECTOR":{const i=il(n.value);return T.newValue({integerValue:((r=i==null?void 0:i.values)==null?void 0:r.length)??0})}case"NULL":return T.gr();default:return T.mr()}}}const bi=BigInt(-62135596800),Ni=BigInt(253402300799),ea=BigInt(1e3),Un=BigInt(1e6),tA=bi*ea,nA=Ni*ea+BigInt(999),sA=bi*Un,rA=Ni*Un+BigInt(999999);function uc(s){return s>=sA&&s<=rA}function Yp(s){return s>=bi&&s<=Ni}function Pi(s,e){const t=BigInt(s);return!(t<bi||t>Ni)&&!(e<0||e>=1e9)&&(t!==bi||e===0)&&!(t===Ni&&e>999999999)}function $p(s,e){return e<0?{seconds:s-1,nanos:e+1e9}:{seconds:s,nanos:e}}function hc(s){return BigInt(s.seconds)*Un+BigInt(Math.trunc(s.nanoseconds/1e3))}class fc{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===1,49262,`${this.expr.name}() function should have exactly one parameter`);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"INT":return this.toTimestamp(BigInt(n.value.integerValue));case"NULL":return T.gr();default:return T.mr()}}}class iA extends fc{toTimestamp(e){if(!uc(e))return T.mr();let t=Number(e/Un),n=Number(e%Un*BigInt(1e3));const r=$p(t,n);return t=r.seconds,n=r.nanos,Pi(t,n)?T.newValue({timestampValue:{seconds:t,nanos:n}}):T.mr()}}class oA extends fc{toTimestamp(e){if(!function(o){return o>=tA&&o<=nA}(e))return T.mr();let t=Number(e/ea),n=Number(e%ea*BigInt(1e6));const r=$p(t,n);return t=r.seconds,n=r.nanos,Pi(t,n)?T.newValue({timestampValue:{seconds:t,nanos:n}}):T.mr()}}class aA extends fc{toTimestamp(e){if(!Yp(e))return T.mr();const t=Number(e);return T.newValue({timestampValue:{seconds:t,nanos:0}})}}class Cc{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===1,1265,`${this.expr.name}() function should have exactly one parameter`);const n=ee(this.expr.params[0]).evaluate(e,t);switch(n.type){case"TIMESTAMP":break;case"NULL":return T.gr();default:return T.mr()}const r=Yl(n.value.timestampValue);return Pi(r.seconds,r.nanoseconds)?this.Nr(r):T.mr()}}class BA extends Cc{Nr(e){const t=hc(e);return uc(t)?T.newValue({integerValue:`${t.toString()}`}):T.mr()}}class lA extends Cc{Nr(e){const t=hc(e),n=t/BigInt(1e3),r=t%BigInt(1e3);return n>BigInt(0)||r===BigInt(0)?T.newValue({integerValue:n.toString()}):T.newValue({integerValue:(n-BigInt(1)).toString()})}}class cA extends Cc{Nr(e){const t=BigInt(e.seconds);return Yp(t)?T.newValue({integerValue:t.toString()}):T.mr()}}class Xp{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===3,2775,`${this.expr.name}() function should have exactly 3 parameters`);let n=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"TIMESTAMP":break;case"NULL":n=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);let o;switch(i.type){case"STRING":if(o=function(te){switch(te){case"microsecond":return"microsecond";case"millisecond":return"millisecond";case"second":return"second";case"minute":return"minute";case"hour":return"hour";case"day":return"day";default:return}}(i.value.stringValue),o===void 0)return T.mr();break;case"NULL":n=!0;break;default:return T.mr()}const a=ee(this.expr.params[2]).evaluate(e,t);switch(a.type){case"INT":break;case"NULL":n=!0;break;default:return T.mr()}if(n)return T.gr();const l=BigInt(a.value.integerValue);let c;try{switch(o){case"microsecond":c=l;break;case"millisecond":c=l*BigInt(1e3);break;case"second":c=l*BigInt(1e6);break;case"minute":c=l*BigInt(6e7);break;case"hour":c=l*BigInt(36e8);break;case"day":c=l*BigInt(864e8);break;default:return T.mr()}if(o!=="microsecond"&&l!==BigInt(0)&&c/l!==BigInt(this.Lr(o)))return T.mr()}catch(J){return Kt(`Error during timestamp arithmetic: ${J}`),T.mr()}const h=Yl(r.value.timestampValue);if(!Pi(h.seconds,h.nanoseconds))return T.mr();const f=hc(h),d=this.Br(f,c);if(!uc(d))return T.mr();const _=Number(d/Un),y=d%Un,N=Number((y<0?y+Un:y)*BigInt(1e3)),F=y<0?_-1:_;return Pi(F,N)?T.newValue({timestampValue:{seconds:F,nanos:N}}):T.mr()}Lr(e){switch(e){case"millisecond":return 1e3;case"second":return 1e6;case"minute":return 6e7;case"hour":return 36e8;case"day":return 864e8;default:return 1}}}class uA extends Xp{Br(e,t){return e+t}}class hA extends Xp{Br(e,t){return e-t}}function Fi(s){if((s=Qp(s))instanceof Dr)return`fld(${s.fieldName})`;if(s instanceof yr)return`cst(${function(t){return t===null?"null":typeof t=="number"?t.toString():typeof t=="string"?`"${t}"`:t instanceof Ne?`ref(${t.path})`:t instanceof wt?`vec(${JSON.stringify(t)})`:JSON.stringify(t)}(s.value)})`;if(s instanceof k)return`fn(${s.name},[${s.params.map(Fi).join(",")}])`;if(s.expressionType==="ListOfExpressions")return`list([${s.cr.map(Fi).join(",")}])`;throw new Error(`Unrecognized expr ${JSON.stringify(s,null,2)}`)}function fA(s){if(s instanceof jp)return`${s._name}(${bo(s.fields)})`;if(s instanceof Kp){let e=`${s._name}(${bo(s.accumulators)})`;return s.groups.size>0&&(e+=`grouping(${bo(s.groups)})`),e}if(s instanceof zp)return`${s._name}(${bo(s.groups)})`;if(s instanceof Na)return`${s._name}(${s.hr})`;if(s instanceof Pa)return`${s._name}(${s.collectionId})`;if(s instanceof ic)return`${s._name}()`;if(s instanceof oc)return`${s._name}(${s.Tr.sort()})`;if(s instanceof Fa)return`${s._name}(${Fi(s.condition)})`;if(s instanceof Rs)return`${s._name}(${s.limit})`;if(s instanceof hn)return`${s._name}(${function(t){return t.map(n=>`${Fi(n.expr)}${n.direction}`).join(",")}(s.orderings)})`;throw new Error(`Unrecognized stage ${s._name}`)}function bo(s){return`${Array.from(s.entries()).sort().map(([e,t])=>`${e}=${Fi(t)}`).join(",")}`}function dn(s){return s.stages.map(e=>fA(e)).join("|")}function Zp(s,e){return dn(s)===dn(e)}function ze(s){return s instanceof dt}function Of(s){return ze(s)?dn(s):ii(s)}function eg(s){return ze(s)?dn(s):function(t){return`${sp(sn(t))}|lt:${t.limitType}`}(s)}function xa(s,e){return s instanceof dt&&e instanceof dt?Zp(s,e):!(s instanceof dt&&!(e instanceof dt)||!(s instanceof dt)&&e instanceof dt)&&Ow(s,e)}function tg(s){return ds(s)?dn(s):sp(s)}function ng(s,e){return s instanceof dt&&e instanceof dt?Zp(s,e):!(s instanceof dt&&!(e instanceof dt)||!(s instanceof dt)&&e instanceof dt)&&rp(s,e)}function CA(s,e){const t=function(r){let i=!1;const o=[];for(const a of r)if(a instanceof hn)if(i=!0,a.orderings.some(l=>l.expr instanceof Dr&&l.expr.fieldName===Zt))o.push(a);else{const l=a.orderings.map(c=>c);l.push(Mo(Zt).ascending()),o.push(new hn(l,{}))}else a instanceof Rs&&(i||(o.push(new hn([Mo(Zt).ascending()],{})),i=!0)),o.push(a);return i||o.push(new hn([Mo(Zt).ascending()],{})),o}(s.stages);if(s.userDataReader){const n=s.userDataReader.createContext(3,"toCorePipeline");t.forEach(r=>r._readUserData(n))}return new dt(s.userDataReader.serializer,t,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dA{constructor(e,t,n,r){this.batchId=e,this.localWriteTime=t,this.baseMutations=n,this.mutations=r}applyToRemoteDocument(e,t){const n=t.mutationResults;for(let r=0;r<this.mutations.length;r++){const i=this.mutations[r];i.key.isEqual(e.key)&&fw(i,e,n[r])}}applyToLocalView(e,t){for(const n of this.baseMutations)n.key.isEqual(e.key)&&(t=ri(n,e,t,this.localWriteTime));for(const n of this.mutations)n.key.isEqual(e.key)&&(t=ri(n,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const n=up();return this.mutations.forEach(r=>{const i=e.get(r.key),o=i.overlayedDocument;let a=this.applyToLocalView(o,i.mutatedFields);a=t.has(r.key)?null:a;const l=Qd(o,a);l!==null&&n.set(r.key,l),o.isValidDocument()||o.convertToNoDocument(ne.min())}),n}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),oe())}isEqual(e){return this.batchId===e.batchId&&rr(this.mutations,e.mutations,(t,n)=>uf(t,n))&&rr(this.baseMutations,e.baseMutations,(t,n)=>uf(t,n))}}class dc{constructor(e,t,n,r){this.batch=e,this.commitVersion=t,this.mutationResults=n,this.docVersions=r}static from(e,t,n){W(e.mutations.length===n.length,58842,{Ur:e.mutations.length,kr:n.length});let r=function(){return Vw}();const i=e.mutations;for(let o=0;o<i.length;o++)r=r.insert(i[o].key,n[o].version);return new dc(e,t,n,r)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sg="";function pA(s){let e="";for(let t=0;t<s.length;t++)e.length>0&&(e=Lf(e)),e=gA(s.get(t),e);return Lf(e)}function gA(s,e){let t=e;const n=s.length;for(let r=0;r<n;r++){const i=s.charAt(r);switch(i){case"\0":t+="";break;case sg:t+="";break;default:t+=i}}return t}function Lf(s){return s+sg+""}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mA{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fn{constructor(e,t,n,r,i=ne.min(),o=ne.min(),a=Je.EMPTY_BYTE_STRING,l=null){this.target=e,this.targetId=t,this.purpose=n,this.sequenceNumber=r,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=a,this.expectedCount=l}withSequenceNumber(e){return new fn(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new fn(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new fn(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new fn(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _A{constructor(e){this.$r=e}}function EA(s){const e=tT({parent:s.parent,structuredQuery:s.structuredQuery});return s.limitType==="LAST"?Xo(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class DA{constructor(){this.Zi=new yA}addToCollectionParentIndex(e,t){return this.Zi.add(t),V.resolve()}getCollectionParents(e,t){return V.resolve(this.Zi.getEntries(t))}addFieldIndex(e,t){return V.resolve()}deleteFieldIndex(e,t){return V.resolve()}deleteAllFieldIndexes(e){return V.resolve()}createTargetIndexes(e,t){return V.resolve()}getDocumentsMatchingTarget(e,t){return V.resolve(null)}getIndexType(e,t){return V.resolve(0)}getFieldIndexes(e,t){return V.resolve([])}getNextCollectionGroupToUpdate(e){return V.resolve(null)}getMinOffset(e,t){return V.resolve(Wn.min())}getMinOffsetFromCollectionGroup(e,t){return V.resolve(Wn.min())}updateCollectionGroup(e,t,n){return V.resolve()}updateIndexEntries(e,t){return V.resolve()}}class yA{constructor(){this.index={}}add(e){const t=e.lastSegment(),n=e.popLast(),r=this.index[t]||new Ue(Ce.comparator),i=!r.has(n);return this.index[t]=r.add(n),i}has(e){const t=e.lastSegment(),n=e.popLast(),r=this.index[t];return r&&r.has(n)}getEntries(e){return(this.index[e]||new Ue(Ce.comparator)).toArray()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zn{constructor(e){this.ys=e}next(){return this.ys+=2,this.ys}static ws(){return new Zn(0)}static bs(){return new Zn(-1)}}// Copyright 2024 Google LLC* @license
function rg(s,e){var n;let t=e;for(const r of s.stages)t=TA({serializer:s.serializer,serverTimestampBehavior:(n=s.listenOptions)==null?void 0:n.serverTimestampBehavior},r,t);return t}function ka(s,e){return rg(s,[e]).length>0}function wA(s,e){return ze(s)?ka(s,e):Aa(s,e)}function TA(s,e,t){if(e instanceof Na)return function(r,i,o){return o.filter(a=>a.isFoundDocument()&&`/${a.key.getCollectionPath().canonicalString()}`===i.hr)}(0,e,t);if(e instanceof Fa)return function(r,i,o){return o.filter(a=>{const l=ci(ee(i.condition).evaluate(r,a));return l!==void 0&&Gt(l,Tt)})}(s,e,t);if(e instanceof Pa)return function(r,i,o){return o.filter(a=>a.isFoundDocument()&&a.key.getCollectionPath().lastSegment()===i.collectionId)}(0,e,t);if(e instanceof ic)return function(r,i,o){return o.filter(a=>a.isFoundDocument())}(0,0,t);if(e instanceof oc)return function(r,i,o){return o.filter(a=>a.isFoundDocument()&&i.Pr.has(a.key.path.toStringWithLeadingSlash()))}(0,e,t);if(e instanceof Rs)return function(r,i,o){return o.slice(0,i.limit)}(0,e,t);if(e instanceof hn)return function(r,i,o){const a=i.orderings.map(l=>({Ms:ee(l.expr),direction:l.direction}));return[...o].sort((l,c)=>{for(const{Ms:h,direction:f}of a){const d=ci(h.evaluate(r,l)),_=ci(h.evaluate(r,c)),y=It(d??or,_??or);if(y!==0)return f==="ascending"?y:-y}return 0})}(s,e,t);throw new Error(`Unknown stage: ${e._name}`)}function fl(s){const e=function(n){for(let r=n.stages.length-1;r>=0;r--){const i=n.stages[r];if(i instanceof hn)return i.orderings}throw new Error("Pipeline must contain at least one Sort stage")}(s);return(t,n)=>{for(const r of e){const i=ci(ee(r.expr).evaluate({serializer:s.serializer},t)),o=ci(ee(r.expr).evaluate({serializer:s.serializer},n)),a=It(i||or,o||or);if(a!==0)return r.direction==="ascending"?a:-a}return 0}}function OB(s){for(let e=s.stages.length-1;e>=0;e--){const t=s.stages[e];if(t instanceof Rs)return{limit:t.limit}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IA{constructor(){this.changes=new Fs(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Xe.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const n=this.changes.get(t);return n!==void 0?V.resolve(n):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class AA{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vA{constructor(e,t,n,r){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=n,this.indexManager=r}getDocument(e,t){let n=null;return this.documentOverlayCache.getOverlay(e,t).next(r=>(n=r,this.remoteDocumentCache.getEntry(e,t))).next(r=>(n!==null&&ri(n.mutation,r,Nt.empty(),_e.now()),r))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(n=>this.getLocalViewOfDocuments(e,n,oe()).next(()=>n))}getLocalViewOfDocuments(e,t,n=oe()){const r=On();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,n).next(i=>{let o=zs();return i.forEach((a,l)=>{o=o.insert(a,l.overlayedDocument)}),o}))}getOverlayedDocuments(e,t){const n=On();return this.populateOverlays(e,n,t).next(()=>this.computeViews(e,t,n,oe()))}populateOverlays(e,t,n){const r=[];return n.forEach(i=>{t.has(i)||r.push(i)}),this.documentOverlayCache.getOverlays(e,r).next(i=>{i.forEach((o,a)=>{t.set(o,a)})})}computeViews(e,t,n,r){let i=Dt();const o=oi(),a=function(){return oi()}();return t.forEach((l,c)=>{const h=n.get(c.key);r.has(c.key)&&(h===void 0||h.mutation instanceof rs)?i=i.insert(c.key,c):h!==void 0?(o.set(c.key,h.mutation.getFieldMask()),ri(h.mutation,c,h.mutation.getFieldMask(),_e.now())):o.set(c.key,Nt.empty())}),this.recalculateAndSaveOverlays(e,i).next(l=>(l.forEach((c,h)=>o.set(c,h)),t.forEach((c,h)=>a.set(c,new AA(h,o.get(c)??null))),a))}recalculateAndSaveOverlays(e,t){const n=oi();let r=new ke((o,a)=>o-a),i=oe();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(o=>{for(const a of o)a.keys().forEach(l=>{const c=t.get(l);if(c===null)return;let h=n.get(l)||Nt.empty();h=a.applyToLocalView(c,h),n.set(l,h);const f=(r.get(a.batchId)||oe()).add(l);r=r.insert(a.batchId,f)})}).next(()=>{const o=[],a=r.getReverseIterator();for(;a.hasNext();){const l=a.getNext(),c=l.key,h=l.value,f=up();h.forEach(d=>{if(!i.has(d)){const _=Qd(t.get(d),n.get(d));_!==null&&f.set(d,_),i=i.add(d)}}),o.push(this.documentOverlayCache.saveOverlays(e,c,f))}return V.waitFor(o)}).next(()=>n)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(n=>this.recalculateAndSaveOverlays(e,n))}getDocumentsMatchingQuery(e,t,n,r){return ze(t)?this.getDocumentsMatchingPipeline(e,t,n,r):Sw(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):zl(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,n,r):this.getDocumentsMatchingCollectionQuery(e,t,n,r)}getNextDocuments(e,t,n,r){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,n,r).next(i=>{const o=r-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,n.largestBatchId,r-i.size):V.resolve(On());let a=Ai,l=i;return o.next(c=>V.forEach(c,(h,f)=>(a<f.largestBatchId&&(a=f.largestBatchId),i.get(h)?V.resolve():this.remoteDocumentCache.getEntry(e,h).next(d=>{l=l.insert(h,d)}))).next(()=>this.populateOverlays(e,c,i)).next(()=>this.computeViews(e,l,c,oe())).next(h=>({batchId:a,changes:cp(h)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new Y(t)).next(n=>{let r=zs();return n.isFoundDocument()&&(r=r.insert(n.key,n)),r})}getDocumentsMatchingCollectionGroupQuery(e,t,n,r){const i=t.collectionGroup;let o=zs();return this.indexManager.getCollectionParents(e,i).next(a=>V.forEach(a,l=>{const c=function(f,d){return new is(d,null,f.explicitOrderBy.slice(),f.filters.slice(),f.limit,f.limitType,f.startAt,f.endAt)}(t,l.child(i));return this.getDocumentsMatchingCollectionQuery(e,c,n,r).next(h=>{h.forEach((f,d)=>{o=o.insert(f,d)})})}).next(()=>o))}getDocumentsMatchingCollectionQuery(e,t,n,r){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,n.largestBatchId).next(o=>(i=o,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,i,r))).next(o=>this.retrieveMatchingLocalDocuments(i,o,a=>Aa(t,a)))}getDocumentsMatchingPipeline(e,t,n,r){if(Hn(t)==="collection_group"){const i=Bc(t);let o=zs();return this.indexManager.getCollectionParents(e,i).next(a=>V.forEach(a,l=>{const c=function(f,d){const _=f.stages.map(y=>y instanceof Pa?new Na(d.canonicalString(),{}):y);return new dt(f.serializer,_)}(t,l.child(i));return this.getDocumentsMatchingPipeline(e,c,n,r).next(h=>{h.forEach((f,d)=>{o=o.insert(f,d)})})}).next(()=>o))}{let i;return this.getOverlaysForPipeline(e,t,n.largestBatchId).next(o=>{switch(i=o,Hn(t)){case"collection":return this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,i,r);case"documents":let a=oe();for(const l of hl(t))a=a.add(Y.fromPath(l));return this.remoteDocumentCache.getEntries(e,a);case"database":return this.remoteDocumentCache.getAllEntries(e);default:throw new G("invalid-argument",`Invalid pipeline source to execute offline: ${dn(t)}`)}}).next(o=>this.retrieveMatchingLocalDocuments(i,o,a=>ka(t,a)))}}retrieveMatchingLocalDocuments(e,t,n){e.forEach((i,o)=>{const a=o.getKey();t.get(a)===null&&(t=t.insert(a,Xe.newInvalidDocument(a)))});let r=zs();return t.forEach((i,o)=>{const a=e.get(i);a!==void 0&&ri(a.mutation,o,Nt.empty(),_e.now()),n(o)&&(r=r.insert(i,o))}),r}getOverlaysForPipeline(e,t,n){switch(Hn(t)){case"collection":return this.documentOverlayCache.getOverlaysForCollection(e,Ce.fromString(Oa(t)),n);case"collection_group":throw new G("invalid-argument",`Unexpected collection group pipeline: ${dn(t)}`);case"documents":return this.documentOverlayCache.getOverlays(e,hl(t).map(r=>Y.fromPath(r)));case"database":return this.documentOverlayCache.getAllOverlays(e,n);default:throw new G("invalid-argument",`Failed to get overlays for pipeline: ${dn(t)}`)}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class RA{constructor(e){this.serializer=e,this.Qs=new Map,this.Ws=new Map}getBundleMetadata(e,t){return V.resolve(this.Qs.get(t))}saveBundleMetadata(e,t){return this.Qs.set(t.id,function(r){return{id:r.id,version:r.version,createTime:Ot(r.createTime)}}(t)),V.resolve()}getNamedQuery(e,t){return V.resolve(this.Ws.get(t))}saveNamedQuery(e,t){return this.Ws.set(t.name,function(r){return{name:r.name,query:EA(r.bundledQuery),readTime:Ot(r.readTime)}}(t)),V.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SA{constructor(){this.overlays=new ke(Y.comparator),this.Gs=new Map}getOverlay(e,t){return V.resolve(this.overlays.get(t))}getOverlays(e,t){const n=On();return V.forEach(t,r=>this.getOverlay(e,r).next(i=>{i!==null&&n.set(r,i)})).next(()=>n)}getAllOverlays(e,t){const n=On();return this.overlays.forEach((r,i)=>{i.largestBatchId>t&&n.set(r,i)}),V.resolve(n)}saveOverlays(e,t,n){return n.forEach((r,i)=>{this.Zr(e,t,i)}),V.resolve()}removeOverlaysForBatchId(e,t,n){const r=this.Gs.get(n);return r!==void 0&&(r.forEach(i=>this.overlays=this.overlays.remove(i)),this.Gs.delete(n)),V.resolve()}getOverlaysForCollection(e,t,n){const r=On(),i=t.length+1,o=new Y(t.child("")),a=this.overlays.getIteratorFrom(o);for(;a.hasNext();){const l=a.getNext().value,c=l.getKey();if(!t.isPrefixOf(c.path))break;c.path.length===i&&l.largestBatchId>n&&r.set(l.getKey(),l)}return V.resolve(r)}getOverlaysForCollectionGroup(e,t,n,r){let i=new ke((c,h)=>c-h);const o=this.overlays.getIterator();for(;o.hasNext();){const c=o.getNext().value;if(c.getKey().getCollectionGroup()===t&&c.largestBatchId>n){let h=i.get(c.largestBatchId);h===null&&(h=On(),i=i.insert(c.largestBatchId,h)),h.set(c.getKey(),c)}}const a=On(),l=i.getIterator();for(;l.hasNext()&&(l.getNext().value.forEach((c,h)=>a.set(c,h)),!(a.size()>=r)););return V.resolve(a)}Zr(e,t,n){const r=this.overlays.get(n.key);if(r!==null){const o=this.Gs.get(r.largestBatchId).delete(n.key);this.Gs.set(r.largestBatchId,o)}this.overlays=this.overlays.insert(n.key,new mA(t,n));let i=this.Gs.get(t);i===void 0&&(i=oe(),this.Gs.set(t,i)),this.Gs.set(t,i.add(n.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bA{constructor(){this.sessionToken=Je.EMPTY_BYTE_STRING}getSessionToken(e){return V.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,V.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pc{constructor(){this.zs=new Ue(Ye.js),this.Hs=new Ue(Ye.Js)}isEmpty(){return this.zs.isEmpty()}addReference(e,t){const n=new Ye(e,t);this.zs=this.zs.add(n),this.Hs=this.Hs.add(n)}Ys(e,t){e.forEach(n=>this.addReference(n,t))}removeReference(e,t){this.Zs(new Ye(e,t))}Xs(e,t){e.forEach(n=>this.removeReference(n,t))}e_(e){const t=new Y(new Ce([])),n=new Ye(t,e),r=new Ye(t,e+1),i=[];return this.Hs.forEachInRange([n,r],o=>{this.Zs(o),i.push(o.key)}),i}t_(){this.zs.forEach(e=>this.Zs(e))}Zs(e){this.zs=this.zs.delete(e),this.Hs=this.Hs.delete(e)}n_(e){const t=new Y(new Ce([])),n=new Ye(t,e),r=new Ye(t,e+1);let i=oe();return this.Hs.forEachInRange([n,r],o=>{i=i.add(o.key)}),i}containsKey(e){const t=new Ye(e,0),n=this.zs.firstAfterOrEqual(t);return n!==null&&e.isEqual(n.key)}}class Ye{constructor(e,t){this.key=e,this.r_=t}static js(e,t){return Y.comparator(e.key,t.key)||ae(e.r_,t.r_)}static Js(e,t){return ae(e.r_,t.r_)||Y.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class NA{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Gr=1,this.i_=new Ue(Ye.js)}checkEmpty(e){return V.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,n,r){const i=this.Gr;this.Gr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new dA(i,t,n,r);this.mutationQueue.push(o);for(const a of r)this.i_=this.i_.add(new Ye(a.key,i)),this.indexManager.addToCollectionParentIndex(e,a.key.path.popLast());return V.resolve(o)}lookupMutationBatch(e,t){return V.resolve(this.s_(t))}getNextMutationBatchAfterBatchId(e,t){const n=t+1,r=this.__(n),i=r<0?0:r;return V.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return V.resolve(this.mutationQueue.length===0?ql:this.Gr-1)}getAllMutationBatches(e){return V.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const n=new Ye(t,0),r=new Ye(t,Number.POSITIVE_INFINITY),i=[];return this.i_.forEachInRange([n,r],o=>{const a=this.s_(o.r_);i.push(a)}),V.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let n=new Ue(ae);return t.forEach(r=>{const i=new Ye(r,0),o=new Ye(r,Number.POSITIVE_INFINITY);this.i_.forEachInRange([i,o],a=>{n=n.add(a.r_)})}),V.resolve(this.o_(n))}getAllMutationBatchesAffectingQuery(e,t){const n=t.path,r=n.length+1;let i=n;Y.isDocumentKey(i)||(i=i.child(""));const o=new Ye(new Y(i),0);let a=new Ue(ae);return this.i_.forEachWhile(l=>{const c=l.key.path;return!!n.isPrefixOf(c)&&(c.length===r&&(a=a.add(l.r_)),!0)},o),V.resolve(this.o_(a))}o_(e){const t=[];return e.forEach(n=>{const r=this.s_(n);r!==null&&t.push(r)}),t}removeMutationBatch(e,t){W(this.a_(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let n=this.i_;return V.forEach(t.mutations,r=>{const i=new Ye(r.key,t.batchId);return n=n.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,r.key)}).next(()=>{this.i_=n})}Hr(e){}containsKey(e,t){const n=new Ye(t,0),r=this.i_.firstAfterOrEqual(n);return V.resolve(t.isEqual(r&&r.key))}performConsistencyCheck(e){return this.mutationQueue.length,V.resolve()}a_(e,t){return this.__(e)}__(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}s_(e){const t=this.__(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PA{constructor(e){this.u_=e,this.docs=function(){return new ke(Y.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const n=t.key,r=this.docs.get(n),i=r?r.size:0,o=this.u_(t);return this.docs=this.docs.insert(n,{document:t.mutableCopy(),size:o}),this.size+=o-i,this.indexManager.addToCollectionParentIndex(e,n.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const n=this.docs.get(t);return V.resolve(n?n.document.mutableCopy():Xe.newInvalidDocument(t))}getEntries(e,t){let n=Dt();return t.forEach(r=>{const i=this.docs.get(r);n=n.insert(r,i?i.document.mutableCopy():Xe.newInvalidDocument(r))}),V.resolve(n)}getAllEntries(e){let t=Dt();return this.docs.forEach((n,r)=>{t=t.insert(n,r.document)}),V.resolve(t)}getDocumentsMatchingQuery(e,t,n,r){let i,o;ze(t)?(i=Ce.fromString(Oa(t)),o=h=>ka(t,h)):(i=t.path,o=h=>Aa(t,h));let a=Dt();const l=new Y(i.child("__id-9223372036854775808__")),c=this.docs.getIteratorFrom(l);for(;c.hasNext();){const{key:h,value:{document:f}}=c.getNext();if(!i.isPrefixOf(h.path))break;h.path.length>i.length+1||Aw(Iw(f),n)<=0||(r.has(f.key)||o(f))&&(a=a.insert(f.key,f.mutableCopy()))}return V.resolve(a)}getAllFromCollectionGroup(e,t,n,r){X(9500)}c_(e,t){return V.forEach(this.docs,n=>t(n))}newChangeBuffer(e){return new FA(this)}getSize(e){return V.resolve(this.size)}}class FA extends IA{constructor(e){super(),this.$s=e}applyChanges(e){const t=[];return this.changes.forEach((n,r)=>{r.isValidDocument()?t.push(this.$s.addEntry(e,r)):this.$s.removeEntry(n)}),V.waitFor(t)}getFromCache(e,t){return this.$s.getEntry(e,t)}getAllFromCache(e,t){return this.$s.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class OA{constructor(e){this.persistence=e,this.l_=new Fs(t=>tg(t),ng),this.lastRemoteSnapshotVersion=ne.min(),this.highestTargetId=0,this.E_=0,this.h_=new pc,this.targetCount=0,this.T_=Zn.ws()}forEachTarget(e,t){return this.l_.forEach((n,r)=>t(r)),V.resolve()}getLastRemoteSnapshotVersion(e){return V.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return V.resolve(this.E_)}allocateTargetId(e){return this.highestTargetId=this.T_.next(),V.resolve(this.highestTargetId)}setTargetsMetadata(e,t,n){return n&&(this.lastRemoteSnapshotVersion=n),t>this.E_&&(this.E_=t),V.resolve()}Ds(e){this.l_.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.T_=new Zn(t),this.highestTargetId=t),e.sequenceNumber>this.E_&&(this.E_=e.sequenceNumber)}addTargetData(e,t){return this.Ds(t),this.targetCount+=1,V.resolve()}updateTargetData(e,t){return this.Ds(t),V.resolve()}removeTargetData(e,t){return this.l_.delete(t.target),this.h_.e_(t.targetId),this.targetCount-=1,V.resolve()}removeTargets(e,t,n){let r=0;const i=[];return this.l_.forEach((o,a)=>{a.sequenceNumber<=t&&n.get(a.targetId)===null&&(this.l_.delete(o),i.push(this.removeMatchingKeysForTargetId(e,a.targetId)),r++)}),V.waitFor(i).next(()=>r)}getTargetCount(e){return V.resolve(this.targetCount)}getTargetData(e,t){const n=this.l_.get(t)||null;return V.resolve(n)}addMatchingKeys(e,t,n){return this.h_.Ys(t,n),V.resolve()}removeMatchingKeys(e,t,n){this.h_.Xs(t,n);const r=this.persistence.referenceDelegate,i=[];return r&&t.forEach(o=>{i.push(r.markPotentiallyOrphaned(e,o))}),V.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.h_.e_(t),V.resolve()}getMatchingKeysForTargetId(e,t){const n=this.h_.n_(t);return V.resolve(n)}containsKey(e,t){return V.resolve(this.h_.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ig{constructor(e,t){this.P_={},this.overlays={},this.I_=new Ra(0),this.R_=!1,this.R_=!0,this.A_=new bA,this.referenceDelegate=e(this),this.V_=new OA(this),this.indexManager=new DA,this.remoteDocumentCache=function(r){return new PA(r)}(n=>this.referenceDelegate.d_(n)),this.serializer=new _A(t),this.f_=new RA(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.R_=!1,Promise.resolve()}get started(){return this.R_}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new SA,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let n=this.P_[e.toKey()];return n||(n=new NA(t,this.referenceDelegate),this.P_[e.toKey()]=n),n}getGlobalsCache(){return this.A_}getTargetCache(){return this.V_}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.f_}runTransaction(e,t,n){z("MemoryPersistence","Starting transaction:",e);const r=new LA(this.I_.next());return this.referenceDelegate.m_(),n(r).next(i=>this.referenceDelegate.p_(r).next(()=>i)).toPromise().then(i=>(r.raiseOnCommittedEvent(),i))}g_(e,t){return V.or(Object.values(this.P_).map(n=>()=>n.containsKey(e,t)))}}class LA extends RT{constructor(e){super(),this.currentSequenceNumber=e}}class gc{constructor(e){this.persistence=e,this.y_=new pc,this.w_=null}static b_(e){return new gc(e)}get S_(){if(this.w_)return this.w_;throw X(60996)}addReference(e,t,n){return this.y_.addReference(n,t),this.S_.delete(n.toString()),V.resolve()}removeReference(e,t,n){return this.y_.removeReference(n,t),this.S_.add(n.toString()),V.resolve()}markPotentiallyOrphaned(e,t){return this.S_.add(t.toString()),V.resolve()}removeTarget(e,t){this.y_.e_(t.targetId).forEach(r=>this.S_.add(r.toString()));const n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(e,t.targetId).next(r=>{r.forEach(i=>this.S_.add(i.toString()))}).next(()=>n.removeTargetData(e,t))}m_(){this.w_=new Set}p_(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return V.forEach(this.S_,n=>{const r=Y.fromPath(n);return this.v_(e,r).next(i=>{i||t.removeEntry(r,ne.min())})}).next(()=>(this.w_=null,t.apply(e)))}updateLimboDocument(e,t){return this.v_(e,t).next(n=>{n?this.S_.delete(t.toString()):this.S_.add(t.toString())})}d_(e){return 0}v_(e,t){return V.or([()=>V.resolve(this.y_.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.g_(e,t)])}}class ta{constructor(e,t){this.persistence=e,this.D_=new Fs(n=>pA(n.path),(n,r)=>n.isEqual(r)),this.garbageCollector=OT(this,t)}static b_(e,t){return new ta(e,t)}m_(){}p_(e){return V.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}ir(e){const t=this.Cs(e);return this.persistence.getTargetCache().getTargetCount(e).next(n=>t.next(r=>n+r))}Cs(e){let t=0;return this.sr(e,n=>{t++}).next(()=>t)}sr(e,t){return V.forEach(this.D_,(n,r)=>this.Os(e,n,r).next(i=>i?V.resolve():t(r)))}removeTargets(e,t,n){return this.persistence.getTargetCache().removeTargets(e,t,n)}removeOrphanedDocuments(e,t){let n=0;const r=this.persistence.getRemoteDocumentCache(),i=r.newChangeBuffer();return r.c_(e,o=>this.Os(e,o,t).next(a=>{a||(n++,i.removeEntry(o,ne.min()))})).next(()=>i.apply(e)).next(()=>n)}markPotentiallyOrphaned(e,t){return this.D_.set(t,e.currentSequenceNumber),V.resolve()}removeTarget(e,t){const n=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,n)}addReference(e,t,n){return this.D_.set(n,e.currentSequenceNumber),V.resolve()}removeReference(e,t,n){return this.D_.set(n,e.currentSequenceNumber),V.resolve()}updateLimboDocument(e,t){return this.D_.set(t,e.currentSequenceNumber),V.resolve()}d_(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=Lo(e.data.value)),t}Os(e,t,n){return V.or([()=>this.persistence.g_(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const r=this.D_.get(t);return V.resolve(r!==void 0&&r>n)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mc{constructor(e,t,n,r){this.targetId=e,this.fromCache=t,this.Vo=n,this.fo=r}static mo(e,t){let n=oe(),r=oe();for(const i of t.docChanges)switch(i.type){case 0:n=n.add(i.doc.key);break;case 1:r=r.add(i.doc.key)}return new mc(e,t.fromCache,n,r)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xA(s,e){return Y.comparator(s.key,e.key)}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kA{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VA{constructor(){this.po=!1,this.yo=!1,this.wo=100,this.bo=function(){return O_()?8:ST(VC())>0?6:4}()}initialize(e,t){this.So=e,this.indexManager=t,this.po=!0}getDocumentsMatchingQuery(e,t,n,r){const i={result:null};return this.vo(e,t).next(o=>{i.result=o}).next(()=>{if(!i.result)return this.Do(e,t,r,n).next(o=>{i.result=o})}).next(()=>{if(i.result)return;const o=new kA;return this.xo(e,t,o).next(a=>{if(i.result=a,this.yo)return this.Co(e,t,o,a.size)})}).next(()=>i.result)}Co(e,t,n,r){return ze(t)?V.resolve():n.documentReadCount<this.wo?(js()<=Be.DEBUG&&z("QueryEngine","SDK will not create cache indexes for query:",ii(t),"since it only creates cache indexes for collection contains","more than or equal to",this.wo,"documents"),V.resolve()):(js()<=Be.DEBUG&&z("QueryEngine","Query:",ii(t),"scans",n.documentReadCount,"local documents and returns",r,"documents as results."),n.documentReadCount>this.bo*r?(js()<=Be.DEBUG&&z("QueryEngine","The SDK decides to create cache indexes for query:",ii(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,sn(t))):V.resolve())}vo(e,t){if(ze(t))return V.resolve(null);let n=t;if(gf(n))return V.resolve(null);let r=sn(n);return this.indexManager.getIndexType(e,r).next(i=>i===0?null:(n.limit!==null&&i===1&&(n=Xo(n,null,"F"),r=sn(n)),this.indexManager.getDocumentsMatchingTarget(e,r).next(o=>{const a=oe(...o);return this.So.getDocuments(e,a).next(l=>this.indexManager.getMinOffset(e,r).next(c=>{const h=this.Fo(n,l);return this.Oo(n,h,a,c.readTime)?this.vo(e,Xo(n,null,"F")):this.Mo(e,h,n,c)}))})))}Do(e,t,n,r){return(ze(t)?function(o){for(const a of o.stages){if(a instanceof Rs||a instanceof Ff)return!1;if(a instanceof Fa){if(a.condition instanceof Up&&a.condition._expr.name==="exists"&&a.condition._expr.params[0]instanceof Dr&&a.condition._expr.params[0].fieldName===Zt)continue;return!1}}return!0}(t):gf(t))||r.isEqual(ne.min())?V.resolve(null):this.So.getDocuments(e,n).next(i=>{const o=this.Fo(t,i);return this.Oo(t,o,n,r)?V.resolve(null):(js()<=Be.DEBUG&&z("QueryEngine","Re-using previous result from %s to execute query: %s",r.toString(),Of(t)),this.Mo(e,o,t,Tw(r,Ai)).next(a=>a))})}Fo(e,t){let n,r;return ze(e)?(n=new Ue(xA),r=i=>ka(e,i)):(n=new Ue(Ql(e)),r=i=>Aa(e,i)),t.forEach((i,o)=>{r(o)&&(n=n.add(o))}),n}Oo(e,t,n,r){if(ze(e))return function(a){return a.stages.some(l=>l instanceof Rs||l instanceof Ff)}(e);if(e.limit===null)return!1;if(n.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(r)>0)}xo(e,t,n){return js()<=Be.DEBUG&&z("QueryEngine","Using full collection scan to execute query:",Of(t)),this.So.getDocumentsMatchingQuery(e,t,Wn.min(),n)}Mo(e,t,n,r){return this.So.getDocumentsMatchingQuery(e,n,r).next(i=>(t.forEach(o=>{i=i.insert(o.key,o)}),i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _c="LocalStore",MA=3e8;class GA{constructor(e,t,n,r){this.persistence=e,this.No=t,this.serializer=r,this.Lo=new ke(ae),this.Bo=new Fs(i=>tg(i),ng),this.Uo=new Map,this.ko=e.getRemoteDocumentCache(),this.V_=e.getTargetCache(),this.f_=e.getBundleCache(),this.qo(n)}qo(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new vA(this.ko,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.ko.setIndexManager(this.indexManager),this.No.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.Lo))}}function HA(s,e,t,n){return new GA(s,e,t,n)}async function og(s,e){const t=se(s);return await t.persistence.runTransaction("Handle user change","readonly",n=>{let r;return t.mutationQueue.getAllMutationBatches(n).next(i=>(r=i,t.qo(e),t.mutationQueue.getAllMutationBatches(n))).next(i=>{const o=[],a=[];let l=oe();for(const c of r){o.push(c.batchId);for(const h of c.mutations)l=l.add(h.key)}for(const c of i){a.push(c.batchId);for(const h of c.mutations)l=l.add(h.key)}return t.localDocuments.getDocuments(n,l).next(c=>({$o:c,removedBatchIds:o,addedBatchIds:a}))})})}function UA(s,e){const t=se(s);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",n=>{const r=e.batch.keys(),i=t.ko.newChangeBuffer({trackRemovals:!0});return function(a,l,c,h){const f=c.batch,d=f.keys();let _=V.resolve();return d.forEach(y=>{_=_.next(()=>h.getEntry(l,y)).next(N=>{const F=c.docVersions.get(y);W(F!==null,48541),N.version.compareTo(F)<0&&(f.applyToRemoteDocument(N,c),N.isValidDocument()&&(N.setReadTime(c.commitVersion),h.addEntry(N)))})}),_.next(()=>a.mutationQueue.removeMutationBatch(l,f))}(t,n,e,i).next(()=>i.apply(n)).next(()=>t.mutationQueue.performConsistencyCheck(n)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(n,r,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(n,function(a){let l=oe();for(let c=0;c<a.mutationResults.length;++c)a.mutationResults[c].transformResults.length>0&&(l=l.add(a.batch.mutations[c].key));return l}(e))).next(()=>t.localDocuments.getDocuments(n,r))})}function ag(s){const e=se(s);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.V_.getLastRemoteSnapshotVersion(t))}function qA(s,e){const t=se(s),n=e.snapshotVersion;let r=t.Lo;return t.persistence.runTransaction("Apply remote event","readwrite-primary",i=>{const o=t.ko.newChangeBuffer({trackRemovals:!0});r=t.Lo;const a=[];e.targetChanges.forEach((h,f)=>{const d=r.get(f);if(!d)return;a.push(t.V_.removeMatchingKeys(i,h.removedDocuments,f).next(()=>t.V_.addMatchingKeys(i,h.addedDocuments,f)));let _=d.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(f)!==null?_=_.withResumeToken(Je.EMPTY_BYTE_STRING,ne.min()).withLastLimboFreeSnapshotVersion(ne.min()):h.resumeToken.approximateByteSize()>0&&(_=_.withResumeToken(h.resumeToken,n)),r=r.insert(f,_),function(N,F,J){return N.resumeToken.approximateByteSize()===0||F.snapshotVersion.toMicroseconds()-N.snapshotVersion.toMicroseconds()>=MA?!0:J.addedDocuments.size+J.modifiedDocuments.size+J.removedDocuments.size>0}(d,_,h)&&a.push(t.V_.updateTargetData(i,_))});let l=Dt(),c=oe();if(e.documentUpdates.forEach(h=>{e.resolvedLimboDocuments.has(h)&&a.push(t.persistence.referenceDelegate.updateLimboDocument(i,h))}),a.push(JA(i,o,e.documentUpdates).next(h=>{l=h.Ko,c=h.Qo})),!n.isEqual(ne.min())){const h=t.V_.getLastRemoteSnapshotVersion(i).next(f=>t.V_.setTargetsMetadata(i,i.currentSequenceNumber,n));a.push(h)}return V.waitFor(a).next(()=>o.apply(i)).next(()=>t.localDocuments.getLocalViewOfDocuments(i,l,c)).next(()=>l)}).then(i=>(t.Lo=r,i))}function JA(s,e,t){let n=oe(),r=oe();return t.forEach(i=>n=n.add(i)),e.getEntries(s,n).next(i=>{let o=Dt();return t.forEach((a,l)=>{const c=i.get(a);l.isFoundDocument()!==c.isFoundDocument()&&(r=r.add(a)),l.isNoDocument()&&l.version.isEqual(ne.min())?(e.removeEntry(a,l.readTime),o=o.insert(a,l)):!c.isValidDocument()||l.version.compareTo(c.version)>0||l.version.compareTo(c.version)===0&&c.hasPendingWrites?(e.addEntry(l),o=o.insert(a,l)):z(_c,"Ignoring outdated watch update for ",a,". Current version:",c.version," Watch version:",l.version)}),{Ko:o,Qo:r}})}function jA(s,e){const t=se(s);return t.persistence.runTransaction("Get next mutation batch","readonly",n=>(e===void 0&&(e=ql),t.mutationQueue.getNextMutationBatchAfterBatchId(n,e)))}function KA(s,e){const t=se(s);return t.persistence.runTransaction("Allocate target","readwrite",n=>{let r;return t.V_.getTargetData(n,e).next(i=>i?(r=i,V.resolve(r)):t.V_.allocateTargetId(n).next(o=>(r=new fn(e,o,"TargetPurposeListen",n.currentSequenceNumber),t.V_.addTargetData(n,r).next(()=>r))))}).then(n=>{const r=t.Lo.get(n.targetId);return(r===null||n.snapshotVersion.compareTo(r.snapshotVersion)>0)&&(t.Lo=t.Lo.insert(n.targetId,n),t.Bo.set(e,n.targetId)),n})}async function Cl(s,e,t){const n=se(s),r=n.Lo.get(e),i=t?"readwrite":"readwrite-primary";try{t||await n.persistence.runTransaction("Release target",i,o=>n.persistence.referenceDelegate.removeTarget(o,r))}catch(o){if(!_r(o))throw o;z(_c,`Failed to update sequence numbers for target ${e}: ${o}`)}n.Lo=n.Lo.remove(e),n.Bo.delete(r.target)}function xf(s,e,t){const n=se(s);let r=ne.min(),i=oe();return n.persistence.runTransaction("Execute query","readwrite",o=>function(l,c,h){const f=se(l),d=f.Bo.get(h);return d!==void 0?V.resolve(f.Lo.get(d)):f.V_.getTargetData(c,h)}(n,o,ze(e)?e:sn(e)).next(a=>{if(a)return r=a.lastLimboFreeSnapshotVersion,n.V_.getMatchingKeysForTargetId(o,a.targetId).next(l=>{i=l})}).next(()=>n.No.getDocumentsMatchingQuery(o,e,t?r:ne.min(),t?i:oe())).next(a=>(zA(n,a),{documents:a,Wo:i})))}function zA(s,e){e.forEach((t,n)=>{const r=n.key.getCollectionGroup(),i=s.Uo.get(r)||ne.min();n.readTime.compareTo(i)>0&&s.Uo.set(r,n.readTime)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class QA{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.Yo=0,this.Zo=null,this.Xo=!0}ea(){this.Yo===0&&(this.ta("Unknown"),this.Zo=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.Zo=null,this.na("Backend didn't respond within 10 seconds."),this.ta("Offline"),Promise.resolve())))}ra(e){this.state==="Online"?this.ta("Unknown"):(this.Yo++,this.Yo>=1&&(this.ia(),this.na(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ta("Offline")))}set(e){this.ia(),this.Yo=0,e==="Online"&&(this.Xo=!1),this.ta(e)}ta(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}na(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.Xo?(_n(t),this.Xo=!1):z("OnlineStateTracker",t)}ia(){this.Zo!==null&&(this.Zo.cancel(),this.Zo=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const an="RemoteStore";class WA{constructor(e,t,n,r,i){this.localStore=e,this.datastore=t,this.asyncQueue=n,this.remoteSyncer={},this.sa=[],this._a=new Map,this.oa=new Map,this.aa=new Map,this.ua=new Zn(1e3),this.ca=new Zn(1001),this.la=new Set,this.Ea=[],this.ha=i,this.ha.Qe(o=>{n.enqueueAndForget(async()=>{Ls(this)&&(z(an,"Restarting streams for network reachability change."),await async function(l){const c=se(l);c.la.add(4),await Wi(c),c.Ta.set("Unknown"),c.la.delete(4),await Va(c)}(this))})}),this.Ta=new QA(n,r)}}async function Va(s){if(Ls(s))for(const e of s.Ea)await e(!0)}async function Wi(s){for(const e of s.Ea)await e(!1)}function dl(s,e){return s.oa.get(e)||void 0}function Bg(s,e){const t=se(s),n=dl(t,e.targetId);if(n!==void 0&&t._a.has(n))return;const r=function(a,l){const c=dl(a,l);c!==void 0&&a.aa.delete(c);const h=function(d,_){return _%2!=0?d.ca.next():d.ua.next()}(a,l);return a.oa.set(l,h),a.aa.set(h,l),h}(t,e.targetId);z(an,"remoteStoreListen mapping SDK target ID to remote",e.targetId,r);const i=new fn(e.target,r,e.purpose,e.sequenceNumber,e.snapshotVersion,e.lastLimboFreeSnapshotVersion,e.resumeToken);t._a.set(r,i),wc(t)?yc(t):Ir(t).Yt()&&Dc(t,i)}function Ec(s,e){const t=se(s),n=Ir(t),r=dl(t,e);z(an,"remoteStoreUnlisten removing mapping of SDK target ID to remote",e,r),t._a.delete(r),t.oa.delete(e),t.aa.delete(r),n.Yt()&&lg(t,r),t._a.size===0&&(n.Yt()?n.en():Ls(t)&&t.Ta.set("Unknown"))}function Dc(s,e){if(s.Pa.J(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(ne.min())>0){const t=s.aa.get(e.targetId);if(t===void 0)return void z(an,"SDK target ID not found for remote ID: "+e.targetId);const n=s.remoteSyncer.getRemoteKeysForTarget(t).size;e=e.withExpectedCount(n)}Ir(s).Pn(e)}function lg(s,e){s.Pa.J(e),Ir(s).In(e)}function yc(s){s.Pa=new Jw({getRemoteKeysForTarget:e=>{const t=s.aa.get(e);return t!==void 0?s.remoteSyncer.getRemoteKeysForTarget(t):oe()},ye:e=>s._a.get(e)||null,Ve:()=>s.datastore.serializer.databaseId}),Ir(s).start(),s.Ta.ea()}function wc(s){return Ls(s)&&!Ir(s).Jt()&&s._a.size>0}function Ls(s){return se(s).la.size===0}function cg(s){s.Pa=void 0}async function YA(s){s.Ta.set("Online")}async function $A(s){s._a.forEach((e,t)=>{Dc(s,e)})}async function XA(s,e){cg(s),wc(s)?(s.Ta.ra(e),yc(s)):s.Ta.set("Unknown")}async function ZA(s,e,t){if(s.Ta.set("Online"),e instanceof fp&&e.state===2&&e.cause)try{await async function(r,i){const o=i.cause;for(const a of i.targetIds){if(r._a.has(a)){const l=r.aa.get(a);l!==void 0&&(await r.remoteSyncer.rejectListen(l,o),r.oa.delete(l),r.aa.delete(a)),r._a.delete(a)}r.Pa.removeTarget(a)}}(s,e)}catch(n){z(an,"Failed to remove targets %s: %s ",e.targetIds.join(","),n),await na(s,n)}else if(e instanceof ko?s.Pa._e(e):e instanceof hp?s.Pa.he(e):s.Pa.ue(e),!t.isEqual(ne.min()))try{const n=await ag(s.localStore);t.compareTo(n)>=0&&await function(i,o){const a=i.Pa.fe(o);a.targetChanges.forEach((c,h)=>{if(c.resumeToken.approximateByteSize()>0){const f=i._a.get(h);f&&i._a.set(h,f.withResumeToken(c.resumeToken,o))}}),a.targetMismatches.forEach((c,h)=>{const f=i._a.get(c);if(!f)return;i._a.set(c,f.withResumeToken(Je.EMPTY_BYTE_STRING,f.snapshotVersion)),lg(i,c);const d=new fn(f.target,c,h,f.sequenceNumber);Dc(i,d)});const l=function(h,f){const d=new Map;f.targetChanges.forEach((y,N)=>{const F=h.aa.get(N);F!==void 0&&d.set(F,y)});let _=new ke(ae);return f.targetMismatches.forEach((y,N)=>{const F=h.aa.get(y);F!==void 0&&(_=_.insert(F,N))}),new Ji(f.snapshotVersion,d,_,f.documentUpdates,f.augmentedDocumentUpdates,f.resolvedLimboDocuments)}(i,a);return i.remoteSyncer.applyRemoteEvent(l)}(s,t)}catch(n){z(an,"Failed to raise snapshot:",n),await na(s,n)}}async function na(s,e,t){if(!_r(e))throw e;s.la.add(1),await Wi(s),s.Ta.set("Offline"),t||(t=()=>ag(s.localStore)),s.asyncQueue.enqueueRetryable(async()=>{z(an,"Retrying IndexedDB access"),await t(),s.la.delete(1),await Va(s)})}function ug(s,e){return e().catch(t=>na(s,t,e))}async function Ma(s){const e=se(s),t=es(e);let n=e.sa.length>0?e.sa[e.sa.length-1].batchId:ql;for(;ev(e);)try{const r=await jA(e.localStore,n);if(r===null){e.sa.length===0&&t.en();break}n=r.batchId,tv(e,r)}catch(r){await na(e,r)}hg(e)&&fg(e)}function ev(s){return Ls(s)&&s.sa.length<10}function tv(s,e){s.sa.push(e);const t=es(s);t.Yt()&&t.Rn&&t.An(e.mutations)}function hg(s){return Ls(s)&&!es(s).Jt()&&s.sa.length>0}function fg(s){es(s).start()}async function nv(s){es(s).fn()}async function sv(s){const e=es(s);for(const t of s.sa)e.An(t.mutations)}async function rv(s,e,t){const n=s.sa.shift(),r=dc.from(n,e,t);await ug(s,()=>s.remoteSyncer.applySuccessfulWrite(r)),await Ma(s)}async function iv(s,e){e&&es(s).Rn&&await async function(n,r){if(function(o){return ap(o)&&o!==O.ABORTED}(r.code)){const i=n.sa.shift();es(n).Xt(),await ug(n,()=>n.remoteSyncer.rejectFailedWrite(i.batchId,r)),await Ma(n)}}(s,e),hg(s)&&fg(s)}async function kf(s,e){const t=se(s);t.asyncQueue.verifyOperationInProgress(),z(an,"RemoteStore received new credentials");const n=Ls(t);t.la.add(3),await Wi(t),n&&t.Ta.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.la.delete(3),await Va(t)}async function ov(s,e){const t=se(s);e?(t.la.delete(2),await Va(t)):e||(t.la.add(2),await Wi(t),t.Ta.set("Unknown"))}function Ir(s){return s.Ia||(s.Ia=function(t,n,r){const i=se(t);return i.pn(),new ET(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(s.datastore,s.asyncQueue,{ct:YA.bind(null,s),Et:$A.bind(null,s),Tt:XA.bind(null,s),Tn:ZA.bind(null,s)}),s.Ea.push(async e=>{e?(s.Ia.Xt(),wc(s)?yc(s):s.Ta.set("Unknown")):(await s.Ia.stop(),cg(s))})),s.Ia}function es(s){return s.Ra||(s.Ra=function(t,n,r){const i=se(t);return i.pn(),new DT(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(s.datastore,s.asyncQueue,{ct:()=>Promise.resolve(),Et:nv.bind(null,s),Tt:iv.bind(null,s),Vn:sv.bind(null,s),dn:rv.bind(null,s)}),s.Ea.push(async e=>{e?(s.Ra.Xt(),await Ma(s)):(await s.Ra.stop(),s.sa.length>0&&(z(an,`Stopping write stream with ${s.sa.length} pending writes`),s.sa=[]))})),s.Ra}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tc{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Aa(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Aa(this.observer.error,e):_n("Uncaught Error in snapshot listener:",e.toString()))}Va(){this.muted=!0}Aa(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ic{constructor(e,t,n,r,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=n,this.op=r,this.removalCallback=i,this.deferred=new Jt,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,n,r,i){const o=Date.now()+n,a=new Ic(e,t,o,r,i);return a.start(n),a}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new G(O.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Ac(s,e){if(_n("AsyncQueue",`${e}: ${s}`),_r(s))return new G(O.UNAVAILABLE,`${e}: ${s}`);throw s}class Vf{constructor(){this.activeTargetIds=Hw()}Ba(e){this.activeTargetIds=this.activeTargetIds.add(e)}Ua(e){this.activeTargetIds=this.activeTargetIds.delete(e)}La(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class av{constructor(){this.fu=new Vf,this.mu={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,n){}addLocalQueryTarget(e,t=!0){return t&&this.fu.Ba(e),this.mu[e]||"not-current"}updateQueryState(e,t,n){this.mu[e]=t}removeLocalQueryTarget(e){this.fu.Ua(e)}isLocalQueryTarget(e){return this.fu.activeTargetIds.has(e)}clearQueryState(e){delete this.mu[e]}getAllActiveQueryTargets(){return this.fu.activeTargetIds}isActiveQueryTarget(e){return this.fu.activeTargetIds.has(e)}start(){return this.fu=new Vf,Promise.resolve()}handleUserChange(e,t,n){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}function LB(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ys{static emptySet(e){return new ys(e.comparator)}constructor(e){this.comparator=e?(t,n)=>e(t,n)||Y.comparator(t.key,n.key):(t,n)=>Y.comparator(t.key,n.key),this.keyedMap=zs(),this.sortedSet=new ke(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,n)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof ys)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),n=e.sortedSet.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=n.getNext().key;if(!r.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const n=new ys;return n.comparator=this.comparator,n.keyedMap=e,n.sortedSet=t,n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mf{constructor(){this.pu=new ke(Y.comparator)}track(e){const t=e.doc.key,n=this.pu.get(t);n?e.type!==0&&n.type===3?this.pu=this.pu.insert(t,e):e.type===3&&n.type!==1?this.pu=this.pu.insert(t,{type:n.type,doc:e.doc}):e.type===2&&n.type===2?this.pu=this.pu.insert(t,{type:2,doc:e.doc}):e.type===2&&n.type===0?this.pu=this.pu.insert(t,{type:0,doc:e.doc}):e.type===1&&n.type===0?this.pu=this.pu.remove(t):e.type===1&&n.type===2?this.pu=this.pu.insert(t,{type:1,doc:n.doc}):e.type===0&&n.type===1?this.pu=this.pu.insert(t,{type:2,doc:e.doc}):X(63341,{we:e,gu:n}):this.pu=this.pu.insert(t,e)}yu(){const e=[];return this.pu.inorderTraversal((t,n)=>{e.push(n)}),e}}class hr{constructor(e,t,n,r,i,o,a,l,c){this.query=e,this.docs=t,this.oldDocs=n,this.docChanges=r,this.mutatedKeys=i,this.fromCache=o,this.syncStateChanged=a,this.excludesMetadataChanges=l,this.hasCachedResults=c}static fromInitialDocuments(e,t,n,r,i){const o=[];return t.forEach(a=>{o.push({type:0,doc:a})}),new hr(e,t,ys.emptySet(t),o,n,r,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&xa(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,n=e.docChanges;if(t.length!==n.length)return!1;for(let r=0;r<t.length;r++)if(t[r].type!==n[r].type||!t[r].doc.isEqual(n[r].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bv{constructor(){this.wu=void 0,this.bu=[]}Su(){return this.bu.some(e=>e.vu())}}class lv{constructor(){this.queries=Gf(),this.onlineState="Unknown",this.Du=new Set}terminate(){(function(t,n){const r=se(t),i=r.queries;r.queries=Gf(),i.forEach((o,a)=>{for(const l of a.bu)l.onError(n)})})(this,new G(O.ABORTED,"Firestore shutting down"))}}function Gf(){return new Fs(s=>eg(s),xa)}async function vc(s,e){const t=se(s);let n=3;const r=e.query;let i=t.queries.get(r);i?!i.Su()&&e.vu()&&(n=2):(i=new Bv,n=e.vu()?0:1);try{switch(n){case 0:i.wu=await t.onListen(r,!0);break;case 1:i.wu=await t.onListen(r,!1);break;case 2:await t.onFirstRemoteStoreListen(r)}}catch(o){const a=Ac(o,`Initialization of query '${ze(e.query)?dn(e.query):ii(e.query)}' failed`);return void e.onError(a)}t.queries.set(r,i),i.bu.push(e),e.xu(t.onlineState),i.wu&&e.Cu(i.wu)&&Sc(t)}async function Rc(s,e){const t=se(s),n=e.query;let r=3;const i=t.queries.get(n);if(i){const o=i.bu.indexOf(e);o>=0&&(i.bu.splice(o,1),i.bu.length===0?r=e.vu()?0:1:!i.Su()&&e.vu()&&(r=2))}switch(r){case 0:return t.queries.delete(n),t.onUnlisten(n,!0);case 1:return t.queries.delete(n),t.onUnlisten(n,!1);case 2:return t.onLastRemoteStoreUnlisten(n);default:return}}function cv(s,e){const t=se(s);let n=!1;for(const r of e){const i=r.query,o=t.queries.get(i);if(o){for(const a of o.bu)a.Cu(r)&&(n=!0);o.wu=r}}n&&Sc(t)}function uv(s,e,t){const n=se(s),r=n.queries.get(e);if(r)for(const i of r.bu)i.onError(t);n.queries.delete(e)}function Sc(s){s.Du.forEach(e=>{e.next()})}var pl;(function(s){s.Default="default",s.Cache="cache"})(pl||(pl={}));class bc{constructor(e,t,n){this.query=e,this.Fu=t,this.Ou=!1,this.Mu=null,this.onlineState="Unknown",this.options=n||{}}Cu(e){if(!this.options.includeMetadataChanges){const n=[];for(const r of e.docChanges)r.type!==3&&n.push(r);e=new hr(e.query,e.docs,e.oldDocs,n,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Ou?this.Nu(e)&&(this.Fu.next(e),t=!0):this.Lu(e,this.onlineState)&&(this.Bu(e),t=!0),this.Mu=e,t}onError(e){this.Fu.error(e)}xu(e){this.onlineState=e;let t=!1;return this.Mu&&!this.Ou&&this.Lu(this.Mu,e)&&(this.Bu(this.Mu),t=!0),t}Lu(e,t){if(!e.fromCache||!this.vu())return!0;const n=t!=="Offline";return(!this.options.waitForSyncWhenOnline||!n)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Nu(e){if(e.docChanges.length>0)return!0;const t=this.Mu&&this.Mu.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}Bu(e){e=hr.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Ou=!0,this.Fu.next(e)}vu(){return this.options.source!==pl.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cg{constructor(e){this.key=e}}class dg{constructor(e){this.key=e}}class hv{constructor(e,t){this.query=e,this.zu=t,this.ju=null,this.hasCachedResults=!1,this.current=!1,this.Hu=oe(),this.mutatedKeys=oe(),this.Ju=ze(e)?fl(e):Ql(e),this.Yu=new ys(this.Ju)}get Zu(){return this.zu}Xu(e,t){const n=t?t.ec:new Mf,r=t?t.Yu:this.Yu;let i=t?t.mutatedKeys:this.mutatedKeys,o=r,a=!1;const[l,c]=this.tc(this.query,r);e.inorderTraversal((f,d)=>{const _=r.get(f),y=wA(this.query,d)?d:null,N=!!_&&this.mutatedKeys.has(_.key),F=!!y&&(y.hasLocalMutations||this.mutatedKeys.has(y.key)&&y.hasCommittedMutations);let J=!1;_&&y?_.data.isEqual(y.data)?N!==F&&(n.track({type:3,doc:y}),J=!0):this.nc(_,y)||(n.track({type:2,doc:y}),J=!0,(l&&this.Ju(y,l)>0||c&&this.Ju(y,c)<0)&&(a=!0)):!_&&y?(n.track({type:0,doc:y}),J=!0):_&&!y&&(n.track({type:1,doc:_}),J=!0,(l||c)&&(a=!0)),J&&(y?(o=o.add(y),i=F?i.add(f):i.delete(f)):(o=o.delete(f),i=i.delete(f)))});const h=this.rc(this.query);if(h)if(ze(this.query)){const f=[];o.forEach(y=>f.push(y));const d=rg(this.query,f);let _=new ys(fl(this.query));for(const y of d)_=_.add(y);o.forEach(y=>{_.has(y.key)||(i=i.delete(y.key),n.track({type:1,doc:y}))}),o=_}else{const f=this.sc(this.query);for(;o.size>h;){const d=f==="F"?o.last():o.first();o=o.delete(d.key),i=i.delete(d.key),n.track({type:1,doc:d})}}return{Yu:o,ec:n,Oo:a,mutatedKeys:i}}rc(e){var t;return ze(e)?(t=OB(e))==null?void 0:t.limit:e.limit||void 0}sc(e){if(ze(e)){const t=OB(e);return t&&t.limit<0?"L":"F"}return e.limitType}tc(e,t){var n;if(ze(e)){const r=(n=OB(e))==null?void 0:n.limit;return[t.size===r?t.last():null,null]}return[e.limitType==="F"&&t.size===this.rc(this.query)?t.last():null,e.limitType==="L"&&t.size===this.rc(this.query)?t.first():null]}nc(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,n,r){const i=this.Yu;this.Yu=e.Yu,this.mutatedKeys=e.mutatedKeys;const o=e.ec.yu();o.sort((h,f)=>function(_,y){const N=F=>{switch(F){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return X(20277,{we:F})}};return N(_)-N(y)}(h.type,f.type)||this.Ju(h.doc,f.doc)),this._c(n),r=r??!1;const a=t&&!r?this.oc():[],l=this.Hu.size===0&&this.current&&!r?1:0,c=l!==this.ju;return this.ju=l,o.length!==0||c?{snapshot:new hr(this.query,e.Yu,i,o,e.mutatedKeys,l===0,c,!1,!!n&&n.resumeToken.approximateByteSize()>0),ac:a}:{ac:a}}xu(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Yu:this.Yu,ec:new Mf,mutatedKeys:this.mutatedKeys,Oo:!1},!1)):{ac:[]}}uc(e){return!this.zu.has(e)&&!!this.Yu.has(e)&&!this.Yu.get(e).hasLocalMutations}_c(e){e&&(e.addedDocuments.forEach(t=>this.zu=this.zu.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.zu=this.zu.delete(t)),this.current=e.current)}oc(){if(!this.current)return[];const e=this.Hu;this.Hu=oe(),this.Yu.forEach(n=>{this.uc(n.key)&&(this.Hu=this.Hu.add(n.key))});const t=[];return e.forEach(n=>{this.Hu.has(n)||t.push(new dg(n))}),this.Hu.forEach(n=>{e.has(n)||t.push(new Cg(n))}),t}cc(e){this.zu=e.Wo,this.Hu=oe();const t=this.Xu(e.documents);return this.applyChanges(t,!0)}lc(){return hr.fromInitialDocuments(this.query,this.Yu,this.mutatedKeys,this.ju===0,this.hasCachedResults)}}const Nc="SyncEngine";class fv{constructor(e,t,n){this.query=e,this.targetId=t,this.view=n}}class Cv{constructor(e){this.key=e,this.Ec=!1}}class dv{constructor(e,t,n,r,i,o){this.localStore=e,this.remoteStore=t,this.eventManager=n,this.sharedClientState=r,this.currentUser=i,this.maxConcurrentLimboResolutions=o,this.hc={},this.Tc=new Fs(a=>eg(a),xa),this.Pc=new Map,this.Ic=new Set,this.Rc=new ke(Y.comparator),this.Ac=new Map,this.Vc=new pc,this.dc={},this.fc=new Map,this.mc=Zn.bs(),this.onlineState="Unknown",this.gc=void 0}get isPrimaryClient(){return this.gc===!0}}async function pv(s,e,t=!0){const n=Dg(s);let r;const i=n.Tc.get(e);return i?(n.sharedClientState.addLocalQueryTarget(i.targetId),r=i.view.lc()):r=await pg(n,e,t,!0),r}async function gv(s,e){const t=Dg(s);await pg(t,e,!0,!1)}async function pg(s,e,t,n){const r=await KA(s.localStore,ze(e)?e:sn(e)),i=r.targetId,o=s.sharedClientState.addLocalQueryTarget(i,t);let a;return n&&(a=await mv(s,e,i,o==="current",r.resumeToken)),s.isPrimaryClient&&t&&Bg(s.remoteStore,r),a}async function mv(s,e,t,n,r){s.yc=(f,d,_)=>async function(N,F,J,te){let re=F.view.Xu(J);re.Oo&&(re=await xf(N.localStore,F.query,!1).then(({documents:v})=>F.view.Xu(v,re)));const ge=te&&te.targetChanges.get(F.targetId),Le=te&&te.targetMismatches.get(F.targetId)!=null,Fe=F.view.applyChanges(re,N.isPrimaryClient,ge,Le);return Uf(N,F.targetId,Fe.ac),Fe.snapshot}(s,f,d,_);const i=await xf(s.localStore,e,!0),o=new hv(e,i.Wo),a=o.Xu(i.documents),l=ji.createSynthesizedTargetChangeForCurrentChange(t,n&&s.onlineState!=="Offline",r),c=o.applyChanges(a,s.isPrimaryClient,l);Uf(s,t,c.ac);const h=new fv(e,t,o);return s.Tc.set(e,h),s.Pc.has(t)?s.Pc.get(t).push(e):s.Pc.set(t,[e]),c.snapshot}async function _v(s,e,t){const n=se(s),r=n.Tc.get(e),i=n.Pc.get(r.targetId);if(i.length>1)return n.Pc.set(r.targetId,i.filter(o=>!xa(o,e))),void n.Tc.delete(e);n.isPrimaryClient?(n.sharedClientState.removeLocalQueryTarget(r.targetId),n.sharedClientState.isActiveQueryTarget(r.targetId)||await Cl(n.localStore,r.targetId,!1).then(()=>{n.sharedClientState.clearQueryState(r.targetId),t&&Ec(n.remoteStore,r.targetId),gl(n,r.targetId)}).catch(mr)):(gl(n,r.targetId),await Cl(n.localStore,r.targetId,!0))}async function Ev(s,e){const t=se(s),n=t.Tc.get(e),r=t.Pc.get(n.targetId);t.isPrimaryClient&&r.length===1&&(t.sharedClientState.removeLocalQueryTarget(n.targetId),Ec(t.remoteStore,n.targetId))}async function Dv(s,e,t){const n=Rv(s);try{const r=await function(o,a){const l=se(o),c=_e.now(),h=a.reduce((_,y)=>_.add(y.key),oe());let f,d;return l.persistence.runTransaction("Locally write mutations","readwrite",_=>{let y=Dt(),N=oe();return l.ko.getEntries(_,h).next(F=>{y=F,y.forEach((J,te)=>{te.isValidDocument()||(N=N.add(J))})}).next(()=>l.localDocuments.getOverlayedDocuments(_,y)).next(F=>{f=F;const J=[];for(const te of a){const re=Cw(te,f.get(te.key).overlayedDocument);re!=null&&J.push(new rs(te.key,re,qd(re.value.mapValue),st.exists(!0)))}return l.mutationQueue.addMutationBatch(_,c,J,a)}).next(F=>{d=F;const J=F.applyToLocalDocumentSet(f,N);return l.documentOverlayCache.saveOverlays(_,F.batchId,J)})}).then(()=>({batchId:d.batchId,changes:cp(f)}))}(n.localStore,e);n.sharedClientState.addPendingMutation(r.batchId),function(o,a,l){let c=o.dc[o.currentUser.toKey()];c||(c=new ke(ae)),c=c.insert(a,l),o.dc[o.currentUser.toKey()]=c}(n,r.batchId,t),await Yi(n,r.changes),await Ma(n.remoteStore)}catch(r){const i=Ac(r,"Failed to persist write");t.reject(i)}}async function gg(s,e){const t=se(s);try{const n=await qA(t.localStore,e);e.targetChanges.forEach((r,i)=>{const o=t.Ac.get(i);o&&(W(r.addedDocuments.size+r.modifiedDocuments.size+r.removedDocuments.size<=1,22616),r.addedDocuments.size>0?o.Ec=!0:r.modifiedDocuments.size>0?W(o.Ec,14607):r.removedDocuments.size>0&&(W(o.Ec,42227),o.Ec=!1))}),await Yi(t,n,e)}catch(n){await mr(n)}}function Hf(s,e,t){const n=se(s);if(n.isPrimaryClient&&t===0||!n.isPrimaryClient&&t===1){const r=[];n.Tc.forEach((i,o)=>{const a=o.view.xu(e);a.snapshot&&r.push(a.snapshot)}),function(o,a){const l=se(o);l.onlineState=a;let c=!1;l.queries.forEach((h,f)=>{for(const d of f.bu)d.xu(a)&&(c=!0)}),c&&Sc(l)}(n.eventManager,e),r.length&&n.hc.Tn(r),n.onlineState=e,n.isPrimaryClient&&n.sharedClientState.setOnlineState(e)}}async function yv(s,e,t){const n=se(s);n.sharedClientState.updateQueryState(e,"rejected",t);const r=n.Ac.get(e),i=r&&r.key;if(i){let o=new ke(Y.comparator);o=o.insert(i,Xe.newNoDocument(i,ne.min()));const a=oe().add(i),l=new Ji(ne.min(),new Map,new ke(ae),o,Dt(),a);await gg(n,l),n.Rc=n.Rc.remove(i),n.Ac.delete(e),Pc(n)}else await Cl(n.localStore,e,!1).then(()=>gl(n,e,t)).catch(mr)}async function wv(s,e){const t=se(s),n=e.batch.batchId;try{const r=await UA(t.localStore,e);_g(t,n,null),mg(t,n),t.sharedClientState.updateMutationState(n,"acknowledged"),await Yi(t,r)}catch(r){await mr(r)}}async function Tv(s,e,t){const n=se(s);try{const r=await function(o,a){const l=se(o);return l.persistence.runTransaction("Reject batch","readwrite-primary",c=>{let h;return l.mutationQueue.lookupMutationBatch(c,a).next(f=>(W(f!==null,37113),h=f.keys(),l.mutationQueue.removeMutationBatch(c,f))).next(()=>l.mutationQueue.performConsistencyCheck(c)).next(()=>l.documentOverlayCache.removeOverlaysForBatchId(c,h,a)).next(()=>l.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(c,h)).next(()=>l.localDocuments.getDocuments(c,h))})}(n.localStore,e);_g(n,e,t),mg(n,e),n.sharedClientState.updateMutationState(e,"rejected",t),await Yi(n,r)}catch(r){await mr(r)}}function mg(s,e){(s.fc.get(e)||[]).forEach(t=>{t.resolve()}),s.fc.delete(e)}function _g(s,e,t){const n=se(s);let r=n.dc[n.currentUser.toKey()];if(r){const i=r.get(e);i&&(t?i.reject(t):i.resolve(),r=r.remove(e)),n.dc[n.currentUser.toKey()]=r}}function gl(s,e,t=null){s.sharedClientState.removeLocalQueryTarget(e);for(const n of s.Pc.get(e))s.Tc.delete(n),t&&s.hc.wc(n,t);s.Pc.delete(e),s.isPrimaryClient&&s.Vc.e_(e).forEach(n=>{s.Vc.containsKey(n)||Eg(s,n)})}function Eg(s,e){s.Ic.delete(e.path.canonicalString());const t=s.Rc.get(e);t!==null&&(Ec(s.remoteStore,t),s.Rc=s.Rc.remove(e),s.Ac.delete(t),Pc(s))}function Uf(s,e,t){for(const n of t)n instanceof Cg?(s.Vc.addReference(n.key,e),Iv(s,n)):n instanceof dg?(z(Nc,"Document no longer in limbo: "+n.key),s.Vc.removeReference(n.key,e),s.Vc.containsKey(n.key)||Eg(s,n.key)):X(19791,{bc:n})}function Iv(s,e){const t=e.key,n=t.path.canonicalString();s.Rc.get(t)||s.Ic.has(n)||(z(Nc,"New document in limbo: "+t),s.Ic.add(n),Pc(s))}function Pc(s){for(;s.Ic.size>0&&s.Rc.size<s.maxConcurrentLimboResolutions;){const e=s.Ic.values().next().value;s.Ic.delete(e);const t=new Y(Ce.fromString(e)),n=s.mc.next();s.Ac.set(n,new Cv(t)),s.Rc=s.Rc.insert(t,n),Bg(s.remoteStore,new fn(sn(Ia(t.path)),n,"TargetPurposeLimboResolution",Ra.wn))}}async function Yi(s,e,t){const n=se(s),r=[],i=[],o=[];n.Tc.isEmpty()||(n.Tc.forEach((a,l)=>{o.push(n.yc(l,e,t).then(c=>{var h;if((c||t)&&n.isPrimaryClient){const f=c?!c.fromCache:(h=t==null?void 0:t.targetChanges.get(l.targetId))==null?void 0:h.current;n.sharedClientState.updateQueryState(l.targetId,f?"current":"not-current")}if(c){r.push(c);const f=mc.mo(l.targetId,c);i.push(f)}}))}),await Promise.all(o),n.hc.Tn(r),await async function(l,c){const h=se(l);try{await h.persistence.runTransaction("notifyLocalViewChanges","readwrite",f=>V.forEach(c,d=>V.forEach(d.Vo,_=>h.persistence.referenceDelegate.addReference(f,d.targetId,_)).next(()=>V.forEach(d.fo,_=>h.persistence.referenceDelegate.removeReference(f,d.targetId,_)))))}catch(f){if(!_r(f))throw f;z(_c,"Failed to update sequence numbers: "+f)}for(const f of c){const d=f.targetId;if(!f.fromCache){const _=h.Lo.get(d),y=_.snapshotVersion,N=_.withLastLimboFreeSnapshotVersion(y);h.Lo=h.Lo.insert(d,N)}}}(n.localStore,i))}async function Av(s,e){const t=se(s);if(!t.currentUser.isEqual(e)){z(Nc,"User change. New user:",e.toKey());const n=await og(t.localStore,e);t.currentUser=e,function(i,o){i.fc.forEach(a=>{a.forEach(l=>{l.reject(new G(O.CANCELLED,o))})}),i.fc.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,n.removedBatchIds,n.addedBatchIds),await Yi(t,n.$o)}}function vv(s,e){const t=se(s),n=t.Ac.get(e);if(n&&n.Ec)return oe().add(n.key);{let r=oe();const i=t.Pc.get(e);if(!i)return r;for(const o of i??[]){const a=t.Tc.get(o);r=r.unionWith(a.view.Zu)}return r}}function Dg(s){const e=se(s);return e.remoteStore.remoteSyncer.applyRemoteEvent=gg.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=vv.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=yv.bind(null,e),e.hc.Tn=cv.bind(null,e.eventManager),e.hc.wc=uv.bind(null,e.eventManager),e}function Rv(s){const e=se(s);return e.remoteStore.remoteSyncer.applySuccessfulWrite=wv.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=Tv.bind(null,e),e}class sa{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=va(e.databaseInfo.databaseId),this.sharedClientState=this.vc(e),this.persistence=this.Dc(e),await this.persistence.start(),this.localStore=this.xc(e),this.gcScheduler=this.Cc(e,this.localStore),this.indexBackfillerScheduler=this.Fc(e,this.localStore)}Cc(e,t){return null}Fc(e,t){return null}xc(e){return HA(this.persistence,new VA,e.initialUser,this.serializer)}Dc(e){return new ig(gc.b_,this.serializer)}vc(e){return new av}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}sa.provider={build:()=>new sa};class Sv extends sa{constructor(e){super(),this.cacheSizeBytes=e}Cc(e,t){W(this.persistence.referenceDelegate instanceof ta,46915);const n=this.persistence.referenceDelegate.garbageCollector;return new PT(n,e.asyncQueue,t)}Dc(e){const t=this.cacheSizeBytes!==void 0?Et.withCacheSize(this.cacheSizeBytes):Et.DEFAULT;return new ig(n=>ta.b_(n,t),this.serializer)}}class ml{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=n=>Hf(this.syncEngine,n,1),this.remoteStore.remoteSyncer.handleCredentialChange=Av.bind(null,this.syncEngine),await ov(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new lv}()}createDatastore(e){const t=va(e.databaseInfo.databaseId),n=_T(e.databaseInfo);return TT(e.authCredentials,e.appCheckCredentials,n,t)}createRemoteStore(e){return function(n,r,i,o,a){return new WA(n,r,i,o,a)}(this.localStore,this.datastore,e.asyncQueue,t=>Hf(this.syncEngine,t,0),function(){return If.Ye()?new If:new dT}())}createSyncEngine(e,t){return function(r,i,o,a,l,c,h){const f=new dv(r,i,o,a,l,c);return h&&(f.gc=!0),f}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(r){const i=se(r);z(an,"RemoteStore shutting down."),i.la.add(5),await Wi(i),i.ha.shutdown(),i.Ta.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}ml.provider={build:()=>new ml};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let bv=class{constructor(e){this.datastore=e,this.readVersions=new Map,this.mutations=[],this.committed=!1,this.lastTransactionError=null,this.writtenDocs=new Set}async lookup(e){if(this.ensureCommitNotCalled(),this.mutations.length>0)throw this.lastTransactionError=new G(O.INVALID_ARGUMENT,"Firestore transactions require all reads to be executed before all writes."),this.lastTransactionError;const t=await async function(r,i){const o=se(r),a={documents:i.map(f=>vi(o.serializer,f))},l=await o._t("BatchGetDocuments",o.serializer.databaseId,Ce.emptyPath(),a,i.length),c=new Map;l.forEach(f=>{const d=Yw(o.serializer,f);c.set(d.key.toString(),d)});const h=[];return i.forEach(f=>{const d=c.get(f.toString());W(!!d,55234,{key:f}),h.push(d)}),h}(this.datastore,e);return t.forEach(n=>this.recordVersion(n)),t}set(e,t){this.write(t.toMutation(e,this.precondition(e))),this.writtenDocs.add(e.toString())}update(e,t){try{this.write(t.toMutation(e,this.preconditionForUpdate(e)))}catch(n){this.lastTransactionError=n}this.writtenDocs.add(e.toString())}delete(e){this.write(new Ta(e,this.precondition(e))),this.writtenDocs.add(e.toString())}async commit(){if(this.ensureCommitNotCalled(),this.lastTransactionError)throw this.lastTransactionError;const e=this.readVersions;this.mutations.forEach(t=>{e.delete(t.key.toString())}),e.forEach((t,n)=>{const r=Y.fromPath(n);this.mutations.push(new Yd(r,this.precondition(r)))}),await async function(n,r){const i=se(n),o={writes:r.map(a=>mp(i.serializer,a))};await i.nt("Commit",i.serializer.databaseId,Ce.emptyPath(),o)}(this.datastore,this.mutations),this.committed=!0}recordVersion(e){let t;if(e.isFoundDocument())t=e.version;else{if(!e.isNoDocument())throw X(50498,{Mc:e.constructor.name});t=ne.min()}const n=this.readVersions.get(e.key.toString());if(n){if(!t.isEqual(n))throw new G(O.ABORTED,"Document version changed between two reads.")}else this.readVersions.set(e.key.toString(),t)}precondition(e){const t=this.readVersions.get(e.toString());return!this.writtenDocs.has(e.toString())&&t?t.isEqual(ne.min())?st.exists(!1):st.updateTime(t):st.none()}preconditionForUpdate(e){const t=this.readVersions.get(e.toString());if(!this.writtenDocs.has(e.toString())&&t){if(t.isEqual(ne.min()))throw new G(O.INVALID_ARGUMENT,"Can't update a document that doesn't exist.");return st.updateTime(t)}return st.exists(!0)}write(e){this.ensureCommitNotCalled(),this.mutations.push(e)}ensureCommitNotCalled(){}};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nv{constructor(e,t,n,r,i){this.asyncQueue=e,this.datastore=t,this.options=n,this.updateFunction=r,this.deferred=i,this.Nc=n.maxAttempts,this.Ht=new Xl(this.asyncQueue,"transaction_retry")}Lc(){this.Nc-=1,this.Bc()}Bc(){this.Ht.kt(async()=>{const e=new bv(this.datastore),t=this.Uc(e);t&&t.then(n=>{this.asyncQueue.enqueueAndForget(()=>e.commit().then(()=>{this.deferred.resolve(n)}).catch(r=>{this.kc(r)}))}).catch(n=>{this.kc(n)})})}Uc(e){try{const t=this.updateFunction(e);return!Ui(t)&&t.catch&&t.then?t:(this.deferred.reject(Error("Transaction callback must return a Promise")),null)}catch(t){return this.deferred.reject(t),null}}kc(e){this.Nc>0&&this.qc(e)?(this.Nc-=1,this.asyncQueue.enqueueAndForget(()=>(this.Bc(),Promise.resolve()))):this.deferred.reject(e)}qc(e){if((e==null?void 0:e.name)==="FirebaseError"){const t=e.code;return t==="aborted"||t==="failed-precondition"||t==="already-exists"||!ap(t)}return!1}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ts="FirestoreClient";class Pv{constructor(e,t,n,r,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=n,this._databaseInfo=r,this.user=at.UNAUTHENTICATED,this.clientId=Ul.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=i,this.authCredentials.start(n,async o=>{z(ts,"Received user=",o.uid),await this.authCredentialListener(o),this.user=o}),this.appCheckCredentials.start(n,o=>(z(ts,"Received new app check token=",o),this.appCheckCredentialListener(o,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new Jt;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const n=Ac(t,"Failed to shutdown persistence");e.reject(n)}}),e.promise}}async function xB(s,e){s.asyncQueue.verifyOperationInProgress(),z(ts,"Initializing OfflineComponentProvider");const t=s.configuration;await e.initialize(t);let n=t.initialUser;s.setCredentialChangeListener(async r=>{n.isEqual(r)||(await og(e.localStore,r),n=r)}),e.persistence.setDatabaseDeletedListener(()=>s.terminate()),s._offlineComponents=e}async function qf(s,e){s.asyncQueue.verifyOperationInProgress();const t=await Fv(s);z(ts,"Initializing OnlineComponentProvider"),await e.initialize(t,s.configuration),s.setCredentialChangeListener(n=>kf(e.remoteStore,n)),s.setAppCheckTokenChangeListener((n,r)=>kf(e.remoteStore,r)),s._onlineComponents=e}async function Fv(s){if(!s._offlineComponents)if(s._uninitializedComponentsProvider){z(ts,"Using user provided OfflineComponentProvider");try{await xB(s,s._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(r){return r.name==="FirebaseError"?r.code===O.FAILED_PRECONDITION||r.code===O.UNIMPLEMENTED:!(typeof DOMException<"u"&&r instanceof DOMException)||r.code===22||r.code===20||r.code===11}(t))throw t;Kt("Error using user provided cache. Falling back to memory cache: "+t),await xB(s,new sa)}}else z(ts,"Using default OfflineComponentProvider"),await xB(s,new Sv(void 0));return s._offlineComponents}async function Fc(s){return s._onlineComponents||(s._uninitializedComponentsProvider?(z(ts,"Using user provided OnlineComponentProvider"),await qf(s,s._uninitializedComponentsProvider._online)):(z(ts,"Using default OnlineComponentProvider"),await qf(s,new ml))),s._onlineComponents}function Ov(s){return Fc(s).then(e=>e.syncEngine)}function yg(s){return Fc(s).then(e=>e.datastore)}async function ra(s){const e=await Fc(s),t=e.eventManager;return t.onListen=pv.bind(null,e.syncEngine),t.onUnlisten=_v.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=gv.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=Ev.bind(null,e.syncEngine),t}function Lv(s,e,t,n){const r=new Tc(n),i=new bc(e,r,t);return s.asyncQueue.enqueueAndForget(async()=>vc(await ra(s),i)),()=>{r.Va(),s.asyncQueue.enqueueAndForget(async()=>Rc(await ra(s),i))}}function xv(s,e,t={}){const n=new Jt;return s.asyncQueue.enqueueAndForget(async()=>function(i,o,a,l,c){const h=new Tc({next:d=>{h.Va(),o.enqueueAndForget(()=>Rc(i,f));const _=d.docs.has(a);!_&&d.fromCache?c.reject(new G(O.UNAVAILABLE,"Failed to get document because the client is offline.")):_&&d.fromCache&&l&&l.source==="server"?c.reject(new G(O.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):c.resolve(d)},error:d=>c.reject(d)}),f=new bc(Ia(a.path),h,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return vc(i,f)}(await ra(s),s.asyncQueue,e,t,n)),n.promise}function kv(s,e,t={}){const n=new Jt;return s.asyncQueue.enqueueAndForget(async()=>function(i,o,a,l,c){const h=new Tc({next:d=>{h.Va(),o.enqueueAndForget(()=>Rc(i,f)),d.fromCache&&l.source==="server"?c.reject(new G(O.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):c.resolve(d)},error:d=>c.reject(d)}),f=new bc(a instanceof li?CA(a):a,h,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return vc(i,f)}(await ra(s),s.asyncQueue,e,t,n)),n.promise}function Vv(s,e,t){const n=new Jt;return s.asyncQueue.enqueueAndForget(async()=>{try{const r=await yg(s);n.resolve(async function(o,a,l){var N;const c=se(o),{request:h,ve:f,parent:d}=eT(c.serializer,bw(a),l);c.connection.Ze||delete h.parent;const _=(await c._t("RunAggregationQuery",c.serializer.databaseId,d,h,1)).filter(F=>!!F.result);W(_.length===1,64727);const y=(N=_[0].result)==null?void 0:N.aggregateFields;return Object.keys(y).reduce((F,J)=>(F[f[J]]=y[J],F),{})}(r,e,t))}catch(r){n.reject(r)}}),n.promise}function Mv(s,e){const t=new Jt;return s.asyncQueue.enqueueAndForget(async()=>Dv(await Ov(s),e,t)),t.promise}function Gv(s,e,t){const n=new Jt;return s.asyncQueue.enqueueAndForget(async()=>{const r=await yg(s);new Nv(s.asyncQueue,r,t,e,n).Lc()}),n.promise}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Oi=class{constructor(e,t,n,r,i){this._firestore=e,this._userDataWriter=t,this._key=n,this._document=r,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new Ne(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new Hv(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(Yn("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}},Hv=class extends Oi{data(){return super.data()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wg{convertValue(e,t="none"){switch(je(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Pe(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(zn(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw X(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const n={};return ss(e,(r,i)=>{n[r]=this.convertValue(i,t)}),n}convertVectorValue(e){var n,r,i;const t=(i=(r=(n=e.fields)==null?void 0:n[Di].arrayValue)==null?void 0:r.values)==null?void 0:i.map(o=>Pe(o.doubleValue));return new wt(t)}convertGeoPoint(e){return new rn(Pe(e.latitude),Pe(e.longitude))}convertArray(e,t){return(e.values||[]).map(n=>this.convertValue(n,t))}convertServerTimestamp(e,t){switch(t){case"previous":const n=Hi(e);return n==null?null:this.convertValue(n,t);case"estimate":return this.convertTimestamp(ir(e));default:return null}}convertTimestamp(e){const t=Kn(e);return new _e(t.seconds,t.nanos)}convertDocumentKey(e,t){const n=Ce.fromString(e);W(yp(n),9688,{name:e});const r=new _i(n.get(1),n.get(3)),i=new Y(n.popFirst(5));return r.isEqual(t)||_n(`A document reference to ${i} refers to a different database (${r.projectId}/${r.database}), which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Oc(s,e,t){let n;return n=s?t&&(t.merge||t.mergeFields)?s.toFirestore(e,t):s.toFirestore(e):e,n}class Uv extends wg{constructor(e){super(),this.firestore=e}convertBytes(e){return new bt(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Ne(this.firestore,null,t)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jf="AsyncQueue";class jf{constructor(e=Promise.resolve()){this.$c=[],this.Kc=!1,this.Qc=[],this.Wc=null,this.Gc=!1,this.zc=!1,this.jc=[],this.Ht=new Xl(this,"async_queue_retry"),this.Hc=()=>{const n=LB();n&&z(Jf,"Visibility state changed to "+n.visibilityState),this.Ht.$t()},this.Jc=e;const t=LB();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this.Hc)}get isShuttingDown(){return this.Kc}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Yc(),this.Zc(e)}enterRestrictedMode(e){if(!this.Kc){this.Kc=!0,this.zc=e||!1;const t=LB();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.Hc)}}enqueue(e){if(this.Yc(),this.Kc)return new Promise(()=>{});const t=new Jt;return this.Zc(()=>this.Kc&&this.zc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.$c.push(e),this.Xc()))}async Xc(){if(this.$c.length!==0){try{await this.$c[0](),this.$c.shift(),this.Ht.reset()}catch(e){if(!_r(e))throw e;z(Jf,"Operation failed with retryable error: "+e)}this.$c.length>0&&this.Ht.kt(()=>this.Xc())}}Zc(e){const t=this.Jc.then(()=>(this.Gc=!0,e().catch(n=>{throw this.Wc=n,this.Gc=!1,_n("INTERNAL UNHANDLED ERROR: ",Kf(n)),n}).then(n=>(this.Gc=!1,n))));return this.Jc=t,t}enqueueAfterDelay(e,t,n){this.Yc(),this.jc.indexOf(e)>-1&&(t=0);const r=Ic.createAndSchedule(this,e,t,n,i=>this.el(i));return this.Qc.push(r),r}Yc(){this.Wc&&X(47125,{tl:Kf(this.Wc)})}verifyOperationInProgress(){}async nl(){let e;do e=this.Jc,await e;while(e!==this.Jc)}rl(e){for(const t of this.Qc)if(t.timerId===e)return!0;return!1}il(e){return this.nl().then(()=>{this.Qc.sort((t,n)=>t.targetTimeMs-n.targetTimeMs);for(const t of this.Qc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.nl()})}sl(e){this.jc.push(e)}el(e){const t=this.Qc.indexOf(e);this.Qc.splice(t,1)}}function Kf(s){let e=s.message||"";return s.stack&&(e=s.stack.includes(s.message)?s.stack:s.message+`
`+s.stack),e}class Qt extends Sa{constructor(e,t,n,r){super(e,t,n,r),this.type="firestore",this._queue=new jf,this._persistenceKey=(r==null?void 0:r.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new jf(e),this._firestoreClient=void 0,await e}}}function eb(s,e){const t=QC(),n=Ko,r=pa(t,"firestore").getImmediate({identifier:n});if(!r._initialized){const i=S_("firestore");i&&LT(r,...i)}return r}function Ar(s){if(s._terminated)throw new G(O.FAILED_PRECONDITION,"The client has already been terminated.");return s._firestoreClient||qv(s),s._firestoreClient}function qv(s){var n,r,i,o;const e=s._freezeSettings(),t=AT(s._databaseId,((n=s._app)==null?void 0:n.options.appId)||"",s._persistenceKey,(r=s._app)==null?void 0:r.options.apiKey,e);s._componentsProvider||(i=e.localCache)!=null&&i._offlineComponentProvider&&((o=e.localCache)!=null&&o._onlineComponentProvider)&&(s._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),s._firestoreClient=new Pv(s._authCredentials,s._appCheckCredentials,s._queue,t,s._componentsProvider&&function(l){const c=l==null?void 0:l._online.build();return{_offline:l==null?void 0:l._offline.build(c),_online:c}}(s._componentsProvider))}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $i extends wg{constructor(e){super(),this.firestore=e}convertBytes(e){return new bt(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Ne(this.firestore,null,t)}}class Ws{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class qn extends Oi{constructor(e,t,n,r,i,o){super(e,t,n,r,o),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new Go(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const n=this._document.data.field(Yn("DocumentSnapshot.get",e));if(n!==null)return this._userDataWriter.convertValue(n,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new G(O.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=qn._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}qn._jsonSchemaVersion="firestore/documentSnapshot/1.0",qn._jsonSchema={type:He("string",qn._jsonSchemaVersion),bundleSource:He("string","DocumentSnapshot"),bundleName:He("string"),bundle:He("string")};class Go extends qn{data(e={}){return super.data(e)}}class ws{constructor(e,t,n,r){this._firestore=e,this._userDataWriter=t,this._snapshot=r,this.metadata=new Ws(r.hasPendingWrites,r.fromCache),this.query=n}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(n=>{e.call(t,new Go(this._firestore,this._userDataWriter,n.key,n,new Ws(this._snapshot.mutatedKeys.has(n.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new G(O.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(r,i){if(r._snapshot.oldDocs.isEmpty()){let o=0;return r._snapshot.docChanges.map(a=>{ze(r._snapshot.query)?fl(r._snapshot.query):Ql(r.query._query);const l=new Go(r._firestore,r._userDataWriter,a.doc.key,a.doc,new Ws(r._snapshot.mutatedKeys.has(a.doc.key),r._snapshot.fromCache),r.query.converter);return a.doc,{type:"added",doc:l,oldIndex:-1,newIndex:o++}})}{let o=r._snapshot.oldDocs;return r._snapshot.docChanges.filter(a=>i||a.type!==3).map(a=>{const l=new Go(r._firestore,r._userDataWriter,a.doc.key,a.doc,new Ws(r._snapshot.mutatedKeys.has(a.doc.key),r._snapshot.fromCache),r.query.converter);let c=-1,h=-1;return a.type!==0&&(c=o.indexOf(a.doc.key),o=o.delete(a.doc.key)),a.type!==1&&(o=o.add(a.doc),h=o.indexOf(a.doc.key)),{type:Jv(a.type),doc:l,oldIndex:c,newIndex:h}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new G(O.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=ws._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=Ul.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],n=[],r=[];return this.docs.forEach(i=>{i._document!==null&&(t.push(i._document),n.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),r.push(i.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function Jv(s){switch(s){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return X(61501,{type:s})}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ws._jsonSchemaVersion="firestore/querySnapshot/1.0",ws._jsonSchema={type:He("string",ws._jsonSchemaVersion),bundleSource:He("string","QuerySnapshot"),bundleName:He("string"),bundle:He("string")};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jv{constructor(e="count",t){this._internalFieldPath=t,this.type="AggregateField",this.aggregateType=e}}class Kv{constructor(e,t,n){this._userDataWriter=t,this._data=n,this.type="AggregateQuerySnapshot",this.query=e}data(){return this._userDataWriter.convertObjectMap(this._data)}_fieldsProto(){return new nt({mapValue:{fields:this._data}}).clone().value.mapValue.fields}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Tg(s){if(s.limitType==="L"&&s.explicitOrderBy.length===0)throw new G(O.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Lc{}class Xi extends Lc{}function tb(s,e,...t){let n=[];e instanceof Lc&&n.push(e),n=n.concat(t),function(i){const o=i.filter(l=>l instanceof xc).length,a=i.filter(l=>l instanceof Ga).length;if(o>1||o>0&&a>0)throw new G(O.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(n);for(const r of n)s=r._apply(s);return s}class Ga extends Xi{constructor(e,t,n){super(),this._field=e,this._op=t,this._value=n,this.type="where"}static _create(e,t,n){return new Ga(e,t,n)}_apply(e){const t=this._parse(e);return Ag(e._query,t),new Wt(e.firestore,e.converter,al(e._query,t))}_parse(e){const t=Er(e.firestore);return function(i,o,a,l,c,h,f){let d;if(c.isKeyField()){if(h==="array-contains"||h==="array-contains-any")throw new G(O.INVALID_ARGUMENT,`Invalid Query. You can't perform '${h}' queries on documentId().`);if(h==="in"||h==="not-in"){Qf(f,h);const y=[];for(const N of f)y.push(zf(l,i,N));d={arrayValue:{values:y}}}else d=zf(l,i,f)}else h!=="in"&&h!=="not-in"&&h!=="array-contains-any"||Qf(f,h),d=Op(a,o,f,h==="in"||h==="not-in");return Ge.create(c,h,d)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}function nb(s,e,t){const n=e,r=Yn("where",s);return Ga._create(r,n,t)}class xc extends Lc{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new xc(e,t)}_parse(e){const t=this._queryConstraints.map(n=>n._parse(e)).filter(n=>n.getFilters().length>0);return t.length===1?t[0]:zt.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(r,i){let o=r;const a=i.getFlattenedFilters();for(const l of a)Ag(o,l),o=al(o,l)}(e._query,t),new Wt(e.firestore,e.converter,al(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class kc extends Xi{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new kc(e,t)}_apply(e){const t=function(r,i,o){if(r.startAt!==null)throw new G(O.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(r.endAt!==null)throw new G(O.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new Ii(i,o)}(e._query,this._field,this._direction);return new Wt(e.firestore,e.converter,Nw(e._query,t))}}function sb(s,e="asc"){const t=e,n=Yn("orderBy",s);return kc._create(n,t)}class Vc extends Xi{constructor(e,t,n){super(),this.type=e,this._limit=t,this._limitType=n}static _create(e,t,n){return new Vc(e,t,n)}_apply(e){return new Wt(e.firestore,e.converter,Xo(e._query,this._limit,this._limitType))}}function rb(s){return tw("limit",s),Vc._create("limit",s,"F")}class Ha extends Xi{constructor(e,t,n){super(),this.type=e,this._docOrFields=t,this._inclusive=n}static _create(e,t,n){return new Ha(e,t,n)}_apply(e){const t=Ig(e,this.type,this._docOrFields,this._inclusive);return new Wt(e.firestore,e.converter,Pw(e._query,t))}}function ib(...s){return Ha._create("startAt",s,!0)}function ob(...s){return Ha._create("startAfter",s,!1)}class Ua extends Xi{constructor(e,t,n){super(),this.type=e,this._docOrFields=t,this._inclusive=n}static _create(e,t,n){return new Ua(e,t,n)}_apply(e){const t=Ig(e,this.type,this._docOrFields,this._inclusive);return new Wt(e.firestore,e.converter,Fw(e._query,t))}}function ab(...s){return Ua._create("endBefore",s,!1)}function Bb(...s){return Ua._create("endAt",s,!0)}function Ig(s,e,t,n){if(t[0]=qe(t[0]),t[0]instanceof Oi)return function(i,o,a,l,c){if(!l)throw new G(O.NOT_FOUND,`Can't use a DocumentSnapshot that doesn't exist for ${a}().`);const h=[];for(const f of Xs(i))if(f.field.isKeyField())h.push(zo(o,l.key));else{const d=l.data.field(f.field);if(Gi(d))throw new G(O.INVALID_ARGUMENT,'Invalid query. You are trying to start or end a query using a document for which the field "'+f.field+'" is an uncommitted server timestamp. (Since the value of this field is unknown, you cannot start/end a query with it.)');if(d===null){const _=f.field.canonicalString();throw new G(O.INVALID_ARGUMENT,`Invalid query. You are trying to start or end a query using a document for which the field '${_}' (used as the orderBy) does not exist.`)}h.push(d)}return new ur(h,c)}(s._query,s.firestore._databaseId,e,t[0]._document,n);{const r=Er(s.firestore);return function(o,a,l,c,h,f){const d=o.explicitOrderBy;if(h.length>d.length)throw new G(O.INVALID_ARGUMENT,`Too many arguments provided to ${c}(). The number of arguments must be less than or equal to the number of orderBy() clauses`);const _=[];for(let y=0;y<h.length;y++){const N=h[y];if(d[y].field.isKeyField()){if(typeof N!="string")throw new G(O.INVALID_ARGUMENT,`Invalid query. Expected a string for document ID in ${c}(), but got a ${typeof N}`);if(!zl(o)&&N.indexOf("/")!==-1)throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying a collection and ordering by documentId(), the value passed to ${c}() must be a plain document ID, but '${N}' contains a slash.`);const F=o.path.child(Ce.fromString(N));if(!Y.isDocumentKey(F))throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying a collection group and ordering by documentId(), the value passed to ${c}() must result in a valid document path, but '${F}' is not because it contains an odd number of segments.`);const J=new Y(F);_.push(zo(a,J))}else{const F=Op(l,c,N);_.push(F)}}return new ur(_,f)}(s._query,s.firestore._databaseId,r,e,t,n)}}function zf(s,e,t){if(typeof(t=qe(t))=="string"){if(t==="")throw new G(O.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!zl(e)&&t.indexOf("/")!==-1)throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const n=e.path.child(Ce.fromString(t));if(!Y.isDocumentKey(n))throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${n}' is not because it has an odd number of segments (${n.length}).`);return zo(s,new Y(n))}if(t instanceof Ne)return zo(s,t._key);throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${_a(t)}.`)}function Qf(s,e){if(!Array.isArray(s)||s.length===0)throw new G(O.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Ag(s,e){const t=function(r,i){for(const o of r)for(const a of o.getFlattenedFilters())if(i.indexOf(a.op)>=0)return a.op;return null}(s.filters,function(r){switch(r){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new G(O.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new G(O.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function zv(){return new jv("count")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wf(s){return function(t,n){if(typeof t!="object"||t===null)return!1;const r=t;for(const i of n)if(i in r&&typeof r[i]=="function")return!0;return!1}(s,["next","error","complete"])}function lb(s){return Qv(s,{count:zv()})}function Qv(s,e){const t=ut(s.firestore,Qt),n=Ar(t),r=Fd(e,(i,o)=>new Qy(o,i.aggregateType,i._internalFieldPath));return Vv(n,s._query,r).then(i=>function(a,l,c){const h=new $i(a);return new Kv(l,h,c)}(t,s,i))}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wv={maxAttempts:5};function ti(s,e){if((s=qe(s)).firestore!==e)throw new G(O.INVALID_ARGUMENT,"Provided document reference is from a different Firestore instance.");return s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Yv=class{constructor(e,t){this._firestore=e,this._transaction=t,this._dataReader=Er(e)}get(e){const t=ti(e,this._firestore),n=new Uv(this._firestore);return this._transaction.lookup([t._key]).then(r=>{if(!r||r.length!==1)return X(24041);const i=r[0];if(i.isFoundDocument())return new Oi(this._firestore,n,i.key,i,t.converter);if(i.isNoDocument())return new Oi(this._firestore,n,t._key,null,t.converter);throw X(18433,{doc:i})})}set(e,t,n){const r=ti(e,this._firestore),i=Oc(r.converter,t,n),o=Zl(this._dataReader,"Transaction.set",r._key,i,r.converter!==null,n);return this._transaction.set(r._key,o),this}update(e,t,n,...r){const i=ti(e,this._firestore);let o;return o=typeof(t=qe(t))=="string"||t instanceof Ki?Fp(this._dataReader,"Transaction.update",i._key,t,n,r):Pp(this._dataReader,"Transaction.update",i._key,t),this._transaction.update(i._key,o),this}delete(e){const t=ti(e,this._firestore);return this._transaction.delete(t._key),this}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $v extends Yv{constructor(e,t){super(e,t),this._firestore=e}get(e){const t=ti(e,this._firestore),n=new $i(this._firestore);return super.get(e).then(r=>new qn(this._firestore,n,t._key,r._document,new Ws(!1,!1),t.converter))}}function ub(s,e,t){s=ut(s,Qt);const n={...Wv,...t};(function(o){if(o.maxAttempts<1)throw new G(O.INVALID_ARGUMENT,"Max attempts must be at least 1")})(n);const r=Ar(s);return Gv(r,i=>e(new $v(s,i)),n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hb(s){s=ut(s,Ne);const e=ut(s.firestore,Qt),t=Ar(e);return xv(t,s._key).then(n=>vg(e,s,n))}function fb(s){s=ut(s,Wt);const e=ut(s.firestore,Qt),t=Ar(e),n=new $i(e);return Tg(s._query),kv(t,s._query).then(r=>new ws(e,n,s,r))}function Cb(s,e,t){s=ut(s,Ne);const n=ut(s.firestore,Qt),r=Oc(s.converter,e,t),i=Er(n);return qa(n,[Zl(i,"setDoc",s._key,r,s.converter!==null,t).toMutation(s._key,st.none())])}function db(s,e,t,...n){s=ut(s,Ne);const r=ut(s.firestore,Qt),i=Er(r);let o;return o=typeof(e=qe(e))=="string"||e instanceof Ki?Fp(i,"updateDoc",s._key,e,t,n):Pp(i,"updateDoc",s._key,e),qa(r,[o.toMutation(s._key,st.exists(!0))])}function pb(s){return qa(ut(s.firestore,Qt),[new Ta(s._key,st.none())])}function gb(s,e){const t=ut(s.firestore,Qt),n=xT(s),r=Oc(s.converter,e),i=Er(s.firestore);return qa(t,[Zl(i,"addDoc",n._key,r,s.converter!==null,{}).toMutation(n._key,st.exists(!1))]).then(()=>n)}function mb(s,...e){var c,h,f;s=qe(s);let t={includeMetadataChanges:!1,source:"default"},n=0;typeof e[n]!="object"||Wf(e[n])||(t=e[n++]);const r={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(Wf(e[n])){const d=e[n];e[n]=(c=d.next)==null?void 0:c.bind(d),e[n+1]=(h=d.error)==null?void 0:h.bind(d),e[n+2]=(f=d.complete)==null?void 0:f.bind(d)}let i,o,a;if(s instanceof Ne)o=ut(s.firestore,Qt),a=Ia(s._key.path),i={next:d=>{e[n]&&e[n](vg(o,s,d))},error:e[n+1],complete:e[n+2]};else{const d=ut(s,Wt);o=ut(d.firestore,Qt),a=d._query;const _=new $i(o);i={next:y=>{e[n]&&e[n](new ws(o,_,d,y))},error:e[n+1],complete:e[n+2]},Tg(s._query)}const l=Ar(o);return Lv(l,a,r,i)}function qa(s,e){const t=Ar(s);return Mv(t,e)}function vg(s,e,t){const n=t.docs.get(e._key),r=new $i(s);return new qn(s,r,e._key,n,new Ws(t.hasPendingWrites,t.fromCache),e.converter)}const Yf="@firebase/firestore",$f="4.17.2";(function(e,t=!0){Wy(qo),jn(new gn("firestore",(n,{instanceIdentifier:r,options:i})=>{const o=n.getProvider("app").getImmediate(),a=new Qt(new uT(n.getProvider("auth-internal")),new CT(o,n.getProvider("app-check-internal")),rw(o,r),o);return i={useFetchStreams:t,...i},a._setSettings(i),a},"PUBLIC").setMultipleInstances(!0)),Mt(Yf,$f,e),Mt(Yf,$f,"esm2020")})();var Xf={};const Zf="@firebase/database",eC="1.1.5";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Rg="";function Xv(s){Rg=s}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zv{constructor(e){this.domStorage_=e,this.prefix_="firebase:"}set(e,t){t==null?this.domStorage_.removeItem(this.prefixedName_(e)):this.domStorage_.setItem(this.prefixedName_(e),tt(t))}get(e){const t=this.domStorage_.getItem(this.prefixedName_(e));return t==null?null:di(t)}remove(e){this.domStorage_.removeItem(this.prefixedName_(e))}prefixedName_(e){return this.prefix_+e}toString(){return this.domStorage_.toString()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eR{constructor(){this.cache_={},this.isInMemoryStorage=!0}set(e,t){t==null?delete this.cache_[e]:this.cache_[e]=t}get(e){return wn(this.cache_,e)?this.cache_[e]:null}remove(e){delete this.cache_[e]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sg=function(s){try{if(typeof window<"u"&&typeof window[s]<"u"){const e=window[s];return e.setItem("firebase:sentinel","cache"),e.removeItem("firebase:sentinel"),new Zv(e)}}catch{}return new eR},_s=Sg("localStorage"),tR=Sg("sessionStorage");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const er=new da("@firebase/database"),nR=function(){let s=1;return function(){return s++}}(),bg=function(s){const e=q_(s),t=new H_;t.update(e);const n=t.digest();return Nl.encodeByteArray(n)},Zi=function(...s){let e="";for(let t=0;t<s.length;t++){const n=s[t];Array.isArray(n)||n&&typeof n=="object"&&typeof n.length=="number"?e+=Zi.apply(null,n):typeof n=="object"?e+=tt(n):e+=n,e+=" "}return e};let ui=null,tC=!0;const sR=function(s,e){K(!0,"Can't turn on custom loggers persistently."),er.logLevel=Be.VERBOSE,ui=er.log.bind(er)},Bt=function(...s){if(tC===!0&&(tC=!1,ui===null&&tR.get("logging_enabled")===!0&&sR()),ui){const e=Zi.apply(null,s);ui(e)}},eo=function(s){return function(...e){Bt(s,...e)}},_l=function(...s){const e="FIREBASE INTERNAL ERROR: "+Zi(...s);er.error(e)},Ss=function(...s){const e=`FIREBASE FATAL ERROR: ${Zi(...s)}`;throw er.error(e),new Error(e)},Lt=function(...s){const e="FIREBASE WARNING: "+Zi(...s);er.warn(e)},rR=function(){typeof window<"u"&&window.location&&window.location.protocol&&window.location.protocol.indexOf("https:")!==-1&&Lt("Insecure Firebase access from a secure page. Please use https in calls to new Firebase().")},Ng=function(s){return typeof s=="number"&&(s!==s||s===Number.POSITIVE_INFINITY||s===Number.NEGATIVE_INFINITY)},iR=function(s){if(document.readyState==="complete")s();else{let e=!1;const t=function(){if(!document.body){setTimeout(t,Math.floor(10));return}e||(e=!0,s())};document.addEventListener?(document.addEventListener("DOMContentLoaded",t,!1),window.addEventListener("load",t,!1)):document.attachEvent&&(document.attachEvent("onreadystatechange",()=>{document.readyState==="complete"&&t()}),window.attachEvent("onload",t))}},fr="[MIN_NAME]",bs="[MAX_NAME]",vr=function(s,e){if(s===e)return 0;if(s===fr||e===bs)return-1;if(e===fr||s===bs)return 1;{const t=nC(s),n=nC(e);return t!==null?n!==null?t-n===0?s.length-e.length:t-n:-1:n!==null?1:s<e?-1:1}},oR=function(s,e){return s===e?0:s<e?-1:1},Qr=function(s,e){if(e&&s in e)return e[s];throw new Error("Missing required key ("+s+") in object: "+tt(e))},Mc=function(s){if(typeof s!="object"||s===null)return tt(s);const e=[];for(const n in s)e.push(n);e.sort();let t="{";for(let n=0;n<e.length;n++)n!==0&&(t+=","),t+=tt(e[n]),t+=":",t+=Mc(s[e[n]]);return t+="}",t},Pg=function(s,e){const t=s.length;if(t<=e)return[s];const n=[];for(let r=0;r<t;r+=e)r+e>t?n.push(s.substring(r,t)):n.push(s.substring(r,r+e));return n};function Ht(s,e){for(const t in s)s.hasOwnProperty(t)&&e(t,s[t])}const Fg=function(s){K(!Ng(s),"Invalid JSON number");const e=11,t=52,n=(1<<e-1)-1;let r,i,o,a,l;s===0?(i=0,o=0,r=1/s===-1/0?1:0):(r=s<0,s=Math.abs(s),s>=Math.pow(2,1-n)?(a=Math.min(Math.floor(Math.log(s)/Math.LN2),n),i=a+n,o=Math.round(s*Math.pow(2,t-a)-Math.pow(2,t))):(i=0,o=Math.round(s/Math.pow(2,1-n-t))));const c=[];for(l=t;l;l-=1)c.push(o%2?1:0),o=Math.floor(o/2);for(l=e;l;l-=1)c.push(i%2?1:0),i=Math.floor(i/2);c.push(r?1:0),c.reverse();const h=c.join("");let f="";for(l=0;l<64;l+=8){let d=parseInt(h.substr(l,8),2).toString(16);d.length===1&&(d="0"+d),f=f+d}return f.toLowerCase()},aR=function(){return!!(typeof window=="object"&&window.chrome&&window.chrome.extension&&!/^chrome/.test(window.location.href))},BR=function(){return typeof Windows=="object"&&typeof Windows.UI=="object"},lR=new RegExp("^-?(0*)\\d{1,10}$"),cR=-2147483648,uR=2147483647,nC=function(s){if(lR.test(s)){const e=Number(s);if(e>=cR&&e<=uR)return e}return null},to=function(s){try{s()}catch(e){setTimeout(()=>{const t=e.stack||"";throw Lt("Exception was thrown by user callback.",t),e},Math.floor(0))}},hR=function(){return(typeof window=="object"&&window.navigator&&window.navigator.userAgent||"").search(/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0},hi=function(s,e){const t=setTimeout(s,e);return typeof t=="number"&&typeof Deno<"u"&&Deno.unrefTimer?Deno.unrefTimer(t):typeof t=="object"&&t.unref&&t.unref(),t};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fR{constructor(e,t){this.appCheckProvider=t,this.appName=e.name,zC(e)&&e.settings.appCheckToken&&(this.serverAppAppCheckToken=e.settings.appCheckToken),this.appCheck=t==null?void 0:t.getImmediate({optional:!0}),this.appCheck||t==null||t.get().then(n=>this.appCheck=n)}getToken(e){if(this.serverAppAppCheckToken){if(e)throw new Error("Attempted reuse of `FirebaseServerApp.appCheckToken` after previous usage failed.");return Promise.resolve({token:this.serverAppAppCheckToken})}return this.appCheck?this.appCheck.getToken(e):new Promise((t,n)=>{setTimeout(()=>{this.appCheck?this.getToken(e).then(t,n):t(null)},0)})}addTokenChangeListener(e){var t;(t=this.appCheckProvider)==null||t.get().then(n=>n.addTokenListener(e))}notifyForInvalidToken(){Lt(`Provided AppCheck credentials for the app named "${this.appName}" are invalid. This usually indicates your app was not initialized correctly.`)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CR{constructor(e,t,n){this.appName_=e,this.firebaseOptions_=t,this.authProvider_=n,this.auth_=null,this.auth_=n.getImmediate({optional:!0}),this.auth_||n.onInit(r=>this.auth_=r)}getToken(e){return this.auth_?this.auth_.getToken(e).catch(t=>t&&t.code==="auth/token-not-initialized"?(Bt("Got auth/token-not-initialized error.  Treating as null token."),null):Promise.reject(t)):new Promise((t,n)=>{setTimeout(()=>{this.auth_?this.getToken(e).then(t,n):t(null)},0)})}addTokenChangeListener(e){this.auth_?this.auth_.addAuthTokenListener(e):this.authProvider_.get().then(t=>t.addAuthTokenListener(e))}removeTokenChangeListener(e){this.authProvider_.get().then(t=>t.removeAuthTokenListener(e))}notifyForInvalidToken(){let e='Provided authentication credentials for the app named "'+this.appName_+'" are invalid. This usually indicates your app was not initialized correctly. ';"credential"in this.firebaseOptions_?e+='Make sure the "credential" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':"serviceAccount"in this.firebaseOptions_?e+='Make sure the "serviceAccount" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':e+='Make sure the "apiKey" and "databaseURL" properties provided to initializeApp() match the values provided for your app at https://console.firebase.google.com/.',Lt(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gc="5",Og="v",Lg="s",xg="r",kg="f",Vg=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,Mg="ls",Gg="p",El="ac",Hg="websocket",Ug="long_polling";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dR{constructor(e,t,n,r,i=!1,o="",a=!1,l=!1,c=null){this.secure=t,this.namespace=n,this.webSocketOnly=r,this.nodeAdmin=i,this.persistenceKey=o,this.includeNamespaceInQueryParams=a,this.isUsingEmulator=l,this.emulatorOptions=c,this._host=e.toLowerCase(),this._domain=this._host.substr(this._host.indexOf(".")+1),this.internalHost=_s.get("host:"+e)||this._host}isCacheableHost(){return this.internalHost.substr(0,2)==="s-"}isCustomHost(){return this._domain!=="firebaseio.com"&&this._domain!=="firebaseio-demo.com"}get host(){return this._host}set host(e){e!==this.internalHost&&(this.internalHost=e,this.isCacheableHost()&&_s.set("host:"+this._host,this.internalHost))}toString(){let e=this.toURLString();return this.persistenceKey&&(e+="<"+this.persistenceKey+">"),e}toURLString(){const e=this.secure?"https://":"http://",t=this.includeNamespaceInQueryParams?`?ns=${this.namespace}`:"";return`${e}${this.host}/${t}`}}function pR(s){return s.host!==s.internalHost||s.isCustomHost()||s.includeNamespaceInQueryParams}function qg(s,e,t){K(typeof e=="string","typeof type must == string"),K(typeof t=="object","typeof params must == object");let n;if(e===Hg)n=(s.secure?"wss://":"ws://")+s.internalHost+"/.ws?";else if(e===Ug)n=(s.secure?"https://":"http://")+s.internalHost+"/.lp?";else throw new Error("Unknown connection type: "+e);pR(s)&&(t.ns=s.namespace);const r=[];return Ht(t,(i,o)=>{r.push(i+"="+o)}),n+r.join("&")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gR{constructor(){this.counters_={}}incrementCounter(e,t=1){wn(this.counters_,e)||(this.counters_[e]=0),this.counters_[e]+=t}get(){return y_(this.counters_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kB={},VB={};function Hc(s){const e=s.toString();return kB[e]||(kB[e]=new gR),kB[e]}function mR(s,e){const t=s.toString();return VB[t]||(VB[t]=e()),VB[t]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _R{constructor(e){this.onMessage_=e,this.pendingResponses=[],this.currentResponseNum=0,this.closeAfterResponse=-1,this.onClose=null}closeAfter(e,t){this.closeAfterResponse=e,this.onClose=t,this.closeAfterResponse<this.currentResponseNum&&(this.onClose(),this.onClose=null)}handleResponse(e,t){for(this.pendingResponses[e]=t;this.pendingResponses[this.currentResponseNum];){const n=this.pendingResponses[this.currentResponseNum];delete this.pendingResponses[this.currentResponseNum];for(let r=0;r<n.length;++r)n[r]&&to(()=>{this.onMessage_(n[r])});if(this.currentResponseNum===this.closeAfterResponse){this.onClose&&(this.onClose(),this.onClose=null);break}this.currentResponseNum++}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sC="start",ER="close",DR="pLPCommand",yR="pRTLPCB",Jg="id",jg="pw",Kg="ser",wR="cb",TR="seg",IR="ts",AR="d",vR="dframe",zg=1870,Qg=30,RR=zg-Qg,SR=25e3,bR=3e4;class Ys{constructor(e,t,n,r,i,o,a){this.connId=e,this.repoInfo=t,this.applicationId=n,this.appCheckToken=r,this.authToken=i,this.transportSessionId=o,this.lastSessionId=a,this.bytesSent=0,this.bytesReceived=0,this.everConnected_=!1,this.log_=eo(e),this.stats_=Hc(t),this.urlFn=l=>(this.appCheckToken&&(l[El]=this.appCheckToken),qg(t,Ug,l))}open(e,t){this.curSegmentNum=0,this.onDisconnect_=t,this.myPacketOrderer=new _R(e),this.isClosed_=!1,this.connectTimeoutTimer_=setTimeout(()=>{this.log_("Timed out trying to connect."),this.onClosed_(),this.connectTimeoutTimer_=null},Math.floor(bR)),iR(()=>{if(this.isClosed_)return;this.scriptTagHolder=new Uc((...i)=>{const[o,a,l,c,h]=i;if(this.incrementIncomingBytes_(i),!!this.scriptTagHolder)if(this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null),this.everConnected_=!0,o===sC)this.id=a,this.password=l;else if(o===ER)a?(this.scriptTagHolder.sendNewPolls=!1,this.myPacketOrderer.closeAfter(a,()=>{this.onClosed_()})):this.onClosed_();else throw new Error("Unrecognized command received: "+o)},(...i)=>{const[o,a]=i;this.incrementIncomingBytes_(i),this.myPacketOrderer.handleResponse(o,a)},()=>{this.onClosed_()},this.urlFn);const n={};n[sC]="t",n[Kg]=Math.floor(Math.random()*1e8),this.scriptTagHolder.uniqueCallbackIdentifier&&(n[wR]=this.scriptTagHolder.uniqueCallbackIdentifier),n[Og]=Gc,this.transportSessionId&&(n[Lg]=this.transportSessionId),this.lastSessionId&&(n[Mg]=this.lastSessionId),this.applicationId&&(n[Gg]=this.applicationId),this.appCheckToken&&(n[El]=this.appCheckToken),typeof location<"u"&&location.hostname&&Vg.test(location.hostname)&&(n[xg]=kg);const r=this.urlFn(n);this.log_("Connecting via long-poll to "+r),this.scriptTagHolder.addTag(r,()=>{})})}start(){this.scriptTagHolder.startLongPoll(this.id,this.password),this.addDisconnectPingFrame(this.id,this.password)}static forceAllow(){Ys.forceAllow_=!0}static forceDisallow(){Ys.forceDisallow_=!0}static isAvailable(){return Ys.forceAllow_?!0:!Ys.forceDisallow_&&typeof document<"u"&&document.createElement!=null&&!aR()&&!BR()}markConnectionHealthy(){}shutdown_(){this.isClosed_=!0,this.scriptTagHolder&&(this.scriptTagHolder.close(),this.scriptTagHolder=null),this.myDisconnFrame&&(document.body.removeChild(this.myDisconnFrame),this.myDisconnFrame=null),this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null)}onClosed_(){this.isClosed_||(this.log_("Longpoll is closing itself"),this.shutdown_(),this.onDisconnect_&&(this.onDisconnect_(this.everConnected_),this.onDisconnect_=null))}close(){this.isClosed_||(this.log_("Longpoll is being closed."),this.shutdown_())}send(e){const t=tt(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);const n=LC(t),r=Pg(n,RR);for(let i=0;i<r.length;i++)this.scriptTagHolder.enqueueSegment(this.curSegmentNum,r.length,r[i]),this.curSegmentNum++}addDisconnectPingFrame(e,t){this.myDisconnFrame=document.createElement("iframe");const n={};n[vR]="t",n[Jg]=e,n[jg]=t,this.myDisconnFrame.src=this.urlFn(n),this.myDisconnFrame.style.display="none",document.body.appendChild(this.myDisconnFrame)}incrementIncomingBytes_(e){const t=tt(e).length;this.bytesReceived+=t,this.stats_.incrementCounter("bytes_received",t)}}class Uc{constructor(e,t,n,r){this.onDisconnect=n,this.urlFn=r,this.outstandingRequests=new Set,this.pendingSegs=[],this.currentSerial=Math.floor(Math.random()*1e8),this.sendNewPolls=!0;{this.uniqueCallbackIdentifier=nR(),window[DR+this.uniqueCallbackIdentifier]=e,window[yR+this.uniqueCallbackIdentifier]=t,this.myIFrame=Uc.createIFrame_();let i="";this.myIFrame.src&&this.myIFrame.src.substr(0,11)==="javascript:"&&(i='<script>document.domain="'+document.domain+'";<\/script>');const o="<html><body>"+i+"</body></html>";try{this.myIFrame.doc.open(),this.myIFrame.doc.write(o),this.myIFrame.doc.close()}catch(a){Bt("frame writing exception"),a.stack&&Bt(a.stack),Bt(a)}}}static createIFrame_(){const e=document.createElement("iframe");if(e.style.display="none",document.body){document.body.appendChild(e);try{e.contentWindow.document||Bt("No IE domain setting required")}catch{const n=document.domain;e.src="javascript:void((function(){document.open();document.domain='"+n+"';document.close();})())"}}else throw"Document body has not initialized. Wait to initialize Firebase until after the document is ready.";return e.contentDocument?e.doc=e.contentDocument:e.contentWindow?e.doc=e.contentWindow.document:e.document&&(e.doc=e.document),e}close(){this.alive=!1,this.myIFrame&&(this.myIFrame.doc.body.textContent="",setTimeout(()=>{this.myIFrame!==null&&(document.body.removeChild(this.myIFrame),this.myIFrame=null)},Math.floor(0)));const e=this.onDisconnect;e&&(this.onDisconnect=null,e())}startLongPoll(e,t){for(this.myID=e,this.myPW=t,this.alive=!0;this.newRequest_(););}newRequest_(){if(this.alive&&this.sendNewPolls&&this.outstandingRequests.size<(this.pendingSegs.length>0?2:1)){this.currentSerial++;const e={};e[Jg]=this.myID,e[jg]=this.myPW,e[Kg]=this.currentSerial;let t=this.urlFn(e),n="",r=0;for(;this.pendingSegs.length>0&&this.pendingSegs[0].d.length+Qg+n.length<=zg;){const o=this.pendingSegs.shift();n=n+"&"+TR+r+"="+o.seg+"&"+IR+r+"="+o.ts+"&"+AR+r+"="+o.d,r++}return t=t+n,this.addLongPollTag_(t,this.currentSerial),!0}else return!1}enqueueSegment(e,t,n){this.pendingSegs.push({seg:e,ts:t,d:n}),this.alive&&this.newRequest_()}addLongPollTag_(e,t){this.outstandingRequests.add(t);const n=()=>{this.outstandingRequests.delete(t),this.newRequest_()},r=setTimeout(n,Math.floor(SR)),i=()=>{clearTimeout(r),n()};this.addTag(e,i)}addTag(e,t){setTimeout(()=>{try{if(!this.sendNewPolls)return;const n=this.myIFrame.doc.createElement("script");n.type="text/javascript",n.async=!0,n.src=e,n.onload=n.onreadystatechange=function(){const r=n.readyState;(!r||r==="loaded"||r==="complete")&&(n.onload=n.onreadystatechange=null,n.parentNode&&n.parentNode.removeChild(n),t())},n.onerror=()=>{Bt("Long-poll script failed to load: "+e),this.sendNewPolls=!1,this.close()},this.myIFrame.doc.body.appendChild(n)}catch{}},Math.floor(1))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const NR=16384,PR=45e3;let ia=null;typeof MozWebSocket<"u"?ia=MozWebSocket:typeof WebSocket<"u"&&(ia=WebSocket);class Ut{constructor(e,t,n,r,i,o,a){this.connId=e,this.applicationId=n,this.appCheckToken=r,this.authToken=i,this.keepaliveTimer=null,this.frames=null,this.totalFrames=0,this.bytesSent=0,this.bytesReceived=0,this.log_=eo(this.connId),this.stats_=Hc(t),this.connURL=Ut.connectionURL_(t,o,a,r,n),this.nodeAdmin=t.nodeAdmin}static connectionURL_(e,t,n,r,i){const o={};return o[Og]=Gc,typeof location<"u"&&location.hostname&&Vg.test(location.hostname)&&(o[xg]=kg),t&&(o[Lg]=t),n&&(o[Mg]=n),r&&(o[El]=r),i&&(o[Gg]=i),qg(e,Hg,o)}open(e,t){this.onDisconnect=t,this.onMessage=e,this.log_("Websocket connecting to "+this.connURL),this.everConnected_=!1,_s.set("previous_websocket_failure",!0);try{let n;F_(),this.mySock=new ia(this.connURL,[],n)}catch(n){this.log_("Error instantiating WebSocket.");const r=n.message||n.data;r&&this.log_(r),this.onClosed_();return}this.mySock.onopen=()=>{this.log_("Websocket connected."),this.everConnected_=!0},this.mySock.onclose=()=>{this.log_("Websocket connection was disconnected."),this.mySock=null,this.onClosed_()},this.mySock.onmessage=n=>{this.handleIncomingFrame(n)},this.mySock.onerror=n=>{this.log_("WebSocket error.  Closing connection.");const r=n.message||n.data;r&&this.log_(r),this.onClosed_()}}start(){}static forceDisallow(){Ut.forceDisallow_=!0}static isAvailable(){let e=!1;if(typeof navigator<"u"&&navigator.userAgent){const t=/Android ([0-9]{0,}\.[0-9]{0,})/,n=navigator.userAgent.match(t);n&&n.length>1&&parseFloat(n[1])<4.4&&(e=!0)}return!e&&ia!==null&&!Ut.forceDisallow_}static previouslyFailed(){return _s.isInMemoryStorage||_s.get("previous_websocket_failure")===!0}markConnectionHealthy(){_s.remove("previous_websocket_failure")}appendFrame_(e){if(this.frames.push(e),this.frames.length===this.totalFrames){const t=this.frames.join("");this.frames=null;const n=di(t);this.onMessage(n)}}handleNewFrameCount_(e){this.totalFrames=e,this.frames=[]}extractFrameCount_(e){if(K(this.frames===null,"We already have a frame buffer"),e.length<=6){const t=Number(e);if(!isNaN(t))return this.handleNewFrameCount_(t),null}return this.handleNewFrameCount_(1),e}handleIncomingFrame(e){if(this.mySock===null)return;const t=e.data;if(this.bytesReceived+=t.length,this.stats_.incrementCounter("bytes_received",t.length),this.resetKeepAlive(),this.frames!==null)this.appendFrame_(t);else{const n=this.extractFrameCount_(t);n!==null&&this.appendFrame_(n)}}send(e){this.resetKeepAlive();const t=tt(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);const n=Pg(t,NR);n.length>1&&this.sendString_(String(n.length));for(let r=0;r<n.length;r++)this.sendString_(n[r])}shutdown_(){this.isClosed_=!0,this.keepaliveTimer&&(clearInterval(this.keepaliveTimer),this.keepaliveTimer=null),this.mySock&&(this.mySock.close(),this.mySock=null)}onClosed_(){this.isClosed_||(this.log_("WebSocket is closing itself"),this.shutdown_(),this.onDisconnect&&(this.onDisconnect(this.everConnected_),this.onDisconnect=null))}close(){this.isClosed_||(this.log_("WebSocket is being closed"),this.shutdown_())}resetKeepAlive(){clearInterval(this.keepaliveTimer),this.keepaliveTimer=setInterval(()=>{this.mySock&&this.sendString_("0"),this.resetKeepAlive()},Math.floor(PR))}sendString_(e){try{this.mySock.send(e)}catch(t){this.log_("Exception thrown from WebSocket.send():",t.message||t.data,"Closing connection."),setTimeout(this.onClosed_.bind(this),0)}}}Ut.responsesRequiredToBeHealthy=2;Ut.healthyTimeout=3e4;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Li{static get ALL_TRANSPORTS(){return[Ys,Ut]}static get IS_TRANSPORT_INITIALIZED(){return this.globalTransportInitialized_}constructor(e){this.initTransports_(e)}initTransports_(e){const t=Ut&&Ut.isAvailable();let n=t&&!Ut.previouslyFailed();if(e.webSocketOnly&&(t||Lt("wss:// URL used, but browser isn't known to support websockets.  Trying anyway."),n=!0),n)this.transports_=[Ut];else{const r=this.transports_=[];for(const i of Li.ALL_TRANSPORTS)i&&i.isAvailable()&&r.push(i);Li.globalTransportInitialized_=!0}}initialTransport(){if(this.transports_.length>0)return this.transports_[0];throw new Error("No transports available")}upgradeTransport(){return this.transports_.length>1?this.transports_[1]:null}}Li.globalTransportInitialized_=!1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const FR=6e4,OR=5e3,LR=10*1024,xR=100*1024,MB="t",rC="d",kR="s",iC="r",VR="e",oC="o",aC="a",BC="n",lC="p",MR="h";class GR{constructor(e,t,n,r,i,o,a,l,c,h){this.id=e,this.repoInfo_=t,this.applicationId_=n,this.appCheckToken_=r,this.authToken_=i,this.onMessage_=o,this.onReady_=a,this.onDisconnect_=l,this.onKill_=c,this.lastSessionId=h,this.connectionCount=0,this.pendingDataMessages=[],this.state_=0,this.log_=eo("c:"+this.id+":"),this.transportManager_=new Li(t),this.log_("Connection created"),this.start_()}start_(){const e=this.transportManager_.initialTransport();this.conn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,null,this.lastSessionId),this.primaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;const t=this.connReceiver_(this.conn_),n=this.disconnReceiver_(this.conn_);this.tx_=this.conn_,this.rx_=this.conn_,this.secondaryConn_=null,this.isHealthy_=!1,setTimeout(()=>{this.conn_&&this.conn_.open(t,n)},Math.floor(0));const r=e.healthyTimeout||0;r>0&&(this.healthyTimeout_=hi(()=>{this.healthyTimeout_=null,this.isHealthy_||(this.conn_&&this.conn_.bytesReceived>xR?(this.log_("Connection exceeded healthy timeout but has received "+this.conn_.bytesReceived+" bytes.  Marking connection healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()):this.conn_&&this.conn_.bytesSent>LR?this.log_("Connection exceeded healthy timeout but has sent "+this.conn_.bytesSent+" bytes.  Leaving connection alive."):(this.log_("Closing unhealthy connection after timeout."),this.close()))},Math.floor(r)))}nextTransportId_(){return"c:"+this.id+":"+this.connectionCount++}disconnReceiver_(e){return t=>{e===this.conn_?this.onConnectionLost_(t):e===this.secondaryConn_?(this.log_("Secondary connection lost."),this.onSecondaryConnectionLost_()):this.log_("closing an old connection")}}connReceiver_(e){return t=>{this.state_!==2&&(e===this.rx_?this.onPrimaryMessageReceived_(t):e===this.secondaryConn_?this.onSecondaryMessageReceived_(t):this.log_("message on old connection"))}}sendRequest(e){const t={t:"d",d:e};this.sendData_(t)}tryCleanupConnection(){this.tx_===this.secondaryConn_&&this.rx_===this.secondaryConn_&&(this.log_("cleaning up and promoting a connection: "+this.secondaryConn_.connId),this.conn_=this.secondaryConn_,this.secondaryConn_=null)}onSecondaryControl_(e){if(MB in e){const t=e[MB];t===aC?this.upgradeIfSecondaryHealthy_():t===iC?(this.log_("Got a reset on secondary, closing it"),this.secondaryConn_.close(),(this.tx_===this.secondaryConn_||this.rx_===this.secondaryConn_)&&this.close()):t===oC&&(this.log_("got pong on secondary."),this.secondaryResponsesRequired_--,this.upgradeIfSecondaryHealthy_())}}onSecondaryMessageReceived_(e){const t=Qr("t",e),n=Qr("d",e);if(t==="c")this.onSecondaryControl_(n);else if(t==="d")this.pendingDataMessages.push(n);else throw new Error("Unknown protocol layer: "+t)}upgradeIfSecondaryHealthy_(){this.secondaryResponsesRequired_<=0?(this.log_("Secondary connection is healthy."),this.isHealthy_=!0,this.secondaryConn_.markConnectionHealthy(),this.proceedWithUpgrade_()):(this.log_("sending ping on secondary."),this.secondaryConn_.send({t:"c",d:{t:lC,d:{}}}))}proceedWithUpgrade_(){this.secondaryConn_.start(),this.log_("sending client ack on secondary"),this.secondaryConn_.send({t:"c",d:{t:aC,d:{}}}),this.log_("Ending transmission on primary"),this.conn_.send({t:"c",d:{t:BC,d:{}}}),this.tx_=this.secondaryConn_,this.tryCleanupConnection()}onPrimaryMessageReceived_(e){const t=Qr("t",e),n=Qr("d",e);t==="c"?this.onControl_(n):t==="d"&&this.onDataMessage_(n)}onDataMessage_(e){this.onPrimaryResponse_(),this.onMessage_(e)}onPrimaryResponse_(){this.isHealthy_||(this.primaryResponsesRequired_--,this.primaryResponsesRequired_<=0&&(this.log_("Primary connection is healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()))}onControl_(e){const t=Qr(MB,e);if(rC in e){const n=e[rC];if(t===MR){const r={...n};this.repoInfo_.isUsingEmulator&&(r.h=this.repoInfo_.host),this.onHandshake_(r)}else if(t===BC){this.log_("recvd end transmission on primary"),this.rx_=this.secondaryConn_;for(let r=0;r<this.pendingDataMessages.length;++r)this.onDataMessage_(this.pendingDataMessages[r]);this.pendingDataMessages=[],this.tryCleanupConnection()}else t===kR?this.onConnectionShutdown_(n):t===iC?this.onReset_(n):t===VR?_l("Server Error: "+n):t===oC?(this.log_("got pong on primary."),this.onPrimaryResponse_(),this.sendPingOnPrimaryIfNecessary_()):_l("Unknown control packet command: "+t)}}onHandshake_(e){const t=e.ts,n=e.v,r=e.h;this.sessionId=e.s,this.repoInfo_.host=r,this.state_===0&&(this.conn_.start(),this.onConnectionEstablished_(this.conn_,t),Gc!==n&&Lt("Protocol version mismatch detected"),this.tryStartUpgrade_())}tryStartUpgrade_(){const e=this.transportManager_.upgradeTransport();e&&this.startUpgrade_(e)}startUpgrade_(e){this.secondaryConn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,this.sessionId),this.secondaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;const t=this.connReceiver_(this.secondaryConn_),n=this.disconnReceiver_(this.secondaryConn_);this.secondaryConn_.open(t,n),hi(()=>{this.secondaryConn_&&(this.log_("Timed out trying to upgrade."),this.secondaryConn_.close())},Math.floor(FR))}onReset_(e){this.log_("Reset packet received.  New host: "+e),this.repoInfo_.host=e,this.state_===1?this.close():(this.closeConnections_(),this.start_())}onConnectionEstablished_(e,t){this.log_("Realtime connection established."),this.conn_=e,this.state_=1,this.onReady_&&(this.onReady_(t,this.sessionId),this.onReady_=null),this.primaryResponsesRequired_===0?(this.log_("Primary connection is healthy."),this.isHealthy_=!0):hi(()=>{this.sendPingOnPrimaryIfNecessary_()},Math.floor(OR))}sendPingOnPrimaryIfNecessary_(){!this.isHealthy_&&this.state_===1&&(this.log_("sending ping on primary."),this.sendData_({t:"c",d:{t:lC,d:{}}}))}onSecondaryConnectionLost_(){const e=this.secondaryConn_;this.secondaryConn_=null,(this.tx_===e||this.rx_===e)&&this.close()}onConnectionLost_(e){this.conn_=null,!e&&this.state_===0?(this.log_("Realtime connection failed."),this.repoInfo_.isCacheableHost()&&(_s.remove("host:"+this.repoInfo_.host),this.repoInfo_.internalHost=this.repoInfo_.host)):this.state_===1&&this.log_("Realtime connection lost."),this.close()}onConnectionShutdown_(e){this.log_("Connection shutdown command received. Shutting down..."),this.onKill_&&(this.onKill_(e),this.onKill_=null),this.onDisconnect_=null,this.close()}sendData_(e){if(this.state_!==1)throw"Connection is not connected";this.tx_.send(e)}close(){this.state_!==2&&(this.log_("Closing realtime connection."),this.state_=2,this.closeConnections_(),this.onDisconnect_&&(this.onDisconnect_(),this.onDisconnect_=null))}closeConnections_(){this.log_("Shutting down all connections"),this.conn_&&(this.conn_.close(),this.conn_=null),this.secondaryConn_&&(this.secondaryConn_.close(),this.secondaryConn_=null),this.healthyTimeout_&&(clearTimeout(this.healthyTimeout_),this.healthyTimeout_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wg{put(e,t,n,r){}merge(e,t,n,r){}refreshAuthToken(e){}refreshAppCheckToken(e){}onDisconnectPut(e,t,n){}onDisconnectMerge(e,t,n){}onDisconnectCancel(e,t){}reportStats(e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yg{constructor(e){this.allowedEvents_=e,this.listeners_={},K(Array.isArray(e)&&e.length>0,"Requires a non-empty array")}trigger(e,...t){if(Array.isArray(this.listeners_[e])){const n=[...this.listeners_[e]];for(let r=0;r<n.length;r++)n[r].callback.apply(n[r].context,t)}}on(e,t,n){this.validateEventType_(e),this.listeners_[e]=this.listeners_[e]||[],this.listeners_[e].push({callback:t,context:n});const r=this.getInitialEvent(e);r&&t.apply(n,r)}off(e,t,n){this.validateEventType_(e);const r=this.listeners_[e]||[];for(let i=0;i<r.length;i++)if(r[i].callback===t&&(!n||n===r[i].context)){r.splice(i,1);return}}validateEventType_(e){K(this.allowedEvents_.find(t=>t===e),"Unknown event: "+e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oa extends Yg{static getInstance(){return new oa}constructor(){super(["online"]),this.online_=!0,typeof window<"u"&&typeof window.addEventListener<"u"&&!MC()&&(window.addEventListener("online",()=>{this.online_||(this.online_=!0,this.trigger("online",!0))},!1),window.addEventListener("offline",()=>{this.online_&&(this.online_=!1,this.trigger("online",!1))},!1))}getInitialEvent(e){return K(e==="online","Unknown event type: "+e),[this.online_]}currentlyOnline(){return this.online_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cC=32,uC=768;class be{constructor(e,t){if(t===void 0){this.pieces_=e.split("/");let n=0;for(let r=0;r<this.pieces_.length;r++)this.pieces_[r].length>0&&(this.pieces_[n]=this.pieces_[r],n++);this.pieces_.length=n,this.pieceNum_=0}else this.pieces_=e,this.pieceNum_=t}toString(){let e="";for(let t=this.pieceNum_;t<this.pieces_.length;t++)this.pieces_[t]!==""&&(e+="/"+this.pieces_[t]);return e||"/"}}function Ee(){return new be("")}function fe(s){return s.pieceNum_>=s.pieces_.length?null:s.pieces_[s.pieceNum_]}function ns(s){return s.pieces_.length-s.pieceNum_}function Se(s){let e=s.pieceNum_;return e<s.pieces_.length&&e++,new be(s.pieces_,e)}function $g(s){return s.pieceNum_<s.pieces_.length?s.pieces_[s.pieces_.length-1]:null}function HR(s){let e="";for(let t=s.pieceNum_;t<s.pieces_.length;t++)s.pieces_[t]!==""&&(e+="/"+encodeURIComponent(String(s.pieces_[t])));return e||"/"}function Xg(s,e=0){return s.pieces_.slice(s.pieceNum_+e)}function Zg(s){if(s.pieceNum_>=s.pieces_.length)return null;const e=[];for(let t=s.pieceNum_;t<s.pieces_.length-1;t++)e.push(s.pieces_[t]);return new be(e,0)}function Ze(s,e){const t=[];for(let n=s.pieceNum_;n<s.pieces_.length;n++)t.push(s.pieces_[n]);if(e instanceof be)for(let n=e.pieceNum_;n<e.pieces_.length;n++)t.push(e.pieces_[n]);else{const n=e.split("/");for(let r=0;r<n.length;r++)n[r].length>0&&t.push(n[r])}return new be(t,0)}function ce(s){return s.pieceNum_>=s.pieces_.length}function Vt(s,e){const t=fe(s),n=fe(e);if(t===null)return e;if(t===n)return Vt(Se(s),Se(e));throw new Error("INTERNAL ERROR: innerPath ("+e+") is not within outerPath ("+s+")")}function em(s,e){if(ns(s)!==ns(e))return!1;for(let t=s.pieceNum_,n=e.pieceNum_;t<=s.pieces_.length;t++,n++)if(s.pieces_[t]!==e.pieces_[n])return!1;return!0}function qt(s,e){let t=s.pieceNum_,n=e.pieceNum_;if(ns(s)>ns(e))return!1;for(;t<s.pieces_.length;){if(s.pieces_[t]!==e.pieces_[n])return!1;++t,++n}return!0}class UR{constructor(e,t){this.errorPrefix_=t,this.parts_=Xg(e,0),this.byteLength_=Math.max(1,this.parts_.length);for(let n=0;n<this.parts_.length;n++)this.byteLength_+=Ca(this.parts_[n]);tm(this)}}function qR(s,e){s.parts_.length>0&&(s.byteLength_+=1),s.parts_.push(e),s.byteLength_+=Ca(e),tm(s)}function JR(s){const e=s.parts_.pop();s.byteLength_-=Ca(e),s.parts_.length>0&&(s.byteLength_-=1)}function tm(s){if(s.byteLength_>uC)throw new Error(s.errorPrefix_+"has a key path longer than "+uC+" bytes ("+s.byteLength_+").");if(s.parts_.length>cC)throw new Error(s.errorPrefix_+"path specified exceeds the maximum depth that can be written ("+cC+") or object contains a cycle "+Cs(s))}function Cs(s){return s.parts_.length===0?"":"in property '"+s.parts_.join(".")+"'"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qc extends Yg{static getInstance(){return new qc}constructor(){super(["visible"]);let e,t;typeof document<"u"&&typeof document.addEventListener<"u"&&(typeof document.hidden<"u"?(t="visibilitychange",e="hidden"):typeof document.mozHidden<"u"?(t="mozvisibilitychange",e="mozHidden"):typeof document.msHidden<"u"?(t="msvisibilitychange",e="msHidden"):typeof document.webkitHidden<"u"&&(t="webkitvisibilitychange",e="webkitHidden")),this.visible_=!0,t&&document.addEventListener(t,()=>{const n=!document[e];n!==this.visible_&&(this.visible_=n,this.trigger("visible",n))},!1)}getInitialEvent(e){return K(e==="visible","Unknown event type: "+e),[this.visible_]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wr=1e3,jR=60*5*1e3,hC=30*1e3,KR=1.3,zR=3e4,QR="server_kill",fC=3;class pn extends Wg{constructor(e,t,n,r,i,o,a,l){if(super(),this.repoInfo_=e,this.applicationId_=t,this.onDataUpdate_=n,this.onConnectStatus_=r,this.onServerInfoUpdate_=i,this.authTokenProvider_=o,this.appCheckTokenProvider_=a,this.authOverride_=l,this.id=pn.nextPersistentConnectionId_++,this.log_=eo("p:"+this.id+":"),this.interruptReasons_={},this.listens=new Map,this.outstandingPuts_=[],this.outstandingGets_=[],this.outstandingPutCount_=0,this.outstandingGetCount_=0,this.onDisconnectRequestQueue_=[],this.connected_=!1,this.reconnectDelay_=Wr,this.maxReconnectDelay_=jR,this.securityDebugCallback_=null,this.lastSessionId=null,this.establishConnectionTimer_=null,this.visible_=!1,this.requestCBHash_={},this.requestNumber_=0,this.realtime_=null,this.authToken_=null,this.appCheckToken_=null,this.forceTokenRefresh_=!1,this.invalidAuthTokenCount_=0,this.invalidAppCheckTokenCount_=0,this.firstConnection_=!0,this.lastConnectionAttemptTime_=null,this.lastConnectionEstablishedTime_=null,l)throw new Error("Auth override specified in options, but not supported on non Node.js platforms");qc.getInstance().on("visible",this.onVisible_,this),e.host.indexOf("fblocal")===-1&&oa.getInstance().on("online",this.onOnline_,this)}sendRequest(e,t,n){const r=++this.requestNumber_,i={r,a:e,b:t};this.log_(tt(i)),K(this.connected_,"sendRequest call when we're not connected not allowed."),this.realtime_.sendRequest(i),n&&(this.requestCBHash_[r]=n)}get(e){this.initConnection_();const t=new Fl,r={action:"g",request:{p:e._path.toString(),q:e._queryObject},onComplete:o=>{const a=o.d;o.s==="ok"?t.resolve(a):t.reject(a)}};this.outstandingGets_.push(r),this.outstandingGetCount_++;const i=this.outstandingGets_.length-1;return this.connected_&&this.sendGet_(i),t.promise}listen(e,t,n,r){this.initConnection_();const i=e._queryIdentifier,o=e._path.toString();this.log_("Listen called for "+o+" "+i),this.listens.has(o)||this.listens.set(o,new Map),K(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"listen() called for non-default but complete query"),K(!this.listens.get(o).has(i),"listen() called twice for same path/queryId.");const a={onComplete:r,hashFn:t,query:e,tag:n};this.listens.get(o).set(i,a),this.connected_&&this.sendListen_(a)}sendGet_(e){const t=this.outstandingGets_[e];this.sendRequest("g",t.request,n=>{delete this.outstandingGets_[e],this.outstandingGetCount_--,this.outstandingGetCount_===0&&(this.outstandingGets_=[]),t.onComplete&&t.onComplete(n)})}sendListen_(e){const t=e.query,n=t._path.toString(),r=t._queryIdentifier;this.log_("Listen on "+n+" for "+r);const i={p:n},o="q";e.tag&&(i.q=t._queryObject,i.t=e.tag),i.h=e.hashFn(),this.sendRequest(o,i,a=>{const l=a.d,c=a.s;pn.warnOnListenWarnings_(l,t),(this.listens.get(n)&&this.listens.get(n).get(r))===e&&(this.log_("listen response",a),c!=="ok"&&this.removeListen_(n,r),e.onComplete&&e.onComplete(c,l))})}static warnOnListenWarnings_(e,t){if(e&&typeof e=="object"&&wn(e,"w")){const n=nr(e,"w");if(Array.isArray(n)&&~n.indexOf("no_index")){const r='".indexOn": "'+t._queryParams.getIndex().toString()+'"',i=t._path.toString();Lt(`Using an unspecified index. Your data will be downloaded and filtered on the client. Consider adding ${r} at ${i} to your security rules for better performance.`)}}}refreshAuthToken(e){this.authToken_=e,this.log_("Auth token refreshed"),this.authToken_?this.tryAuth():this.connected_&&this.sendRequest("unauth",{},()=>{}),this.reduceReconnectDelayIfAdminCredential_(e)}reduceReconnectDelayIfAdminCredential_(e){(e&&e.length===40||M_(e))&&(this.log_("Admin auth credential detected.  Reducing max reconnect time."),this.maxReconnectDelay_=hC)}refreshAppCheckToken(e){this.appCheckToken_=e,this.log_("App check token refreshed"),this.appCheckToken_?this.tryAppCheck():this.connected_&&this.sendRequest("unappeck",{},()=>{})}tryAuth(){if(this.connected_&&this.authToken_){const e=this.authToken_,t=V_(e)?"auth":"gauth",n={cred:e};this.authOverride_===null?n.noauth=!0:typeof this.authOverride_=="object"&&(n.authvar=this.authOverride_),this.sendRequest(t,n,r=>{const i=r.s,o=r.d||"error";this.authToken_===e&&(i==="ok"?this.invalidAuthTokenCount_=0:this.onAuthRevoked_(i,o))})}}tryAppCheck(){this.connected_&&this.appCheckToken_&&this.sendRequest("appcheck",{token:this.appCheckToken_},e=>{const t=e.s,n=e.d||"error";t==="ok"?this.invalidAppCheckTokenCount_=0:this.onAppCheckRevoked_(t,n)})}unlisten(e,t){const n=e._path.toString(),r=e._queryIdentifier;this.log_("Unlisten called for "+n+" "+r),K(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"unlisten() called for non-default but complete query"),this.removeListen_(n,r)&&this.connected_&&this.sendUnlisten_(n,r,e._queryObject,t)}sendUnlisten_(e,t,n,r){this.log_("Unlisten on "+e+" for "+t);const i={p:e},o="n";r&&(i.q=n,i.t=r),this.sendRequest(o,i)}onDisconnectPut(e,t,n){this.initConnection_(),this.connected_?this.sendOnDisconnect_("o",e,t,n):this.onDisconnectRequestQueue_.push({pathString:e,action:"o",data:t,onComplete:n})}onDisconnectMerge(e,t,n){this.initConnection_(),this.connected_?this.sendOnDisconnect_("om",e,t,n):this.onDisconnectRequestQueue_.push({pathString:e,action:"om",data:t,onComplete:n})}onDisconnectCancel(e,t){this.initConnection_(),this.connected_?this.sendOnDisconnect_("oc",e,null,t):this.onDisconnectRequestQueue_.push({pathString:e,action:"oc",data:null,onComplete:t})}sendOnDisconnect_(e,t,n,r){const i={p:t,d:n};this.log_("onDisconnect "+e,i),this.sendRequest(e,i,o=>{r&&setTimeout(()=>{r(o.s,o.d)},Math.floor(0))})}put(e,t,n,r){this.putInternal("p",e,t,n,r)}merge(e,t,n,r){this.putInternal("m",e,t,n,r)}putInternal(e,t,n,r,i){this.initConnection_();const o={p:t,d:n};i!==void 0&&(o.h=i),this.outstandingPuts_.push({action:e,request:o,onComplete:r}),this.outstandingPutCount_++;const a=this.outstandingPuts_.length-1;this.connected_?this.sendPut_(a):this.log_("Buffering put: "+t)}sendPut_(e){const t=this.outstandingPuts_[e].action,n=this.outstandingPuts_[e].request,r=this.outstandingPuts_[e].onComplete;this.outstandingPuts_[e].queued=this.connected_,this.sendRequest(t,n,i=>{this.log_(t+" response",i),delete this.outstandingPuts_[e],this.outstandingPutCount_--,this.outstandingPutCount_===0&&(this.outstandingPuts_=[]),r&&r(i.s,i.d)})}reportStats(e){if(this.connected_){const t={c:e};this.log_("reportStats",t),this.sendRequest("s",t,n=>{if(n.s!=="ok"){const i=n.d;this.log_("reportStats","Error sending stats: "+i)}})}}onDataMessage_(e){if("r"in e){this.log_("from server: "+tt(e));const t=e.r,n=this.requestCBHash_[t];n&&(delete this.requestCBHash_[t],n(e.b))}else{if("error"in e)throw"A server-side error has occurred: "+e.error;"a"in e&&this.onDataPush_(e.a,e.b)}}onDataPush_(e,t){this.log_("handleServerMessage",e,t),e==="d"?this.onDataUpdate_(t.p,t.d,!1,t.t):e==="m"?this.onDataUpdate_(t.p,t.d,!0,t.t):e==="c"?this.onListenRevoked_(t.p,t.q):e==="ac"?this.onAuthRevoked_(t.s,t.d):e==="apc"?this.onAppCheckRevoked_(t.s,t.d):e==="sd"?this.onSecurityDebugPacket_(t):_l("Unrecognized action received from server: "+tt(e)+`
Are you using the latest client?`)}onReady_(e,t){this.log_("connection ready"),this.connected_=!0,this.lastConnectionEstablishedTime_=new Date().getTime(),this.handleTimestamp_(e),this.lastSessionId=t,this.firstConnection_&&this.sendConnectStats_(),this.restoreState_(),this.firstConnection_=!1,this.onConnectStatus_(!0)}scheduleConnect_(e){K(!this.realtime_,"Scheduling a connect when we're already connected/ing?"),this.establishConnectionTimer_&&clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=setTimeout(()=>{this.establishConnectionTimer_=null,this.establishConnection_()},Math.floor(e))}initConnection_(){!this.realtime_&&this.firstConnection_&&this.scheduleConnect_(0)}onVisible_(e){e&&!this.visible_&&this.reconnectDelay_===this.maxReconnectDelay_&&(this.log_("Window became visible.  Reducing delay."),this.reconnectDelay_=Wr,this.realtime_||this.scheduleConnect_(0)),this.visible_=e}onOnline_(e){e?(this.log_("Browser went online."),this.reconnectDelay_=Wr,this.realtime_||this.scheduleConnect_(0)):(this.log_("Browser went offline.  Killing connection."),this.realtime_&&this.realtime_.close())}onRealtimeDisconnect_(){if(this.log_("data client disconnected"),this.connected_=!1,this.realtime_=null,this.cancelSentTransactions_(),this.requestCBHash_={},this.shouldReconnect_()){this.visible_?this.lastConnectionEstablishedTime_&&(new Date().getTime()-this.lastConnectionEstablishedTime_>zR&&(this.reconnectDelay_=Wr),this.lastConnectionEstablishedTime_=null):(this.log_("Window isn't visible.  Delaying reconnect."),this.reconnectDelay_=this.maxReconnectDelay_,this.lastConnectionAttemptTime_=new Date().getTime());const e=Math.max(0,new Date().getTime()-this.lastConnectionAttemptTime_);let t=Math.max(0,this.reconnectDelay_-e);t=Math.random()*t,this.log_("Trying to reconnect in "+t+"ms"),this.scheduleConnect_(t),this.reconnectDelay_=Math.min(this.maxReconnectDelay_,this.reconnectDelay_*KR)}this.onConnectStatus_(!1)}async establishConnection_(){if(this.shouldReconnect_()){this.log_("Making a connection attempt"),this.lastConnectionAttemptTime_=new Date().getTime(),this.lastConnectionEstablishedTime_=null;const e=this.onDataMessage_.bind(this),t=this.onReady_.bind(this),n=this.onRealtimeDisconnect_.bind(this),r=this.id+":"+pn.nextConnectionId_++,i=this.lastSessionId;let o=!1,a=null;const l=function(){a?a.close():(o=!0,n())},c=function(f){K(a,"sendRequest call when we're not connected not allowed."),a.sendRequest(f)};this.realtime_={close:l,sendRequest:c};const h=this.forceTokenRefresh_;this.forceTokenRefresh_=!1;try{const[f,d]=await Promise.all([this.authTokenProvider_.getToken(h),this.appCheckTokenProvider_.getToken(h)]);o?Bt("getToken() completed but was canceled"):(Bt("getToken() completed. Creating connection."),this.authToken_=f&&f.accessToken,this.appCheckToken_=d&&d.token,a=new GR(r,this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,e,t,n,_=>{Lt(_+" ("+this.repoInfo_.toString()+")"),this.interrupt(QR)},i))}catch(f){this.log_("Failed to get token: "+f),o||(this.repoInfo_.nodeAdmin&&Lt(f),l())}}}interrupt(e){Bt("Interrupting connection for reason: "+e),this.interruptReasons_[e]=!0,this.realtime_?this.realtime_.close():(this.establishConnectionTimer_&&(clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=null),this.connected_&&this.onRealtimeDisconnect_())}resume(e){Bt("Resuming connection for reason: "+e),delete this.interruptReasons_[e],Bh(this.interruptReasons_)&&(this.reconnectDelay_=Wr,this.realtime_||this.scheduleConnect_(0))}handleTimestamp_(e){const t=e-new Date().getTime();this.onServerInfoUpdate_({serverTimeOffset:t})}cancelSentTransactions_(){for(let e=0;e<this.outstandingPuts_.length;e++){const t=this.outstandingPuts_[e];t&&"h"in t.request&&t.queued&&(t.onComplete&&t.onComplete("disconnect"),delete this.outstandingPuts_[e],this.outstandingPutCount_--)}this.outstandingPutCount_===0&&(this.outstandingPuts_=[])}onListenRevoked_(e,t){let n;t?n=t.map(i=>Mc(i)).join("$"):n="default";const r=this.removeListen_(e,n);r&&r.onComplete&&r.onComplete("permission_denied")}removeListen_(e,t){const n=new be(e).toString();let r;if(this.listens.has(n)){const i=this.listens.get(n);r=i.get(t),i.delete(t),i.size===0&&this.listens.delete(n)}else r=void 0;return r}onAuthRevoked_(e,t){Bt("Auth token revoked: "+e+"/"+t),this.authToken_=null,this.forceTokenRefresh_=!0,this.realtime_.close(),(e==="invalid_token"||e==="permission_denied")&&(this.invalidAuthTokenCount_++,this.invalidAuthTokenCount_>=fC&&(this.reconnectDelay_=hC,this.authTokenProvider_.notifyForInvalidToken()))}onAppCheckRevoked_(e,t){Bt("App check token revoked: "+e+"/"+t),this.appCheckToken_=null,this.forceTokenRefresh_=!0,(e==="invalid_token"||e==="permission_denied")&&(this.invalidAppCheckTokenCount_++,this.invalidAppCheckTokenCount_>=fC&&this.appCheckTokenProvider_.notifyForInvalidToken())}onSecurityDebugPacket_(e){this.securityDebugCallback_?this.securityDebugCallback_(e):"msg"in e&&console.log("FIREBASE: "+e.msg.replace(`
`,`
FIREBASE: `))}restoreState_(){this.tryAuth(),this.tryAppCheck();for(const e of this.listens.values())for(const t of e.values())this.sendListen_(t);for(let e=0;e<this.outstandingPuts_.length;e++)this.outstandingPuts_[e]&&this.sendPut_(e);for(;this.onDisconnectRequestQueue_.length;){const e=this.onDisconnectRequestQueue_.shift();this.sendOnDisconnect_(e.action,e.pathString,e.data,e.onComplete)}for(let e=0;e<this.outstandingGets_.length;e++)this.outstandingGets_[e]&&this.sendGet_(e)}sendConnectStats_(){const e={};let t="js";e["sdk."+t+"."+Rg.replace(/\./g,"-")]=1,MC()?e["framework.cordova"]=1:P_()&&(e["framework.reactnative"]=1),this.reportStats(e)}shouldReconnect_(){const e=oa.getInstance().currentlyOnline();return Bh(this.interruptReasons_)&&e}}pn.nextPersistentConnectionId_=0;pn.nextConnectionId_=0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class de{constructor(e,t){this.name=e,this.node=t}static Wrap(e,t){return new de(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ja{getCompare(){return this.compare.bind(this)}indexedValueChanged(e,t){const n=new de(fr,e),r=new de(fr,t);return this.compare(n,r)!==0}minPost(){return de.MIN}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let No;class nm extends Ja{static get __EMPTY_NODE(){return No}static set __EMPTY_NODE(e){No=e}compare(e,t){return vr(e.name,t.name)}isDefinedOn(e){throw dr("KeyIndex.isDefinedOn not expected to be called.")}indexedValueChanged(e,t){return!1}minPost(){return de.MIN}maxPost(){return new de(bs,No)}makePost(e,t){return K(typeof e=="string","KeyIndex indexValue must always be a string."),new de(e,No)}toString(){return".key"}}const tr=new nm;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Po{constructor(e,t,n,r,i=null){this.isReverse_=r,this.resultGenerator_=i,this.nodeStack_=[];let o=1;for(;!e.isEmpty();)if(e=e,o=t?n(e.key,t):1,r&&(o*=-1),o<0)this.isReverse_?e=e.left:e=e.right;else if(o===0){this.nodeStack_.push(e);break}else this.nodeStack_.push(e),this.isReverse_?e=e.right:e=e.left}getNext(){if(this.nodeStack_.length===0)return null;let e=this.nodeStack_.pop(),t;if(this.resultGenerator_?t=this.resultGenerator_(e.key,e.value):t={key:e.key,value:e.value},this.isReverse_)for(e=e.left;!e.isEmpty();)this.nodeStack_.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack_.push(e),e=e.left;return t}hasNext(){return this.nodeStack_.length>0}peek(){if(this.nodeStack_.length===0)return null;const e=this.nodeStack_[this.nodeStack_.length-1];return this.resultGenerator_?this.resultGenerator_(e.key,e.value):{key:e.key,value:e.value}}}class $e{constructor(e,t,n,r,i){this.key=e,this.value=t,this.color=n??$e.RED,this.left=r??yt.EMPTY_NODE,this.right=i??yt.EMPTY_NODE}copy(e,t,n,r,i){return new $e(e??this.key,t??this.value,n??this.color,r??this.left,i??this.right)}count(){return this.left.count()+1+this.right.count()}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||!!e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min_(){return this.left.isEmpty()?this:this.left.min_()}minKey(){return this.min_().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,n){let r=this;const i=n(e,r.key);return i<0?r=r.copy(null,null,null,r.left.insert(e,t,n),null):i===0?r=r.copy(null,t,null,null,null):r=r.copy(null,null,null,null,r.right.insert(e,t,n)),r.fixUp_()}removeMin_(){if(this.left.isEmpty())return yt.EMPTY_NODE;let e=this;return!e.left.isRed_()&&!e.left.left.isRed_()&&(e=e.moveRedLeft_()),e=e.copy(null,null,null,e.left.removeMin_(),null),e.fixUp_()}remove(e,t){let n,r;if(n=this,t(e,n.key)<0)!n.left.isEmpty()&&!n.left.isRed_()&&!n.left.left.isRed_()&&(n=n.moveRedLeft_()),n=n.copy(null,null,null,n.left.remove(e,t),null);else{if(n.left.isRed_()&&(n=n.rotateRight_()),!n.right.isEmpty()&&!n.right.isRed_()&&!n.right.left.isRed_()&&(n=n.moveRedRight_()),t(e,n.key)===0){if(n.right.isEmpty())return yt.EMPTY_NODE;r=n.right.min_(),n=n.copy(r.key,r.value,null,null,n.right.removeMin_())}n=n.copy(null,null,null,null,n.right.remove(e,t))}return n.fixUp_()}isRed_(){return this.color}fixUp_(){let e=this;return e.right.isRed_()&&!e.left.isRed_()&&(e=e.rotateLeft_()),e.left.isRed_()&&e.left.left.isRed_()&&(e=e.rotateRight_()),e.left.isRed_()&&e.right.isRed_()&&(e=e.colorFlip_()),e}moveRedLeft_(){let e=this.colorFlip_();return e.right.left.isRed_()&&(e=e.copy(null,null,null,null,e.right.rotateRight_()),e=e.rotateLeft_(),e=e.colorFlip_()),e}moveRedRight_(){let e=this.colorFlip_();return e.left.left.isRed_()&&(e=e.rotateRight_(),e=e.colorFlip_()),e}rotateLeft_(){const e=this.copy(null,null,$e.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight_(){const e=this.copy(null,null,$e.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip_(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth_(){const e=this.check_();return Math.pow(2,e)<=this.count()+1}check_(){if(this.isRed_()&&this.left.isRed_())throw new Error("Red node has red child("+this.key+","+this.value+")");if(this.right.isRed_())throw new Error("Right child of ("+this.key+","+this.value+") is red");const e=this.left.check_();if(e!==this.right.check_())throw new Error("Black depths differ");return e+(this.isRed_()?0:1)}}$e.RED=!0;$e.BLACK=!1;class WR{copy(e,t,n,r,i){return this}insert(e,t,n){return new $e(e,t,null)}remove(e,t){return this}count(){return 0}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}check_(){return 0}isRed_(){return!1}}class yt{constructor(e,t=yt.EMPTY_NODE){this.comparator_=e,this.root_=t}insert(e,t){return new yt(this.comparator_,this.root_.insert(e,t,this.comparator_).copy(null,null,$e.BLACK,null,null))}remove(e){return new yt(this.comparator_,this.root_.remove(e,this.comparator_).copy(null,null,$e.BLACK,null,null))}get(e){let t,n=this.root_;for(;!n.isEmpty();){if(t=this.comparator_(e,n.key),t===0)return n.value;t<0?n=n.left:t>0&&(n=n.right)}return null}getPredecessorKey(e){let t,n=this.root_,r=null;for(;!n.isEmpty();)if(t=this.comparator_(e,n.key),t===0){if(n.left.isEmpty())return r?r.key:null;for(n=n.left;!n.right.isEmpty();)n=n.right;return n.key}else t<0?n=n.left:t>0&&(r=n,n=n.right);throw new Error("Attempted to find predecessor key for a nonexistent key.  What gives?")}isEmpty(){return this.root_.isEmpty()}count(){return this.root_.count()}minKey(){return this.root_.minKey()}maxKey(){return this.root_.maxKey()}inorderTraversal(e){return this.root_.inorderTraversal(e)}reverseTraversal(e){return this.root_.reverseTraversal(e)}getIterator(e){return new Po(this.root_,null,this.comparator_,!1,e)}getIteratorFrom(e,t){return new Po(this.root_,e,this.comparator_,!1,t)}getReverseIteratorFrom(e,t){return new Po(this.root_,e,this.comparator_,!0,t)}getReverseIterator(e){return new Po(this.root_,null,this.comparator_,!0,e)}}yt.EMPTY_NODE=new WR;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function YR(s,e){return vr(s.name,e.name)}function Jc(s,e){return vr(s,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Dl;function $R(s){Dl=s}const sm=function(s){return typeof s=="number"?"number:"+Fg(s):"string:"+s},rm=function(s){if(s.isLeafNode()){const e=s.val();K(typeof e=="string"||typeof e=="number"||typeof e=="object"&&wn(e,".sv"),"Priority must be a string or number.")}else K(s===Dl||s.isEmpty(),"priority of unexpected type.");K(s===Dl||s.getPriority().isEmpty(),"Priority nodes can't have a priority of their own.")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let CC;class We{static set __childrenNodeConstructor(e){CC=e}static get __childrenNodeConstructor(){return CC}constructor(e,t=We.__childrenNodeConstructor.EMPTY_NODE){this.value_=e,this.priorityNode_=t,this.lazyHash_=null,K(this.value_!==void 0&&this.value_!==null,"LeafNode shouldn't be created with null/undefined value."),rm(this.priorityNode_)}isLeafNode(){return!0}getPriority(){return this.priorityNode_}updatePriority(e){return new We(this.value_,e)}getImmediateChild(e){return e===".priority"?this.priorityNode_:We.__childrenNodeConstructor.EMPTY_NODE}getChild(e){return ce(e)?this:fe(e)===".priority"?this.priorityNode_:We.__childrenNodeConstructor.EMPTY_NODE}hasChild(){return!1}getPredecessorChildName(e,t){return null}updateImmediateChild(e,t){return e===".priority"?this.updatePriority(t):t.isEmpty()&&e!==".priority"?this:We.__childrenNodeConstructor.EMPTY_NODE.updateImmediateChild(e,t).updatePriority(this.priorityNode_)}updateChild(e,t){const n=fe(e);return n===null?t:t.isEmpty()&&n!==".priority"?this:(K(n!==".priority"||ns(e)===1,".priority must be the last token in a path"),this.updateImmediateChild(n,We.__childrenNodeConstructor.EMPTY_NODE.updateChild(Se(e),t)))}isEmpty(){return!1}numChildren(){return 0}forEachChild(e,t){return!1}val(e){return e&&!this.getPriority().isEmpty()?{".value":this.getValue(),".priority":this.getPriority().val()}:this.getValue()}hash(){if(this.lazyHash_===null){let e="";this.priorityNode_.isEmpty()||(e+="priority:"+sm(this.priorityNode_.val())+":");const t=typeof this.value_;e+=t+":",t==="number"?e+=Fg(this.value_):e+=this.value_,this.lazyHash_=bg(e)}return this.lazyHash_}getValue(){return this.value_}compareTo(e){return e===We.__childrenNodeConstructor.EMPTY_NODE?1:e instanceof We.__childrenNodeConstructor?-1:(K(e.isLeafNode(),"Unknown node type"),this.compareToLeafNode_(e))}compareToLeafNode_(e){const t=typeof e.value_,n=typeof this.value_,r=We.VALUE_TYPE_ORDER.indexOf(t),i=We.VALUE_TYPE_ORDER.indexOf(n);return K(r>=0,"Unknown leaf type: "+t),K(i>=0,"Unknown leaf type: "+n),r===i?n==="object"?0:this.value_<e.value_?-1:this.value_===e.value_?0:1:i-r}withIndex(){return this}isIndexed(){return!0}equals(e){if(e===this)return!0;if(e.isLeafNode()){const t=e;return this.value_===t.value_&&this.priorityNode_.equals(t.priorityNode_)}else return!1}}We.VALUE_TYPE_ORDER=["object","boolean","number","string"];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let im,om;function XR(s){im=s}function ZR(s){om=s}class eS extends Ja{compare(e,t){const n=e.node.getPriority(),r=t.node.getPriority(),i=n.compareTo(r);return i===0?vr(e.name,t.name):i}isDefinedOn(e){return!e.getPriority().isEmpty()}indexedValueChanged(e,t){return!e.getPriority().equals(t.getPriority())}minPost(){return de.MIN}maxPost(){return new de(bs,new We("[PRIORITY-POST]",om))}makePost(e,t){const n=im(e);return new de(t,new We("[PRIORITY-POST]",n))}toString(){return".priority"}}const ct=new eS;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tS=Math.log(2);class nS{constructor(e){const t=i=>parseInt(Math.log(i)/tS,10),n=i=>parseInt(Array(i+1).join("1"),2);this.count=t(e+1),this.current_=this.count-1;const r=n(this.count);this.bits_=e+1&r}nextBitIsOne(){const e=!(this.bits_&1<<this.current_);return this.current_--,e}}const aa=function(s,e,t,n){s.sort(e);const r=function(l,c){const h=c-l;let f,d;if(h===0)return null;if(h===1)return f=s[l],d=t?t(f):f,new $e(d,f.node,$e.BLACK,null,null);{const _=parseInt(h/2,10)+l,y=r(l,_),N=r(_+1,c);return f=s[_],d=t?t(f):f,new $e(d,f.node,$e.BLACK,y,N)}},i=function(l){let c=null,h=null,f=s.length;const d=function(y,N){const F=f-y,J=f;f-=y;const te=r(F+1,J),re=s[F],ge=t?t(re):re;_(new $e(ge,re.node,N,null,te))},_=function(y){c?(c.left=y,c=y):(h=y,c=y)};for(let y=0;y<l.count;++y){const N=l.nextBitIsOne(),F=Math.pow(2,l.count-(y+1));N?d(F,$e.BLACK):(d(F,$e.BLACK),d(F,$e.RED))}return h},o=new nS(s.length),a=i(o);return new yt(n||e,a)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let GB;const Us={};class Cn{static get Default(){return K(Us&&ct,"ChildrenNode.ts has not been loaded"),GB=GB||new Cn({".priority":Us},{".priority":ct}),GB}constructor(e,t){this.indexes_=e,this.indexSet_=t}get(e){const t=nr(this.indexes_,e);if(!t)throw new Error("No index defined for "+e);return t instanceof yt?t:null}hasIndex(e){return wn(this.indexSet_,e.toString())}addIndex(e,t){K(e!==tr,"KeyIndex always exists and isn't meant to be added to the IndexMap.");const n=[];let r=!1;const i=t.getIterator(de.Wrap);let o=i.getNext();for(;o;)r=r||e.isDefinedOn(o.node),n.push(o),o=i.getNext();let a;r?a=aa(n,e.getCompare()):a=Us;const l=e.toString(),c={...this.indexSet_};c[l]=e;const h={...this.indexes_};return h[l]=a,new Cn(h,c)}addToIndexes(e,t){const n=Uo(this.indexes_,(r,i)=>{const o=nr(this.indexSet_,i);if(K(o,"Missing index implementation for "+i),r===Us)if(o.isDefinedOn(e.node)){const a=[],l=t.getIterator(de.Wrap);let c=l.getNext();for(;c;)c.name!==e.name&&a.push(c),c=l.getNext();return a.push(e),aa(a,o.getCompare())}else return Us;else{const a=t.get(e.name);let l=r;return a&&(l=l.remove(new de(e.name,a))),l.insert(e,e.node)}});return new Cn(n,this.indexSet_)}removeFromIndexes(e,t){const n=Uo(this.indexes_,r=>{if(r===Us)return r;{const i=t.get(e.name);return i?r.remove(new de(e.name,i)):r}});return new Cn(n,this.indexSet_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Yr;class me{static get EMPTY_NODE(){return Yr||(Yr=new me(new yt(Jc),null,Cn.Default))}constructor(e,t,n){this.children_=e,this.priorityNode_=t,this.indexMap_=n,this.lazyHash_=null,this.priorityNode_&&rm(this.priorityNode_),this.children_.isEmpty()&&K(!this.priorityNode_||this.priorityNode_.isEmpty(),"An empty node cannot have a priority")}isLeafNode(){return!1}getPriority(){return this.priorityNode_||Yr}updatePriority(e){return this.children_.isEmpty()?this:new me(this.children_,e,this.indexMap_)}getImmediateChild(e){if(e===".priority")return this.getPriority();{const t=this.children_.get(e);return t===null?Yr:t}}getChild(e){const t=fe(e);return t===null?this:this.getImmediateChild(t).getChild(Se(e))}hasChild(e){return this.children_.get(e)!==null}updateImmediateChild(e,t){if(K(t,"We should always be passing snapshot nodes"),e===".priority")return this.updatePriority(t);{const n=new de(e,t);let r,i;t.isEmpty()?(r=this.children_.remove(e),i=this.indexMap_.removeFromIndexes(n,this.children_)):(r=this.children_.insert(e,t),i=this.indexMap_.addToIndexes(n,this.children_));const o=r.isEmpty()?Yr:this.priorityNode_;return new me(r,o,i)}}updateChild(e,t){const n=fe(e);if(n===null)return t;{K(fe(e)!==".priority"||ns(e)===1,".priority must be the last token in a path");const r=this.getImmediateChild(n).updateChild(Se(e),t);return this.updateImmediateChild(n,r)}}isEmpty(){return this.children_.isEmpty()}numChildren(){return this.children_.count()}val(e){if(this.isEmpty())return null;const t={};let n=0,r=0,i=!0;if(this.forEachChild(ct,(o,a)=>{t[o]=a.val(e),n++,i&&me.INTEGER_REGEXP_.test(o)?r=Math.max(r,Number(o)):i=!1}),!e&&i&&r<2*n){const o=[];for(const a in t)o[a]=t[a];return o}else return e&&!this.getPriority().isEmpty()&&(t[".priority"]=this.getPriority().val()),t}hash(){if(this.lazyHash_===null){let e="";this.getPriority().isEmpty()||(e+="priority:"+sm(this.getPriority().val())+":"),this.forEachChild(ct,(t,n)=>{const r=n.hash();r!==""&&(e+=":"+t+":"+r)}),this.lazyHash_=e===""?"":bg(e)}return this.lazyHash_}getPredecessorChildName(e,t,n){const r=this.resolveIndex_(n);if(r){const i=r.getPredecessorKey(new de(e,t));return i?i.name:null}else return this.children_.getPredecessorKey(e)}getFirstChildName(e){const t=this.resolveIndex_(e);if(t){const n=t.minKey();return n&&n.name}else return this.children_.minKey()}getFirstChild(e){const t=this.getFirstChildName(e);return t?new de(t,this.children_.get(t)):null}getLastChildName(e){const t=this.resolveIndex_(e);if(t){const n=t.maxKey();return n&&n.name}else return this.children_.maxKey()}getLastChild(e){const t=this.getLastChildName(e);return t?new de(t,this.children_.get(t)):null}forEachChild(e,t){const n=this.resolveIndex_(e);return n?n.inorderTraversal(r=>t(r.name,r.node)):this.children_.inorderTraversal(t)}getIterator(e){return this.getIteratorFrom(e.minPost(),e)}getIteratorFrom(e,t){const n=this.resolveIndex_(t);if(n)return n.getIteratorFrom(e,r=>r);{const r=this.children_.getIteratorFrom(e.name,de.Wrap);let i=r.peek();for(;i!=null&&t.compare(i,e)<0;)r.getNext(),i=r.peek();return r}}getReverseIterator(e){return this.getReverseIteratorFrom(e.maxPost(),e)}getReverseIteratorFrom(e,t){const n=this.resolveIndex_(t);if(n)return n.getReverseIteratorFrom(e,r=>r);{const r=this.children_.getReverseIteratorFrom(e.name,de.Wrap);let i=r.peek();for(;i!=null&&t.compare(i,e)>0;)r.getNext(),i=r.peek();return r}}compareTo(e){return this.isEmpty()?e.isEmpty()?0:-1:e.isLeafNode()||e.isEmpty()?1:e===no?-1:0}withIndex(e){if(e===tr||this.indexMap_.hasIndex(e))return this;{const t=this.indexMap_.addIndex(e,this.children_);return new me(this.children_,this.priorityNode_,t)}}isIndexed(e){return e===tr||this.indexMap_.hasIndex(e)}equals(e){if(e===this)return!0;if(e.isLeafNode())return!1;{const t=e;if(this.getPriority().equals(t.getPriority()))if(this.children_.count()===t.children_.count()){const n=this.getIterator(ct),r=t.getIterator(ct);let i=n.getNext(),o=r.getNext();for(;i&&o;){if(i.name!==o.name||!i.node.equals(o.node))return!1;i=n.getNext(),o=r.getNext()}return i===null&&o===null}else return!1;else return!1}}resolveIndex_(e){return e===tr?null:this.indexMap_.get(e.toString())}}me.INTEGER_REGEXP_=/^(0|[1-9]\d*)$/;class sS extends me{constructor(){super(new yt(Jc),me.EMPTY_NODE,Cn.Default)}compareTo(e){return e===this?0:1}equals(e){return e===this}getPriority(){return this}getImmediateChild(e){return me.EMPTY_NODE}isEmpty(){return!1}}const no=new sS;Object.defineProperties(de,{MIN:{value:new de(fr,me.EMPTY_NODE)},MAX:{value:new de(bs,no)}});nm.__EMPTY_NODE=me.EMPTY_NODE;We.__childrenNodeConstructor=me;$R(no);ZR(no);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rS=!0;function lt(s,e=null){if(s===null)return me.EMPTY_NODE;if(typeof s=="object"&&".priority"in s&&(e=s[".priority"]),K(e===null||typeof e=="string"||typeof e=="number"||typeof e=="object"&&".sv"in e,"Invalid priority type found: "+typeof e),typeof s=="object"&&".value"in s&&s[".value"]!==null&&(s=s[".value"]),typeof s!="object"||".sv"in s){const t=s;return new We(t,lt(e))}if(!(s instanceof Array)&&rS){const t=[];let n=!1;if(Ht(s,(o,a)=>{if(o.substring(0,1)!=="."){const l=lt(a);l.isEmpty()||(n=n||!l.getPriority().isEmpty(),t.push(new de(o,l)))}}),t.length===0)return me.EMPTY_NODE;const i=aa(t,YR,o=>o.name,Jc);if(n){const o=aa(t,ct.getCompare());return new me(i,lt(e),new Cn({".priority":o},{".priority":ct}))}else return new me(i,lt(e),Cn.Default)}else{let t=me.EMPTY_NODE;return Ht(s,(n,r)=>{if(wn(s,n)&&n.substring(0,1)!=="."){const i=lt(r);(i.isLeafNode()||!i.isEmpty())&&(t=t.updateImmediateChild(n,i))}}),t.updatePriority(lt(e))}}XR(lt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iS extends Ja{constructor(e){super(),this.indexPath_=e,K(!ce(e)&&fe(e)!==".priority","Can't create PathIndex with empty path or .priority key")}extractChild(e){return e.getChild(this.indexPath_)}isDefinedOn(e){return!e.getChild(this.indexPath_).isEmpty()}compare(e,t){const n=this.extractChild(e.node),r=this.extractChild(t.node),i=n.compareTo(r);return i===0?vr(e.name,t.name):i}makePost(e,t){const n=lt(e),r=me.EMPTY_NODE.updateChild(this.indexPath_,n);return new de(t,r)}maxPost(){const e=me.EMPTY_NODE.updateChild(this.indexPath_,no);return new de(bs,e)}toString(){return Xg(this.indexPath_,0).join("/")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oS extends Ja{compare(e,t){const n=e.node.compareTo(t.node);return n===0?vr(e.name,t.name):n}isDefinedOn(e){return!0}indexedValueChanged(e,t){return!e.equals(t)}minPost(){return de.MIN}maxPost(){return de.MAX}makePost(e,t){const n=lt(e);return new de(t,n)}toString(){return".value"}}const aS=new oS;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function BS(s){return{type:"value",snapshotNode:s}}function lS(s,e){return{type:"child_added",snapshotNode:e,childName:s}}function cS(s,e){return{type:"child_removed",snapshotNode:e,childName:s}}function dC(s,e,t){return{type:"child_changed",snapshotNode:e,childName:s,oldSnap:t}}function uS(s,e){return{type:"child_moved",snapshotNode:e,childName:s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jc{constructor(){this.limitSet_=!1,this.startSet_=!1,this.startNameSet_=!1,this.startAfterSet_=!1,this.endSet_=!1,this.endNameSet_=!1,this.endBeforeSet_=!1,this.limit_=0,this.viewFrom_="",this.indexStartValue_=null,this.indexStartName_="",this.indexEndValue_=null,this.indexEndName_="",this.index_=ct}hasStart(){return this.startSet_}isViewFromLeft(){return this.viewFrom_===""?this.startSet_:this.viewFrom_==="l"}getIndexStartValue(){return K(this.startSet_,"Only valid if start has been set"),this.indexStartValue_}getIndexStartName(){return K(this.startSet_,"Only valid if start has been set"),this.startNameSet_?this.indexStartName_:fr}hasEnd(){return this.endSet_}getIndexEndValue(){return K(this.endSet_,"Only valid if end has been set"),this.indexEndValue_}getIndexEndName(){return K(this.endSet_,"Only valid if end has been set"),this.endNameSet_?this.indexEndName_:bs}hasLimit(){return this.limitSet_}hasAnchoredLimit(){return this.limitSet_&&this.viewFrom_!==""}getLimit(){return K(this.limitSet_,"Only valid if limit has been set"),this.limit_}getIndex(){return this.index_}loadsAllData(){return!(this.startSet_||this.endSet_||this.limitSet_)}isDefault(){return this.loadsAllData()&&this.index_===ct}copy(){const e=new jc;return e.limitSet_=this.limitSet_,e.limit_=this.limit_,e.startSet_=this.startSet_,e.startAfterSet_=this.startAfterSet_,e.indexStartValue_=this.indexStartValue_,e.startNameSet_=this.startNameSet_,e.indexStartName_=this.indexStartName_,e.endSet_=this.endSet_,e.endBeforeSet_=this.endBeforeSet_,e.indexEndValue_=this.indexEndValue_,e.endNameSet_=this.endNameSet_,e.indexEndName_=this.indexEndName_,e.index_=this.index_,e.viewFrom_=this.viewFrom_,e}}function pC(s){const e={};if(s.isDefault())return e;let t;if(s.index_===ct?t="$priority":s.index_===aS?t="$value":s.index_===tr?t="$key":(K(s.index_ instanceof iS,"Unrecognized index type!"),t=s.index_.toString()),e.orderBy=tt(t),s.startSet_){const n=s.startAfterSet_?"startAfter":"startAt";e[n]=tt(s.indexStartValue_),s.startNameSet_&&(e[n]+=","+tt(s.indexStartName_))}if(s.endSet_){const n=s.endBeforeSet_?"endBefore":"endAt";e[n]=tt(s.indexEndValue_),s.endNameSet_&&(e[n]+=","+tt(s.indexEndName_))}return s.limitSet_&&(s.isViewFromLeft()?e.limitToFirst=s.limit_:e.limitToLast=s.limit_),e}function gC(s){const e={};if(s.startSet_&&(e.sp=s.indexStartValue_,s.startNameSet_&&(e.sn=s.indexStartName_),e.sin=!s.startAfterSet_),s.endSet_&&(e.ep=s.indexEndValue_,s.endNameSet_&&(e.en=s.indexEndName_),e.ein=!s.endBeforeSet_),s.limitSet_){e.l=s.limit_;let t=s.viewFrom_;t===""&&(s.isViewFromLeft()?t="l":t="r"),e.vf=t}return s.index_!==ct&&(e.i=s.index_.toString()),e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ba extends Wg{reportStats(e){throw new Error("Method not implemented.")}static getListenId_(e,t){return t!==void 0?"tag$"+t:(K(e._queryParams.isDefault(),"should have a tag if it's not a default query."),e._path.toString())}constructor(e,t,n,r){super(),this.repoInfo_=e,this.onDataUpdate_=t,this.authTokenProvider_=n,this.appCheckTokenProvider_=r,this.log_=eo("p:rest:"),this.listens_={}}listen(e,t,n,r){const i=e._path.toString();this.log_("Listen called for "+i+" "+e._queryIdentifier);const o=Ba.getListenId_(e,n),a={};this.listens_[o]=a;const l=pC(e._queryParams);this.restRequest_(i+".json",l,(c,h)=>{let f=h;if(c===404&&(f=null,c=null),c===null&&this.onDataUpdate_(i,f,!1,n),nr(this.listens_,o)===a){let d;c?c===401?d="permission_denied":d="rest_error:"+c:d="ok",r(d,null)}})}unlisten(e,t){const n=Ba.getListenId_(e,t);delete this.listens_[n]}get(e){const t=pC(e._queryParams),n=e._path.toString(),r=new Fl;return this.restRequest_(n+".json",t,(i,o)=>{let a=o;i===404&&(a=null,i=null),i===null?(this.onDataUpdate_(n,a,!1,null),r.resolve(a)):r.reject(new Error(a))}),r.promise}refreshAuthToken(e){}restRequest_(e,t={},n){return t.format="export",Promise.all([this.authTokenProvider_.getToken(!1),this.appCheckTokenProvider_.getToken(!1)]).then(([r,i])=>{r&&r.accessToken&&(t.auth=r.accessToken),i&&i.token&&(t.ac=i.token);const o=(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host+e+"?ns="+this.repoInfo_.namespace+G_(t);this.log_("Sending REST request for "+o);const a=new XMLHttpRequest;a.onreadystatechange=()=>{if(n&&a.readyState===4){this.log_("REST Response for "+o+" received. status:",a.status,"response:",a.responseText);let l=null;if(a.status>=200&&a.status<300){try{l=di(a.responseText)}catch{Lt("Failed to parse JSON response for "+o+": "+a.responseText)}n(null,l)}else a.status!==401&&a.status!==404&&Lt("Got unsuccessful REST response for "+o+" Status: "+a.status),n(a.status);n=null}},a.open("GET",o,!0),a.send()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hS{constructor(){this.rootNode_=me.EMPTY_NODE}getNode(e){return this.rootNode_.getChild(e)}updateSnapshot(e,t){this.rootNode_=this.rootNode_.updateChild(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function la(){return{value:null,children:new Map}}function am(s,e,t){if(ce(e))s.value=t,s.children.clear();else if(s.value!==null)s.value=s.value.updateChild(e,t);else{const n=fe(e);s.children.has(n)||s.children.set(n,la());const r=s.children.get(n);e=Se(e),am(r,e,t)}}function yl(s,e,t){s.value!==null?t(e,s.value):fS(s,(n,r)=>{const i=new be(e.toString()+"/"+n);yl(r,i,t)})}function fS(s,e){s.children.forEach((t,n)=>{e(n,t)})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CS{constructor(e){this.collection_=e,this.last_=null}get(){const e=this.collection_.get(),t={...e};return this.last_&&Ht(this.last_,(n,r)=>{t[n]=t[n]-r}),this.last_=e,t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mC=10*1e3,dS=30*1e3,pS=5*60*1e3;class gS{constructor(e,t){this.server_=t,this.statsToReport_={},this.statsListener_=new CS(e);const n=mC+(dS-mC)*Math.random();hi(this.reportStats_.bind(this),Math.floor(n))}reportStats_(){const e=this.statsListener_.get(),t={};let n=!1;Ht(e,(r,i)=>{i>0&&wn(this.statsToReport_,r)&&(t[r]=i,n=!0)}),n&&this.server_.reportStats(t),hi(this.reportStats_.bind(this),Math.floor(Math.random()*2*pS))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var tn;(function(s){s[s.OVERWRITE=0]="OVERWRITE",s[s.MERGE=1]="MERGE",s[s.ACK_USER_WRITE=2]="ACK_USER_WRITE",s[s.LISTEN_COMPLETE=3]="LISTEN_COMPLETE"})(tn||(tn={}));function Bm(){return{fromUser:!0,fromServer:!1,queryId:null,tagged:!1}}function lm(){return{fromUser:!1,fromServer:!0,queryId:null,tagged:!1}}function cm(s){return{fromUser:!1,fromServer:!0,queryId:s,tagged:!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ca{constructor(e,t,n){this.path=e,this.affectedTree=t,this.revert=n,this.type=tn.ACK_USER_WRITE,this.source=Bm()}operationForChild(e){if(ce(this.path)){if(this.affectedTree.value!=null)return K(this.affectedTree.children.isEmpty(),"affectedTree should not have overlapping affected paths."),this;{const t=this.affectedTree.subtree(new be(e));return new ca(Ee(),t,this.revert)}}else return K(fe(this.path)===e,"operationForChild called for unrelated child."),new ca(Se(this.path),this.affectedTree,this.revert)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ns{constructor(e,t,n){this.source=e,this.path=t,this.snap=n,this.type=tn.OVERWRITE}operationForChild(e){return ce(this.path)?new Ns(this.source,Ee(),this.snap.getImmediateChild(e)):new Ns(this.source,Se(this.path),this.snap)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xi{constructor(e,t,n){this.source=e,this.path=t,this.children=n,this.type=tn.MERGE}operationForChild(e){if(ce(this.path)){const t=this.children.subtree(new be(e));return t.isEmpty()?null:t.value?new Ns(this.source,Ee(),t.value):new xi(this.source,Ee(),t)}else return K(fe(this.path)===e,"Can't get a merge for a child not on the path of the operation"),new xi(this.source,Se(this.path),this.children)}toString(){return"Operation("+this.path+": "+this.source.toString()+" merge: "+this.children.toString()+")"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kc{constructor(e,t,n){this.node_=e,this.fullyInitialized_=t,this.filtered_=n}isFullyInitialized(){return this.fullyInitialized_}isFiltered(){return this.filtered_}isCompleteForPath(e){if(ce(e))return this.isFullyInitialized()&&!this.filtered_;const t=fe(e);return this.isCompleteForChild(t)}isCompleteForChild(e){return this.isFullyInitialized()&&!this.filtered_||this.node_.hasChild(e)}getNode(){return this.node_}}function mS(s,e,t,n){const r=[],i=[];return e.forEach(o=>{o.type==="child_changed"&&s.index_.indexedValueChanged(o.oldSnap,o.snapshotNode)&&i.push(uS(o.childName,o.snapshotNode))}),$r(s,r,"child_removed",e,n,t),$r(s,r,"child_added",e,n,t),$r(s,r,"child_moved",i,n,t),$r(s,r,"child_changed",e,n,t),$r(s,r,"value",e,n,t),r}function $r(s,e,t,n,r,i){const o=n.filter(a=>a.type===t);o.sort((a,l)=>ES(s,a,l)),o.forEach(a=>{const l=_S(s,a,i);r.forEach(c=>{c.respondsTo(a.type)&&e.push(c.createEvent(l,s.query_))})})}function _S(s,e,t){return e.type==="value"||e.type==="child_removed"||(e.prevName=t.getPredecessorChildName(e.childName,e.snapshotNode,s.index_)),e}function ES(s,e,t){if(e.childName==null||t.childName==null)throw dr("Should only compare child_ events.");const n=new de(e.childName,e.snapshotNode),r=new de(t.childName,t.snapshotNode);return s.index_.compare(n,r)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function um(s,e){return{eventCache:s,serverCache:e}}function fi(s,e,t,n){return um(new Kc(e,t,n),s.serverCache)}function hm(s,e,t,n){return um(s.eventCache,new Kc(e,t,n))}function wl(s){return s.eventCache.isFullyInitialized()?s.eventCache.getNode():null}function Ps(s){return s.serverCache.isFullyInitialized()?s.serverCache.getNode():null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let HB;const DS=()=>(HB||(HB=new yt(oR)),HB);class ve{static fromObject(e){let t=new ve(null);return Ht(e,(n,r)=>{t=t.set(new be(n),r)}),t}constructor(e,t=DS()){this.value=e,this.children=t}isEmpty(){return this.value===null&&this.children.isEmpty()}findRootMostMatchingPathAndValue(e,t){if(this.value!=null&&t(this.value))return{path:Ee(),value:this.value};if(ce(e))return null;{const n=fe(e),r=this.children.get(n);if(r!==null){const i=r.findRootMostMatchingPathAndValue(Se(e),t);return i!=null?{path:Ze(new be(n),i.path),value:i.value}:null}else return null}}findRootMostValueAndPath(e){return this.findRootMostMatchingPathAndValue(e,()=>!0)}subtree(e){if(ce(e))return this;{const t=fe(e),n=this.children.get(t);return n!==null?n.subtree(Se(e)):new ve(null)}}set(e,t){if(ce(e))return new ve(t,this.children);{const n=fe(e),i=(this.children.get(n)||new ve(null)).set(Se(e),t),o=this.children.insert(n,i);return new ve(this.value,o)}}remove(e){if(ce(e))return this.children.isEmpty()?new ve(null):new ve(null,this.children);{const t=fe(e),n=this.children.get(t);if(n){const r=n.remove(Se(e));let i;return r.isEmpty()?i=this.children.remove(t):i=this.children.insert(t,r),this.value===null&&i.isEmpty()?new ve(null):new ve(this.value,i)}else return this}}get(e){if(ce(e))return this.value;{const t=fe(e),n=this.children.get(t);return n?n.get(Se(e)):null}}setTree(e,t){if(ce(e))return t;{const n=fe(e),i=(this.children.get(n)||new ve(null)).setTree(Se(e),t);let o;return i.isEmpty()?o=this.children.remove(n):o=this.children.insert(n,i),new ve(this.value,o)}}fold(e){return this.fold_(Ee(),e)}fold_(e,t){const n={};return this.children.inorderTraversal((r,i)=>{n[r]=i.fold_(Ze(e,r),t)}),t(e,this.value,n)}findOnPath(e,t){return this.findOnPath_(e,Ee(),t)}findOnPath_(e,t,n){const r=this.value?n(t,this.value):!1;if(r)return r;if(ce(e))return null;{const i=fe(e),o=this.children.get(i);return o?o.findOnPath_(Se(e),Ze(t,i),n):null}}foreachOnPath(e,t){return this.foreachOnPath_(e,Ee(),t)}foreachOnPath_(e,t,n){if(ce(e))return this;{this.value&&n(t,this.value);const r=fe(e),i=this.children.get(r);return i?i.foreachOnPath_(Se(e),Ze(t,r),n):new ve(null)}}foreach(e){this.foreach_(Ee(),e)}foreach_(e,t){this.children.inorderTraversal((n,r)=>{r.foreach_(Ze(e,n),t)}),this.value&&t(e,this.value)}foreachChild(e){this.children.inorderTraversal((t,n)=>{n.value&&e(t,n.value)})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jt{constructor(e){this.writeTree_=e}static empty(){return new jt(new ve(null))}}function Ci(s,e,t){if(ce(e))return new jt(new ve(t));{const n=s.writeTree_.findRootMostValueAndPath(e);if(n!=null){const r=n.path;let i=n.value;const o=Vt(r,e);return i=i.updateChild(o,t),new jt(s.writeTree_.set(r,i))}else{const r=new ve(t),i=s.writeTree_.setTree(e,r);return new jt(i)}}}function _C(s,e,t){let n=s;return Ht(t,(r,i)=>{n=Ci(n,Ze(e,r),i)}),n}function EC(s,e){if(ce(e))return jt.empty();{const t=s.writeTree_.setTree(e,new ve(null));return new jt(t)}}function Tl(s,e){return xs(s,e)!=null}function xs(s,e){const t=s.writeTree_.findRootMostValueAndPath(e);return t!=null?s.writeTree_.get(t.path).getChild(Vt(t.path,e)):null}function DC(s){const e=[],t=s.writeTree_.value;return t!=null?t.isLeafNode()||t.forEachChild(ct,(n,r)=>{e.push(new de(n,r))}):s.writeTree_.children.inorderTraversal((n,r)=>{r.value!=null&&e.push(new de(n,r.value))}),e}function Jn(s,e){if(ce(e))return s;{const t=xs(s,e);return t!=null?new jt(new ve(t)):new jt(s.writeTree_.subtree(e))}}function Il(s){return s.writeTree_.isEmpty()}function Cr(s,e){return fm(Ee(),s.writeTree_,e)}function fm(s,e,t){if(e.value!=null)return t.updateChild(s,e.value);{let n=null;return e.children.inorderTraversal((r,i)=>{r===".priority"?(K(i.value!==null,"Priority writes must always be leaf nodes"),n=i.value):t=fm(Ze(s,r),i,t)}),!t.getChild(s).isEmpty()&&n!==null&&(t=t.updateChild(Ze(s,".priority"),n)),t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cm(s,e){return _m(e,s)}function yS(s,e,t,n,r){K(n>s.lastWriteId,"Stacking an older write on top of newer ones"),r===void 0&&(r=!0),s.allWrites.push({path:e,snap:t,writeId:n,visible:r}),r&&(s.visibleWrites=Ci(s.visibleWrites,e,t)),s.lastWriteId=n}function wS(s,e){for(let t=0;t<s.allWrites.length;t++){const n=s.allWrites[t];if(n.writeId===e)return n}return null}function TS(s,e){const t=s.allWrites.findIndex(a=>a.writeId===e);K(t>=0,"removeWrite called with nonexistent writeId.");const n=s.allWrites[t];s.allWrites.splice(t,1);let r=n.visible,i=!1,o=s.allWrites.length-1;for(;r&&o>=0;){const a=s.allWrites[o];a.visible&&(o>=t&&IS(a,n.path)?r=!1:qt(n.path,a.path)&&(i=!0)),o--}if(r){if(i)return AS(s),!0;if(n.snap)s.visibleWrites=EC(s.visibleWrites,n.path);else{const a=n.children;Ht(a,l=>{s.visibleWrites=EC(s.visibleWrites,Ze(n.path,l))})}return!0}else return!1}function IS(s,e){if(s.snap)return qt(s.path,e);for(const t in s.children)if(s.children.hasOwnProperty(t)&&qt(Ze(s.path,t),e))return!0;return!1}function AS(s){s.visibleWrites=dm(s.allWrites,vS,Ee()),s.allWrites.length>0?s.lastWriteId=s.allWrites[s.allWrites.length-1].writeId:s.lastWriteId=-1}function vS(s){return s.visible}function dm(s,e,t){let n=jt.empty();for(let r=0;r<s.length;++r){const i=s[r];if(e(i)){const o=i.path;let a;if(i.snap)qt(t,o)?(a=Vt(t,o),n=Ci(n,a,i.snap)):qt(o,t)&&(a=Vt(o,t),n=Ci(n,Ee(),i.snap.getChild(a)));else if(i.children){if(qt(t,o))a=Vt(t,o),n=_C(n,a,i.children);else if(qt(o,t))if(a=Vt(o,t),ce(a))n=_C(n,Ee(),i.children);else{const l=nr(i.children,fe(a));if(l){const c=l.getChild(Se(a));n=Ci(n,Ee(),c)}}}else throw dr("WriteRecord should have .snap or .children")}}return n}function pm(s,e,t,n,r){if(!n&&!r){const i=xs(s.visibleWrites,e);if(i!=null)return i;{const o=Jn(s.visibleWrites,e);if(Il(o))return t;if(t==null&&!Tl(o,Ee()))return null;{const a=t||me.EMPTY_NODE;return Cr(o,a)}}}else{const i=Jn(s.visibleWrites,e);if(!r&&Il(i))return t;if(!r&&t==null&&!Tl(i,Ee()))return null;{const o=function(c){return(c.visible||r)&&(!n||!~n.indexOf(c.writeId))&&(qt(c.path,e)||qt(e,c.path))},a=dm(s.allWrites,o,e),l=t||me.EMPTY_NODE;return Cr(a,l)}}}function RS(s,e,t){let n=me.EMPTY_NODE;const r=xs(s.visibleWrites,e);if(r)return r.isLeafNode()||r.forEachChild(ct,(i,o)=>{n=n.updateImmediateChild(i,o)}),n;if(t){const i=Jn(s.visibleWrites,e);return t.forEachChild(ct,(o,a)=>{const l=Cr(Jn(i,new be(o)),a);n=n.updateImmediateChild(o,l)}),DC(i).forEach(o=>{n=n.updateImmediateChild(o.name,o.node)}),n}else{const i=Jn(s.visibleWrites,e);return DC(i).forEach(o=>{n=n.updateImmediateChild(o.name,o.node)}),n}}function SS(s,e,t,n,r){K(n||r,"Either existingEventSnap or existingServerSnap must exist");const i=Ze(e,t);if(Tl(s.visibleWrites,i))return null;{const o=Jn(s.visibleWrites,i);return Il(o)?r.getChild(t):Cr(o,r.getChild(t))}}function bS(s,e,t,n){const r=Ze(e,t),i=xs(s.visibleWrites,r);if(i!=null)return i;if(n.isCompleteForChild(t)){const o=Jn(s.visibleWrites,r);return Cr(o,n.getNode().getImmediateChild(t))}else return null}function NS(s,e){return xs(s.visibleWrites,e)}function PS(s,e,t,n,r,i,o){let a;const l=Jn(s.visibleWrites,e),c=xs(l,Ee());if(c!=null)a=c;else if(t!=null)a=Cr(l,t);else return[];if(a=a.withIndex(o),!a.isEmpty()&&!a.isLeafNode()){const h=[],f=o.getCompare(),d=i?a.getReverseIteratorFrom(n,o):a.getIteratorFrom(n,o);let _=d.getNext();for(;_&&h.length<r;)f(_,n)!==0&&h.push(_),_=d.getNext();return h}else return[]}function FS(){return{visibleWrites:jt.empty(),allWrites:[],lastWriteId:-1}}function Al(s,e,t,n){return pm(s.writeTree,s.treePath,e,t,n)}function gm(s,e){return RS(s.writeTree,s.treePath,e)}function yC(s,e,t,n){return SS(s.writeTree,s.treePath,e,t,n)}function ua(s,e){return NS(s.writeTree,Ze(s.treePath,e))}function OS(s,e,t,n,r,i){return PS(s.writeTree,s.treePath,e,t,n,r,i)}function zc(s,e,t){return bS(s.writeTree,s.treePath,e,t)}function mm(s,e){return _m(Ze(s.treePath,e),s.writeTree)}function _m(s,e){return{treePath:s,writeTree:e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class LS{constructor(){this.changeMap=new Map}trackChildChange(e){const t=e.type,n=e.childName;K(t==="child_added"||t==="child_changed"||t==="child_removed","Only child changes supported for tracking"),K(n!==".priority","Only non-priority child changes can be tracked.");const r=this.changeMap.get(n);if(r){const i=r.type;if(t==="child_added"&&i==="child_removed")this.changeMap.set(n,dC(n,e.snapshotNode,r.snapshotNode));else if(t==="child_removed"&&i==="child_added")this.changeMap.delete(n);else if(t==="child_removed"&&i==="child_changed")this.changeMap.set(n,cS(n,r.oldSnap));else if(t==="child_changed"&&i==="child_added")this.changeMap.set(n,lS(n,e.snapshotNode));else if(t==="child_changed"&&i==="child_changed")this.changeMap.set(n,dC(n,e.snapshotNode,r.oldSnap));else throw dr("Illegal combination of changes: "+e+" occurred after "+r)}else this.changeMap.set(n,e)}getChanges(){return Array.from(this.changeMap.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xS{getCompleteChild(e){return null}getChildAfterChild(e,t,n){return null}}const Em=new xS;class Qc{constructor(e,t,n=null){this.writes_=e,this.viewCache_=t,this.optCompleteServerCache_=n}getCompleteChild(e){const t=this.viewCache_.eventCache;if(t.isCompleteForChild(e))return t.getNode().getImmediateChild(e);{const n=this.optCompleteServerCache_!=null?new Kc(this.optCompleteServerCache_,!0,!1):this.viewCache_.serverCache;return zc(this.writes_,e,n)}}getChildAfterChild(e,t,n){const r=this.optCompleteServerCache_!=null?this.optCompleteServerCache_:Ps(this.viewCache_),i=OS(this.writes_,r,t,1,n,e);return i.length===0?null:i[0]}}function kS(s,e){K(e.eventCache.getNode().isIndexed(s.filter.getIndex()),"Event snap not indexed"),K(e.serverCache.getNode().isIndexed(s.filter.getIndex()),"Server snap not indexed")}function VS(s,e,t,n,r){const i=new LS;let o,a;if(t.type===tn.OVERWRITE){const c=t;c.source.fromUser?o=vl(s,e,c.path,c.snap,n,r,i):(K(c.source.fromServer,"Unknown source."),a=c.source.tagged||e.serverCache.isFiltered()&&!ce(c.path),o=ha(s,e,c.path,c.snap,n,r,a,i))}else if(t.type===tn.MERGE){const c=t;c.source.fromUser?o=GS(s,e,c.path,c.children,n,r,i):(K(c.source.fromServer,"Unknown source."),a=c.source.tagged||e.serverCache.isFiltered(),o=Rl(s,e,c.path,c.children,n,r,a,i))}else if(t.type===tn.ACK_USER_WRITE){const c=t;c.revert?o=qS(s,e,c.path,n,r,i):o=HS(s,e,c.path,c.affectedTree,n,r,i)}else if(t.type===tn.LISTEN_COMPLETE)o=US(s,e,t.path,n,i);else throw dr("Unknown operation type: "+t.type);const l=i.getChanges();return MS(e,o,l),{viewCache:o,changes:l}}function MS(s,e,t){const n=e.eventCache;if(n.isFullyInitialized()){const r=n.getNode().isLeafNode()||n.getNode().isEmpty(),i=wl(s);(t.length>0||!s.eventCache.isFullyInitialized()||r&&!n.getNode().equals(i)||!n.getNode().getPriority().equals(i.getPriority()))&&t.push(BS(wl(e)))}}function Dm(s,e,t,n,r,i){const o=e.eventCache;if(ua(n,t)!=null)return e;{let a,l;if(ce(t))if(K(e.serverCache.isFullyInitialized(),"If change path is empty, we must have complete server data"),e.serverCache.isFiltered()){const c=Ps(e),h=c instanceof me?c:me.EMPTY_NODE,f=gm(n,h);a=s.filter.updateFullNode(e.eventCache.getNode(),f,i)}else{const c=Al(n,Ps(e));a=s.filter.updateFullNode(e.eventCache.getNode(),c,i)}else{const c=fe(t);if(c===".priority"){K(ns(t)===1,"Can't have a priority with additional path components");const h=o.getNode();l=e.serverCache.getNode();const f=yC(n,t,h,l);f!=null?a=s.filter.updatePriority(h,f):a=o.getNode()}else{const h=Se(t);let f;if(o.isCompleteForChild(c)){l=e.serverCache.getNode();const d=yC(n,t,o.getNode(),l);d!=null?f=o.getNode().getImmediateChild(c).updateChild(h,d):f=o.getNode().getImmediateChild(c)}else f=zc(n,c,e.serverCache);f!=null?a=s.filter.updateChild(o.getNode(),c,f,h,r,i):a=o.getNode()}}return fi(e,a,o.isFullyInitialized()||ce(t),s.filter.filtersNodes())}}function ha(s,e,t,n,r,i,o,a){const l=e.serverCache;let c;const h=o?s.filter:s.filter.getIndexedFilter();if(ce(t))c=h.updateFullNode(l.getNode(),n,null);else if(h.filtersNodes()&&!l.isFiltered()){const _=l.getNode().updateChild(t,n);c=h.updateFullNode(l.getNode(),_,null)}else{const _=fe(t);if(!l.isCompleteForPath(t)&&ns(t)>1)return e;const y=Se(t),F=l.getNode().getImmediateChild(_).updateChild(y,n);_===".priority"?c=h.updatePriority(l.getNode(),F):c=h.updateChild(l.getNode(),_,F,y,Em,null)}const f=hm(e,c,l.isFullyInitialized()||ce(t),h.filtersNodes()),d=new Qc(r,f,i);return Dm(s,f,t,r,d,a)}function vl(s,e,t,n,r,i,o){const a=e.eventCache;let l,c;const h=new Qc(r,e,i);if(ce(t))c=s.filter.updateFullNode(e.eventCache.getNode(),n,o),l=fi(e,c,!0,s.filter.filtersNodes());else{const f=fe(t);if(f===".priority")c=s.filter.updatePriority(e.eventCache.getNode(),n),l=fi(e,c,a.isFullyInitialized(),a.isFiltered());else{const d=Se(t),_=a.getNode().getImmediateChild(f);let y;if(ce(d))y=n;else{const N=h.getCompleteChild(f);N!=null?$g(d)===".priority"&&N.getChild(Zg(d)).isEmpty()?y=N:y=N.updateChild(d,n):y=me.EMPTY_NODE}if(_.equals(y))l=e;else{const N=s.filter.updateChild(a.getNode(),f,y,d,h,o);l=fi(e,N,a.isFullyInitialized(),s.filter.filtersNodes())}}}return l}function wC(s,e){return s.eventCache.isCompleteForChild(e)}function GS(s,e,t,n,r,i,o){let a=e;return n.foreach((l,c)=>{const h=Ze(t,l);wC(e,fe(h))&&(a=vl(s,a,h,c,r,i,o))}),n.foreach((l,c)=>{const h=Ze(t,l);wC(e,fe(h))||(a=vl(s,a,h,c,r,i,o))}),a}function TC(s,e,t){return t.foreach((n,r)=>{e=e.updateChild(n,r)}),e}function Rl(s,e,t,n,r,i,o,a){if(e.serverCache.getNode().isEmpty()&&!e.serverCache.isFullyInitialized())return e;let l=e,c;ce(t)?c=n:c=new ve(null).setTree(t,n);const h=e.serverCache.getNode();return c.children.inorderTraversal((f,d)=>{if(h.hasChild(f)){const _=e.serverCache.getNode().getImmediateChild(f),y=TC(s,_,d);l=ha(s,l,new be(f),y,r,i,o,a)}}),c.children.inorderTraversal((f,d)=>{const _=!e.serverCache.isCompleteForChild(f)&&d.value===null;if(!h.hasChild(f)&&!_){const y=e.serverCache.getNode().getImmediateChild(f),N=TC(s,y,d);l=ha(s,l,new be(f),N,r,i,o,a)}}),l}function HS(s,e,t,n,r,i,o){if(ua(r,t)!=null)return e;const a=e.serverCache.isFiltered(),l=e.serverCache;if(n.value!=null){if(ce(t)&&l.isFullyInitialized()||l.isCompleteForPath(t))return ha(s,e,t,l.getNode().getChild(t),r,i,a,o);if(ce(t)){let c=new ve(null);return l.getNode().forEachChild(tr,(h,f)=>{c=c.set(new be(h),f)}),Rl(s,e,t,c,r,i,a,o)}else return e}else{let c=new ve(null);return n.foreach((h,f)=>{const d=Ze(t,h);l.isCompleteForPath(d)&&(c=c.set(h,l.getNode().getChild(d)))}),Rl(s,e,t,c,r,i,a,o)}}function US(s,e,t,n,r){const i=e.serverCache,o=hm(e,i.getNode(),i.isFullyInitialized()||ce(t),i.isFiltered());return Dm(s,o,t,n,Em,r)}function qS(s,e,t,n,r,i){let o;if(ua(n,t)!=null)return e;{const a=new Qc(n,e,r),l=e.eventCache.getNode();let c;if(ce(t)||fe(t)===".priority"){let h;if(e.serverCache.isFullyInitialized())h=Al(n,Ps(e));else{const f=e.serverCache.getNode();K(f instanceof me,"serverChildren would be complete if leaf node"),h=gm(n,f)}h=h,c=s.filter.updateFullNode(l,h,i)}else{const h=fe(t);let f=zc(n,h,e.serverCache);f==null&&e.serverCache.isCompleteForChild(h)&&(f=l.getImmediateChild(h)),f!=null?c=s.filter.updateChild(l,h,f,Se(t),a,i):e.eventCache.getNode().hasChild(h)?c=s.filter.updateChild(l,h,me.EMPTY_NODE,Se(t),a,i):c=l,c.isEmpty()&&e.serverCache.isFullyInitialized()&&(o=Al(n,Ps(e)),o.isLeafNode()&&(c=s.filter.updateFullNode(c,o,i)))}return o=e.serverCache.isFullyInitialized()||ua(n,Ee())!=null,fi(e,c,o,s.filter.filtersNodes())}}function JS(s,e){const t=Ps(s.viewCache_);return t&&(s.query._queryParams.loadsAllData()||!ce(e)&&!t.getImmediateChild(fe(e)).isEmpty())?t.getChild(e):null}function IC(s,e,t,n){e.type===tn.MERGE&&e.source.queryId!==null&&(K(Ps(s.viewCache_),"We should always have a full cache before handling merges"),K(wl(s.viewCache_),"Missing event cache, even though we have a server cache"));const r=s.viewCache_,i=VS(s.processor_,r,e,t,n);return kS(s.processor_,i.viewCache),K(i.viewCache.serverCache.isFullyInitialized()||!r.serverCache.isFullyInitialized(),"Once a server snap is complete, it should never go back"),s.viewCache_=i.viewCache,jS(s,i.changes,i.viewCache.eventCache.getNode())}function jS(s,e,t,n){const r=s.eventRegistrations_;return mS(s.eventGenerator_,e,t,r)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let AC;function KS(s){K(!AC,"__referenceConstructor has already been defined"),AC=s}function Wc(s,e,t,n){const r=e.source.queryId;if(r!==null){const i=s.views.get(r);return K(i!=null,"SyncTree gave us an op for an invalid query."),IC(i,e,t,n)}else{let i=[];for(const o of s.views.values())i=i.concat(IC(o,e,t,n));return i}}function Yc(s,e){let t=null;for(const n of s.views.values())t=t||JS(n,e);return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let vC;function zS(s){K(!vC,"__referenceConstructor has already been defined"),vC=s}class RC{constructor(e){this.listenProvider_=e,this.syncPointTree_=new ve(null),this.pendingWriteTree_=FS(),this.tagToQueryMap=new Map,this.queryToTagMap=new Map}}function QS(s,e,t,n,r){return yS(s.pendingWriteTree_,e,t,n,r),r?Ka(s,new Ns(Bm(),e,t)):[]}function $s(s,e,t=!1){const n=wS(s.pendingWriteTree_,e);if(TS(s.pendingWriteTree_,e)){let i=new ve(null);return n.snap!=null?i=i.set(Ee(),!0):Ht(n.children,o=>{i=i.set(new be(o),!0)}),Ka(s,new ca(n.path,i,t))}else return[]}function ja(s,e,t){return Ka(s,new Ns(lm(),e,t))}function WS(s,e,t){const n=ve.fromObject(t);return Ka(s,new xi(lm(),e,n))}function YS(s,e,t,n){const r=Im(s,n);if(r!=null){const i=Am(r),o=i.path,a=i.queryId,l=Vt(o,e),c=new Ns(cm(a),l,t);return vm(s,o,c)}else return[]}function $S(s,e,t,n){const r=Im(s,n);if(r){const i=Am(r),o=i.path,a=i.queryId,l=Vt(o,e),c=ve.fromObject(t),h=new xi(cm(a),l,c);return vm(s,o,h)}else return[]}function ym(s,e,t){const r=s.pendingWriteTree_,i=s.syncPointTree_.findOnPath(e,(o,a)=>{const l=Vt(o,e),c=Yc(a,l);if(c)return c});return pm(r,e,i,t,!0)}function Ka(s,e){return wm(e,s.syncPointTree_,null,Cm(s.pendingWriteTree_,Ee()))}function wm(s,e,t,n){if(ce(s.path))return Tm(s,e,t,n);{const r=e.get(Ee());t==null&&r!=null&&(t=Yc(r,Ee()));let i=[];const o=fe(s.path),a=s.operationForChild(o),l=e.children.get(o);if(l&&a){const c=t?t.getImmediateChild(o):null,h=mm(n,o);i=i.concat(wm(a,l,c,h))}return r&&(i=i.concat(Wc(r,s,n,t))),i}}function Tm(s,e,t,n){const r=e.get(Ee());t==null&&r!=null&&(t=Yc(r,Ee()));let i=[];return e.children.inorderTraversal((o,a)=>{const l=t?t.getImmediateChild(o):null,c=mm(n,o),h=s.operationForChild(o);h&&(i=i.concat(Tm(h,a,l,c)))}),r&&(i=i.concat(Wc(r,s,n,t))),i}function Im(s,e){return s.tagToQueryMap.get(e)}function Am(s){const e=s.indexOf("$");return K(e!==-1&&e<s.length-1,"Bad queryKey."),{queryId:s.substr(e+1),path:new be(s.substr(0,e))}}function vm(s,e,t){const n=s.syncPointTree_.get(e);K(n,"Missing sync point for query tag that we're tracking");const r=Cm(s.pendingWriteTree_,e);return Wc(n,t,r,null)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $c{constructor(e){this.node_=e}getImmediateChild(e){const t=this.node_.getImmediateChild(e);return new $c(t)}node(){return this.node_}}class Xc{constructor(e,t){this.syncTree_=e,this.path_=t}getImmediateChild(e){const t=Ze(this.path_,e);return new Xc(this.syncTree_,t)}node(){return ym(this.syncTree_,this.path_)}}const XS=function(s){return s=s||{},s.timestamp=s.timestamp||new Date().getTime(),s},SC=function(s,e,t){if(!s||typeof s!="object")return s;if(K(".sv"in s,"Unexpected leaf node or priority contents"),typeof s[".sv"]=="string")return ZS(s[".sv"],e,t);if(typeof s[".sv"]=="object")return e0(s[".sv"],e);K(!1,"Unexpected server value: "+JSON.stringify(s,null,2))},ZS=function(s,e,t){switch(s){case"timestamp":return t.timestamp;default:K(!1,"Unexpected server value: "+s)}},e0=function(s,e,t){s.hasOwnProperty("increment")||K(!1,"Unexpected server value: "+JSON.stringify(s,null,2));const n=s.increment;typeof n!="number"&&K(!1,"Unexpected increment value: "+n);const r=e.node();if(K(r!==null&&typeof r<"u","Expected ChildrenNode.EMPTY_NODE for nulls"),!r.isLeafNode())return n;const o=r.getValue();return typeof o!="number"?n:o+n},t0=function(s,e,t,n){return Zc(e,new Xc(t,s),n)},n0=function(s,e,t){return Zc(s,new $c(e),t)};function Zc(s,e,t){const n=s.getPriority().val(),r=SC(n,e.getImmediateChild(".priority"),t);let i;if(s.isLeafNode()){const o=s,a=SC(o.getValue(),e,t);return a!==o.getValue()||r!==o.getPriority().val()?new We(a,lt(r)):s}else{const o=s;return i=o,r!==o.getPriority().val()&&(i=i.updatePriority(new We(r))),o.forEachChild(ct,(a,l)=>{const c=Zc(l,e.getImmediateChild(a),t);c!==l&&(i=i.updateImmediateChild(a,c))}),i}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eu{constructor(e="",t=null,n={children:{},childCount:0}){this.name=e,this.parent=t,this.node=n}}function tu(s,e){let t=e instanceof be?e:new be(e),n=s,r=fe(t);for(;r!==null;){const i=nr(n.node.children,r)||{children:{},childCount:0};n=new eu(r,n,i),t=Se(t),r=fe(t)}return n}function Rr(s){return s.node.value}function Rm(s,e){s.node.value=e,Sl(s)}function Sm(s){return s.node.childCount>0}function s0(s){return Rr(s)===void 0&&!Sm(s)}function za(s,e){Ht(s.node.children,(t,n)=>{e(new eu(t,s,n))})}function bm(s,e,t,n){t&&e(s),za(s,r=>{bm(r,e,!0)})}function r0(s,e,t){let n=s.parent;for(;n!==null;){if(e(n))return!0;n=n.parent}return!1}function so(s){return new be(s.parent===null?s.name:so(s.parent)+"/"+s.name)}function Sl(s){s.parent!==null&&i0(s.parent,s.name,s)}function i0(s,e,t){const n=s0(t),r=wn(s.node.children,e);n&&r?(delete s.node.children[e],s.node.childCount--,Sl(s)):!n&&!r&&(s.node.children[e]=t.node,s.node.childCount++,Sl(s))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const o0=/[\[\].#$\/\u0000-\u001F\u007F]/,a0=/[\[\].#$\u0000-\u001F\u007F]/,UB=10*1024*1024,Nm=function(s){return typeof s=="string"&&s.length!==0&&!o0.test(s)},B0=function(s){return typeof s=="string"&&s.length!==0&&!a0.test(s)},l0=function(s){return s&&(s=s.replace(/^\/*\.info(\/|$)/,"/")),B0(s)},Pm=function(s,e,t){const n=t instanceof be?new UR(t,s):t;if(e===void 0)throw new Error(s+"contains undefined "+Cs(n));if(typeof e=="function")throw new Error(s+"contains a function "+Cs(n)+" with contents = "+e.toString());if(Ng(e))throw new Error(s+"contains "+e.toString()+" "+Cs(n));if(typeof e=="string"&&e.length>UB/3&&Ca(e)>UB)throw new Error(s+"contains a string greater than "+UB+" utf8 bytes "+Cs(n)+" ('"+e.substring(0,50)+"...')");if(e&&typeof e=="object"){let r=!1,i=!1;if(Ht(e,(o,a)=>{if(o===".value")r=!0;else if(o!==".priority"&&o!==".sv"&&(i=!0,!Nm(o)))throw new Error(s+" contains an invalid key ("+o+") "+Cs(n)+`.  Keys must be non-empty strings and can't contain ".", "#", "$", "/", "[", or "]"`);qR(n,o),Pm(s,a,n),JR(n)}),r&&i)throw new Error(s+' contains ".value" child '+Cs(n)+" in addition to actual children.")}},c0=function(s,e){const t=e.path.toString();if(typeof e.repoInfo.host!="string"||e.repoInfo.host.length===0||!Nm(e.repoInfo.namespace)&&e.repoInfo.host.split(":")[0]!=="localhost"||t.length!==0&&!l0(t))throw new Error(U_(s,"url")+`must be a valid firebase URL and the path can't contain ".", "#", "$", "[", or "]".`)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class u0{constructor(){this.eventLists_=[],this.recursionDepth_=0}}function h0(s,e){let t=null;for(let n=0;n<e.length;n++){const r=e[n],i=r.getPath();t!==null&&!em(i,t.path)&&(s.eventLists_.push(t),t=null),t===null&&(t={events:[],path:i}),t.events.push(r)}t&&s.eventLists_.push(t)}function ks(s,e,t){h0(s,t),f0(s,n=>qt(n,e)||qt(e,n))}function f0(s,e){s.recursionDepth_++;let t=!0;for(let n=0;n<s.eventLists_.length;n++){const r=s.eventLists_[n];if(r){const i=r.path;e(i)?(C0(s.eventLists_[n]),s.eventLists_[n]=null):t=!1}}t&&(s.eventLists_=[]),s.recursionDepth_--}function C0(s){for(let e=0;e<s.events.length;e++){const t=s.events[e];if(t!==null){s.events[e]=null;const n=t.getEventRunner();ui&&Bt("event: "+t.toString()),to(n)}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const d0="repo_interrupt",p0=25;class g0{constructor(e,t,n,r){this.repoInfo_=e,this.forceRestClient_=t,this.authTokenProvider_=n,this.appCheckProvider_=r,this.dataUpdateCount=0,this.statsListener_=null,this.eventQueue_=new u0,this.nextWriteId_=1,this.interceptServerDataCallback_=null,this.onDisconnect_=la(),this.transactionQueueTree_=new eu,this.persistentConnection_=null,this.key=this.repoInfo_.toURLString()}toString(){return(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host}}function m0(s,e,t){if(s.stats_=Hc(s.repoInfo_),s.forceRestClient_||hR())s.server_=new Ba(s.repoInfo_,(n,r,i,o)=>{bC(s,n,r,i,o)},s.authTokenProvider_,s.appCheckProvider_),setTimeout(()=>NC(s,!0),0);else{if(typeof t<"u"&&t!==null){if(typeof t!="object")throw new Error("Only objects are supported for option databaseAuthVariableOverride");try{tt(t)}catch(n){throw new Error("Invalid authOverride provided: "+n)}}s.persistentConnection_=new pn(s.repoInfo_,e,(n,r,i,o)=>{bC(s,n,r,i,o)},n=>{NC(s,n)},n=>{E0(s,n)},s.authTokenProvider_,s.appCheckProvider_,t),s.server_=s.persistentConnection_}s.authTokenProvider_.addTokenChangeListener(n=>{s.server_.refreshAuthToken(n)}),s.appCheckProvider_.addTokenChangeListener(n=>{s.server_.refreshAppCheckToken(n.token)}),s.statsReporter_=mR(s.repoInfo_,()=>new gS(s.stats_,s.server_)),s.infoData_=new hS,s.infoSyncTree_=new RC({startListening:(n,r,i,o)=>{let a=[];const l=s.infoData_.getNode(n._path);return l.isEmpty()||(a=ja(s.infoSyncTree_,n._path,l),setTimeout(()=>{o("ok")},0)),a},stopListening:()=>{}}),nu(s,"connected",!1),s.serverSyncTree_=new RC({startListening:(n,r,i,o)=>(s.server_.listen(n,i,r,(a,l)=>{const c=o(a,l);ks(s.eventQueue_,n._path,c)}),[]),stopListening:(n,r)=>{s.server_.unlisten(n,r)}})}function _0(s){const t=s.infoData_.getNode(new be(".info/serverTimeOffset")).val()||0;return new Date().getTime()+t}function Fm(s){return XS({timestamp:_0(s)})}function bC(s,e,t,n,r){s.dataUpdateCount++;const i=new be(e);t=s.interceptServerDataCallback_?s.interceptServerDataCallback_(e,t):t;let o=[];if(r)if(n){const l=Uo(t,c=>lt(c));o=$S(s.serverSyncTree_,i,l,r)}else{const l=lt(t);o=YS(s.serverSyncTree_,i,l,r)}else if(n){const l=Uo(t,c=>lt(c));o=WS(s.serverSyncTree_,i,l)}else{const l=lt(t);o=ja(s.serverSyncTree_,i,l)}let a=i;o.length>0&&(a=ru(s,i)),ks(s.eventQueue_,a,o)}function NC(s,e){nu(s,"connected",e),e===!1&&y0(s)}function E0(s,e){Ht(e,(t,n)=>{nu(s,t,n)})}function nu(s,e,t){const n=new be("/.info/"+e),r=lt(t);s.infoData_.updateSnapshot(n,r);const i=ja(s.infoSyncTree_,n,r);ks(s.eventQueue_,n,i)}function D0(s){return s.nextWriteId_++}function y0(s){Om(s,"onDisconnectEvents");const e=Fm(s),t=la();yl(s.onDisconnect_,Ee(),(r,i)=>{const o=t0(r,i,s.serverSyncTree_,e);am(t,r,o)});let n=[];yl(t,Ee(),(r,i)=>{n=n.concat(ja(s.serverSyncTree_,r,i));const o=A0(s,r);ru(s,o)}),s.onDisconnect_=la(),ks(s.eventQueue_,Ee(),n)}function w0(s){s.persistentConnection_&&s.persistentConnection_.interrupt(d0)}function Om(s,...e){let t="";s.persistentConnection_&&(t=s.persistentConnection_.id+":"),Bt(t,...e)}function Lm(s,e,t){return ym(s.serverSyncTree_,e,t)||me.EMPTY_NODE}function su(s,e=s.transactionQueueTree_){if(e||Qa(s,e),Rr(e)){const t=km(s,e);K(t.length>0,"Sending zero length transaction queue"),t.every(r=>r.status===0)&&T0(s,so(e),t)}else Sm(e)&&za(e,t=>{su(s,t)})}function T0(s,e,t){const n=t.map(c=>c.currentWriteId),r=Lm(s,e,n);let i=r;const o=r.hash();for(let c=0;c<t.length;c++){const h=t[c];K(h.status===0,"tryToSendTransactionQueue_: items in queue should all be run."),h.status=1,h.retryCount++;const f=Vt(e,h.path);i=i.updateChild(f,h.currentOutputSnapshotRaw)}const a=i.val(!0),l=e;s.server_.put(l.toString(),a,c=>{Om(s,"transaction put response",{path:l.toString(),status:c});let h=[];if(c==="ok"){const f=[];for(let d=0;d<t.length;d++)t[d].status=2,h=h.concat($s(s.serverSyncTree_,t[d].currentWriteId)),t[d].onComplete&&f.push(()=>t[d].onComplete(null,!0,t[d].currentOutputSnapshotResolved)),t[d].unwatcher();Qa(s,tu(s.transactionQueueTree_,e)),su(s,s.transactionQueueTree_),ks(s.eventQueue_,e,h);for(let d=0;d<f.length;d++)to(f[d])}else{if(c==="datastale")for(let f=0;f<t.length;f++)t[f].status===3?t[f].status=4:t[f].status=0;else{Lt("transaction at "+l.toString()+" failed: "+c);for(let f=0;f<t.length;f++)t[f].status=4,t[f].abortReason=c}ru(s,e)}},o)}function ru(s,e){const t=xm(s,e),n=so(t),r=km(s,t);return I0(s,r,n),n}function I0(s,e,t){if(e.length===0)return;const n=[];let r=[];const o=e.filter(a=>a.status===0).map(a=>a.currentWriteId);for(let a=0;a<e.length;a++){const l=e[a],c=Vt(t,l.path);let h=!1,f;if(K(c!==null,"rerunTransactionsUnderNode_: relativePath should not be null."),l.status===4)h=!0,f=l.abortReason,r=r.concat($s(s.serverSyncTree_,l.currentWriteId,!0));else if(l.status===0)if(l.retryCount>=p0)h=!0,f="maxretry",r=r.concat($s(s.serverSyncTree_,l.currentWriteId,!0));else{const d=Lm(s,l.path,o);l.currentInputSnapshot=d;const _=e[a].update(d.val());if(_!==void 0){Pm("transaction failed: Data returned ",_,l.path);let y=lt(_);typeof _=="object"&&_!=null&&wn(_,".priority")||(y=y.updatePriority(d.getPriority()));const F=l.currentWriteId,J=Fm(s),te=n0(y,d,J);l.currentOutputSnapshotRaw=y,l.currentOutputSnapshotResolved=te,l.currentWriteId=D0(s),o.splice(o.indexOf(F),1),r=r.concat(QS(s.serverSyncTree_,l.path,te,l.currentWriteId,l.applyLocally)),r=r.concat($s(s.serverSyncTree_,F,!0))}else h=!0,f="nodata",r=r.concat($s(s.serverSyncTree_,l.currentWriteId,!0))}ks(s.eventQueue_,t,r),r=[],h&&(e[a].status=2,function(d){setTimeout(d,Math.floor(0))}(e[a].unwatcher),e[a].onComplete&&(f==="nodata"?n.push(()=>e[a].onComplete(null,!1,e[a].currentInputSnapshot)):n.push(()=>e[a].onComplete(new Error(f),!1,null))))}Qa(s,s.transactionQueueTree_);for(let a=0;a<n.length;a++)to(n[a]);su(s,s.transactionQueueTree_)}function xm(s,e){let t,n=s.transactionQueueTree_;for(t=fe(e);t!==null&&Rr(n)===void 0;)n=tu(n,t),e=Se(e),t=fe(e);return n}function km(s,e){const t=[];return Vm(s,e,t),t.sort((n,r)=>n.order-r.order),t}function Vm(s,e,t){const n=Rr(e);if(n)for(let r=0;r<n.length;r++)t.push(n[r]);za(e,r=>{Vm(s,r,t)})}function Qa(s,e){const t=Rr(e);if(t){let n=0;for(let r=0;r<t.length;r++)t[r].status!==2&&(t[n]=t[r],n++);t.length=n,Rm(e,t.length>0?t:void 0)}za(e,n=>{Qa(s,n)})}function A0(s,e){const t=so(xm(s,e)),n=tu(s.transactionQueueTree_,e);return r0(n,r=>{qB(s,r)}),qB(s,n),bm(n,r=>{qB(s,r)}),t}function qB(s,e){const t=Rr(e);if(t){const n=[];let r=[],i=-1;for(let o=0;o<t.length;o++)t[o].status===3||(t[o].status===1?(K(i===o-1,"All SENT items should be at beginning of queue."),i=o,t[o].status=3,t[o].abortReason="set"):(K(t[o].status===0,"Unexpected transaction status in abort"),t[o].unwatcher(),r=r.concat($s(s.serverSyncTree_,t[o].currentWriteId,!0)),t[o].onComplete&&n.push(t[o].onComplete.bind(null,new Error("set"),!1,null))));i===-1?Rm(e,void 0):t.length=i+1,ks(s.eventQueue_,so(e),r);for(let o=0;o<n.length;o++)to(n[o])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function v0(s){let e="";const t=s.split("/");for(let n=0;n<t.length;n++)if(t[n].length>0){let r=t[n];try{r=decodeURIComponent(r.replace(/\+/g," "))}catch{}e+="/"+r}return e}function R0(s){const e={};s.charAt(0)==="?"&&(s=s.substring(1));for(const t of s.split("&")){if(t.length===0)continue;const n=t.split("=");n.length===2?e[decodeURIComponent(n[0])]=decodeURIComponent(n[1]):Lt(`Invalid query segment '${t}' in query '${s}'`)}return e}const PC=function(s,e){const t=S0(s),n=t.namespace;t.domain==="firebase.com"&&Ss(t.host+" is no longer supported. Please use <YOUR FIREBASE>.firebaseio.com instead"),(!n||n==="undefined")&&t.domain!=="localhost"&&Ss("Cannot parse Firebase url. Please use https://<YOUR FIREBASE>.firebaseio.com"),t.secure||rR();const r=t.scheme==="ws"||t.scheme==="wss";return{repoInfo:new dR(t.host,t.secure,n,r,e,"",n!==t.subdomain),path:new be(t.pathString)}},S0=function(s){let e="",t="",n="",r="",i="",o=!0,a="https",l=443;if(typeof s=="string"){let c=s.indexOf("//");c>=0&&(a=s.substring(0,c-1),s=s.substring(c+2));let h=s.indexOf("/");h===-1&&(h=s.length);let f=s.indexOf("?");f===-1&&(f=s.length),e=s.substring(0,Math.min(h,f)),h<f&&(r=v0(s.substring(h,f)));const d=R0(s.substring(Math.min(s.length,f)));c=e.indexOf(":"),c>=0?(o=a==="https"||a==="wss",l=parseInt(e.substring(c+1),10)):c=e.length;const _=e.slice(0,c);if(_.toLowerCase()==="localhost")t="localhost";else if(_.split(".").length<=2)t=_;else{const y=e.indexOf(".");n=e.substring(0,y).toLowerCase(),t=e.substring(y+1),i=n}"ns"in d&&(i=d.ns)}return{host:e,port:l,domain:t,subdomain:n,secure:o,scheme:a,pathString:r,namespace:i}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iu{constructor(e,t,n,r){this._repo=e,this._path=t,this._queryParams=n,this._orderByCalled=r}get key(){return ce(this._path)?null:$g(this._path)}get ref(){return new Sr(this._repo,this._path)}get _queryIdentifier(){const e=gC(this._queryParams),t=Mc(e);return t==="{}"?"default":t}get _queryObject(){return gC(this._queryParams)}isEqual(e){if(e=qe(e),!(e instanceof iu))return!1;const t=this._repo===e._repo,n=em(this._path,e._path),r=this._queryIdentifier===e._queryIdentifier;return t&&n&&r}toJSON(){return this.toString()}toString(){return this._repo.toString()+HR(this._path)}}class Sr extends iu{constructor(e,t){super(e,t,new jc,!1)}get parent(){const e=Zg(this._path);return e===null?null:new Sr(this._repo,e)}get root(){let e=this;for(;e.parent!==null;)e=e.parent;return e}}KS(Sr);zS(Sr);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const b0="FIREBASE_DATABASE_EMULATOR_HOST",bl={};let N0=!1;function P0(s,e,t,n,r){let i=n||s.options.databaseURL;i===void 0&&(s.options.projectId||Ss("Can't determine Firebase Database URL. Be sure to include  a Project ID when calling firebase.initializeApp()."),Bt("Using default host for project ",s.options.projectId),i=`${s.options.projectId}-default-rtdb.firebaseio.com`);let o=PC(i,r),a=o.repoInfo,l;typeof process<"u"&&Xf&&(l=Xf[b0]),l?(i=`http://${l}?ns=${a.namespace}`,o=PC(i,r),a=o.repoInfo):o.repoInfo.secure;const c=new CR(s.name,s.options,e);c0("Invalid Firebase Database URL",o),ce(o.path)||Ss("Database URL must point to the root of a Firebase Database (not including a child path).");const h=O0(a,s,c,new fR(s,t));return new L0(h,s)}function F0(s,e){const t=bl[e];(!t||t[s.key]!==s)&&Ss(`Database ${e}(${s.repoInfo_}) has already been deleted.`),w0(s),delete t[s.key]}function O0(s,e,t,n){let r=bl[e.name];r||(r={},bl[e.name]=r);let i=r[s.toURLString()];return i&&Ss("Database initialized multiple times. Please make sure the format of the database URL matches with each database() call."),i=new g0(s,N0,t,n),r[s.toURLString()]=i,i}class L0{constructor(e,t){this._repoInternal=e,this.app=t,this.type="database",this._instanceStarted=!1}get _repo(){return this._instanceStarted||(m0(this._repoInternal,this.app.options.appId,this.app.options.databaseAuthVariableOverride),this._instanceStarted=!0),this._repoInternal}get _root(){return this._rootInternal||(this._rootInternal=new Sr(this._repo,Ee())),this._rootInternal}_delete(){return this._rootInternal!==null&&(F0(this._repo,this.app.name),this._repoInternal=null,this._rootInternal=null),Promise.resolve()}_checkNotDeleted(e){this._rootInternal===null&&Ss("Cannot call "+e+" on a deleted database.")}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function x0(s){Xv(qo),jn(new gn("database",(e,{instanceIdentifier:t})=>{const n=e.getProvider("app").getImmediate(),r=e.getProvider("auth-internal"),i=e.getProvider("app-check-internal");return P0(n,r,i,t)},"PUBLIC").setMultipleInstances(!0)),Mt(Zf,eC,s),Mt(Zf,eC,"esm2020")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */pn.prototype.simpleListen=function(s,e){this.sendRequest("q",{p:s},e)};pn.prototype.echo=function(s,e){this.sendRequest("echo",{d:s},e)};x0();export{lb as A,hb as B,fb as C,z0 as D,QC as a,G0 as b,M0 as c,eb as d,ob as e,U0 as f,V0 as g,Bb as h,KE as i,ab as j,mb as k,rb as l,xT as m,K0 as n,sb as o,Cb as p,tb as q,gb as r,ib as s,W0 as t,db as u,ub as v,nb as w,pb as x,Y0 as y,Q0 as z};
